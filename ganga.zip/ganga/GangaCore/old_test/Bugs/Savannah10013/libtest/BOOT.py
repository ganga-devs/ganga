from GangaCore.Runtime.GPIexport import exportToGPI

exportToGPI('lib_tested_correctly', 1, 'Objects')
