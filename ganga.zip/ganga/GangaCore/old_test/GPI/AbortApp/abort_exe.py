#!/usr/bin/env python

import os
os.abort()
