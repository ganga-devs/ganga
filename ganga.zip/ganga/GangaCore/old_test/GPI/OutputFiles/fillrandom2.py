#!/usr/bin/env python

with open('fillrandom.root', 'w') as wrfile:
    wrfile.write('this is just a test')


with open('fillrandom1.root', 'w') as wrfile1:
    wrfile1.write('this is another a test')


with open('fillrandom2.root', 'w') as wrfile2:
    wrfile2.write('this is another a test')
