#!/usr/bin/env python

with open('fillrandom.root', 'w') as wrfile:
    wrfile.write('this is just a test')


with open('fillrandom1.root', 'w') as wrfile1:
    wrfile1.write('this is another a test')


with open('fillrandom.root1', 'w') as wrfile2:
    wrfile2.write('this is another a test')


with open('fillrandom1.root1', 'w') as wrfile3:
    wrfile3.write('this is another a test')
