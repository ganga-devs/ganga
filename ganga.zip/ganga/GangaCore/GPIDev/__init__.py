"""
GPI development subsystem. Basic definitions for GPI objects and an essential library of plugins.
"""
