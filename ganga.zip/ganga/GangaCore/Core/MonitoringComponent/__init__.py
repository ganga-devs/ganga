monitoring_thread_id = None
