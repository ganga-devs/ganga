"""Package initialisation file"""


__author__ = "Mark Slater <mws@hep.ph.bham.ac.uk>"
__date__ = "10 June 2008"
__version__ = "1.0"

from .Remote import Remote
