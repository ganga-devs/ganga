
from .Merger import RootMerger, TextMerger
