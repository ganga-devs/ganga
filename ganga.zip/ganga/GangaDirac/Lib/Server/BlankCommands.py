

def looper():
    while True:
        pass
    return 23
