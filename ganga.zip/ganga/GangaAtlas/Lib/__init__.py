# File: GangaAtlas/Lib/__init__.py

from ATLASDataset import *
