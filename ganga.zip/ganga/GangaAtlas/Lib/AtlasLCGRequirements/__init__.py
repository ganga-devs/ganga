from AtlasLCGRequirements import *
