"""
DQ2 validation aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: validation.py,v 1.19 2009/10/15 13:06:48 angelos Exp $
"""


import dq2.common.validator.DQValidator
import dq2.info.TiersOfATLASValidator
import dq2.subscription.DQSubscriptionValidator
import dq2.location.DQLocationValidator


from dq2.location.DQLocationConstants import LocationState
from dq2.subscription.DQSubscriptionConstants import SourcesPolicy, SubscriptionArchivedState
from dq2.common.aspects import wrap_around, wrap_around_re


def wrap_package ():
    """
    @since: 0.3.0
    """
    
    wrap_dq2()


def wrap_dq2 ():
    """
    @since: 0.3.0
    """
    
    from dq2.clientapi.DQ2 import DQ2

    wrap_around (DQ2.bulkDeleteDatasetReplicas,  bulkDeleteDatasetReplicas)    
    wrap_around (DQ2.queryStorageUsage,          queryStorageUsage)    
    wrap_around (DQ2.queryStorageUsageHistory,   queryStorageUsageHistory)             
    wrap_around (DQ2.closeDataset, closeDataset)
    wrap_around (DQ2.deleteDatasetReplicas, deleteDatasetReplicas)
    wrap_around (DQ2.deleteDatasetSubscription, deleteDatasetSubscription)
    wrap_around (DQ2.deleteDatasetSubscriptions, deleteDatasetSubscriptions)
    wrap_around (DQ2.deleteDatasetVersionSubscriptions, deleteDatasetVersionSubscriptions)
    wrap_around (DQ2.deleteFilesFromDataset, deleteFilesFromDataset)
    wrap_around (DQ2.eraseDataset, eraseDataset)
    wrap_around (DQ2.freezeDataset, freezeDataset)
    wrap_around (DQ2.getMetaDataAttribute, getMetaDataAttribute)
    wrap_around (DQ2.getNumberOfFiles, getNumberOfFiles)
    wrap_around (DQ2.getState, getState)
    wrap_around (DQ2.listDatasetReplicas, listDatasetReplicas)
    wrap_around (DQ2.listDatasets, listDatasets)
    wrap_around (DQ2.listDatasetsByCreationDate, listDatasetsByCreationDate)
    wrap_around (DQ2.listDatasetsByGUIDs, listDatasetsByGUIDs)
    wrap_around (DQ2.listDatasetsInSite, listDatasetsInSite)
    wrap_around (DQ2.listFileReplicas, listFileReplicas)
    wrap_around (DQ2.listFilesInDataset, listFilesInDataset)
    wrap_around (DQ2.listSubscriptionInfo, listSubscriptionInfo)
    wrap_around (DQ2.listSubscriptionsInSite, listSubscriptionsInSite)
    wrap_around (DQ2.registerDatasetLocation, registerDatasetLocation)
    wrap_around (DQ2.registerDatasetSubscription, registerDatasetSubscription)
    wrap_around (DQ2.registerFilesInDataset, registerFilesInDataset)
    wrap_around (DQ2.registerNewDataset, registerNewDataset)
    wrap_around (DQ2.registerNewVersion, registerNewVersion)
    wrap_around (DQ2.setMetaDataAttribute, setMetaDataAttribute)

    wrap_around (DQ2.getMasterReplicaLocation, getMasterReplicaLocation)
    wrap_around (DQ2.checkDatasetConsistency,  checkDatasetConsistency)
    wrap_around (DQ2.listMetaDataReplica,      listMetaDataReplica)
    wrap_around (DQ2.listDatasetsByNameInSite,      listDatasetsByNameInSite)

    wrap_around (DQ2.listGarbageCollectedReplicas, listGarbageCollectedReplicas)
    wrap_around (DQ2.listDeletedReplicas,          listDeletedReplicas)
    wrap_around (DQ2.listGarbageCollectedFiles,    listGarbageCollectedFiles)
    wrap_around (DQ2.setDatasetReplicaToDeleted,   setDatasetReplicaToDeleted)

def closeDataset (self, dsn):
    """
    @since: 0.3.0
    """
    
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    return self.__proceed(dsn)


def deleteDatasetReplicas (self, dsn, locations, version=0, deep=True):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    dq2.info.TiersOfATLASValidator.is_list_of_sites(locations)
    
    return self.__proceed(dsn, locations, version, deep)


def deleteDatasetSubscription (self, dsn, site, version=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.info.TiersOfATLASValidator.is_site(site)
    
    return self.__proceed(dsn, site, version)


def deleteDatasetSubscriptions (self, dsn):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    return self.__proceed(dsn)


def deleteDatasetVersionSubscriptions (self, dsn, version):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_string([version])
    
    return self.__proceed(dsn, version)


def deleteFilesFromDataset (self, dsn, guids=[]):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_uid(guids)
    
    return self.__proceed(dsn, guids)



def eraseDataset (self, dsn):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    return self.__proceed(dsn)


def freezeDataset (self, dsn):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    return self.__proceed(dsn)


def getMetaDataAttribute (self, dsn, attributes, version=0):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_metadata_attribute(attributes)
    dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, attributes, version)


def listSubscriptionInfo (self, dsn, location, version):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, location, version)


def getNumberOfFiles (self, dsn, version=0):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, version)


def getState (self, dsn):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    return self.__proceed(dsn)


def listDatasetReplicas (self, dsn, version=0, complete=None, old=True):
    """
    @since: 0.3.0
    
    @author: Vincent Garonne
    @contact: vincent.garonne@cern.ch
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    dq2.common.validator.DQValidator.is_boolean([old])
    if complete is not None:
        dq2.location.DQLocationValidator.is_location_state([complete])
    
    return self.__proceed(dsn, version, complete, old)


def listDatasets (self, dsn, version=0, onlyNames=False, p=None, rpp=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, version, onlyNames, p, rpp)


def listDatasetsByCreationDate (self, seconds, criteria, dsn=None, location=None, complete=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_integer([seconds])
    
    if dsn is not None:
        dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    if location is not None:
        dq2.info.TiersOfATLASValidator.is_site(location)
    if complete is not None:
        dq2.location.DQLocationValidator.is_location_state([complete])
    
    return self.__proceed(seconds, criteria, dsn, location, complete)

def listDatasetsByGUIDs (self, guids):
    """
    @since: 0.3.1
    """

    dq2.common.validator.DQValidator.is_uid(guids)
    
    return self.__proceed(guids)

def listDatasetsInSite (self, site, complete=None, page=1, rpp=100):
    """
    @since: 0.3.0
    """
    dq2.info.TiersOfATLASValidator.is_site(site)
    if complete is not None:
        dq2.location.DQLocationValidator.is_location_state([complete])
    
    return self.__proceed(site, complete, page, rpp)

def setReplicaMetaDataAttribute (self, dsn, location, attrname, attrvalue):
    dq2.info.TiersOfATLASValidator.is_site(location)
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.is_string([attrname])
    
    return self.__proceed(dsn, location, attrname, attrvalue)


#def listFileReplicas (self, lfn):
#    """
#    @since: 0.3.0
#    """
#    dq2.common.validator.DQValidator.is_lfn(lfn)
#    
#    return self.__proceed(lfn)


def listFilesInDataset (self, dsn, version=None):
    """
    @since: 0.3.0
    """
    
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    if version is not None:
        dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, version)

def  bulkDeleteDatasetReplicas(self, pattern, locations):
    """
    @since: 0.4.0
    
    @author: Vincent Garonne
    @contact: vincent.garonne@cern.ch
    """
    #dq2.common.validator.DQValidator.has_wildcard([pattern])
    dq2.info.TiersOfATLASValidator.is_list_of_sites(locations)
    
    return self.__proceed(pattern, locations)


def listFileReplicas (self, location, dsn, version=0):
    """
    @since: 0.4.0
    
    @author: Vincent Garonne
    @contact: vincent.garonne@cern.ch
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    dq2.info.TiersOfATLASValidator.is_list_of_sites([location,])
    
    return self.__proceed(location, dsn, version)


def listSubscriptionInfo (self, dsn, site, version=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_integer([version])
    dq2.info.TiersOfATLASValidator.is_destination(site)
    
    return self.__proceed(dsn, site, version)


def listSubscriptions (self, dsn, version=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    
    if version is not None:
        dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, version)


def listSubscriptionsInSite (self, site):
    """
    @since: 0.3.0
    """
    dq2.info.TiersOfATLASValidator.is_destination(site)
    
    return self.__proceed(site)


def registerDatasetLocation (self, dsn, location, version=0, complete=LocationState.INCOMPLETE, group=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.info.TiersOfATLASValidator.is_site(location)
    dq2.location.DQLocationValidator.is_location_state([complete])
    dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, location, version, complete, group)


def registerDatasetSubscription (self, dsn, location, version=0, archived=SubscriptionArchivedState.UNARCHIVE, callbacks={}, sources={}, sources_policy=(SourcesPolicy.COMPLETE_SOURCES | SourcesPolicy.INCOMPLETE_SOURCES), wait_for_sources=0, destination=None, query_more_sources=0, sshare=None, group=None, activity=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.info.TiersOfATLASValidator.is_destination(location)
    dq2.common.validator.DQValidator.is_integer([version])
    dq2.subscription.DQSubscriptionValidator.is_subscription_state([archived])
    for eachSource in sources.keys():
        dq2.info.TiersOfATLASValidator.is_source(eachSource)
    
    return self.__proceed(dsn, location, version, archived, callbacks, sources, sources_policy, wait_for_sources, destination, query_more_sources, sshare, group, activity)


def registerFilesInDataset (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_uid(guids)
    dq2.common.validator.DQValidator.is_lfn(lfns)
    
    for eachSize in sizes:
        if eachSize is not None:
            dq2.common.validator.DQValidator.is_long([eachSize])
    for eachChecksum in checksums:
        if eachChecksum is not None:
            dq2.common.validator.DQValidator.is_md5([eachChecksum])
    
    return self.__proceed(dsn, lfns, guids, sizes, checksums)


def registerNewDataset (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_uid(guids)
    dq2.common.validator.DQValidator.is_lfn(lfns)
    
    for eachSize in sizes:
        if eachSize is not None:
            dq2.common.validator.DQValidator.is_long([eachSize])
    for eachChecksum in checksums:
        if eachChecksum is not None:
            dq2.common.validator.DQValidator.is_md5([eachChecksum])
    
    
    if len(lfns) != len(guids) or len(lfns) != len(sizes) or len(lfns) != len(checksums):
        from dq2.common.DQException import DQInvalidRequestException
        raise DQInvalidRequestException('lfns, guids, sizes and checksums lists must be the same length!')
    
    
    return self.__proceed(dsn, lfns, guids, sizes, checksums)


def registerNewVersion (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_uid(guids)
    dq2.common.validator.DQValidator.is_lfn(lfns)
    
    for eachSize in sizes:
        if eachSize is not None:
            dq2.common.validator.DQValidator.is_long([eachSize])
    for eachChecksum in checksums:
        if eachChecksum is not None:
            dq2.common.validator.DQValidator.is_md5([eachChecksum])
    
    return self.__proceed(dsn, lfns, guids, sizes, checksums)


def resetSubscription (self, dsn, location, version=0):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.info.TiersOfATLASValidator.is_site(location)
    dq2.common.validator.DQValidator.is_integer([version])
    
    return self.__proceed(dsn, location, version)


def resetSubscriptionsInSite (self, site):
    """
    @since: 0.3.0
    """
    dq2.info.TiersOfATLASValidator.is_site(site)
    
    return self.__proceed(site)


def setMetaDataAttribute (self, dsn, attrname, attrvalue):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_or_container_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard([dsn])
    dq2.common.validator.DQValidator.is_string([attrname])
    if not attrname.lower() == 'owner':
        dq2.common.validator.DQValidator.is_metadata_attribute([attrname])
    
    return self.__proceed(dsn, attrname, attrvalue)

def getMasterReplicaLocation(self, dsn, version=0):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.has_wildcard   ([dsn])
    dq2.common.validator.DQValidator.is_integer     ([version])
    
    return self.__proceed(dsn, version)

def checkDatasetConsistency(self,location,dsn, version=0, threshold=None):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.has_wildcard   ([dsn])
    dq2.common.validator.DQValidator.is_integer     ([version])
    dq2.info.TiersOfATLASValidator.is_site         (location)        
    
    return self.__proceed(location,dsn, version, threshold)

def listMetaDataReplica(self, location, dsn, version=0):
    """
    @since: 0.3.0
    """
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.common.validator.DQValidator.has_wildcard   ([dsn])
    dq2.common.validator.DQValidator.is_integer     ([version])
    dq2.info.TiersOfATLASValidator.is_site          (location)
    
    return self.__proceed(location, dsn, version)
    
def listDatasetsByNameInSite(self, site, complete=None, name=None, p=None, rpp=None, group=None):
    """
    @since: 0.3.0
    """
    dq2.info.TiersOfATLASValidator.is_site          (site)    
    if complete is not None:
	    dq2.location.DQLocationValidator.is_location_state([complete])    
    return self.__proceed(site, complete, name, p, rpp, group)

    
def listGarbageCollectedReplicas (self,  location, name=None, p=None, rpp=None):

    dq2.info.TiersOfATLASValidator.is_site          (location)    
    return self.__proceed(location, name, p, rpp)

def listDeletedReplicas (self,  location, name=None, p=None, rpp=None):

    dq2.info.TiersOfATLASValidator.is_site          (location)    
    return self.__proceed(location, name, p, rpp)

def listGarbageCollectedFiles (self, dsn, location):

    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    dq2.info.TiersOfATLASValidator.is_site          (location)    
    return self.__proceed(dsn, location)
	   	    
def setDatasetReplicaToDeleted (self, dsn, location):

    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    return self.__proceed(dsn, location)
    
def listDatasetReplicasInContainer (self, cn):
    dq2.common.validator.DQValidator.is_container_name([cn])
    return self.__proceed(cn)
               
def listFileReplicasBySites (self, dsn, version=0, locations=[], threshold=None, timeout=None):
    dq2.common.validator.DQValidator.is_dataset_name([dsn])
    return self.__proceed(dsn, version, locations, threshold, timeout)

def queryStorageUsage (self, key=None, value=None, site=None, metaDataAttributes={}, locations=[]):

    return self.__proceed(key, value, site, metaDataAttributes, locations) 

def queryStorageUsageHistory (self, site, key='GRID', value='total'):

    return self.__proceed(site, key, value)  

def queryReplicaHistory (self, dsn, location):

    return self.__proceed(dsn, location)