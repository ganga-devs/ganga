"""
Client transaction aspects.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: transaction.py,v 1.5 2009/10/15 13:06:48 angelos Exp $
"""


from dq2.common.aspects import wrap_around, wrap_around_re


def wrap_package ():
    """
    @since: 0.3.0
    """
    from dq2.clientapi.DQ2 import DQ2
    from dq2.common.dao.aspects.transaction import start_and_end, start_and_commit
    
    
    # DQ2 should pass its TUID to the catalogs clients
    wrap_around (DQ2.closeDataset, pass_tuid_to_clients)
    wrap_around_re (DQ2, '(delete.*)', pass_tuid_to_clients)
    
    wrap_around (DQ2.eraseDataset, pass_tuid_to_clients)
    wrap_around (DQ2.freezeDataset, pass_tuid_to_clients)
    
    wrap_around_re (DQ2, '(get.*)', pass_tuid_to_clients)
    
    wrap_around_re (DQ2, '(list.*)', pass_tuid_to_clients)
    
    wrap_around_re (DQ2, '(register.*)', pass_tuid_to_clients)
    
    wrap_around (DQ2.setMetaDataAttribute, pass_tuid_to_clients)
    
    wrap_around (DQ2.checkDatasetConsistency,  pass_tuid_to_clients)
    
    # DQ2 methods should be wrapped in a transaction
    wrap_around (DQ2.closeDataset, start_and_commit)
    wrap_around_re (DQ2, '(delete.*)', start_and_commit)
    
    wrap_around (DQ2.eraseDataset, start_and_commit)
    wrap_around (DQ2.freezeDataset, start_and_commit)
    
    wrap_around_re (DQ2, '(get.*)', start_and_end)
    
    wrap_around_re (DQ2, '(list.*)', start_and_end)
    
    wrap_around_re (DQ2, '(register.*)', start_and_commit)

    wrap_around_re (DQ2, '(bulk.*)', start_and_commit)
    
    wrap_around (DQ2.setMetaDataAttribute,     start_and_commit)
    wrap_around (DQ2.checkDatasetConsistency,  start_and_commit)
    wrap_around (DQ2.queryStorageUsage,  start_and_commit)

    


def pass_tuid_to_clients (self, *args, **kwargs):
    """
    Sets the central catalogs with the DQ2 transaction unique identifier (tuid).
    
    @since: 0.3.0
    """
    self.contentClient.tuid = self.tuid
    self.locationClient.tuid = self.tuid
    self.repositoryClient.tuid = self.tuid
    self.subscriptionClient.tuid = self.tuid
    
    return self.__proceed(*args, **kwargs)
