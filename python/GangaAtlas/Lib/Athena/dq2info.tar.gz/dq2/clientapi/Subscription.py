"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: Subscription.py,v 1.1 2008/02/04 14:37:14 psalgado Exp $
"""

from dq2.common.python.uuid import uuid4


from dq2.subscription.DQSubscriptionConstants import CallbackType, SourcesPolicy, SourceResolverPolicy, SubscriptionArchivedState
from dq2.subscription.DQSubscriptionException import *
from dq2.subscription.client.SubscriptionClient import SubscriptionClient


class Subscription (object):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.1 $
    """


    def deleteDatasetSubscription (self, dsn, site, version=None):
        """
        Removes the dataset/dataset version subscription of the given dataset name from the given site.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param site: is the subscription dq2.location.
        @param version: is the dataset version number (None is passed the duid will be used).
        
        B{Exceptions}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        if version is None or version == 0:
            """delete subscription to duid"""
            
            # may raise DQUnknownDatasetException
            duid = self.repositoryClient.resolveName(dsn)['duid']
            self.subscriptionClient.deleteDatasetSubscription(duid, site)
            
        else:
            """delete subscription to vuid"""
            
            # {'dataset_nameA': {'vuids': ['A_vuid_for_versionX']}}
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            if len(dataset) == 0:
                raise DQUnknownDatasetException(dsn=dsn)
            
            dataset = dict_get_item(dataset, dsn)
            
            # vuids will always be a list
            vuid = dataset['vuids'][0]
            
            self.subscriptionClient.deleteDatasetSubscription(vuid, site)


    def deleteDatasetSubscriptions (self, dsn):
        """
        Marks all dataset/dataset version subscriptions of the given dataset.
        
        (since 0.2.1)
        
        @param dsn: is the dataset name.
        
        B{Exceptions}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        # may raise DQUnknownDatasetException
        duid = self.repositoryClient.resolveName(dsn)['duid']
        # {'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
        dataset = self.repositoryClient.queryDatasetByName(dsn, -1)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn)
        
        dataset = dict_get_item(dataset, dsn)
        
        duid_and_vuids = dataset['vuids']
        duid_and_vuids.append(dataset['duid'])
        
        self.subscriptionClient.deleteDatasetSubscriptions(duid_and_vuids)


    def deleteDatasetVersionSubscriptions (self, dsn, version):
        """
        Removes all subscriptions of the given dataset version.
        
        @since: 0.2.1
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number
            (
            0 only of the latest version,
            -1 all dataset versions - NOT of the duid -,
            >0 only of the specific version
            ).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        # {'dataset_nameA': ['A_vuid_for_versionX']}
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        dataset = dict_get_item(dataset, dsn)
        
        if not len(dataset) > 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        # vuids will always be a list
        vuid = dataset['vuids'][0]
        self.subscriptionClient.deleteDatasetSubscriptions(vuid)


    def listSubscriptionInfo (self, dsn, location, version):
        """
        (since 0.2.11)
        """
        
        if version is not None and version > 0:
            """querying by vuid"""
            dict = self.repositoryClient.queryDatasetByName(dsn, version)
            dataset = dict_get_item(dict, dsn)
            uid = dataset['vuids'][0]
        else:
            """querying by duid [latest version always]"""
            uid = self.repositoryClient.resolveName(dsn)['duid']
        
        return self.subscriptionClient.getInfo(uid, location)


    def listSubscriptions (self, dsn, version=None, archived=SubscriptionArchivedState.__ANY__):
        """
        Return a list of sites that have subscribed the given dataset.
        
        (since 0.2.11)
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number (0 is the latest).
        @param archived: is the dataset subscription state.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: List containing the sites that subscribed, at least, a version of the dataset.
        """
        
        if version is not None and version > 0:
            """querying by vuid"""
            
            output = self.repositoryClient.queryDatasetByName(dsn, version)
            
            if len(output) == 0:
                raise DQUnknownDatasetException(dsn)
            
            output = dict_get_item(output, dsn)
            uids = [output['vuids'][0]]
            
        else:
            """querying by duid and vuids"""
            output = self.repositoryClient.queryDatasetByName(dsn)
            
            if len(output) == 0:
                raise DQUnknownDatasetException(dsn)
            
            output = dict_get_item(output, dsn)
            
            uids = output['vuids']
            uids.append(output['duid'])
        
        output = self.subscriptionClient.querySubscriptions(uids)
        
        return output.keys()


    def listSubscriptionsInSite (self, site):
        """
        Returns a dict of all subscribed uids in a site containing all attributes.
        
        @since: 0.2.0
        
        @param site: is the dataset subscription dq2.location.
        @param archived: is the dataset subscription state.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: Returns a list of all subscribed uids in a site containing all attributes.
            {'dsn': [versionX, versionY]}
        """
        tmp = self.subscriptionClient.querySubscriptionsInSite(site)
        
        if len(tmp.keys()) == 0:
            return {}
        
        dsets = []
        for ds in tmp:
            dsets.append(ds)
         
        ds_subscriptions = self.repositoryClient.queryDatasetByDUIDs(dsets)
        vs_subscriptions =  self.repositoryClient.queryDatasetByVUIDs(dsets)
        
        for eachDataset in vs_subscriptions:
            if ds_subscriptions.has_key(eachDataset):
                ds_subscriptions[eachDataset].append(vs_subscriptions[eachDataset])
            else:
                ds_subscriptions[eachDataset] = vs_subscriptions[eachDataset]
        
        return ds_subscriptions


    def registerDatasetSubscription (self, dsn, location, version=0, archived=SubscriptionArchivedState.UNARCHIVE, callbacks={}, sources={}, sources_policy=(SourcesPolicy.COMPLETE_SOURCES | SourcesPolicy.INCOMPLETE_SOURCES), wait_for_sources=0, destination=None, query_more_sources=0, sshare=None):
        """
        Register a new subscription in the location catalog. If the
        version is not specified a duid is used.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param location: is the location where the dataset should be subscribed.
        @param version: is the dataset version number.
        @param archive: is the subscription state (dq2.common.DQConstants.SubscriptionArchivedState).
            is a bit indicating the archival bit for the dq2.subscription.
            Archival subscriptions are never deleted by the cache turnover
            service, while non-archival data may be deleted if the destination
            storage becomes full at some point. Possible values are
            SubscriptionArchivedState.ARCHIVE or SubscriptionArchivedState.UNARCHIVE.
        @param callbacks: is a dictionary which specifies, per subscription callback
            state, the list of HTTP URLs that should be triggered when the event
            occurs. e.g.::
                callbacks = {
                    CallbackType['FETCHER_VUID_COMPLETE']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_SKIP_VUID']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_FILE_NOT_QUEUED']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_FILES_QUEUED']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_UNKNOWN_DATASET']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FILE_PROPERTY_SET']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FILE_DONE']:
                        ['http://localhost:7777/monitor']
                }
        @param sources: is a dictionary indicating known sources for the
        @param subscription: and the strategy to look them up: either by doing a LRC
            lookup at the source, or by directly specifying a URL, e.g.::
                sources = {
                    'CERN'  : { 'policy': SourceResolverPolicy.LRC_LOOKUP },
                    'RAL'   : { 'policy' : SourceResolverPolicy.RELATIVE_SURL,
                    'rsurl' : 'srm://ral.uk/some/data/here/' }
                }
        @param sources_policy: may be one of dq2.common.DQConstants.SourcesPolicy.(ALL_SOURCES | KNOWN_SOURCES | CLOSE_SOURCES | COMPLETE_SOURCES | INCOMPLETE_SOURCES).
            This triggers the subscription services to change the strategy used
            for finding source replicas.
            KNOWN_SOURCES is required if 'sources' is specified as part of the dq2.subscription.
            It is possible to specify cumulative strategies: e.g.
            source_policy=SourcesPolicy.KNOWN_SOURCES | SourcesPolicy.COMPLETE_SOURCES
            will look for sources in the sites specified as part of the 'sources' field
            in the subscription, as well as in all sites known to have complete copies of the dataset.
        @param wait_for_sources: is a bit (True/False) indicating whether the subscription services
            should keep retrying to fulfill the subscription even if the sources files are missing.
            If True, subscription will not go to HOLD states even if sources are missing.
        @param destination: is a relative SURL where the destination files should be
            placed within the destination storage (e.g. '/my/path/').
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQSubscriptionExistsException is raised,
                in case there is a subscription for this uid-dq2.location.
            - DQUnknownDatasetException is raised,
                in case the given dataset name doesn't exist.
            - DQUnknownDatasetVersionException is raised,
                in case the given version number doesn't exist for the given dataset.
        """
        uid = None
        # get the required vuid or duid => register the duid
        if version == 0:
            """registering version 0 is the same as registering the dataset (uid=duid)."""
            # if dataset doesn't exist it will throw a DQUnknownDatasetException
            duid = self.repositoryClient.resolveName(dsn)['duid']
            uid = duid
            
        else:
            """registering a specific dataset version (uid=vuid)."""
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            # WARNING: central catalog result may have a different case -> use dict_get_item
            # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
            dataset = dict_get_item(dataset, dsn)
            
            if len(dataset) == 0:
                """
                if dataset doesn't exist resolveName will throw a DQUnknownDatasetException
                if not then the dataset exists but the given version no => DQUnknowDatasetVersionException
                """
                self.repositoryClient.resolveName(dsn)
                raise DQUnknownDatasetVersionException(dsn, version)
            
            uid = dataset['vuids'][0]
        
        # register in subscription catalog
        self.subscriptionClient.addDatasetSubscription(
            uid, location, archived=archived, callbacks=callbacks, sources=sources, sources_policy=sources_policy, wait_for_sources=wait_for_sources, destination=destination, query_more_sources=query_more_sources, sshare=sshare
        )


    def resetSubscription (self, dsn, location, version=0):
        """
        Reset the dataset subscription registered at the given dq2.location.
        
        @since: 0.3.0
        
        @param dsn: is the dataset name.
        @param location: is the location where the dataset is subscribed.
        @param version: is the dataset version number.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the given dataset name doesn't exist.
            - DQUnknownDatasetVersionException is raised,
                in case the given version number doesn't exist for the given dataset.
            - DQUnknownSubscriptionException is raised,
                in case there are no subscriptions at the given site.
        """
        uid = None
        # get the required vuid or duid => register the duid
        if version == 0:
            """registering version 0 is the same as registering the dataset (uid=duid)."""
            # if dataset doesn't exist it will throw a DQUnknownDatasetException
            # but we have to handle it manually because a TypeError will precede it
            try:
                duid = self.repositoryClient.resolveName(dsn)['duid']
            except TypeError, e:
                raise DQUnknownDatasetException(dsn, version)
            uid = duid
            
        else:
            """registering a specific dataset version (uid=vuid)."""
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            # WARNING: central catalog result may have a different case -> use dict_get_item
            # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
            dataset = dict_get_item(dataset, dsn)
            
            if len(dataset) == 0:
                """
                if dataset doesn't exist resolveName will throw a DQUnknownDatasetException
                if not then the dataset exists but the given version no => DQUnknowDatasetVersionException
                """
                self.repositoryClient.resolveName(dsn)
                raise DQUnknownDatasetVersionException(dsn, version)
            
            uid = dataset['vuids'][0]
        
        self.subscriptionClient.reset(uid, location)


    def resetSubscriptionsInSite (self, site):
        """
        Resets the subscriptions registered in the given site.
        
        @since: 0.3.0
        
        @param site: is the dataset subscription dq2.location.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownSubscriptionException is raised,
                in case there are no subscriptions at the given site.
        """
        
        subscriptions = self.subscriptionClient.querySubscriptionsInSite(site)
        
        if len(subscriptions) <= 0:
            """ there are no subscriptions at the given site """
            raise DQUnknownSubscriptionException('', site)
        
        for eachUID in subscriptions.keys():
            self.subscriptionClient.reset(eachUID, site)