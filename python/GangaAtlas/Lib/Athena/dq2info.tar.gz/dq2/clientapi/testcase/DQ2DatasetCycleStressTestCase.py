"""
DQ2 stress test for dataset cycle.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQ2DatasetCycleStressTestCase.py,v 1.2 2009/10/15 13:06:48 angelos Exp $
"""


import Queue


from dq2.common.testcase.DQTestCase import DQTestCase
from dq2.common.threadpool import ThreadPool


NTHREADS = 1


class DQ2DatasetCycleStressTestCase (DQTestCase):
    """
    @since: 0.3.0
    """


    def __init__ (self, name, instance):
        """
        @since: 0.3.0
        """
        DQTestCase.__init__(self, name)


    def generateUUID (self):
        """"@since: 0.3.0"""
        pass

    generateUUID = staticmethod(generateUUID)


    def getUUID (self):
        """"@since: 0.3.0"""
        pass

    getUUID = staticmethod(getUUID)


    def setUp (self):
        """
        @since: 0.3.0
        """
        pass


    def slave ():
        """
        @since: 0.3.0
        """
        dq2 = DQ2()


    def testDatasetCycle (self):
        """
        @since: 0.3.0
        """
        
        threads = ThreadPool(NTHREADS)
        
        print 'spawning threads...'
        for i in range(NTHREADS):
            try:
                req = WorkRequest(slave, None, None, callback=None)
                threads.putRequest(req)
            except:
                pass
        threads.wait()