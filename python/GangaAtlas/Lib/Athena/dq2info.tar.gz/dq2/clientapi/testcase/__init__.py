"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2.0
@version: $Id: __init__.py,v 1.3 2009/10/15 13:06:48 angelos Exp $
"""