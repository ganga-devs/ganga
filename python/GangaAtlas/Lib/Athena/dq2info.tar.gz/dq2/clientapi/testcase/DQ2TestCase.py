"""
A series of tests to make sure DQ2 and the catalogs are working ok.

TODO list:
- test add a dataset subscription to a non-existing dataset version => DQUnknownDatasetVersionException. 

+ add this test
python LocationClient.py addDatasetReplica -i vuid_1 site_1 psalgado_1
None
python LocationClient.py queryDatasetsInSite -c site_1
{}
python LocationClient.py queryDatasetsInSite -i site_1
{'psalgado_1': ['vuid_1']}
python LocationClient.py addDatasetReplica vuid_1 site_1 psalgado_1
Error: The dataset vuid_1 already exists at location site_1!
python LocationClient.py addDatasetReplica -i vuid_1 site_1 psalgado_1
Error: The dataset vuid_1 already exists at location site_1!
python LocationClient.py addDatasetReplica -c vuid_1 site_1 psalgado_1
None
python LocationClient.py queryDatasetsInSite -c site_1
{'psalgado_1': ['vuid_1']}
python LocationClient.py queryDatasetsInSite -i site_1
{}

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: DQ2TestCase.py,v 1.11 2009/10/15 13:06:48 angelos Exp $
"""


import commands
import sys
import os


from dq2.clientapi.DQ2 import DQ2

from dq2.common.DQConstants import DatasetState, DateCriteria, Metadata, TestCaseData
from dq2.common.DQException import *
from dq2.common.testcase.DQTestCase import DQTestCase

from dq2.content.DQContentException import *

from dq2.location.DQLocationException import *
from dq2.location.DQLocationConstants import LocationState

from dq2.repository.DQRepositoryException import *

from dq2.subscription.DQSubscriptionConstants import SubscriptionArchivedState
from dq2.subscription.DQSubscriptionException import *


TestCaseData.LFNS.sort()
TestCaseData.GUIDS.sort()

import dq2.info.TiersOfATLAS
DESTINATIONS = []
SOURCES = []
ds = dq2.info.TiersOfATLAS.getAllDestinationSites()
for d in ds:
    DESTINATIONS.append('MOCKTESTCASE_'+ d)
DESTINATIONS.sort()
ss = dq2.info.TiersOfATLAS.getAllSources()
for s in ss:
    SOURCES.append('MOCKTESTCASE_'+ s)
SOURCES.sort()


class DQ2TestCase (DQTestCase):
    """
    Testcase for the dq2.clientapi.DQ2 module.
    
    @since: 0.2.0
    """


    def __init__ (self, name):
        """
        Constructs an instance of DQ2TestCase.
        
        (since 0.2.1)
        
        name is the testcase name.
        """
        DQTestCase.__init__(self, name)
        
        self.dq2 = DQ2()


    def _cleanup_database (self):
        """
        
        @since: 0.3.0
        """
        for dsn in TestCaseData.DSNS:
            try:
                self.dq2.eraseDataset(dsn)
            except DQUnknownDatasetException: pass
            except DQDatasetOwnershipException: pass
            try:
                self.dq2.repositoryClient.trashDataset(dsn)
            except:
                pass


# PUBLIC methods


    def setUp (self):
        """
        
        @since: 0.2.0
        """
        self._cleanup_database()


    def tearDown (self):
        """
        
        @since: 0.2.0
        """
        self._cleanup_database()
        del self.dq2


    def testBug19018 (self):
        """
        bug #19018 overview: dq2 client crashed.
        
        https://savannah.cern.ch/bugs/?func=detailitem&item_id=19018
        """
        
        self.dq2.registerNewDataset(TestCaseData.DSNS[3], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        
        # 1. bug #19018
        self.assertRaises(DQUnknownDatasetException,
                          self.dq2.listDatasetReplicas,
                          TestCaseData.DSNS[4])


    def testCompleteness (self):
        """
        
        @since: 0.2.0
        """
        r = self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                        TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0], complete=LocationState.INCOMPLETE)
        self.dq2.freezeDataset(TestCaseData.DSNS[0])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[1], complete=LocationState.COMPLETE)
        
        expected = {0: [SOURCES[0]], 1: []}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], complete=LocationState.INCOMPLETE)[r['vuid']]
        self.assertEqual(expected, result)
        
        expected = {0: [], 1: [SOURCES[1]]}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], complete=LocationState.COMPLETE)[r['vuid']]
        self.assertEqual(expected, result)


    def testDatasetState (self):
        """
        
        # 1. registered dataset state
        # 2. closed dataset state
        """
        
        
        # 1. registered dataset state
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        
        result = self.dq2.getState(TestCaseData.DSNS[0])
        expected = DatasetState.OPEN
        
        self.assertEqual(expected, result, self._fmt_message('1. registered dataset state', expected, result))
        
        
        # 2. closed dataset state
        
        self.dq2.closeDataset(TestCaseData.DSNS[0])
        
        result = self.dq2.getState(TestCaseData.DSNS[0])
        expected = DatasetState.CLOSED
        
        self.assertEqual(expected, result, self._fmt_message('2. closed dataset state', expected, result))
        
        self.assertRaises(DQClosedDatasetException,
                          self.dq2.registerFilesInDataset,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.assertRaises(DQClosedDatasetException,
                          self.dq2.closeDataset,
                          TestCaseData.DSNS[0])
        
        
        # 3. frozen dataset state
        
        self.dq2.freezeDataset(TestCaseData.DSNS[0])
        
        result = self.dq2.getState(TestCaseData.DSNS[0])
        expected = DatasetState.FROZEN
        
        self.assertEqual(expected, result, self._fmt_message('3. frozen dataset state', expected, result))
        
        self.assertRaises(DQFrozenDatasetException,
                          self.dq2.registerFilesInDataset,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1])
        self.assertRaises(DQFrozenDatasetException,
                          self.dq2.closeDataset,
                          TestCaseData.DSNS[0])
        self.assertRaises(DQFrozenDatasetException,
                          self.dq2.freezeDataset,
                          TestCaseData.DSNS[0])


    def testDeleteDatasetReplica (self):
        """
        
        @since: 0.2.0
        """
        r = self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                        TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        # registers an incomplete dataset replica
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0])
        # registers another incomplete dataset replica
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[1])
        self.dq2.deleteDatasetReplicas(TestCaseData.DSNS[0], [SOURCES[0]])
        
        # 1.
        expected = {0: [SOURCES[1]], 1: []}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])[r['vuid']]
        self.assertEqual(expected, result, self._fmt_message('1.', expected, result))
        self.dq2.deleteDatasetReplicas(TestCaseData.DSNS[0], [SOURCES[1]])
        
        # 2.
        expected = {}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])
        self.assertEqual(expected, result, self._fmt_message('2.', expected, result))


    def testEraseDataset (self):
        """
        
        @since: 0.2.0
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[1])
        self.dq2.eraseDataset(TestCaseData.DSNS[0])
        self.assertEqual(self.dq2.listDatasets(TestCaseData.DSNS[0]), {})


    def testFileOperationsInDataset (self):
        """
        Tests addind and removing files from a dataset.
        
        (since 0.2.1)
        """
        
        # 1. register new dataset
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:2], TestCaseData.GUIDS[0:2],
                                    TestCaseData.SIZES[0:2], TestCaseData.CHECKSUMS[0:2])
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])[0]
        
        # 1.1
        result = dsfiles.keys()
        result.sort()
        
        expected = TestCaseData.GUIDS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message('1.1', expected, result))
        
        # 1.2
        result = []
        for eachDict in dsfiles.keys():
            result.append(dsfiles[eachDict]['lfn'])
        result.sort()
        
        expected = TestCaseData.LFNS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message('1.2', expected, result))
        
        
        # 2. trying to insert duplicate LFN on the same dataset
        # 2.1
        try:
            self.dq2.registerFilesInDataset(
                TestCaseData.DSNS[0],
                [TestCaseData.LFNS[0]],
                [TestCaseData.GUIDS[1]],
                [TestCaseData.SIZES[0]],
                [TestCaseData.CHECKSUMS[0]]
            )
        except:
            self.fail('cannot raise an exception!')
        
        
        # 3. delete files from dataset
        self.dq2.deleteFilesFromDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]])
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])[0]
        
        # 3.1 checking if GUID was deleted
        result = dsfiles.keys()
        result.sort()
        
        expected = [TestCaseData.GUIDS[1]]
        
        self.assertEqual(expected, result, self._fmt_message('3.1', expected, result))
        
        # 3.2 checking if LFN was deleted
        result = dsfiles[TestCaseData.GUIDS[1]]['lfn']
        expected = TestCaseData.LFNS[1]
        
        self.assertEqual(expected, result, self._fmt_message('3.2', expected, result))
        
        
        # x. register new dataset version
        self.dq2.registerNewVersion(TestCaseData.DSNS[0], [TestCaseData.LFNS[0]], [TestCaseData.GUIDS[0]],
                                    [TestCaseData.SIZES[0]], [TestCaseData.CHECKSUMS[0]])
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])[0]
        
        # x.1
        result = dsfiles.keys()
        result.sort()
        
        expected = TestCaseData.GUIDS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message('x.1', expected, result))
        
        # x.2
        result = []
        for eachDict in dsfiles.keys():
            result.append(dsfiles[eachDict]['lfn'])
        result.sort()
        
        expected = TestCaseData.LFNS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message('x.2', expected, result))


    def testGetNumberOfFiles (self):
        """
        
        (since 0.2.5)
        
        # 1. register dataset sets the number of files correctly?
        # 2. register files in dataset sets the number of files correctly?
        # 3. update dataset version sets the number of files correctly? TODO
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        
        # 1. register dataset sets the number of files correctly?
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 1
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('1.1 register dataset sets the number of files correctly?', expected, result)
        )
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 1
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('1.2 register dataset sets the number of files correctly?', expected, result)
        )
        
        
        # 2. register files in dataset sets the number of files correctly?
        # 2.1 whole dataset
        self.dq2.registerFilesInDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2],
                                        TestCaseData.SIZES[1:2], TestCaseData.CHECKSUMS[1:2])
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 2
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('2.1 register files in dataset sets the number of files correctly?', expected, result)
        )
        
        # 2.2 last version - should be the same as the whole dataset
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], 0)
        expected = 2
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('2.2 register files in dataset sets the number of files correctly?', expected, result)
        )
        
        
        # 3. update dataset version sets the number of files correctly?
        self.dq2.tuid = 'dq2test0-0000-0000-0000-000000000000'
        # 3.1 whole dataset
        self.dq2.registerNewVersion(TestCaseData.DSNS[0],TestCaseData.LFNS[2:3], TestCaseData.GUIDS[2:3],
                                    TestCaseData.SIZES[2:3],TestCaseData.CHECKSUMS[2:3])
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 3
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('3.1 update dataset version sets the number of files correctly?', expected, result)
        )
        
        # 3.2 last version
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], 0)
        expected = 3
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('3.2 update dataset version sets the number of files correctly?', expected, result)
        )
        
        # 3.3 specific version
        # 3.3.1 version 1
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], 1)
        expected = 2
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('3.3.1 update dataset version sets the number of files correctly?', expected, result)
        )
        
        # 3.3.2 version 2
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], 2)
        expected = 3
        
        self.assertEqual(
            expected,
            result,
            self._fmt_message('3.3.2 update dataset version sets the number of files correctly?', expected, result)
        )
        
        
        # 4. user specified a version greater than the one existing on the central catalogs
        self.assertRaises(
            DQInvalidRequestException,
            self.dq2.getNumberOfFiles,
            TestCaseData.DSNS[0],
            3000
        )


    def __testListDatasetsByCreationDate (self):
        """
        
        @since: 0.3.0
        
        # 1. querying all dataset versions older than today (inclusive) but with no datasets
        # 2. querying all dataset versions registered today
        # 2.1 complete only
        # 2.2 incomplete only
        # 3. querying all dataset versions registered between today-1 and today (inclusive)
        # 4.1 querying all dataset versions registered newer than today-1 (exclusive)
        # 4.2 querying all dataset versions registered newer than today (exclusive)
        # 5. querying all dataset versions older than today (inclusive)
        # 6. querying all dataset versions older later than today (exclusive)
        # 7. querying all dataset versions registered between today-1 and today (inclusive) in site
        # 8. querying all complete dataset versions registered between today-1 and today (inclusive)
        
        listDatasetsByCreationDate (self, seconds, criteria, dsn=None, location=None, complete=None)
        """
        
        # 1. querying all dataset versions older than today (inclusive) but with no datasets
        result = self.dq2.listDatasetsByCreationDate(1, DateCriteria.LEQ)
        expected = {}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('1. querying all dataset versions older than today (inclusive) but with no datasets', expected, result)
        )
        
        dataset_01 = self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                                 TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0], complete=LocationState.INCOMPLETE)
        
        
        vuid_01 = dataset_01['vuid']
        duid_01 = dataset_01['duid']
        
        # 2. querying all dataset versions registered today
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.EQ)
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('2. querying all dataset versions registered today', expected, result)
        )
        
        # 2.1 at site but only complete
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.LEQ, location=SOURCES[0], complete=LocationState.COMPLETE)
        expected = {}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('2.1 complete only', expected, result)
        )
        
        # 2.2 at site but only incomplete
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.LEQ, location=SOURCES[0], complete=LocationState.INCOMPLETE)
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('2.2 incomplete only', expected, result)
        )
        
        # 2.3 at site
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.LEQ, location=SOURCES[0])
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('2.3.1 at registered site', expected, result)
        )
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.LEQ, location=SOURCES[1])
        expected = {}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('2.3.2 at not registered site', expected, result)
        )
        
        # 3. querying all dataset versions registered between today-1 and today (inclusive)
        result = self.dq2.listDatasetsByCreationDate(1, DateCriteria.LEQ)
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('3. querying all dataset versions registered between today-1 and today', expected, result)
        )
        
        # 4.1 querying all dataset versions registered newer than today-1 (exclusive)
        result = self.dq2.listDatasetsByCreationDate(1, DateCriteria.LT)
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('4.1 querying all dataset versions registered newer than today-1 (exclusive)', expected, result)
        )
        
        # 4.2 querying all dataset versions registered newer than today (exclusive)
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.LT)
        expected = {}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('4.2 querying all dataset versions registered newer than today (exclusive)', expected, result)
        )
        
        # 5. querying all dataset versions older than today (inclusive)
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.GEQ)
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('5. querying all dataset versions registered later than today-1 (inclusive)', expected, result)
        )
        
        # 6. querying all dataset versions older later than today (exclusive)
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.GT)
        expected = {}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('6. querying all dataset versions registered later than today-1 (exclusive)', expected, result)
        )
        
        # 7. querying all dataset versions registered between today-1 and today (inclusive) in site
        result = self.dq2.listDatasetsByCreationDate(0, DateCriteria.LEQ, location=SOURCES[0])
        expected = {TestCaseData.DSNS[0]: [vuid_01]}
        
        self.assertEqual(
            expected, result,
            self._fmt_message('7. querying all dataset versions registered between today-1 and today (inclusive) in site', expected, result)
        )


    def testListDatasetsByMetaData (self):
        """
        Tests dq2.clientapi.DQ2.listDatasetsByMetaData method.
        
        @since: 0.3.0
        
        # 1. listDatasetsByMetaData with no datasets
        # 2.1 listDatasetsByMetaData by metadata with no dataset
        # 2.2 listDatasetsByMetaData by metadata with datasets
        # 2.3 listDatasetsByMetaData by 2 metadata with no datasets
        # 2.4 listDatasetsByMetaData by 2 metadata with datasets
        """
        value = 'abc'
        no_data = '-no_data-'
        
        # 1. listDatasetsByMetaData with no datasets
        result = self.dq2.listDatasetsByMetaData({Metadata.USER_VERSION[0]: value})
        expected = []
        self.assertEqual(result, expected, self._fmt_message('1. listDatasetsByMetaData with no datasets', expected, result))
        
        
        vuid_dict = self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                                TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.setMetaDataAttribute(TestCaseData.DSNS[0], Metadata.USER_VERSION[0], value)
        self.dq2.setMetaDataAttribute(TestCaseData.DSNS[0], Metadata.USER_VERSION[1], value)
        vuid = vuid_dict['vuid']
        
        # 2.1 listDatasetsByMetaData by metadata value with no dataset
        result = self.dq2.listDatasetsByMetaData({Metadata.USER_VERSION[0]: no_data})
        expected = []
        self.assertEqual(result, expected, self._fmt_message('2.1 listDatasetsByMetaData by metadata with no dataset', expected, result))
        
        # 2.2 listDatasetsByMetaData by metadata value with datasets
        result = self.dq2.listDatasetsByMetaData({Metadata.USER_VERSION[0]: value})
        expected = [TestCaseData.DSNS[0]]
        self.assertEqual(result, expected, self._fmt_message('2.2 listDatasetsByMetaData by metadata with datasets', expected, result))
        
        # 2.3 listDatasetsByMetaData by 2 metadata with no datasets
        result = self.dq2.listDatasetsByMetaData({Metadata.USER_VERSION[0]: value, Metadata.USER_VERSION[1]: no_data})
        expected = []
        self.assertEqual(result, expected, self._fmt_message('2.3.1 listDatasetsByMetaData by 2 metadata with no datasets', expected, result))
        
        result = self.dq2.listDatasetsByMetaData({Metadata.USER_VERSION[0]: no_data, Metadata.USER_VERSION[1]: value})
        expected = []
        self.assertEqual(result, expected, self._fmt_message('2.3.2 listDatasetsByMetaData by 2 metadata with no datasets', expected, result))
        
        # 2.4 listDatasetsByMetaData by 2 metadata with datasets
        result = self.dq2.listDatasetsByMetaData({Metadata.USER_VERSION[0]: value, Metadata.USER_VERSION[1]: value})
        expected = [TestCaseData.DSNS[0]]
        self.assertEqual(result, expected, self._fmt_message('2.4 listDatasetsByMetaData by 2 metadata fields with datasets', expected, result))


    def testListDatasetReplicas (self):
        """
        Tests dq2.clientapi.DQ2.listDatasetReplicas method.
        
        @since: 0.2.0
        """
        r = self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                        TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[1])
        
        expected = {LocationState.INCOMPLETE: SOURCES[0:2], LocationState.COMPLETE: []}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])[r['vuid']]
        
        self.assertEqual(result, expected)


    def testListDatasets (self):
        """
        Tests dq2.clientapi.DQ2.listDatasets method.
        
        @since: 0.2.0
        
        # 1. queryDatasetByName with the registered name
        # 2. queryDatasetByName with the registered name in lowercase and answer in registered case
        # 3. queryDatasetByName with the registered name in uppercase and answer in registered case
        """
        
        # 1. queryDatasetByName with the registered name
        message = '1. queryDatasetByName with the registered name'
        
        regular = TestCaseData.DSNS[0]
        self.dq2.registerNewDataset(regular, TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        
        result = self.dq2.listDatasets(regular).keys()
        expected = [TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 2. queryDatasetByName with the registered name in lowercase and answer in registered case
        
        lowercase = TestCaseData.DSNS[0].lower()
        
        result = self.dq2.listDatasets(lowercase).keys()
        expected = [TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 3. queryDatasetByName with the registered name in uppercase and answer in registered case
        message = '3. queryDatasetByName with the registered name in uppercase and answer in registered case'
        
        uppercase = TestCaseData.DSNS[0].upper()
        
        result = self.dq2.listDatasets(uppercase).keys()
        expected = [TestCaseData.DSNS[0]]
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def testListFilesInDataset (self):
        """
        Tests dq2.clientapi.DQ2.listFilesInDataset method.
        
        @since: 0.2.0
        
        # 1.1 listFilesInDataset
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])[0]
        
        
        # 1.1 listFilesInDataset
        message = '1.1 listFilesInDataset'
        
        result = dsfiles.keys()
        result.sort()
        expected = TestCaseData.GUIDS[0:1]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.2 listFilesInDataset
        message = '1.2 listFilesInDataset'
        
        result = []
        for eachDict in dsfiles.keys():
            result.append(dsfiles[eachDict]['lfn'])
        result.sort()
        expected = TestCaseData.LFNS[0:1]
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.3.1 listFilesInDataset (latest versions) :: GUID check
        message = '1.3.1 listFilesInDataset (latest version) :: GUID check'
        
        self.dq2.registerNewVersion(TestCaseData.DSNS[0], TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2],
                                    TestCaseData.SIZES[1:2], TestCaseData.CHECKSUMS[1:2])
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0], version=0)[0]
        
        result = dsfiles.keys()
        result.sort()
        
        expected = TestCaseData.GUIDS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.3.2 listFilesInDataset (latest versions) :: LFN check
        message = '1.3.2 listFilesInDataset (latest version) :: LFN check'
        
        result = []
        for eachDict in dsfiles.keys():
            result.append(dsfiles[eachDict]['lfn'])
        result.sort()
        
        expected = TestCaseData.LFNS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.4.1 listFilesInDataset (all versions) :: GUID check
        message = '1.4.1 listFilesInDataset (all versions) :: GUID check'
        
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])[0]
        
        result = dsfiles.keys()
        result.sort()
        
        expected = TestCaseData.GUIDS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.4.2 listFilesInDataset (all versions) :: LFN check
        message = '1.4.2 listFilesInDataset (all versions) :: LFN check'
        
        result = []
        for eachDict in dsfiles.keys():
            result.append(dsfiles[eachDict]['lfn'])
        result.sort()
        
        expected = TestCaseData.LFNS[0:2]
        expected.sort()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 2. user specified a version greater than the one existing on the central catalogs
        self.assertRaises(
            DQInvalidRequestException,
            self.dq2.listFilesInDataset,
            TestCaseData.DSNS[0],
            version=3000
        )


    def testListDatasetsInSite (self):
        """
        Tests dq2.clientapi.DQ2.listDatasetsInSite method.
        
        @since: 0.2.0
        """
        r1 = self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0])
        
        r2 = self.dq2.registerNewDataset(TestCaseData.DSNS[1],TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2],
                                    TestCaseData.SIZES[1:2], TestCaseData.CHECKSUMS[1:2])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[1], SOURCES[0])
        
        message = ''
        result = self.dq2.listDatasetsInSite(SOURCES[0])
        expected = {
            TestCaseData.DSNS[0]: [1],
            TestCaseData.DSNS[1]: [1]
        }
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))


    def testListSubscriptions (self):
        """
        Tests dq2.clientapi.DQ2.listSubscriptionsInSite method.
        
        @since: 0.2.0
        
        # 1. listSubscriptions with no datasets
        # 2. listSubscriptions
        # 2.1 listSubscriptions on any state
        """
        
        # 1. listSubscriptionsInSite with no datasets
        
        self.assertRaises(
            DQUnknownDatasetException,
            self.dq2.listSubscriptions,
            TestCaseData.DSNS[0]
        )
        
        
        # 2. listSubscriptionsInSite
        
        # registering datasets
        duid_0 = self.dq2.registerNewDataset(TestCaseData.DSNS[0])['duid']
        duid_1 = self.dq2.registerNewDataset(TestCaseData.DSNS[1])['duid']
        
        # registering subscriptions
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[1], DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE)
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[1], DESTINATIONS[1], archived=SubscriptionArchivedState.ARCHIVE)
        
        # 2.1 listSubscriptions with no dataset
        result = self.dq2.listSubscriptions(TestCaseData.DSNS[0])
        expected = []
        
        self.assertEqual(result, expected, self._fmt_message('2.1. listSubscriptions with no dataset', expected, result))
        
        # 2.1 listSubscriptionsInSite on any state
        result = self.dq2.listSubscriptions(TestCaseData.DSNS[1])
        result.sort()
        expected = [DESTINATIONS[0], DESTINATIONS[1]]
        expected.sort()
        
        self.assertEqual(result, expected, self._fmt_message('2.1 listSubscriptions on any state', expected, result))


    def testListSubscriptionsInSite (self):
        """
        Tests dq2.clientapi.DQ2.listSubscriptionsInSite method.
        
        @since: 0.2.0
        
        # 1. listSubscriptionsInSite with no datasets
        # 2. listSubscriptionsInSite
        # 2.1 listSubscriptionsInSite with no dataset
        # 2.2 listSubscriptionsInSite on any state
        """
        # 1. listSubscriptionsInSite with no datasets
        message = '1. listSubscriptionsInSite with no datasets'
        
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[0])
        expected = {}
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
        # 2. listSubscriptionsInSite
        
        # registering datasets
        duid_0 = self.dq2.registerNewDataset(TestCaseData.DSNS[0])['duid']
        duid_1 = self.dq2.registerNewDataset(TestCaseData.DSNS[1])['duid']
        
        # registering subscriptions
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[0], DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE)
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[1], DESTINATIONS[0], archived=SubscriptionArchivedState.ARCHIVE)
        
        
        # 2.1 listSubscriptionsInSite with no dataset
        message = '2.1. listSubscriptionsInSite with no dataset'
        
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[1])
        expected = {}
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
        # 2.2 listSubscriptionsInSite on any state
        message = '2.2 listSubscriptionsInSite on any state'
        
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[0])
        expected = {
            TestCaseData.DSNS[0]: [1],
            TestCaseData.DSNS[1]: [1]
        }
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))


    def testMetadata (self):
        """
        Tests dq2.clientapi.DQ2.setMetaDataAttribute
        
        @since: 0.3.0
        
        # 1. set metadata for all Tier0 atttributes
        # 2. set dataset owner metadata
        """
        
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        value = 'abc'
        
        
        # 1. set metadata for all Tier0 atttributes
        for eachAttribute in Metadata.USER_VERSION:
            self.dq2.setMetaDataAttribute(TestCaseData.DSNS[0], eachAttribute, value)
            
            result = self.dq2.getMetaDataAttribute(TestCaseData.DSNS[0], [eachAttribute])
            expected = {eachAttribute: value}
            self.assertEqual(expected, result, self._fmt_message('1. set metadata for all Tier0 atttributes', expected, result))
        
        
        # 2. set dataset owner metadata
        fake_owner = 'test'
        
        self.dq2.setMetaDataAttribute(TestCaseData.DSNS[0], 'owner', fake_owner)
        result = self.dq2.getMetaDataAttribute(TestCaseData.DSNS[0], ['owner'])
        expected = {'owner': fake_owner}
        
        self.assertEqual(expected, result, self._fmt_message('2. set dataset owner metadata', expected, result))


    def testRegisterDatasetLocations (self):
        """
        Tests dq2.clientapi.DQ2.registerDatasetLocation method.
        
        @since: 0.2.0
        """
        r = self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                        TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], SOURCES[0])
        
        expected = {r['vuid']: {LocationState.INCOMPLETE: [SOURCES[0]], LocationState.COMPLETE: []}}
        result = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0])
        self.assertEqual(expected, result, self._fmt_message(expected, result, ''))





    def testRegisterNewVersion (self):
        """
        Tests dq2.clientapi.DQ2.registerNewDataset method.
        
        @since: 0.2.0
        
        # 1.1 listDatasetReplicas for latest version is not ok!
        # 1.2 listDatasetReplicas for specific version is not ok!
        # 2. dataset replicas was copied from latest version?
        """
        self.dq2.registerNewDataset(TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        self.dq2.closeDataset(TestCaseData.DSNS[0]) # to be able to register complete replicas
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], 'MOCK_CERN_1', 0, LocationState.COMPLETE)
        self.dq2.registerDatasetLocation(TestCaseData.DSNS[0], 'MOCK_CNAF_1', 0, LocationState.INCOMPLETE)
        vuid = self.dq2.listDatasets(TestCaseData.DSNS[0])[TestCaseData.DSNS[0]]['vuids'][0]
        
        # 1.1 listDatasetReplicas for latest version is not ok!
        message = '1.1 listDatasetReplicas with specific version is not ok!'
        
        loc_v0 = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], 0)
        expected = {
            vuid:
                {
                    LocationState.COMPLETE: ['MOCK_CERN_1'],
                    LocationState.INCOMPLETE: ['MOCK_CNAF_1']
                }
        }
        
        self.assertEqual(expected, loc_v0, self._fmt_message(message, expected, loc_v0))
        
        # 1.2 listDatasetReplicas for specific version is not ok!
        message = '1.2 listDatasetReplicas with specific version is not ok!'
        
        loc_v1 = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], 1)
        
        self.assertEqual(loc_v0, loc_v1, self._fmt_message(message, loc_v0, loc_v1))
        
        
        # creating version 2
        try:
            self.dq2.registerNewVersion(
                TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1], TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1]
            )
        except:
            fail('registerNewVersion raise any exception!')
        
        # creating version 3
        self.dq2.registerNewVersion(TestCaseData.DSNS[0], TestCaseData.LFNS[1:2], TestCaseData.GUIDS[1:2],
                                    TestCaseData.SIZES[1:2], TestCaseData.CHECKSUMS[1:2])
        self.assertEqual(self.dq2.listDatasets(TestCaseData.DSNS[0], version=2).keys(), [TestCaseData.DSNS[0]])
        vuid = self.dq2.listDatasets(TestCaseData.DSNS[0])[TestCaseData.DSNS[0]]['vuids'][0]
        
        
        # 2. dataset replicas was copied from latest version?
        message = '2. dataset replicas was copied from latest version?'
        
        loc_v2 = self.dq2.listDatasetReplicas(TestCaseData.DSNS[0], 3)
        expected = {
            vuid:
                {
                    LocationState.COMPLETE: [],
                    LocationState.INCOMPLETE: ['MOCK_CERN_1', 'MOCK_CNAF_1']
                }
        }
        
        self.assertEqual(expected, loc_v2, self._fmt_message(message, expected, loc_v2))
        
        #
        
        dsfiles = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])[0]
        result_guids = dsfiles.keys()
        result_guids.sort()
        
        
        result_lfns = []
        for eachDict in dsfiles.keys():
            result_lfns.append(dsfiles[eachDict]['lfn'])
        result_lfns.sort()
        
        expected_guids = TestCaseData.GUIDS[0:2]
        expected_lfns = TestCaseData.LFNS[0:2]
        
        self.assertEqual(expected_guids, result_guids, self._fmt_message('', expected_guids, result_guids))
        self.assertEqual(expected_lfns, result_lfns, self._fmt_message('', expected_lfns, result_lfns))
        
        
        #
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 2
        
        self.assertEqual(expected, result, self._fmt_message(expected, result, ''))


    def testRegisterNewVersionExceptions (self):
        """
        Tests dq2.clientapi.DQ2.registerNewDataset method exceptions (TODO: improve).
        
        @since: 0.2.0
        """
        # LFNs and GUIDs have different length
        # TODO: add validation to DQ2.py
        #self.assertRaises(DQUnknownDatasetException,
        #                  self.dq2.registerNewVersion,
        #                  TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:2])
        
        self.assertRaises(DQUnknownDatasetException,
                          self.dq2.registerNewVersion,
                          TestCaseData.DSNS[0], TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                          TestCaseData.SIZES[2:3],TestCaseData.CHECKSUMS[2:3])
        
        self.dq2.registerNewDataset(TestCaseData.DSNS[0],TestCaseData.LFNS[0:1], TestCaseData.GUIDS[0:1],
                                    TestCaseData.SIZES[0:1], TestCaseData.CHECKSUMS[0:1])
        # trying to register a new dataset version with already existing files


    def testResetSubscription (self):
        """
        Tests dq2.clientapi.DQ2.resetSubscription method.
        
        @since: 0.3.0
        
        # 1. resetSubscription with no subscriptions
        # 2. resetSubscription
        # 2.1. resetSubscriptionsInSite with no subscriptions
        # 2.2. resetSubscription on a dataset
        """
        
        # 1. resetSubscriptionsInSite with no datasets
        message = '1. resetSubscriptionsInSite with no datasets'
        
        self.assertRaises(
            DQUnknownDatasetException,
            self.dq2.resetSubscription,
            TestCaseData.DSNS[0],
            DESTINATIONS[0]
        )
        
        
        # 2. resetSubscriptionsInSite
        
        # registering datasets
        duid_0 = self.dq2.registerNewDataset(TestCaseData.DSNS[0])['duid']
        
        # 2.1. resetSubscriptionsInSite with no subscriptions
        message = '2.1. resetSubscriptionsInSite with no subscriptions'
        
        self.assertRaises(
            DQUnknownSubscriptionException,
            self.dq2.resetSubscription,
            TestCaseData.DSNS[0],
            DESTINATIONS[0]
        )
        
        # registering subscriptions
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[0], DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE)
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[0])
        expected = {
            TestCaseData.DSNS[0]: [1]
        }
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
        # 2.2. resetSubscription on a dataset
        message = '2.2. resetSubscription on a dataset'
        
        self.dq2.resetSubscription(TestCaseData.DSNS[0], DESTINATIONS[0])
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[0])
        expected = {
            TestCaseData.DSNS[0]: [1]
        }
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))


    def testResetSubscriptionsInSite (self):
        """
        Tests dq2.clientapi.DQ2.resetSubscriptionsInSite method.
        
        @since: 0.3.0
        
        # 1. resetSubscriptionsInSite with no subscriptions
        # 2. resetSubscriptionsInSite
        """
        # 1. resetSubscriptionsInSite with no subscriptions
        self.assertRaises(
            DQUnknownSubscriptionException,
            self.dq2.resetSubscriptionsInSite,
            DESTINATIONS[0]
        )
        
        
        # 2. resetSubscriptionsInSite
        message = '2. resetSubscriptionsInSite'
        
        # registering datasets
        duid_0 = self.dq2.registerNewDataset(TestCaseData.DSNS[0])['duid']
        
        # registering subscriptions
        self.dq2.registerDatasetSubscription(TestCaseData.DSNS[0], DESTINATIONS[0], archived=SubscriptionArchivedState.UNARCHIVE)
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[0])
        expected = {TestCaseData.DSNS[0]: [1]}
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        # 2.1 resetSubscriptionsInSite
        message = '2.1 resetSubscriptionsInSite'
        
        self.dq2.resetSubscriptionsInSite(DESTINATIONS[0])
        result = self.dq2.listSubscriptionsInSite(DESTINATIONS[0])
        expected = {TestCaseData.DSNS[0]: [1]}
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))


if __name__ == '__main__':
    """
    Runs all tests in DQ2TestCase.
    
    @since: 0.2.0
    """
    dq2 = DQ2()
    
    print 'Testing DQ2...'
    
    import sys
    argv = sys.argv[1:]
    
    import unittest
    if len(argv) >= 1:
        suite = unittest.TestSuite()
        
        for eachTest in argv:
            suite.addTest(DQ2TestCase(eachTest))
    
    else:
        suite = unittest.makeSuite(DQ2TestCase)
    
    unittest.TextTestRunner(verbosity=2).run(suite)
