"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: Dataset.py,v 1.2 2009/10/15 13:06:49 angelos Exp $
"""


class Dataset (object):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.2 $
    """


#
# Dataset-level operations
#


    def searchDatasets (self, what):
        """
        Search for datasets.
        
        @since: 0.3.22
        
        @return: (duid_10, name, state, owner, creationdate, datasettype, version, vuid, versioncreationdate)
        @rtype: tuple
        """
        
        return self.repositoryClient.searchDatasets(what)