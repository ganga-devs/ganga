"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: GetUsage.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""

from time import gmtime, strftime
import string, sys

from dq2.common                     import optparse
from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.info.TiersOfATLAS          import getQuota

from dq2.clientapi.cli.cliutil import getDQ2

class GetUsage (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <SITE>"
    
    version = "$Revision: 1.2 $"
    
    description = "Get storage usage"

    toolOptions = [
        optparse.make_option(
            "-g", "--group",
            dest="group",
            default=None,
            help="group"
        )
    ]
    
    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0])

        
    def execute (self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
        
        location = self._get_parameters()
        
        group = self.options.group        
        if not group:
           ret = dq.queryStorageUsage (metaDataAttributes={'srm': ['total', 'used']}, value=group, site=location)
           out = ''
           if ret:
            keys = ['location', 'timestamp','bytes', 'tera', ]
            for r in ret:
                if r['value'] == 'total':
                    out += string.ljust('Total space (bytes)', 25) +' : '+ str(r['bytes'])    +'\n'
                if r['value'] == 'used':
                    out += string.ljust('Used space  (bytes)', 25) +' : '+ str(r['bytes'])     +'\n'
            for r in ret:
                if r['value'] == 'total':
                    out += string.ljust('Total space (TiB)', 25) +' : '+ str(r['tera'])       +'\n'
                if r['value'] == 'used':
                    out += string.ljust('Used space  (TiB)'  , 25) +' : '+ str(r['tera'])      +'\n'
                    out += string.ljust('Timestamp'       , 25) +' : '+ str(r['timestamp']) +'\n'

            print out
           return 

        
        ret = dq.queryStorageUsage (key='group', value=group, site=location)
        
        out = ''        
        if ret:
            keys = ['location', 'timestamp','datasets', 'files', 'bytes', 'tera', ]
            for r in ret:
                for at in keys:              
                    if at == 'files':
                        key = '# files'
                    elif at == 'datasets':
                        key = '# datasets'                    
                    elif at == 'bytes':
                        key = '# bytes'                    
                    elif at == 'tera':
                        key = '# tera'                    
                        
                    else:
                        key = at
                    out += string.ljust(key.lower(), 25) +' : '+ str(r[at]) +'\n'
        else:
            timestamp = strftime("%Y-%m-%d %H:%M:%S", gmtime())
            out = '''location                  : %(location)s
timestamp                 : %(timestamp)s
# datasets                : 0
# files                   : 0
# bytes                   : 0
# tera                    : 0.0
''' % locals ()
        quota = getQuota(location, group)
        if quota:
            out += string.ljust('quota', 25) +' : '+ str(quota) +' Tera\n'        
        else:
            out += string.ljust('quota', 25) +' : '+ str(quota) +'\n'        
                    
        print out
