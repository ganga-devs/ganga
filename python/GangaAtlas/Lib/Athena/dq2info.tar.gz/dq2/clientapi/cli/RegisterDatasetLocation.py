"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: RegisterDatasetLocation.py,v 1.7 2009/10/06 13:23:17 angelos Exp $
"""

import cliutil

from dq2.common import optparse

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2, option_value

from dq2.location.DQLocationConstants import LocationState


class RegisterDatasetLocation (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> <SITE>"
    
    version = "$Revision: 1.7 $"
    
    description = "Register Dataset to a location (incomplete per default)"

    toolOptions = [
        optparse.make_option(
            "-c", "--complete",
            action="store_true",
            dest="complete",
            default=False,
            help="dataset is complete"
        ),
        optparse.make_option(
            "-g", "--group",
            dest="group",
            default=None,
            help="group"
        ),        
        cliutil.opt_dataset_version
    ]
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1])


    def execute (self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
        
        dsn, location = self._get_parameters()
        
        complete = LocationState.INCOMPLETE
        if self.options.complete:
            complete = LocationState.COMPLETE
        
        dq.registerDatasetLocation(dsn=dsn, location=location, version=self.options.version, complete=complete, group=self.options.group)
        
        if self.options.version > 0:
            print "Dataset %s version %u registered at %s" % (dsn, self.options.version, location)
        else:
            print "Dataset %s registered at %s" % (dsn, location)