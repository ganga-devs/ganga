"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import sys, getopt
from dq2.common.DQException import DQException

class ErrorCode:
    """
    @since: 0.3.0
    
    ErrorCode class for shell return variables
    """

    OKAY = 0
    ERROR = 1
    CANCEL = 2
    DQEXCEPTION = 3
    GETOPTERROR = 4
    VALUEERROR = 5
    FATAL = 6

class ExceptionHandler:
    """
    @since: 0.3.0
    
    Handle exception-messages properly and return the error codes
    back to the shell
    """

    def __init__(self, exception):
        if isinstance(exception, DQException):
            print(exception)
            sys.exit(ErrorCode.DQEXCEPTION)
        elif isinstance(exception, getopt.GetoptError):
            print(exception)
            sys.exit(ErrorCode.GETOPTERROR)
        elif isinstance(exception, ValueError):
            print('Only integer versions are allowed (0=latest)')
            sys.exit(ErrorCode.VALUEERROR)
        elif isinstance(exception, IndexError):
            sys.exit(ErrorCode.OKAY)
        elif isinstance(exception, KeyboardInterrupt):
            print('Cancelling')
            sys.exit(ErrorCode.CANCEL)
        elif isinstance(exception, Exception):
            print exception
            sys.exit(ErrorCode.ERROR)
        else:
            print 'FATAL:',exception
            sys.exit(ErrorCode.FATAL)