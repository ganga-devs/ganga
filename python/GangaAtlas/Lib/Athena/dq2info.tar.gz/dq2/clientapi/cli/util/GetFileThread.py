"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import commands, os, popen2, signal, sys, tempfile, time, zlib

#backport, so we can use python 2.3
import dq2.clientapi.cli.util.subprocess as subprocess

from dq2.clientapi.cli.util.EndpointTool import EndpointTool

from dq2.tracer.client.TracerClient import TracerClient

class FileThread:
    """
    @since: 0.0.1
    """    
    
    def __init__(self, dataset, file, sourceSite, destinationSite, noDirectories, protocol, debug, report, toStorage, destinationDirectory, toStorageToken, timeout=600):
        """
        @since: 0.0.1
        """
        
        self.dataset = dataset
        
        self.source = file[0]
        self.destination = file[1]
        
        self.sourceSite = sourceSite
        self.destinationSite = destinationSite
        
        if destinationDirectory is not None:
            self.filename = destinationDirectory+'/'+file[2]
        elif noDirectories:
            self.filename = file[2]
        else:
            self.filename = dataset+'/'+file[2]
        
        self.checksum = file[3]
        
        self.protocol = protocol
        self.transferCommand = None
        self.noDirectories = noDirectories
        self.srmSize = None
        self.isCached = None
        self.timeoutCancel = False
        self.toStorage = toStorage
        self.toStorageToken = toStorageToken
        self.timeout = timeout
        
        self.proc = None
        
        self.debug = debug
        
        self.endpointTool = EndpointTool(EndpointTool.GET, self.dataset, self.source, self.destination, self.sourceSite, self.destinationSite, self.toStorageToken, self.protocol)
        self.endpointTool.prepare()
         
        self.report = report
                    
        self.__debug('%s: Checking availability of transfer tools'%(self.filename))
        
        self.__debug('%s: Available protocols: %s'%(self.filename, self.endpointTool.getAvailableProtocols()))
        
        self.__debug('%s: Using protocol: %s'%(self.filename, self.endpointTool.rank()))
        
        
        if '__DQ2' in file[2]:
            self.report['filename'] = file[2][:file[2].find('__DQ2')]
        else:
            self.report['filename'] = file[2]
        self.report['protocol'] = self.endpointTool.protocol
        self.report['guid'] = file[4].replace('-','')
    
    def run(self):
        """
        @since: 0.0.1
        """
        
        try:
            
            self.__selectEndpoint()
        
            self.__transfer()
        
            self.__validate()

            self.report['clientState'] = 'DONE'

            self.__sendReport()

        except:
            excType, excValue, excStack = sys.exc_info()
            print excValue
            self.__sendReport()

    def __selectEndpoint(self):
        """
        @since: 0.0.1
        """
        
        self.preparedSource = self.endpointTool.prepareGet(self.source)
        self.transferCommand = self.endpointTool.cp(self.preparedSource, self.destination)

    def __transfer(self):
        """
        @since: 0.0.1
        """
        
        self.report['clientState'] = 'GET_METADATA'

        self.srmSize = None
        self.isCached = None
        
        if self.preparedSource.startswith('srm'):
            print '%s: Getting SRM metadata for %s'%(self.filename, self.preparedSource)
            self.srmSize, self.isCached, status = self.endpointTool.getMetadata(self.preparedSource)
        
        if self.srmSize is None:
            print '%s: no SRM size information available. No transfer progress display.'%self.filename
        
        if self.isCached is None:
            print '%s: no SRM caching information available. Are you using a local protocol?'%self.filename
        elif not self.isCached:
            print '%s: might not be cached. Staging will take some time.'%self.filename
        else:
            print '%s: is cached.'%self.filename
        
        print '%s: Starting transfer: %s'%(self.filename, self.transferCommand)
        self.alive = True

        FDOUT = tempfile.TemporaryFile()
        FDERR = tempfile.TemporaryFile()

        #we need the transfer establishment overhead
        self.report['relativeStart'] = time.time()
        self.proc = subprocess.Popen(self.transferCommand, shell=True, stdout=FDOUT, stderr=FDERR, close_fds=True)

        #keep track of transferSize
        oldSize = -1
        
        #if the transfer does not continue, keep track of the waiting time
        timeoutCounter = 0
        
        #check the relative time
        transferSet = False
        
        self.report['clientState'] = 'START_TRANSFER'
        try:
            while(self.alive):
                if timeoutCounter > self.timeout:
                    self.timeoutCancel = True
                    os.kill(self.proc.pid, signal.SIGKILL)
                    break
                else:
                    #None means still running
                    if self.proc.poll() == None:  
                        if self.srmSize is not None:    
                            try:
                                #don't display the same transferSize over and over again
                                current = os.stat(self.filename).st_size
                                if oldSize != current:
                                    if transferSet == False:
                                        self.report['transferStart'] = time.time()
                                        transferSet = True
                                    print '%s: %s/%s transferred'%(self.filename,current,self.srmSize)
                                    oldSize = current
                                    timeoutCounter = 0
                                else:
                                    timeoutCounter += 1
                            except:
                                pass
                        time.sleep(1)
                    else:
                        self.alive = False
        except:
            excType, excValue, excStack = sys.exc_info()
            print excValue

        if self.proc.returncode != 0:
            FDOUT.flush()
            FDOUT.seek(0)
            FDERR.flush()
            FDERR.seek(0)
            print '\n%s: external failed:\nstdout:\n%s\n\nstderr:%s\n'%(self.filename,FDOUT.read(),FDERR.read())
        
        try:
            FDOUT.close()
        except:
            pass
        try:
            FDERR.close()
        except:
            pass

        
    def __validate(self):
        """
        @since: 0.0.1
        """
    
        deleted = False
        skipped = False
    
        self.report['clientState'] = 'VALIDATE'
    
        if self.proc.returncode != 0:
            print '%s: external tool failed, no file was transferred'%self.filename
            
            #implicit delete *g*
            deleted = True
    
        elif self.timeoutCancel == True:
            print '%s: timeout on external tool, deleting partially transferred file'%self.filename
            os.unlink(self.filename)
            deleted = True
                
        else:
        
            if self.srmSize is None:
                print '%s: no size information was available, skipping validation'%self.filename
                skipped = True
            elif self.toStorage is not None:
                print '%s: directly put to mass storage, skipping validation'%self.filename
                skipped = True
            else:    
                
                #check size and checksum of file - delete file if bogus
                if long(os.stat(self.filename).st_size) != long(self.srmSize):
                    print '%s: size mismatch, deleting (local: %s, catalogues: %s)'%(self.filename, long(os.stat(self.filename).st_size), long(self.srmSize))
                    os.unlink(self.filename)
                    deleted = True
                else:
                    self.report['filesize'] = long(self.srmSize)
                    if self.checksum is None:
                        print '%s: no checksum information available in LFC, skipping checksum check'%self.filename
                        skipped = True
                    else:
                        self.report['validateStart'] = time.time()
                        if self.checksum.startswith('ad:'):
                            checksum = 'ad:'+self.__adler32(self.filename)
                        else:
                            checksum = 'md5:'+commands.getstatusoutput('md5sum %s'%self.filename)[1].split()[0]
                        
                        if str(checksum) != str(self.checksum):
                            print '%s: checksum mismatch, deleting (local: %s, catalogues: %s)'%(self.filename,str(checksum),str(self.checksum))
                            os.unlink(self.filename)
                            deleted = True
            
        if not deleted:
            
            #we might have a __DQ2-timestamp extension (site services retrials)
            #this is safe to remove
            if '__DQ2' in self.filename:
                new = self.filename[:self.filename.find('__DQ2')]
                print '%s: fixing filename to %s'%(self.filename, new)
                os.rename(self.filename, new)
                self.filename = new
            
            if not skipped:
                print '%s: validated'%self.filename
                self.report['clientState'] = 'FILE_DONE'
    
    def die(self):
        """
        @since: 0.0.1
        """
        
        self.alive = False
        print '%s: killing remaining transfertool'%self.name
        sys.stdout.flush()
        try:
            os.kill(self.proc.pid, signal.SIGKILL)
        except:
            pass
    
    def __debug(self, *messages):
        """
        @since: 0.0.1
        """
        
        if self.debug:
            for message in messages:
                print message,
                print
                
    def __sendReport(self):
        """
        @since: 0.0.1
        """

        self.report['timeEnd'] = time.time()

        try:
            TracerClient().addReport(self.report)
        except:
            pass
        
    def __adler32(self, file):
        """
        @since: 0.0.1
        """

        #adler starting value is _not_ 0
        adler=1L
        
        try:

            openFile = open(file, 'rb')
            
            for line in openFile:
                adler=zlib.adler32(line, adler)

        except:
            raise Exception('FATAL - could not get checksum of file %s'%file)

        #backflip on 32bit
        if adler < 0:
            adler = adler + 2**32
        
        return str('%08x'%adler) #return as hexified string, padded to 8 values