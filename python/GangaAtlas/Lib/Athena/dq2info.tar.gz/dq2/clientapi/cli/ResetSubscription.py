"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ResetSubscription.py,v 1.7 2009/10/06 13:23:18 angelos Exp $
"""

import cliutil

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2, option_value


class ResetSubscription (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> <SITENAME>"
    
    version = "$Revision: 1.7 $"
    
    description = "Reset Subscription"

    toolOptions = [
        cliutil.opt_dataset_version
    ]
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1])

        
    def execute (self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
        
        dsn, location = self._get_parameters()
        
        dq.resetSubscription(dsn,location,self.options.version)
        
        if self.options.version > 0:
            print "Dataset %s version %i subscription at %s was reset." % (dsn, self.options.version, location)
        else:
            print "Dataset %s subscription at %s was reset." % (dsn, location)