"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: __init__.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""