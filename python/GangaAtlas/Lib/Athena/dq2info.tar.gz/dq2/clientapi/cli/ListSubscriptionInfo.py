"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ListSubscriptionInfo.py,v 1.9 2009/10/06 13:23:17 angelos Exp $
"""

import cliutil

from dq2.common.DQException import DQInvalidRequestException
from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2, option_value

from dq2.subscription.DQSubscriptionConstants import SourcesPolicy


class ListSubscriptionInfo (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> <SITE>"
    
    version = "$Revision: 1.9 $"
    
    description = "List Subscription Information"

    toolOptions = [
        cliutil.opt_dataset_version
    ]
    
    
    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1])


    def execute (self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
    
        dsn, location = self._get_parameters()
        
        # (uid, owner, location, destination, creationdate, modifieddate, callbacks, archived, sources_policy, wait_for_sources, sources, query_more_sources)
        ret = dq.listSubscriptionInfo(dsn, location, self.options.version)
        if ret is None or len(ret) == 0:
            raise DQInvalidRequestException('Dataset subscription was not found!')
        
        out = ''
        attr = ['uid', 'owner', 'location', 'destination', 'creationdate', 'modifieddate', 'callbacks', 'archived', 'sources_policy', 'wait_for_sources', 'sources', 'query_more_sources', 'share', 'group']
        
        for i in range(0, len(attr)):
            txt = ''
            
            if attr[i] == 'sources_policy':
                if int(ret[i]) & SourcesPolicy.ALL_SOURCES:
                    txt = 'ALL_SOURCES '
                if int(ret[i]) & SourcesPolicy.KNOWN_SOURCES:
                    txt += 'KNOWN_SOURCES '
                if int(ret[i]) & SourcesPolicy.CLOSE_SOURCES:
                    txt += 'CLOSE_SOURCES '
                if int(ret[i]) & SourcesPolicy.COMPLETE_SOURCES:
                    txt += 'COMPLETE_SOURCES '
                if int(ret[i]) & SourcesPolicy.INCOMPLETE_SOURCES:
                    txt += 'INCOMPLETE_SOURCES '
            
            elif attr[i] == 'sources':
                for src in ret[i]:
                    txt += '%s ' % src
                txt = txt[:-1]
                
            elif attr[i] in ['wait_for_sources', 'archived', 'query_more_sources']:
                txt = bool(ret[i])
                
            else:
                txt = ret[i]
            
            out += '%s: %s\n' % (attr[i].ljust(19), txt)
            
        print out
