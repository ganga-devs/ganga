#!/usr/bin/env python
"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ClientAPITestcase.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""


### UNIT TESTS ###
import unittest
import commands
import re
import random

# Note:
# To enhance:
# dq2-list-files
#dq2-list-dataset-metadata
#dq2-list-subscription-info

class TestCLI(unittest.TestCase):

    __slots__ = ('dataset', )

    dataset = 'test.dq2.validation.' + str(random.random ())


    def setUp(self):
        pass


    def test_dq2_register_dataset (self):
        """
        """
        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-register-dataset  " + self.dataset
        print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
        self.assertEqual(output, 'Dataset ' + self.dataset + ' created.')


    def test_dq2_get_metadata(self):
        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-get-metadata  " + self.dataset
        print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
        self.assertEqual(output, "name                : %s\n"%self.dataset)

    def test_dq2_get_metadata_attribute(self):
        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-get-metadata-attribute "+self.dataset+"  version"
        print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)        
        self.assertEqual(output, 'name                : %s\nversion             : 1\n'%self.dataset)

    
    def test_dq2_list_dataset(self):
    
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-dataset  " + self.dataset
        print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0 , cmd)
        self.assertEqual(output, self.dataset+'\n', cmd)
        

    def test_dq2_delete_files(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-delete-files "+self.dataset+ " 11d168eb-0000-4ea1-b903-1bf8bf418836"
        print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0 , cmd)
        self.assertEqual(output, "Files ['11d168eb-0000-4ea1-b903-1bf8bf418836'] deleted from dataset "+self.dataset)

    def test_dq2_register_files(self):

        cmd = '/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-register-files '+ self.dataset +' lfn.test.12 11d168eb-0000-4ea1-b903-1bf8bf418836  10 md5:455157711d8e08b0c8b660d5f2736bd9'
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)   
        self.assertEqual(output, 'Dataset %s updated'%self.dataset)

    def test_dq2_list_files(self):

        cmd = '/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-files '+ self.dataset
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)   
        self.assertNotEqual(output, "please provide <DATASET> \nError: tuple index out of range [IndexError]")
        self.assertEqual(output,  '11d168eb-0000-4ea1-b903-1bf8bf418836 lfn.test.12 10\n\ntotal files: 1\ntotal size: 10')


    def test_dq2_erase_dataset(self):
               
        #cmd = "dq2-erase-dataset  " + self.dataset
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-erase  " + self.dataset
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
        self.assertEqual(output, 'Dataset ' + self.dataset + ' erased')

    def test_dq2_set_metadata(self):
            
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-set-metadata " + self.dataset + " version 2"
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)    
        self.assertEqual(output, "Metadata attribute version set with value 2 for %s"%self.dataset)


    def test_dq2_metadata(self):
            
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-metadata " + self.dataset
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)   
        expectedoutput= 'duid\nstate\nowner\ncreationdate\nlatestvuid\nlatestversion\nvuid\nversion\nversioncreationdate\ntier0state\ntier0nrpartitions\ntier0type\n'
        self.assertEqual(output, expectedoutput)

    def test_dq2_sources(self):
        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-sources " 
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)  
        self.assertNotEqual(re.match (" (\w*)\n", output), None)

    def test_dq2_destinations(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-destinations " 
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)  
        self.assertNotEqual(re.match (" (\w*)\n", output), None)

    def test_dq2_register_version(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-register-version  "+self.dataset+"  lfn2 1496e05d-43ab-46cc-8dbe-14c8047f6a80 34 md5:de7b6dab2fc54f80f62ca881049e12e1"
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)   
        self.assertEqual(output, "Dataset %s version 2 is open."%self.dataset)        

    def test_dq2_get_number_files(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-get-number-files  " + self.dataset
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)   
        self.assertEqual(output, '1')
        
    def test_dq2_freeze_dataset(self):
        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-freeze-dataset  " + self.dataset
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
        self.assertEqual(output, 'Dataset ' + self.dataset + ' frozen')

    def test_dq2_close_dataset(self):
        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-close-dataset  " + self.dataset
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
        self.assertEqual(output, 'Dataset ' + self.dataset + ' closed')
        
    def test_dq2_ping(self):

        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-ping"
        ##print cmd
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
        
        # Expected output with regular expression
        #:[0-9]*
        expectedOutput = '''DDM server status : Running
Host status:      : {'\w*.cern.ch': 'Alive'}

content           : \('http://\w*.cern.ch//dq2', 'https://\w*.cern.ch//dq2'\)

location          : \('http://\w*.cern.ch//dq2', 'https://\w*.cern.ch//dq2'\)

repository        : \('http://\w*.cern.ch//dq2', 'https://\w*.cern.ch//dq2'\)

subscription      : \('http://\w*.cern.ch//dq2', 'https://\w*.cern.ch//dq2'\)

\*\*\*\*\*
'''

        self.assertNotEqual(re.match (expectedOutput, output), None, '%s !=  %s'%(output, expectedOutput))

    def test_dq2_register_location(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-register-location   "+self.dataset+"  LYONDISK "
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)        
        self.assertEqual(output, "Dataset %s registered at LYONDISK"%self.dataset)

    def test_dq2_list_dataset_site(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-dataset-site   LYONDISK | grep   "+self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)        
        self.assertEqual(output, self.dataset)

    def test_dq2_list_dataset_replicas(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-dataset-replicas "+self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, " INCOMPLETE: LYONDISK\n COMPLETE:")

    def test_dq2_list_dataset_creationdate(self):
        cmd =  "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-dataset-creationdate --leq 100 LYONDISK | grep "+self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, self.dataset)


    def test_dq2_delete_replicas(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-delete-replicas "+self.dataset+ " LYONDISK"
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, "Dataset %s replica at ['LYONDISK'] deleted"%self.dataset)
        
    def test_dq2_register_subscription(self):
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-register-subscription  "+self.dataset+" ROMA1"
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, "Dataset %s subscribed (archived: 0) to ROMA1."%self.dataset)
        
    def test_dq2_list_subscription_site(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-subscription-site ROMA1 | grep "+ self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, '1 2 \t%s'%self.dataset)
        
    def test_dq2_delete_subscription_site(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-delete-subscription " + self.dataset + " ROMA1 "
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, "Dataset %s replica at ROMA1 unsubscribed"%self.dataset)

    def test_dq2_reset_subscription(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-reset-subscription %s ROMA1"%self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, "Dataset %s subscription at ROMA1 was reset."%self.dataset)

    def test_dq2_reset_subscription_site(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-reset-subscription-site ROMA1"
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, "Dataset subscriptions at ROMA1 reset")

    def test_dq2_list_subscription(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-subscription %s"%self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)                
        self.assertEqual(output, "ROMA1")

    def test_dq2_list_subscription_info(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-subscription-info  t%s ROMA1"%self.dataset
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
#uid                : c084ba6a-a91b-4436-8986-e088d8db1d36
#owner              : /DC=ch/DC=cern/OU=Organic Units/OU=Users/CN=vgaronne
#location           : ROMA1
#destination        : None
#creationdate       : 2007-04-10 13:57:19
#modifieddate       : 2007-04-10 13:57:19
#callbacks          : {}
#archived           : 0
#sources_policy     : INCOMPLETE_SOURCES 
#wait_for_sources   : 0
#sources            : 
#query_more_sources : 1

                        
    def test_dq2_list_dataset_metadata(self):        
        cmd = "/afs/cern.ch/user/m/mlassnig/Workspace/DQ2_HEAD/stage/bin/dq2-list-dataset-metadata  state open"
        print 
        status, output = commands.getstatusoutput(cmd)
        self.assertEqual(status, 0, cmd)
  
        
if __name__ == "__main__":
    
    tests = unittest.TestSuite()
    
    # Scenario 1 :  Dataset handling
    tests.addTest(TestCLI('test_dq2_register_dataset'))
    tests.addTest(TestCLI('test_dq2_list_dataset'))
    
    tests.addTest(TestCLI('test_dq2_get_metadata'))
    tests.addTest(TestCLI('test_dq2_get_metadata_attribute'))
    tests.addTest(TestCLI('test_dq2_metadata'))
    tests.addTest(TestCLI('test_dq2_list_dataset_metadata'))
    
    tests.addTest(TestCLI('test_dq2_register_files'))
    tests.addTest(TestCLI('test_dq2_get_number_files'))
    tests.addTest(TestCLI('test_dq2_list_files'))
    tests.addTest(TestCLI('test_dq2_register_version'))
        
    tests.addTest(TestCLI('test_dq2_delete_files'))
    
    tests.addTest(TestCLI('test_dq2_set_metadata'))
    
    tests.addTest(TestCLI('test_dq2_freeze_dataset'))
    tests.addTest(TestCLI('test_dq2_close_dataset'))
        
    tests.addTest(TestCLI('test_dq2_register_location'))
    tests.addTest(TestCLI('test_dq2_list_dataset_replicas'))
    tests.addTest(TestCLI('test_dq2_list_dataset_site'))
    tests.addTest(TestCLI('test_dq2_list_dataset_creationdate'))
    tests.addTest(TestCLI('test_dq2_delete_replicas'))
    
    tests.addTest(TestCLI('test_dq2_register_subscription'))
    tests.addTest(TestCLI('test_dq2_reset_subscription'))   
    tests.addTest(TestCLI('test_dq2_list_subscription_site')) 
    tests.addTest(TestCLI('test_dq2_reset_subscription_site'))    
    tests.addTest(TestCLI('test_dq2_list_subscription')) 
    tests.addTest(TestCLI('test_dq2_list_subscription_info'))
    tests.addTest(TestCLI('test_dq2_delete_subscription_site'))
        
    tests.addTest(TestCLI('test_dq2_erase_dataset'))   
    
    tests.addTest(TestCLI('test_dq2_sources'))
    tests.addTest(TestCLI('test_dq2_destinations'))
    
    # Central services
    tests.addTest(TestCLI('test_dq2_ping')) 
    
    unittest.TextTestRunner().run(tests)