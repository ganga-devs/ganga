"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: RegisterDatasetsInContainer.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""


from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.clientapi.cli.cliutil import getDQ2


class RegisterDatasetsInContainer (DQDashboardTool):
    """
    @since: 1.0
    """


    description = 'Registers datasets in container'
    toolOptions = []
    usage = '%prog [options] <CONTAINER> (dataset)'
    version = '$Revision: 1.2 $'


    def __init__(self):
        """
        Constructs a RegisterDatasetsInContainer instance.
        
        @since: 1.0
        @version: $Revision: 1.2 $
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 1.0
        """
        return (self.args[0], self.args[1:])


    def execute (self):
        """
        @since: 1.0
        """
        
        dq = getDQ2(self)
        
        container, datasets = self._get_parameters()
        
        dq.registerDatasetsInContainer(container, datasets)
        
        print 'Container %s has been updated.' % (container)