"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ResetSubscriptionsInSite.py,v 1.4 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class ResetSubscriptionsInSite (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <SITENAME> "
    
    version = "$Revision: 1.4 $"
    
    description = "Reset Subscriptions In Site"

    toolOptions = []
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]


    def execute (self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
    
        location = self._get_parameters()
        
        dq.resetSubscriptionsInSite(location)

        print "Dataset subscriptions at %s reset" % (location)