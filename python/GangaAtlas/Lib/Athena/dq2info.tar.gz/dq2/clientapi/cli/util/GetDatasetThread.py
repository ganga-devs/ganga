"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import commands, os, random, re, string, sys, time, zlib

from dq2.clientapi.DQ2 import DQ2

from dq2.common.DQException import DQException
from dq2.common.threadpool import WorkRequest, ThreadPool

from dq2.clientapi.cli.util.EndpointTool import EndpointTool
from dq2.clientapi.cli.util.GetFileThread import FileThread

from dq2.info import TiersOfATLAS, TiersOfATLASValidator

from dq2.filecatalog import create_file_catalog

from dq2.tracer.client.TracerClient import TracerClient

from dq2.common.utils.proxy import get_fqans
from dq2.info import PermissionType
from dq2.info.TiersOfATLASValidator import has_permission
from dq2.common.DQException import DQInvalidRequestException

class DatasetThread:
    """
    @since: 0.0.1
    """  
          
    def __init__(self, dataset, noDirectories, DQ2_LOCAL_SITE_ID, nrFileThreads, report, timeout, debug, protocol, toStorage, skipCheck, destinationDirectory, nsample, toStorageToken, dryRun):
        """
        @since: 0.0.1
        """
    
        self.dataset = dataset[0]
        self.version = dataset[1]
        self.complete = dataset[2]
        self.files = dataset[3]
        self.remote = dataset[4]
        self.noDirectories = noDirectories
        self.DQ2_LOCAL_SITE_ID = DQ2_LOCAL_SITE_ID
        self.name = self.dataset
        self.report = report
        self.nrFileThreads = nrFileThreads
        self.timeout = timeout
        self.debug = debug
        self.protocol = protocol
        self.toStorage = toStorage
        self.skipCheck = skipCheck
        self.destinationDirectory = destinationDirectory
        self.nsample = nsample
        self.toStorageToken = toStorageToken
        self.dryRun = dryRun
        
        if self.toStorage is not None:
            self.protocol = 'lcg'
        
        self.report['dataset'] = self.dataset
        self.report['version'] = self.version
        self.report['duid'] = dataset[5].replace('-','')
  
    def __checkForPermissions(self,site_to_access):
        """
        @since: 0.3.0
        """
    
        user_fqans = get_fqans()    
        
        # If list returned is empty then that means user does not have permissions to perform get 
        if not has_permission(fqans=user_fqans,site=site_to_access,permission=PermissionType.READ):
            err_msg = 'Missing the right role to read to this end-point ' + site_to_access
            self.report['CLIENTSTATE'] = 'NO_PERM'
            raise DQInvalidRequestException(err_msg) 
  
    def run(self):
        """
        @since: 0.0.1
        """
        
        try:
            
            #specific directory? check if full or relative path (assume cwd)
            
            if self.destinationDirectory is not None:

                if not self.destinationDirectory.startswith('/'):
                    self.destinationDirectory = '%s/%s'%(os.getcwd(),self.destinationDirectory)
                
                if os.path.isdir(self.destinationDirectory):
                    print '%s: Directory %s already exists'%(self.name, self.destinationDirectory)
                else:
                    os.makedirs(self.destinationDirectory)
                
            #separate directory per dataset?
            elif not self.noDirectories:
                if os.path.isdir(self.dataset):
                    print '%s: Directory %s already exists'%(self.name, self.dataset)
                else:
                    os.makedirs(self.dataset)

            sites, complete, incomplete = self.__chooseSites()
    
            if len(sites):

                GUIDs = self.__getDict()

                if self.dryRun:
                    self.report['clientState'] = 'DRY_RUN'
                    print '%s: Dry run complete'%self.name
                    if len(GUIDs):
                            print 'The following files failed validation:'
                    for guid in GUIDs:
                        print '%s: %s'%(guid, GUIDs[guid])
                    print '%s files failed'%len(GUIDs)
                    self.__sendReport()
                elif not len(GUIDs):
                    self.report['clientState'] = 'NO_FILES'
                    print '%s: No files in dataset or no files left to transfer'%self.name
                    self.__sendReport()
                else:
                    tmp_sites = []
                    if len(complete) > 0:
                        print '%s: Complete replica available'%self.name
                        tmp_sites = [sites[0]]
                    else:
                        print '%s: No complete replica available, trying to gather pieces from incomplete sources'%self.name
                        tmp_sites = sites

                    for site in tmp_sites:

                        print '%s: Using site %s'%(self.name, site)
    
                        self.report['remoteSite'] = site
                        self.__checkForPermissions(site)
    
                        SURLs = {}
                        
                        self.report['clientState'] = 'QUERY_LFC'
                        print '%s: Querying local file catalogue of site %s...'%(self.name, site)
                        sys.stdout.flush()
                        catalog = create_file_catalog(TiersOfATLAS.getLocalCatalog(site))
                        catalog.connect()
                        self.report['catStart'] = time.time()
                        tmp_ret2 = catalog.bulkFindReplicas(GUIDs)
                        tmp_ret = catalog.filterSiteReplicas(tmp_ret2,[site])
                        catalog.disconnect()
                        
                        #do we only want a random sample?
                        if self.nsample is not None:
                            
                            if self.nsample > len(tmp_ret):
                                print '%s: Number of requested samples too large, selecting everything'%self.name
                            else:
                                new_tmp = {}
                                
                                if self.destinationDirectory is not None:
                                    oldDir = self.destinationDirectory
                                elif self.noDirectories:
                                    oldDir = os.getcwd()
                                else:
                                    oldDir = '%s/%s'%(os.getcwd(), self.dataset)
                                
                                for file in random.sample(tmp_ret, self.nsample):
                                    new_tmp[file]=tmp_ret[file]
                                
                                oldFiles = [oldFile for oldFile in os.walk(oldDir)][0][2]
                                
                                tmp_ret = new_tmp
                            
                                newFiles = [tmp_ret[guid]['lfn'] for guid in tmp_ret.keys()]
                                
                                for oldFile in oldFiles:
                                    if oldFile in newFiles:
                                        #print '%s already selected'%oldFile  
                                        pass
                            
                        #build the source and destination paths
                        for guid in tmp_ret:
                            srm = str(random.choice(tmp_ret[guid]['surls']))

                            #do we want the datasets directly on mass storage, organised in folders, somewhere specific, or . ?
                            if self.destinationDirectory is not None:
                                SURLs[guid] = (srm, 'file:///%s%s' % (self.destinationDirectory, srm[string.rfind(srm,'/'):]), srm[string.rfind(srm,'/')+1:], tmp_ret[guid]['checksum'], guid)
                            elif self.toStorage is not None:
                                if self.noDirectories:
                                    SURLs[guid] = (srm, '%s/%s'%(self.toStorage, srm[string.rfind(srm,'/'):]), srm[string.rfind(srm,'/')+1:], tmp_ret[guid]['checksum'], guid)
                                else:
                                    SURLs[guid] = (srm, '%s/%s/%s'%(self.toStorage, self.dataset, srm[string.rfind(srm,'/'):]), srm[string.rfind(srm,'/')+1:], tmp_ret[guid]['checksum'], guid)
                            elif self.noDirectories:
                                SURLs[guid] = (srm, 'file:///%s%s' % (os.getcwd(), srm[string.rfind(srm,'/'):]), srm[string.rfind(srm,'/')+1:], tmp_ret[guid]['checksum'], guid)
                            else:
                                SURLs[guid] = (srm, 'file:///%s/%s%s' % (os.getcwd(), self.dataset, srm[string.rfind(srm,'/'):]), srm[string.rfind(srm,'/')+1:], tmp_ret[guid]['checksum'], guid)

                        fileThreads = ThreadPool(self.nrFileThreads)
                        
                        self.report['clientState'] = 'WORK_FILES'
                        
                        #create all necessary threads
                        for file in SURLs:
                            current =  FileThread(self.dataset, SURLs[file], self.DQ2_LOCAL_SITE_ID, site, self.noDirectories, self.protocol, self.debug, self.report, self.toStorage, self.destinationDirectory,  self.toStorageToken, self.timeout)
                            work = WorkRequest(current.run)
                            fileThreads.putRequest(work)
    
                        fileThreads.wait()
        
            else:
                self.report['state'] = 'NO_SITES'
        
        except:
            excType, excValue, excStack = sys.exc_info()
            print excValue
            self.__sendReport()
        
    def __chooseSites(self):
        """
        @since: 0.0.1
        """
        
        
        self.report['clientState'] = 'QUERY_REPLICAS'
        print '%s: Querying DQ2 central catalogues for replicas...'%self.name
        sys.stdout.flush()
        ret = DQ2().listDatasetReplicas(dsn=self.dataset, version=self.version, complete=self.complete)
        if not len(ret):
            print '%s: No replicas found!'%self.name
            return [],[],[]
        else:

            #gather complete and incomplete datasets
            complete = {}
            incomplete = {}
            
            i = 1
            for site in ret[ret.keys()[0]][0]:
                incomplete[i] = {'siteName' : site}
                i += 1
                
            for site in ret[ret.keys()[0]][1]:
                complete[i] = {'siteName' : site}
                i += 1 
            
            if self.remote is not None:
                if self.remote not in ret[ret.keys()[0]][1]:
                    print '%s: No complete replica found at given site!'%self.name
                    if self.remote not in ret[ret.keys()[0]][0]:
                        print '%s: No incomplete replica found at given site!'%self.name
                        return ([], complete, incomplete)
                    else:
                        print '%s: Using incomplete replica at given site'%self.name
                        return ([self.remote], complete, incomplete)
                else:
                    print '%s: Using complete replica at given site'%self.name
                    return ([self.remote], complete, incomplete)
    
            """
            DQ2Clients load-balancing AI(tm)
            """
    
            sitesToTry = []
            myCloud = 'ALL'
            closeSites = []
            
            mySitePrefix = self.DQ2_LOCAL_SITE_ID.split('_')[0]
            if self.DQ2_LOCAL_SITE_ID != 'ROAMING':
                myCloud = TiersOfATLAS.whichCloud(self.DQ2_LOCAL_SITE_ID)
            
            if myCloud is None:
                print 'Your configured site is not recognised. Make sure you use a ToA site name! Close-sites optimisations is not possible.'
                myCloud = 'ALL'
            
            sitesInMyCloud = TiersOfATLAS._resolveSites(myCloud)
            if self.DQ2_LOCAL_SITE_ID != 'ROAMING':
                closeSites = TiersOfATLAS.getCloseSites(self.DQ2_LOCAL_SITE_ID)
            
            goodComplete = []
            badComplete = []
            uglyComplete = []
            
            goodIncomplete = []
            badIncomplete = []
            uglyIncomplete = []
            
            for site in complete:
                sn = complete[site]['siteName']
                if sn.endswith('DISK'):
                    if sn.startswith(mySitePrefix) and sn not in goodComplete:
                        goodComplete.append(sn)
                    elif sn in sitesInMyCloud and sn not in badComplete:
                        badComplete.append(sn)
                    elif sn in closeSites and sn not in badComplete:
                        badComplete.append(sn)

                if sn not in goodComplete and sn not in badComplete and sn not in uglyComplete:
                    uglyComplete.append(sn)

            for site in incomplete:
                sn = incomplete[site]['siteName']
                if sn.endswith('DISK'):
                    if sn.startswith(mySitePrefix) and sn not in goodIncomplete: 
                        goodIncomplete.append(sn)
                    elif sn in sitesInMyCloud and sn not in badIncomplete:
                        badIncomplete.append(sn)
                    elif sn in closeSites and sn not in badIncomplete:
                        badIncomplete.append(sn)

                if sn not in goodComplete and sn not in badComplete and sn not in uglyComplete:
                    uglyComplete.append(sn)

            
            #try to spread over combinations
            random.shuffle(goodComplete)
            random.shuffle(badComplete)
            random.shuffle(uglyComplete)
            random.shuffle(goodIncomplete)
            random.shuffle(badIncomplete)
            random.shuffle(uglyIncomplete)
            
            for site in goodComplete:
                if site not in sitesToTry:
                    sitesToTry.append(site)
            for site in badComplete:
                if site not in sitesToTry:
                    sitesToTry.append(site)

            for site in goodIncomplete:
                if site not in sitesToTry:
                    sitesToTry.append(site)
            for site in badIncomplete:
                if site not in sitesToTry:
                    sitesToTry.append(site)

            for site in uglyComplete:
                if site not in sitesToTry:
                    sitesToTry.append(site)
            for site in uglyIncomplete:
                if site not in sitesToTry:
                    sitesToTry.append(site)
    
            #is it a valid Tiers of ATLAS site? (if not, we have a serious problem)
            for site in sitesToTry:
                TiersOfATLASValidator.is_site(site)
   
            return sitesToTry, complete, incomplete
        
    def __getDict(self):
        """
        @since: 0.0.1
        
        Get the dict (guid->lfn) of files from the central catalogues
        for either all the files in the dataset, or only the ones selected
        """
        
        files = {}
        
        self.report['clientState'] = 'QUERY_FILES_IN_DS'
        print 'Querying DQ2 central catalogues for files in dataset...'
        sys.stdout.flush()
        tmp_ret = DQ2().listFilesInDataset(dsn=self.dataset, version=self.version)

        if not len(tmp_ret):
            return []
        else:
            #do we only want certain files?
            if len(self.files):
                lfnsInDataset = []
                for entry in tmp_ret[0]:
                    lfnsInDataset.append(tmp_ret[0][entry]['lfn'])
                    lfnsInDataset.append(tmp_ret[0][entry]['checksum'])
                    lfnsInDataset.append(tmp_ret[0][entry]['filesize'])

                #match wildcards
                for lfn in self.files:
                    if '*' in lfn:
                        lfn = lfn.replace('*','.*')
                        for guid in tmp_ret[0]:
                            tmp = re.search(lfn,tmp_ret[0][guid]['lfn'])
                            if tmp is not None:
                                files[guid] = tmp_ret[0][guid]
                                files[guid]['lfn'] = tmp_ret[0][guid]['lfn']
                                files[guid]['checksum'] = tmp_ret[0][guid]['checksum']
                                files[guid]['filesize'] = tmp_ret[0][guid]['filesize']
                    else:
                        if lfn in lfnsInDataset:
                            for guid in tmp_ret[0]:
                                if tmp_ret[0][guid]['lfn'] == lfn:
                                    files[guid] = tmp_ret[0][guid]
                                    files[guid]['lfn'] = tmp_ret[0][guid]['lfn']
                                    files[guid]['checksum'] = tmp_ret[0][guid]['checksum']
                                    files[guid]['filesize'] = tmp_ret[0][guid]['filesize']
                        else:
                            print '%s: Not in this dataset: %s'%(self.name,lfn)
    
                if not len(files):
                    print '%s: No selected file in this dataset!'%self.name
                        
            else:
                for guid in tmp_ret[0]:
                    files[guid] = tmp_ret[0][guid]
                    files[guid]['lfn'] = tmp_ret[0][guid]['lfn']
                    files[guid]['checksum'] = tmp_ret[0][guid]['checksum']
                    files[guid]['filesize'] = tmp_ret[0][guid]['filesize']
                
            #remove files from list that have been transferred already
            
            if self.destinationDirectory is not None:
                alreadyTransferred = os.listdir(self.destinationDirectory)
            elif self.noDirectories:
                alreadyTransferred = os.listdir('.')
            else:
                alreadyTransferred = os.listdir(self.dataset)
            
            readyToTransfer = {}
            
            #perform a deep check of size and md5sum if the file was transferred before
            for file in files:
                if files[file]['lfn'] in alreadyTransferred:
                    print '%s: %s already transferred, validating'%(self.name, files[file]['lfn'])

                    checksum = None

                    if not self.skipCheck:

                        #set the current directory
                        if self.noDirectories:
                            self.destinationDirectory = os.getcwd()

                        if self.destinationDirectory is not None:

                            size = long(os.stat(self.destinationDirectory+'/'+files[file]['lfn']).st_size)
                                            
                            if files[file]['checksum'] is None:
                                print '%s: %s does not have a checksum! Skipping check!'%(self.name, files[file]['lfn'])
                            elif files[file]['checksum'].startswith('ad:'):
                                checksum = 'ad:'+self.__adler32(self.destinationDirectory+'/'+files[file]['lfn'])
                            else:
                                checksum = 'md5:'+commands.getstatusoutput('md5sum %s'%self.destinationDirectory+'/'+files[file]['lfn'])[1].split()[0]
                        else:
                            size = long(os.stat(self.dataset+'/'+files[file]['lfn']).st_size)
                                            
                            if files[file]['checksum'] is None:
                                print '%s: %s does not have a checksum! Skipping check!'%(self.name, files[file]['lfn'])
                            elif files[file]['checksum'].startswith('ad:'):
                                checksum = 'ad:'+self.__adler32(self.dataset+'/'+files[file]['lfn'])
                            else:
                                checksum = 'md5:'+commands.getstatusoutput('md5sum %s'%self.dataset+'/'+files[file]['lfn'])[1].split()[0]
   
                        
                    if self.skipCheck:
                        print '%s: %s skipped check due to manual override'%(self.name, files[file]['lfn'])
                    elif files[file]['filesize'] is None:
                        print '%s: %s does not have a filesize! Skipping check!'%(self.name, files[file]['lfn'])
                    elif size == long(files[file]['filesize']) and checksum == files[file]['checksum']: 
                        print '%s: %s validated'%(self.name, files[file]['lfn'])
                    else:
                        if self.dryRun:
                            print '%s: %s failed validation'%(self.name, files[file]['lfn'])
                        else:
                            print '%s: %s failed validation, restarting transfer'%(self.name, files[file]['lfn'])
                        readyToTransfer[file] = files[file]['lfn']
                else:
                    readyToTransfer[file] = files[file]['lfn']
            
            return readyToTransfer

    def __sendReport(self):
        """
        @since: 0.0.1
        """

        self.report['timeEnd'] = time.time()
        
        try:
            TracerClient().addReport(self.report)
        except:
            pass
        
    def __adler32(self, file):
        """
        @since: 0.0.1
        """

        #adler starting value is _not_ 0
        adler=1L
        
        try:

            openFile = open(file, 'rb')
            
            for line in openFile:
                adler=zlib.adler32(line, adler)

        except:
            raise Exception('FATAL - could not get checksum of file %s'%file)

        #backflip on 32bit
        if adler < 0:
            adler = adler + 2**32
        
        return str('%08x'%adler) #re
