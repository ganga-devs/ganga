"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: RegisterContainer.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class RegisterContainer (DQDashboardTool):
    """
    @since: 1.0
    @version: $Revision: 1.2 $
    """
    
    usage = '%prog [options] <NAME> '
    
    version = '$Revision: 1.2 $'
    
    description = 'Registers a container.'

    toolOptions = [ ]


    def __init__(self):
        """
        @since: 1.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 1.0
        """
        return self.args[0]


    def execute (self):
        """
        @since: 1.0
        """
        
        dq = getDQ2(self)
        
        name = self._get_parameters()
        
        dq.registerContainer(name)
        
        print 'Container %s was registered.' % (name)