"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: RegisterNewVersion.py,v 1.5 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class RegisterNewVersion (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> (lfn1 guid1 size1 checksum1 lfn2 guid2 size2 checksum2 ...)"
    
    version = "$Revision: 1.5 $"
    
    description = "Register a new dataset version"

    toolOptions = []
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1:])
    
    
    def execute (self):
        """
        @since: 0.3.0
        """
    
        dq = getDQ2(self)
        
        dsn, files = self._get_parameters()
            
        guids = []
        lfns = []
        sizes = []
        checksums = []
        
        for i in range(0, len(files), 4):
            lfns.append(files[i])
            guids.append(files[i+1])
            sizes.append(long(files[i+2]))
            checksums.append(files[i+3])

        version = dq.registerNewVersion(dsn, lfns, guids, sizes, checksums)['version']
        print 'Dataset %s version %u is open.' % (dsn, version)