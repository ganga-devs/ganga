"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: FreezeDataset.py,v 1.4 2009/10/06 13:23:17 angelos Exp $
"""

import time

from dq2.common.cli.DQDashboardTool import DQDashboardTool

import dq2.common.optparse as optparse

from dq2.clientapi.cli.cliutil import getDQ2


class FreezeDataset (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> "
    
    version = "$Revision: 1.4 $"
    
    description = "Freeze Dataset"

    toolOptions = [
                optparse.make_option(
                '-x', '--xml',
                dest='xml',
                default=False,
                action='store_true',
                help='Tier-0 internal: display XML status report') ] 
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
       
        
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]
        
        
    def execute (self):
        """
        @since: 0.3.0
        """

        dq2 = getDQ2(self)
    
        dsn = self._get_parameters()
        
        try:
            start = time.time()
            dq2.freezeDataset(dsn)
            end = time.time()

            if self.options.xml:
    
                print
                print '<returnValue>'
                
                print ' <errorCode>'
                print '  <int>0</int>'
                print ' </errorCode>'
                
                print ' <dq2>'
                print '  <float>%s</float>'%(float(end)-float(start))
                print ' </dq2>'
    
                print '</returnValue>'
                print
                
            print "Dataset %s frozen" % (dsn)

        except:
            #make sure we propagate the exception
            if self.options.xml:

                print
                print '<returnValue>'
                
                print ' <errorCode>'
                print '  <int>1</int>'
                print ' </errorCode>'
                
                print ' <dq2>'
                print '  <float>%s</float>'%(time.time()-float(start))
                print ' </dq2>'
    
                print '</returnValue>'
                print
                
            raise
        
