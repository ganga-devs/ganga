"""
(since 0.3.1)
"""
import cliutil

from dq2.common import optparse
from dq2.common.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2, option_value

from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationConstants import ConsistencyCheckState

class ListDatasetReplicaState(DQDashboardTool):
    """
    (since 0.3.1)
    """

    usage = "%prog [options] <DATASET> <SITENAME> "
    
    version = "$Revision: 1.1 $"
    
    description = "List Dataset Replica State In Site"
 
    toolOptions = [
        cliutil.opt_dataset_version
    ]
    
    
    def _get_parameters (self):
        """
        (since 0.3.1)
        """
        return self.args[0]
 
    
    def __init__ (self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
    
    
    
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return (self.args[0], self.args[1])
                
    def execute(self):
        """
        (since 0.3.0)
        """

        dq = getDQ2(self)
    
                
    def execute(self):
        """
        (since 0.3.0)
        """

        dq = getDQ2(self)
    
        location = self._get_parameters()
        
        
        out = ''
        
        dsn, location = self._get_parameters()         
        ret = dq.listDatasetReplicaState(location=location, dsn=dsn, version=self.options.version)
        
        print dq.getNumberOfFiles(dsn=dsn, version=self.options.version)
        if ret['status'] == 0:
            if ret['state']==LocationState.COMPLETE:
                print 'State: COMPLETE'
            elif  ret['state']==LocationState.INCOMPLETE:
                print 'State: INCOMPLETE'
                                
            if ret['ConsistencyCheck'] == ConsistencyCheckState.WAITING: 
                print 'Consistency check request: WAITING'                 
            elif ret['ConsistencyCheck'] == ConsistencyCheckState.QUEUED:
                print 'Consistency check request: QUEUED' 
            elif ret['ConsistencyCheck'] == ConsistencyCheckState.RUNNING:
                print 'Consistency check request: RUNNING'                
            elif ret['ConsistencyCheck'] == ConsistencyCheckState.DONE:
                print 'Consistency check request: DONE'                
                print 'File missings: '+str(len(ret['guids']))#+'/'+str(dq.getNumberOfFiles(dsn)) + '~' + str(len(ret['guids'])/dq.getNumberOfFiles(dsn))
                #, guids=' + str(ret['guids'])                                 
            elif ret['ConsistencyCheck'] == ConsistencyCheckState.NOT_CHECKED:
                print 'Consistency check request: NOT_CHECKED'                
            
            print 'Last modified Date: ' + ret['modifieddate']               
        else:
            print ret['msg']