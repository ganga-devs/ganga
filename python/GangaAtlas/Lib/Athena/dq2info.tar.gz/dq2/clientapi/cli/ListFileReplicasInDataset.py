"""
(since 0.3.0)

$Id: ListFileReplicasInDataset.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""

import sys
import cliutil

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.location.DQLocationConstants import TransferState
from dq2.location.DQLocationConstants import MutableState


class ListFileReplicasInDataset (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog <DATASET> <SITE>"
    
    version = "$Revision: 1.2 $"
    
    description = "List Files In Dataset Replica"

    toolOptions = [
                   cliutil.opt_dataset_version
                   ]
    
    
    def __init__ (self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0], self.args[1]
    
    
    def execute (self):
        """
        (since 0.3.0)
        """
    
        dq = getDQ2(self)
        
        
        dsn, location = self._get_parameters()
        out = ''
        hadNone = False
        count = 0
        size = 0
        count2 = 0
        size2 = 0

        
        import sys
        
        ret = dq.listFileReplicas(dsn=dsn, version=self.options.version, location=location)
        
        if not ret:
            print 'No dataset replica found'
            sys.exit(-1)
        
        ret = ret[0]            
        
        #if ret['immutable'] == MutableState.MUTABLE:
            #print 'Dataset is immutable'
            #sys.exit(-1)
            
        #if ret['transferState'] == TransferState.ACTIVE:
            #print 'Dataset replica is on transfer'
            #sys.exit(-1)

        if ret['checkstate'] != 6:
            print 'Checking dataset replica, content not available'
            sys.exit(-1)
        
        guids = ret['content']        
          
        ret2 = dq.listFilesInDataset(dsn=dsn, version=self.options.version)

        try:
            entry = ret2[0]
        except IndexError, e:
            print 'No files in dataset'
            sys.exit(-1)
        
                                        
        for guid in entry:
            fs = entry[guid]['filesize']            
            if guid in guids:
                print entry[guid]['lfn'],
                print "\t%s" % guid,
                if entry[guid]['checksum'] is not None:
                    print "\t%s" % entry[guid]['checksum'],
                if fs is not None:
                    print "\t%s" % fs,
                print
                
            if guid in guids:                
                count2 += 1
                if fs is None:
                    hadNone = True
                else:
                    size2 += fs
                
            count += 1
            if fs is None:
                hadNone = True
            else:
                size += fs
        print out
        if ret['immutable'] == MutableState.MUTABLE:
            print 'State: open'
            
        if ret['transferState'] == TransferState.ACTIVE:
            print 'Transfer state : active'
        
        print 'total files: %u/%u' % (count2,count)
        if not hadNone:
            print 'total size: %s/%u' % (size2,size)
#        print 'date: %s' % (ret[1])