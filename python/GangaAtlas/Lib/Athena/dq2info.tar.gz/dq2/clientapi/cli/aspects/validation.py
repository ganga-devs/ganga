"""
DQ2 validation aspect.

@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: validation.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""


import dq2.common.validator.DQValidator
import dq2.info.TiersOfATLASValidator
import dq2.subscription.DQSubscriptionValidator
import dq2.location.DQLocationValidator


from dq2.location.DQLocationConstants import LocationState
from dq2.subscription.DQSubscriptionConstants import SourcesPolicy, SubscriptionArchivedState
from dq2.common.aspects import wrap_around, wrap_around_re


def wrap_package ():
    """
    @since: 0.3.0
    """
    
    wrap_commandline()


def wrap_commandline ():
    """
    @since: 0.3.0
    """
    from dq2.clientapi.cli.DQCommandLine import DQCommandLine
    
    wrap_around (DQCommandLine.__init__, command_line)


def command_line (self, *args, **kwargs):
    """
    
    @since: 0.3.0
    """
    import sys
    
    from dq2.clientapi.cli.DQClientConstants import Actions
    
    arguments = sys.argv[1:]
    
    if len(arguments) < 1:
        """insufficient number of arguments"""
        print self.usage()
        print "Insufficient or missing arguments!"
        print
        sys.exit(1)
    
    self.__proceed(*args, **kwargs)
    
    if self.command not in Actions:
        """checking command"""
        #print self.usage()
        print "Unknown command: %s" % (self.command)
        print
        sys.exit(2)
    
    if not check_arguments(self.command, self.args):
        """checking command arguments"""
        #print self.usage()
        print "Invalid or missing arguments!"
        print
        sys.exit(2)


def check_arguments (command, arguments):
    """
    
    (since 0.1.4)
    
    """
    from dq2.clientapi.cli.DQClientConstants import Actions
    
    # check action and number of arguments.
    try:
        # arguments are args minus action
        nargs = len(arguments)
        #print 'nargs   : '+ str(nargs)
        #print str(arguments)
        # get number of mandatory args and whether there is a limit
        nm = Actions[command][0]
        nolimit = Actions[command][1]
        
        #print 'nm      : '+ str(nm)
        #print 'nolimit : '+ str(nolimit)
        
        if nargs < nm or (nargs > nm and not nolimit):
            """check if number of args is correct"""
            print nargs > nm and not nolimit
            return False
        
        if nolimit and Actions[command][2] and (len(arguments)-nm)%2 == 1:
            print 'Error: you must give matching pairs of arguments'
            return False
    except:
        return False
    return True

