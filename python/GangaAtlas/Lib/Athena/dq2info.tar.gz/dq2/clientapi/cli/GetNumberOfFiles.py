"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: GetNumberOfFiles.py,v 1.7 2009/10/06 13:23:18 angelos Exp $
"""


import cliutil


from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class GetNumberOfFiles (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> "
    
    version = "$Revision: 1.7 $"
    
    description = "Get Number Of Files in Dataset"

    toolOptions = [
                   cliutil.opt_dataset_version
                   ]
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]
    
        
    def execute (self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
        
        dsn = self._get_parameters()
        
        print dq.getNumberOfFiles(dsn, version=self.options.version)