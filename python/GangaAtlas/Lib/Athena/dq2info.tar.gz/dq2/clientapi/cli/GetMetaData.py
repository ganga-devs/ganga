"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: GetMetaData.py,v 1.6 2009/10/06 13:23:17 angelos Exp $
"""

import string

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.common.DQConstants import DatasetState

from dq2.common.constants import Metadata

import cliutil


class GetMetaData (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = '%prog [options] <DATASET>'
    
    version = "$Revision: 1.6 $"
    
    description = "Get MetaData for Dataset"

    toolOptions = [ cliutil.opt_dataset_version ]
    
    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1:])

        
    def execute (self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
        
        dsn, attributes = self._get_parameters()
        
        if attributes == []:
            for elem in Metadata.DATASET:
                attributes.append(elem)
            for elem in Metadata.DATASET_VERSION:
                attributes.append(elem)
            for elem in Metadata.USER_DATASET:
                attributes.append(elem)
            for elem in Metadata.USER_VERSION:
                attributes.append(elem) 
        
        out = ''
        metadata = dq.getMetaDataAttribute(dsn, attributes, self.options.version)
        out += string.ljust('name', 19) +' : '+ str(dsn) +'\n'

        keys = metadata.keys()
        keys.sort()

        for eachAttribute in keys:
            if eachAttribute == 'state':
                metadata[eachAttribute] = DatasetState.DESCRIPTION[metadata[eachAttribute]]
            out += string.ljust(eachAttribute, 19) +' : '+ str(metadata[eachAttribute]) +'\n'

        print out