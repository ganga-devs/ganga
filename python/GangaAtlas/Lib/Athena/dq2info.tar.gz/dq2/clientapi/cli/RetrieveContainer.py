"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: RetrieveContainer.py,v 1.2 2008/03/03 15:13:36 psalgado Exp $
"""

from dq2.common.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class RetrieveContainer (DQDashboardTool):
    """
    @since: 1.0
    @version: $Revision: 1.2 $
    """
    
    usage = '%prog [options] <NAME> '
    
    version = '$Revision: 1.2 $'
    
    description = 'Retrieves elements of a container.'

    toolOptions = [ ]


    def __init__(self):
        """
        @since: 1.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 1.0
        """
        return self.args[0]


    def execute (self):
        """
        @since: 1.0
        """
        
        dq = getDQ2(self)
        
        name = self._get_parameters()
        
        for dsn, version in dq.retrieveElements(name=name).iteritems():
            if version == 0:
                print '    [D] %s' % (dsn)
            else:
                print '    [V][%u] %s' % (version, dsn)

