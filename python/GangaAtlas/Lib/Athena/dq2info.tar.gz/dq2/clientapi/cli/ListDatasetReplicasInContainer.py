"""
@author: Vincent Garonne
@contact: vincent.garonne@cern.ch
@since: 0.3
@version: $$
"""

import sys, string
import cliutil

from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common                 import optparse

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationConstants import TransferState
from dq2.location.DQLocationConstants import MutableState

class ListDatasetReplicasInContainer (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog <DATASET> "
    
    version = "$Revision: 1.2 $"
    
    description = "List Dataset Replicas In Container"

    toolOptions = [
        optparse.make_option(
            "-i", "--incomplete",
            action="store_true",
            dest="incomplete",
            default=False,
            help="only list incomplete datasets"
        ),
        optparse.make_option(
             "-c", "--complete",
             action="store_true",
             dest="complete",
             default=False,
             help="only list complete datasets"
         )
        ]
        
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]


    def execute (self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
                
        name = self._get_parameters()

        complete = LocationState.__ANY__
        if self.options.complete:
            complete = LocationState.COMPLETE
        if self.options.incomplete:
            complete = LocationState.INCOMPLETE
        
        ret    = dq.listDatasetReplicasInContainer(name)        
        report = {}
                
#                
        out = ''
        for dataset in ret:
            out += '%s: \n'%(dataset)
            if ret[dataset]:
                if complete == LocationState.__ANY__ or complete == LocationState.INCOMPLETE:
                    out += "\t INCOMPLETE: " % ()
                    sites =  ret[dataset][ret[dataset].keys()[0]]
                    sites[LocationState.INCOMPLETE].sort()                 
                    for eachSite in sites[LocationState.INCOMPLETE]:
                        if not eachSite  in report: 
                            report[eachSite]= {LocationState.COMPLETE:  0 , LocationState.INCOMPLETE: 0}
                        report[eachSite][LocationState.INCOMPLETE] += 1
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)]
                out += '\n'
                if complete == LocationState.__ANY__ or complete == LocationState.COMPLETE:
                    out += "\t COMPLETE: " % ()
                    if  ret[dataset]:
                        sites =  ret[dataset][ ret[dataset].keys()[0]]
                        sites[LocationState.COMPLETE].sort()                    
                    for eachSite in sites[LocationState.COMPLETE]:
                        if not eachSite  in report: 
                            report[eachSite]= {LocationState.COMPLETE:  0 , LocationState.INCOMPLETE: 0}
                        report[eachSite][LocationState.COMPLETE] += 1                                                    
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)] + '\n'
            else:
                 out += ' No replicas found \n' 
       
        print out
        if ret:
            # Sort sites
            sites = report.keys()
            sites.sort()
            # Get largest string size of sites            
            lpad  = 0
            for site in sites:
                if lpad < len(site):
                    lpad = len(site)
            
            print 'Container name: %s' % (name)
            print 'Total  datasets: %u' % (len(ret))
            print 'Summary:'
            print '\t%s / %s / %s / %s '%(string.ljust('SITE', lpad),string.ljust('# COMPLETE', 10), string.ljust('# INCOMPLETE', 10), string.ljust(' TOTAL', 10))
            print '\t--------------------------------------------------------------------------'
            for site in sites:
                print '\t%s    %s    %s    %s  '%(string.ljust(site, lpad), 
                                               string.ljust(str(report[site][LocationState.COMPLETE]), 10),
                                               string.ljust(str(report[site][LocationState.INCOMPLETE]), 10),
                                               string.ljust(str(report[site][LocationState.COMPLETE]+report[site][LocationState.INCOMPLETE]), 10)                                                                                  
                                   )                