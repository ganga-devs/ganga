"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: SetReplicaMetaDataAttribute.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class SetReplicaMetaDataAttribute (DQDashboardTool):
    """
    @since: 0.3.0
    """
    
    usage = "%prog [options] <DATASET> <LOCATION> <ATTRIBUTE> <VALUE>"
    
    version = "$Revision: 1.2 $"
    
    description = "Set Replica MetaData Attribute"

    toolOptions = [ ]
    
    def __init__ (self):
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """

        return (self.args[0], self.args[1], self.args[2], self.args[3])
        
    def execute (self):
        """
        @since: 0.3.0
        """
        try:
            dq = getDQ2(self)
        
            dsn, location, attribute, value = self._get_parameters()
            
            if dq.setReplicaMetaDataAttribute(dsn, location, attribute, value):        
                print "Metadata attribute %(attribute)s set with value %(value)s for %(dsn)s-%(location)s " % locals()
            else:
                print "Metadata attribute %(attribute)s not set with value %(value)s for %(dsn)s-%(location)s " % locals()                
        except IndexError:
            print "please provide <DATASET> <LOCATION> <ATTRIBUTE> <VALUE>"