"""
DQ2 command line exception handling aspect.

@author: Mario Lassnig
@contact: mario.lassnig@cern.ch
@since: 0.3
@version: $Id: exception.py,v 1.10 2009/10/06 13:23:17 angelos Exp $

status code:

STATUS_OK  : ok
STATUS_ERROR_CMD : error retrieving parameters
STATUS_ERROR_DQ : error on DQ
STATUS_ERROR_UNEXPECTED : unexpected error
"""

STATUS_OK = 0
STATUS_ERROR_CMD = -1
STATUS_ERROR_DQ = -2
STATUS_ERROR_UNEXPECTED = -3


import sys

from dq2.common.aspects import wrap_around

from dq2.common.DQException import DQException


def wrap_package ():
    """
    @since: 0.3.0
    """
    from dq2.clientapi.cli.CloseDataset import CloseDataset
    from dq2.clientapi.cli.EraseDataset import EraseDataset
    from dq2.clientapi.cli.DeleteContainerSubscription import DeleteContainerSubscription
    from dq2.clientapi.cli.DeleteDatasetReplicas import DeleteDatasetReplicas
    from dq2.clientapi.cli.DeleteDatasetSubscription import DeleteDatasetSubscription
    from dq2.clientapi.cli.DeleteFilesFromDataset import DeleteFilesFromDataset
    from dq2.clientapi.cli.FreezeDataset import FreezeDataset
    from dq2.clientapi.cli.GetMetaData import GetMetaData
    from dq2.clientapi.cli.GetNumberOfFiles import GetNumberOfFiles
    from dq2.clientapi.cli.ListDatasetReplicas import ListDatasetReplicas
    from dq2.clientapi.cli.ListDatasets import ListDatasets
    from dq2.clientapi.cli.ListDatasetsByCreationDate import ListDatasetsByCreationDate
    from dq2.clientapi.cli.ListDatasetsByMetaData import ListDatasetsByMetaData
    from dq2.clientapi.cli.ListDatasetsInSite import ListDatasetsInSite
    from dq2.clientapi.cli.ListDestinations import ListDestinations
    from dq2.clientapi.cli.ListFilesInDataset import ListFilesInDataset
    from dq2.clientapi.cli.ListFileReplicasInDataset import ListFileReplicasInDataset
    from dq2.clientapi.cli.ListMetaDataAttributes import ListMetaDataAttributes
    from dq2.clientapi.cli.ListSources import ListSources
    from dq2.clientapi.cli.ListSubscriptionInfo import ListSubscriptionInfo
    from dq2.clientapi.cli.ListSubscriptions import ListSubscriptions
    from dq2.clientapi.cli.ListSubscriptionsInSite import ListSubscriptionsInSite
    from dq2.clientapi.cli.Ping import Ping
    from dq2.clientapi.cli.RegisterContainerSubscription import RegisterContainerSubscription
    from dq2.clientapi.cli.RegisterDataset import RegisterDataset
    from dq2.clientapi.cli.RegisterDatasetLocation import RegisterDatasetLocation
    from dq2.clientapi.cli.RegisterDatasetSubscription import RegisterDatasetSubscription
    from dq2.clientapi.cli.RegisterFilesInDataset import RegisterFilesInDataset
    from dq2.clientapi.cli.RegisterNewVersion import RegisterNewVersion
    from dq2.clientapi.cli.ResetSubscription import ResetSubscription
    from dq2.clientapi.cli.ResetSubscriptionsInSite import ResetSubscriptionsInSite
    
    from dq2.clientapi.cli.ListDatasetReplicasInContainer import ListDatasetReplicasInContainer
    from dq2.clientapi.cli.ListMetaDataReplica            import ListMetaDataReplica
    from dq2.clientapi.cli.RegisterCompletenessRefresh    import RegisterCompletenessRefresh
    
    from dq2.clientapi.cli.ListDeletedReplicas            import ListDeletedReplicas
    from dq2.clientapi.cli.ListGarbageCollectedReplicas   import ListGarbageCollectedReplicas
    from dq2.clientapi.cli.ListGarbageCollectedFiles      import ListGarbageCollectedFiles
    
    from dq2.clientapi.cli.DeleteDatasetsFromContainer import DeleteDatasetsFromContainer
    from dq2.clientapi.cli.ListDatasetsInContainer     import ListDatasetsInContainer
    from dq2.clientapi.cli.RegisterDatasetsInContainer import RegisterDatasetsInContainer
    from dq2.clientapi.cli.RegisterContainer           import RegisterContainer
    
    from dq2.clientapi.cli.ListDatasetReplicaHistory   import ListDatasetReplicaHistory        
    from dq2.clientapi.cli.GetUsage                    import GetUsage   
     
    from dq2.clientapi.cli.SetReplicaMetaDataAttribute import SetReplicaMetaDataAttribute
    
    for eachClass in [
        CloseDataset,
        DeleteContainerSubscription,
        DeleteDatasetReplicas, DeleteDatasetSubscription, DeleteFilesFromDataset,
        FreezeDataset, EraseDataset,
        GetMetaData, GetNumberOfFiles,
        ListDatasetReplicas, ListDatasetReplicasInContainer,
        ListDatasets, ListDatasetsByCreationDate,
        ListDatasetsByMetaData, ListDatasetsInSite, ListDestinations,
        ListFilesInDataset, ListMetaDataAttributes, ListSources,
        ListSubscriptionInfo, ListSubscriptions, ListSubscriptionsInSite,
        Ping,
        RegisterContainerSubscription,
        RegisterDataset, RegisterDatasetLocation, RegisterDatasetSubscription,
        RegisterFilesInDataset, RegisterNewVersion, ResetSubscription,
        ResetSubscriptionsInSite, ListFileReplicasInDataset, ListMetaDataReplica,
        RegisterCompletenessRefresh,
        ListDeletedReplicas, ListGarbageCollectedReplicas, ListGarbageCollectedFiles,
        DeleteDatasetsFromContainer, ListDatasetsInContainer, RegisterDatasetsInContainer,
        RegisterContainer, ListDatasetReplicaHistory, GetUsage, SetReplicaMetaDataAttribute
    ]:
        wrap_around (eachClass.__init__, init)
        wrap_around (eachClass._get_parameters, get_parameters)
        wrap_around (eachClass.execute, execute)


def execute (self):
    """
    @since: 0.3.0
    """
    try:
        self.__proceed()
    except DQException, e:
        print 'Error: %s' % (e)    
        sys.exit(STATUS_ERROR_DQ)
    except [IndexError, ValueError], e:
        print self.index_error
        sys.exit(STATUS_ERROR_CMD)
    except StandardError, e:
        print self.index_error
        print 'Error: %s [%s]' % (e, e.__class__.__name__)   
        sys.exit(STATUS_ERROR_UNEXPECTED)
    
    sys.exit(STATUS_OK)


def get_parameters (self):
    """
    @since: 0.3.0
    """
    try:
        return self.__proceed()
    except IndexError:
        print self.index_error
        sys.exit(STATUS_ERROR_CMD)


def init (self):
    """
    @since: 0.3.0
    """

    self.__proceed()
    
    ltIdx = self.usage.find('<')
    
    self.index_error = 'please provide %s' % (self.usage[ltIdx:])