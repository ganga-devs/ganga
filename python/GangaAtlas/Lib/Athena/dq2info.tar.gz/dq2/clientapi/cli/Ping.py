"""
@author: Mario Lassnig
@contact: mario.lassnig@cern.ch
@since: 0.3
@version: $Id: Ping.py,v 1.3 2009/10/06 13:23:18 angelos Exp $
"""

import socket

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class Ping (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <SITENAME> "
    
    version = "$Revision: 1.3 $"
    
    description = "Ping the DQ2 servers"

    toolOptions = []
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
    def execute (self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
        
        result = dq.ping()
        
        for entry in result:
            print '%s:\tinsecure: %s\tsecure: %s\talive: %s'%(entry,result[entry][0],result[entry][1],result[entry][2])