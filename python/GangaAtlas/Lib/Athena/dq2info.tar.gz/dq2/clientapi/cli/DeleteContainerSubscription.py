"""
Delete container subscription command.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.9
@version: $Id: DeleteContainerSubscription.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""

import cliutil

from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common.DQException import DQException

from dq2.clientapi.cli.cliutil import getDQ2, option_value


class DeleteContainerSubscription(DQDashboardTool):
    """
    @since: 0.3.9
    """

    usage = '%prog [options] <CONTAINER> <SITENAME>'

    version = '$Revision: 1.2 $'

    description = 'Delete Subscription of Container'

    toolOptions = [
        cliutil.opt_dataset_version
    ]


    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1])


    def execute (self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
        
        dsn, site = self._get_parameters()
        
        for dataset in dq.listDatasetsInContainer(dsn):
            """go through all data sets of the container"""
            
            try:
                dq.deleteDatasetSubscription(dataset, site)
                print 'Subscription for dataset %s replica at %s deleted' % (dsn, site)
            except DQException, e:
                print str(e)
