"""
@since: 0.3.0

$Id: ListDatasetReplicas.py,v 1.9 2009/10/06 13:23:17 angelos Exp $
"""

"""
(since 0.3.0)

$Id: ListDatasetReplicas.py,v 1.9 2009/10/06 13:23:17 angelos Exp $
"""


from dq2.common import optparse

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from  dq2.clientapi.cli         import cliutil
from dq2.clientapi.cli.cliutil import getDQ2, option_value

from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationConstants import TransferState
from dq2.location.DQLocationConstants import MutableState
    

class ListDatasetReplicas (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog [options] <DATASET>"
    
    version = "$Revision: 1.9 $"
    
    description = "List Dataset Replicas"

    toolOptions = [
        optparse.make_option(
            "-i", "--incomplete",
            action="store_true",
            dest="incomplete",
            default=False,
            help="only list incomplete datasets"
        ),
        optparse.make_option(
             "-c", "--complete",
             action="store_true",
             dest="complete",
             default=False,
             help="only list complete datasets"
         ),
        optparse.make_option(
             "-a", "--all",
             action="store_true",
             dest="all",
             default=False,
             help='''print all informations about dataset replicas:
<Site>:
     <Dataset version>  <Transfer status: Active or Inactive> < ratio: files at site /total files>   
             '''
         )         
         ,
         cliutil.opt_dataset_version
     ]
    
    
    def __init__ (self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0]
    
        
    def execute (self):
        """
        (since 0.3.0)
        """
     
        dq = getDQ2(self)
    
        dsn = self._get_parameters()
        
        complete = LocationState.__ANY__
        if self.options.complete:
            complete = LocationState.COMPLETE
        if self.options.incomplete:
            complete = LocationState.INCOMPLETE
                                        
        out = ''        
        
        ret = dq.listDatasetReplicas(dsn, self.options.version, complete, old=not self.options.all)
        if not self.options.all:
            if ret:
                if complete == LocationState.__ANY__ or complete == LocationState.INCOMPLETE:
                    out += " INCOMPLETE: " % ()
                    sites = ret[ret.keys()[0]]
                    sites[LocationState.INCOMPLETE].sort()                    
                    for eachSite in sites[LocationState.INCOMPLETE]:
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)]
                out += '\n'
                if complete == LocationState.__ANY__ or complete == LocationState.COMPLETE:
                    out += " COMPLETE: " % ()
                    if ret:
                        sites = ret[ret.keys()[0]]
                        sites[LocationState.COMPLETE].sort()                    
                    for eachSite in sites[LocationState.COMPLETE]:
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)]
        else:
            out += 'Site: Version Transfer Completeness\n'            
            out += '----------------------------------------'            
            
            for location in ret:
                out += '\n%s:'%location
                for v in  ret[location]:
                    version = v['version']
                    total = '?'          
                    found = '?'

                    if v['found']:
	                    found = v['found']
                    
                    
                    if v['transferState'] == TransferState.ACTIVE:                            
                        transfer = 'Active'
                    elif v['transferState'] == TransferState.INACTIVE:
                        transfer = 'Inactive'
                    
                    if v['immutable'] == MutableState.IMMUTABLE:
                        if v['total']!=-1:
                            total = v['total']

                    if v['immutable'] == MutableState.MUTABLE:
                        if v['total'] !=-1:
                            total = '%s (mutable)'%(v['total'])
                        #else:
                        #    total = '? (mutable)'
                        

                    
                    if v['immutable'] == MutableState.IMMUTABLE:
                        if v['checkstate']== 6:
                            found = v['found']
                        elif v['checkstate'] > 0:
                            found = 'checking'
                        
                    out += '\n\t %s %s %s/%s'%(version, transfer, found, total)
                    
        print out