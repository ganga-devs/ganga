"""
@author: Mario Lassnig
@contact: mario.lassnig@cern.ch
@since: 0.3.0
@version: $Id: RegisterDataset.py,v 1.8 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.common import optparse
from dq2.common.cli.DQDashboardTool import DQDashboardTool


class RegisterDataset (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = '%prog [options] <DATASET> (lfn1 guid1 [[fs:size1] [md5|ad:checksum1]] lfn2 guid2 [[fs:size2] [md5|ad:checksum2]] ...)'

    version = '$Revision: 1.8 $'

    description = 'Register a new dataset'

    toolOptions = [
        optparse.make_option(
            '-f', '--xml-pool-file-catalog',
            dest='pool',
            default=False,
            help='use xml pool file catalog'
        )
    ]


    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1:])


    def execute(self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
        
        pool = None
        
        dsn, files = self._get_parameters()
        
        if pool is not None:
            """using a pool file catalog as input"""
            
            import utils.xml
            lfns, guids, sizes, checksums = utils.xml.getFilesFromCatalog(poolfile)
            dq.registerNewDataset(dsn, lfns, guids, sizes, checksums)
            
        else:
            
            guids = []
            lfns = []
            sizes = []
            checksums = []
            
            sizeL = []
            checksumL = []
            
            for i in range(0, len(files)):
                if files[i].startswith('fs:'):
                    sizeL.append(i)
                elif files[i].startswith('md5:') or files[i].startswith('ad:'):
                    checksumL.append(i)
            
            if len(sizeL) == 0 and len(checksumL) == 0:
                for i in range(0, len(files), 2):
                    lfns.append(files[i])
                    guids.append(files[i+1])
                    sizes.append(None)
                    checksums.append(None)
            else:
                i = 0
                s = 0
                c = 0
                while i < len(files):
                    lfns.append(files[i])
                    guids.append(files[i+1])
                    i += 2
                    if i in sizeL:
                        sizes.append(long(files[sizeL[s]][3:]))
                        s += 1
                        i += 1
                    else:
                        sizes.append(None)
                    if i in checksumL:
                        checksums.append(files[checksumL[c]])
                        c += 1
                        i += 1
                    else:
                        checksums.append(None)
            
            """           
            print "lfns:     ", lfns
            print "guids:    ", guids
            print "sizes:    ", sizes
            print "checksums:", checksums
            """
            
            dq.registerNewDataset(dsn, lfns, guids, sizes, checksums)
            
            print "Dataset %s created." % (dsn)