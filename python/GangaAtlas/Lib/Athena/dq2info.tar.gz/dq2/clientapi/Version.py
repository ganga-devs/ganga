"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: Version.py,v 1.2 2009/10/15 13:06:49 angelos Exp $
"""


class Version (object):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.2 $
    """


#
# Dataset version-level operations
#


    def getVersionMetadata (self, dsn, version=0):
        """
        Retrieve data set version metadata.
        
        @since: 0.3.24
        
        @return: duid_10, vuid_10, version, versioncreationdate, tier0state, tier0type, numberfiles, size
        @rtype: tuple
        """
        
        return self.repositoryClient.getVersionMetadata(dsn, version)