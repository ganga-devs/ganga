"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: Repository.py,v 1.4 2008/05/20 14:57:40 psalgado Exp $
"""

from dq2.common.DQConstants import DatasetState, HTTP
from dq2.common.DQException import DQException, DQInvalidRequestException


from dq2.repository.DQRepositoryException import *
from dq2.repository.client.RepositoryClient import RepositoryClient


class Repository (object):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.4 $
    """


    def closeDataset (self, dsn):
        """
        Closes the latest dataset version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
            - DQClosedDatasetException is raised,
                in case the dataset version is already closed.
            - DQFrozenDatasetException is raised,
                in case the dataset is frozen.
            - DQSecurityException is raised,
                in case the given user cannot change the dataset version state.
        """
        self.repositoryClient.setState(dsn, DatasetState.CLOSED)
        
        #dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        #dataset = dict_get_item(dataset, dsn)


    def eraseDataset (self, dsn):
        """
        Marks the dataset as Deleted and removes the dataset entries in content, location and subscription catalogs.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name (can be used with wildcard).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case the dataset name has wildcards.
            - DQSecurityException is raised,
                in case the user has no permissions to delete the dataset.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
        """
        
        if dsn.find('*') != -1:
            # too dangerous to allow wildcards.
            # Comment this line out if we really want them
            raise DQInvalidRequestException('Wildcards are not supported in this operation!')
        
        #{'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1'], 'dataset_nameB': ['B_vuid_for_version1']}, where X > 0
        datasets = self.repositoryClient.queryDatasetByName(dsn)
        
        if len(datasets) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        # removing dataset one by one
        
        for dsname in datasets.keys():
            
            # get all dataset versions
            datasets = dict_get_item(datasets, dsname)
            duid = datasets['duid']
            vuids = datasets['vuids']
            
            self.repositoryClient.setState(dsname, DatasetState.DELETED)
            
            # delete the contents of each vuid
            #self.contentClient.deleteDataset(vuids)
            
            # delete all replicas from dq2.location catalog
            #self.locationClient.deleteDataset(vuids)
            
            # delete all subscriptions (dataset and dataset version)
            uids = vuids
            uids.append(duid)
            
            self.subscriptionClient.deleteDatasetSubscriptions(uids)
        
        return


    def freezeDataset (self, dsn):
        """
        Freezes a dataset.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQFrozenDatasetException is raised,
                in case the user is trying to freeze an already frozen dataset.
            - DQInvalidRequestException is raised,
                in case the given lfns and guids are not the same length.
            - DQSecurityException is raised,
                in case the given user cannot change the dataset version state.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        self.repositoryClient.setState(dsn, DatasetState.FROZEN)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        dataset = dict_get_item(dataset, dsn)


    def getMetaDataAttribute (self, dsn, attributes, version=0):
        """
        Get the metadata information for the given dataset/dataset version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param attributes: is a list of dataset metadata attributes.
        @param version: is the dataset version (0 is the latest).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return Dictionary in the following format:
            {'attribute_1': value_1, ..., 'attribute_N': value_N}
        """

        return self.repositoryClient.getMetaDataAttribute(dsn, attributes, version)


    def getNumberOfFiles (self, dsn, version=0):
        """
        Returns the number of files in the given dataset (or dataversion).
        
        @since: 0.3.0
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number.
        
        Note: to get all files in the whole dataset use version=None.
        
        Note: to get the number of files added on the last version use version=0.
        
        """
        # get the vuid
        dataset = self.repositoryClient.queryDatasetByName(dsn, None)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        
        # get all versions until this one
        if version == 0:
            """get the number of files of the whole dataset"""
            vuids = dataset['vuids']
        else:
            """get the number of files of the given version"""
            vuids = dataset['vuids'][-version:]
        
        return self.contentClient.getNumberOfFiles(vuids)


    def getState (self, dsn):
        """
        Returns the dataset state.
        
        @since: 0.3.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
        
        @return: The dataset state (check L{dq2.common.DQConstants.DatasetState<common.DQConstants.DatasetState>}).
        """
        return self.repositoryClient.getState(dsn)


    def listDatasets (self, dsn, version=0):
        """
        Used to return a list of datasets matching the given
        pattern and version.
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        usage::
            listDatasets('myname') - returns all versions of the given dataset
            listDatasets('myname*') - returns all versions of the datasets that start by 'myname'.
            listDatasets('*myname') - returns all versions of the datasets that end by 'myname'.
        
            listDatasets('myname', 2) - returns the version 2 of dataset 'myname'.
            listDatasets('myname', 0) - returns the latest version of the dataset 'myname'.
            listDatasets('myname', <0) - returns all the versions of the dataset 'myname'.
            listDatasets('myname', ]-infinite, 0[) - returns all the versions of the dataset 'myname'.
        
            listDatasets('myname*', 2) - returns the version 2 of the datasets that start by 'myname'.
            listDatasets('*myname', None) - returns all the versions of the datasets that end with 'myname'.
        
        @return: Dictionary containing the dataset versions information.
            {
                'dataset_nameA': {'duid': duid, 'vuids': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
                'dataset_nameB': {'duid': duid, 'vuids': ['B_vuid_for_version1']}
            }, where X > 0
        """
        
        self.type = HTTP.GET
        self.is_secure = False
        self.request = '/ws_dq2/rpc'
        self.params = {'operation': 'dataset_search', 'what': {'name': dsn, 'version': version, 'state': -DatasetState.DELETED}}
        
        return self.send()


    def listDatasetsByCreationDate (self, seconds, criteria, dsn=None, location=None, complete=None):
        """
        Returns a dictionary mapping names to last created vuids between [now-<seconds>, now+<seconds>].
        
        @since: 0.2.0
        
        @param seconds: is the number of seconds counted from now [in the server side].
        @param criteria: is the criteria to be used (check dq2.common.DQConstants.DateCriteria).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: Dictionary containing the dataset versions information.
            {
                'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
                'dataset_nameB': ['B_vuid_for_version1']
            }, where X > 0
        """
        datasets_by_date = self.repositoryClient.queryDatasetByCreationDate(seconds, criteria, dsn=dsn)

        if location is not None:
            """querying by location"""
            datasets_by_location = {}
            #"""{'dsn': ['vuid_1', ... 'vuid_N']}"""
            datasets_by_location = self.locationClient.queryDatasetsInSite(location, complete=complete)
            # when querying by location one has to merge the results
            if len(datasets_by_location) > 0:
                """locations were retrieved: merge repository dsns with location vuids"""
                for eachDSN in datasets_by_date.keys():
                    for vuid in datasets_by_date[eachDSN]:
                        if vuid not in datasets_by_location:
                            """if a date vuid is in the location list it means we need it, else delete it"""
                            del (datasets_by_date[eachDSN])
            else:
                return {}

        return datasets_by_date


    def listDatasetsByMetaData (self, filter):
        """
        List the dataset versions that match the given criteria.
        
        @since: 0.2.0
        
        @param filter: list containing dictionaries of metadata attributes and values
            ({'attrname_0': attrvalue_0, ..., 'attrname_N': attrvalue_N}).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
        
        @return: List of tuples with (dataset name, version).
            [
                ('dataset_name_1', 'vuid_1'),
                (...),
                ('dataset_name_N', 'vuid_N')
            ]
        """
        return self.repositoryClient.queryDatasetByMetaData(filter)


    def registerNewDataset (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
        """
        Register a brand new dataset and associated files (lists of lfns and guids).
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param lfns: is a list of logical filenames (LFN).
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param sizes: is a list of the file sizes.
        @param checksums: is a list of the file checksums.
            [md5:<md5_32_character_string>, ...]
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQDatasetExistsException is raised,
                in case there is a dataset with the given name.
        
        @return: Dictionary containing the dataset duid, vuid and version information.::
            {'duid': '...', 'vuid': '...', 'version': ...}
        """
        # add to repository and obtain vuid ({'vuid', 'version'})
        duid = dq2.common.generate_uuid()
        vuid = dq2.common.generate_uuid()
        
        self.repositoryClient.addDataset(dsn, duid, vuid)
        
        if len(lfns) > 0:
            files = build_file_dictionary(lfns, guids, sizes, checksums)
            
            self.contentClient.addFilesToDataset(vuid, [], files)
        
        return {'duid': duid, 'version': 1, 'vuid': vuid}


    def registerNewVersion (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
        """
        Register a new version of the dataset with the
        given additional files (lists of lfns and guids).
        Plus, it notifies the subscription catalog for changes
        on the dataset and on dataset previous version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param lfns: is a list of logical filenames (LFN).
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param sizes: is a list of the file sizes.
        @param checksums: is a list of the file checksums.
            [md5:<md5_32_character_string>, ...]
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQFileExistsInDatasetException is raised,
                in case the given guid is already registered for the given dataset.
            - DQInvalidRequestException is raised,
                in case no files have been added to the content catalog.
            - DQSecurityException is raised,
                in case the user has no permissions to update the dataset.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: Dictionary containing the dataset version information.::
            {'vuid': vuid_1, 'version': 1, 'duid': duid}
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0) # returns the latest version
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)

        # WARNING: central catalog result may have a different case -> use dict_get_item
        # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
        dataset = dict_get_item(dataset, dsn)
        
        # register new version
        newvuid = dq2.common.generate_uuid()
        newvuid_dict = self.repositoryClient.updateVersion(dsn, newvuid)
        newvuid_dict['vuid'] = newvuid
        newversion = newvuid_dict['version']
        
        # register new files
        files = build_file_dictionary(lfns, guids, sizes, checksums)
        self.contentClient.addFilesToDataset(newvuid, dataset['vuids'], files)
        
        # notify dataset changes
        duid = newvuid_dict['duid']
        
        
        return newvuid_dict


    def setMetaDataAttribute (self, dsn, attrname, attrvalue):
        """
        Set the value of the given attribute to the given
        value for the given dataset. Operates on the current version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param attrname: is the metadata dataset attribute name.
        @param attrvalue: is the metadata dataset attribute value.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
            - DQSecurityException is raised,
                in case the user has no permissions to set metadata attributes on the dataset.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        return self.repositoryClient.setMetaDataAttribute(dsn, attrname, attrvalue)