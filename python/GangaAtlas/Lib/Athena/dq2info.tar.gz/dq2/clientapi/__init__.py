"""
Load aspects for dq2.common.client

Order is important

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: __init__.py,v 1.6 2009/10/15 13:06:49 angelos Exp $
"""

__version__ = '$Name: dq2-clientapi-0-5-0 $'

from dq2.clientapi.aspects.transaction import wrap_package
wrap_package()

from dq2.clientapi.aspects.validation import wrap_package
wrap_package()

from dq2.clientapi.aspects.logger import wrap_package
wrap_package()