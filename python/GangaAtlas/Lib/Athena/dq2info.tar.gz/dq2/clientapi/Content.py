"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: Content.py,v 1.4 2008/06/18 11:26:15 psalgado Exp $
"""

from dq2.common.python.uuid import uuid4

from dq2.content import build_file_dictionary
from dq2.content.DQContentException import *
from dq2.content.client.v03.ContentClient import ContentClient

class Content (object):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.4 $
    """


    def deleteFilesFromDataset (self, dsn, guids=[]):
        """
        Removes files from an existing dataset. Files are
        removed from the latest open version only.
        
        (since 0.2.1)
        
        @param dsn: is the dataset name.
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQClosedDatasetException is raised,
                in case the dataset version is closed.
            - DQFrozenDatasetException is raised,
                in case the dataset is frozen.
        
        @return: List of lfns that failed to be added since they are duplicates?
        """
        
        dataset = self.repositoryClient.queryDatasetByName(dsn)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        
        vuid = dataset['vuids'][0] # the latest version
        
        self.contentClient.deleteFilesFromDataset(vuid, dataset['vuids'], guids)


    def listFilesInDataset (self, dsn, version=None):
        """
        Given a dataset name, and optional version, the guids
        and lfns of the files in the dataset are returned.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number (0 => the latest version).
        
        B{Exceptions}:
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: Tuple containing the last timestamp and dictionary of guids mapped to lfns.::
            (
            {
                'guid_00': {'lfn': 'lfn_00', 'filesize': filesize_00, 'checksum': checksum_00},
                ...,
                'guid_n0': {'lfn': 'lfn_n0', 'filesize': filesize_n0, 'checksum': checksum_n0}
            },
            lastdate
            )
            where checksum is 'md5:<md5_32_character_string>'
        """
        
        self.type = HTTP.GET
        self.is_secure = False
        self.request = '/ws_dq2/rpc'
        self.params = {'operation': 'listFilesInDataset', 'dsn': dsn, 'version': version}
        
        return self.send()


    def registerFilesInDataset (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
        """
        Add files to an existing dataset.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param lfns: is a list of logical filenames (LFN).
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param sizes: is a list of the file sizes.
        @param checksums: is a list of the file checksums.
            [md5:<md5_32_character_string>, ...]
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQClosedDatasetException is raised,
                in case the dataset version is closed.
            - DQFrozenDatasetException is raised,
                in case the dataset is frozen.
            - DQInvalidRequestException is raised,
                in case no files were added.
        """
        st = self.repositoryClient.getState(dsn)
        
        # is closed!
        if st == DatasetState.CLOSED:
            raise DQClosedDatasetException(dsn)
        elif st == DatasetState.FROZEN:
            raise DQFrozenDatasetException(dsn)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn)
        # WARNING: central catalog result may have a different case -> use dict_get_item
        # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
        dataset = dict_get_item(dataset, dsn)
        
        duid = dataset['duid']
        vuid = dataset['vuids'][0] # latest version in on index 0
        
        # build the files structure
        files = build_file_dictionary(lfns, guids, sizes, checksums)
        
        self.contentClient.addFilesToDataset(vuid, dataset['vuids'], files)


    def registerFilesInDatasets (self, datasets):
        """
        @since: 0.3.0
        
        @param dataset: is a dictionary containing the dataset name and a list of its files.
            {'dsn': [{'guid', 'vuid', 'lfn', 'size', 'checksum'}]}
            where checksum is 'md5:<md5_32_character_string>'
        """
        
        
        for dsn in datasets:
            st = self.repositoryClient.getState(dsn)
            
            # is closed!
            if st == DatasetState.CLOSED:
                raise DQClosedDatasetException(dsn)
            elif st == DatasetState.FROZEN:
                raise DQFrozenDatasetException(dsn)
        
        bulk = []
        
        for dsn in datasets:
            dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
            # WARNING: central catalog result may have a different case -> use dict_get_item
            # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
            dataset = dict_get_item(dataset, dsn)
            
            duid = dataset['duid']
            vuid = dataset['vuids'][0] # latest version in on index 0
            
            lfns = []
            guids = []
            sizes = []
            checksums = []
            
            for eachFile in datasets[dsn]:
                """"retrieve all file info to be inserted"""
                lfns.append(eachFile['lfn'])
                guids.append(eachFile['guid'])
                sizes.append(eachFile['size'])
                checksums.append(eachFile['checksum'])
            
            # build the files structure
            files = build_file_dictionary(lfns, guids, sizes, checksums)
            
            bulk.append({'vuid': vuid, 'vuids': dataset['vuids'], 'files': files})
        
        if len(bulk) > 0:
            self.contentClient.addFilesToDatasets(bulk)
        else:
            raise ValueError('There are no files to be registered.')


    def verifyFilesInDataset (self, dsn, guids, version=None):
        """
        Verifies if the given files' global unique identifiers (GUIDS) are registered on the dataset.
        
        (since 0.4.0)
        
        @param dsn: is the dataset name.
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param version: is the dataset version number (0 => the latest version).
        
        B{Exceptions}:
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: Dictionary with the following format:
            {
                GUIDX: True, # exist
                (...)
                GUIDY: False # don't exist
            }
        """
        
        # get all vuids to choose the one the user wants after
        dataset = self.repositoryClient.queryDatasetByName(dsn, version=0)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        if version == 0:
            """for the latest version use all vuids to get all diffs of the dataset"""
            vuids = dict_get_item(dataset, dsn)['vuids']
        elif version >= 0:
            """"""
            dataset = dict_get_item(dataset, dsn)
            vuids = dataset['vuids'][-version:]
        else:
            vuids = dict_get_item(dataset, dsn)['vuids']
        
        
        # get the list of files
        return self.contentClient.filesInDataset(vuids, guids)