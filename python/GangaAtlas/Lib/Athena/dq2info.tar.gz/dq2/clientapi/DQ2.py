"""
The main interface for users to perform operations involving multiple central catalogs.

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Mario Lassnig
@contact: mario.lassnig@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@author: Vincent Garonne
@contact: vincent.garonne@cern.ch

@since: 0.2.0
@version: $Id: DQ2.py,v 1.32 2009/10/15 13:06:48 angelos Exp $
"""

from   dq2.common.retry import retry
import dq2.common.DQPing

import os
import time
from time import sleep

from dq2.clientapi.Container import Container
from dq2.clientapi.Dataset import Dataset
from dq2.clientapi.Version import Version

from dq2.common import dict_get_item
from dq2.common.DQConstants import DatasetState, Metadata
from dq2.common.DQException import *

from dq2.common.client.DQClient import DQClient

from dq2.common.dao.DQDaoException import *

from dq2.content import build_file_dictionary
from dq2.content.DQContentException import *

from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationException import *

from dq2.repository.DQRepositoryException import *

from dq2.subscription.DQSubscriptionConstants import CallbackType, SourcesPolicy, SourceResolverPolicy, SubscriptionArchivedState
from dq2.subscription.DQSubscriptionException import *


FMT_TIMESTAMP = '%04i%02i%02i-%02i%02i%02i%02i'

try:
    USER = os.environ['USER'] + '-'
except:
    USER = '-'


def dict_has_key (dictionary, key):
    """
    Returns whether the dictionary has the key or not.
    Searches for keys in a case INSENSITIVE manner.
    
    @since: 0.3.0    
    """
    assert dictionary is not None
    assert type(dictionary) is dict
    assert key is not None

    for eachKey in dictionary.keys():
        if eachKey.lower() == key.lower():
            return True
    
    return False


def list_has_item (inputlist, item):
    """
    Returns whether the list has the item or not.
    Searches for items in a case INSENSITIVE manner.
    
    @since: 0.3.0
    """
    assert list is not None
    assert type(inputlist) is list
    assert item is not None
    
    for eachItem in inputlist:
        if eachItem.lower() == item.lower():
            return True
    
    return False


class DQ2 (DQClient, Container, Dataset, Version):
    """
    Class to make requests to central catalogs.
    
    @since: 0.2.0
    
    This class is not intended to be thread-safe.
    Please use a different instance for each thread.
    """


    def __init__ (self, con_url=None, con_urlsec=None, loc_url=None, loc_urlsec=None, rep_url=None, rep_urlsec=None, sub_url=None, sub_urlsec=None, mon_url=None, mon_urlsec=None, certificate=None):
        """
        Constructs an instance of DQ2.
        
        @since: 0.2.0
        
        @param con_url: is the non-secure URL of the host to be contacted.
        @param con_urlsec: is the secure URL of the host to be contacted.
        @param loc_url: is the non-secure URL of the host to be contacted.
        @param loc_urlsec: is the secure URL of the host to be contacted.
        @param rep_url: is the non-secure URL of the host to be contacted.
        @param rep_urlsec: is the secure URL of the host to be contacted.
        @param sub_url: is the non-secure URL of the host to be contacted.
        @param sub_urlsec: is the secure URL of the host to be contacted.
        @param mon_url: is the non-secure URL of the host to be contacted.
        @param mon_urlsec: is the secure URL of the host to be contacted.
        @param certificate: is the proxy certificate.
        
        B{Exceptions:}
            - DQInvalidRequestException is raised,
                in case any given/configured url is not a string or if it
                doesn't match the regular expression (L{dq2.common.validator.DQValidator.URL_REGEXP<common.validator.DQValidator.URL_REGEXP>}).
        """
        
        from dq2.content.client.ContentClient import ContentClient
        from dq2.location.client.LocationClient import LocationClient
        from dq2.repository.client.RepositoryClient import RepositoryClient
        from dq2.subscription.client.SubscriptionClient import SubscriptionClient
        from dq2.container.client import ContainerClient
        
        self.containerClient = ContainerClient()
        self.contentClient = ContentClient(con_url, con_urlsec, certificate=certificate)
        self.locationClient = LocationClient(loc_url, loc_urlsec, certificate=certificate)
        self.repositoryClient = RepositoryClient(rep_url, rep_urlsec, certificate=certificate)
        self.subscriptionClient = SubscriptionClient(sub_url, sub_urlsec, certificate=certificate)
        
        DQClient.__init__(self, con_url, con_urlsec, certificate=certificate)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.1
        """
        return """DQ2
        (
        container client      : %s
        content client      : %s
        location client     : %s
        repository client   : %s
        subscription client : %s
        )""" % (self.containerClient, self.contentClient, self.locationClient, self.repositoryClient, self.subscriptionClient)


# PUBLIC methods


    def auto_configure ():
        """
        Returns this client configuration.
        
        This is a dummy implementation for dq2.clientapi.DQ2
        
        @since: 0.2.0
        
        @return: Tuple in the following format::
            (url_insecure_host, url_secure_host)
        """
        
        return ('http://foo', 'https://foo')

    auto_configure = staticmethod(auto_configure)


    def catalogStatus (self):
        """
        Checks if the DQ2 clients are well configured and the state of the central catalogs.
        
        @since: 0.3.0
        
        @return Dictionary containing the client's configuration settings.::
            {
                'content'      : (url_insecure, url_secure),
                'location'     : (url_insecure, url_secure),
                'repository'   : (url_insecure, url_secure),
                'subscription' : (url_insecure, url_secure)
                'host status'  : <int>
                'catalog status' : <str>
            }
        """
        clients = [
            self.contentClient,
            self.locationClient,
            self.repositoryClient,
            self.subscriptionClient
        ]
        
        hosts = []
        for eachClient in clients:
            """for each client check its insecure and secure hosts."""
            
            pinglist = []
            for eachHost in eachClient._getHosts():
                if not eachHost in hosts:
                    hosts.append(eachHost)
        
        status = dq2.common.DQPing.pings(hosts, user_friendly=True)
        #catalogStatus = self.monitorClient.catalogStatus()
        
        result = {
            'content'      : (
                self.contentClient.url,
                self.contentClient.url_secure,
                #catalogStatus['content']['status']
            ),
            'location'     : (
                self.locationClient.url,
                self.locationClient.url_secure,
                #catalogStatus['location']['status']
            ),
            'repository'   : (
                self.repositoryClient.url,
                self.repositoryClient.url_secure,
                #catalogStatus['repository']['status']
            ),
            'subscription' : (
                self.subscriptionClient.url,
                self.subscriptionClient.url_secure,
                #catalogStatus['subscription']['status']
            ),
            'host status'       : status
        }
        
        return result


    def closeDataset (self, dsn):
        """
        Closes the latest dataset version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
            - DQClosedDatasetException is raised,
                in case the dataset version is already closed.
            - DQFrozenDatasetException is raised,
                in case the dataset is frozen.
            - DQSecurityException is raised,
                in case the given user cannot change the dataset version state.
        """
        self.repositoryClient.setState(dsn, DatasetState.CLOSED)


    def deleteDatasetReplicas (self, dsn, locations, version=0, deep=False):
        """
        Delete the dataset replica from the given site. If it
        was the last replica, delete entries from the repository
        and dq2.content.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param locations: is a list with the dataset replica locations.
        @param version: is the dataset version number.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0 and version == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        if deep:
            duid = dataset['duid']
            self.locationClient.deleteDatasetReplica2(duid, locations)
        else:
            vuid = dataset['vuids'][0] # the latest version retrieved by the catalog
            
            self.locationClient.deleteDatasetReplica(vuid, locations)


    def  bulkDeleteDatasetReplicas(self, pattern, locations):
        """
        Bulk Deletion methods by pattern.
        @since: 1.0.0
        
        @param pattern: is the pattern.
        @param locations: is a list with the dataset replica locations.
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        """
        return self.locationClient.bulkDeleteDatasetReplicas(pattern=pattern, locations=locations)


    def deleteDatasetSubscription (self, dsn, site, version=None):
        """
        Removes the dataset/dataset version subscription of the given dataset name from the given site.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param site: is the subscription dq2.location.
        @param version: is the dataset version number (None is passed the duid will be used).
        
        B{Exceptions}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        if version is None or version == 0:
            """delete subscription to duid"""
            
            # may raise DQUnknownDatasetException
            duid = self.repositoryClient.resolveName(dsn)['duid']
            self.subscriptionClient.deleteDatasetSubscription(duid, site)
            
        else:
            """delete subscription to vuid"""
            
            # {'dataset_nameA': {'vuids': ['A_vuid_for_versionX']}}
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            if len(dataset) == 0:
                raise DQUnknownDatasetException(dsn=dsn)
                      
            dataset = dict_get_item(dataset, dsn)
            
            # vuids will always be a list
            vuid = dataset['vuids'][0]
            
            self.subscriptionClient.deleteDatasetSubscription(vuid, site)


    def deleteDatasetSubscriptions (self, dsn):
        """
        Marks all dataset/dataset version subscriptions of the given dataset.
        
        (since 0.2.1)
        
        @param dsn: is the dataset name.
        
        B{Exceptions}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        # may raise DQUnknownDatasetException
        duid = self.repositoryClient.resolveName(dsn)['duid']
        # {'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
        dataset = self.repositoryClient.queryDatasetByName(dsn, -1)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn)
        
        dataset = dict_get_item(dataset, dsn)
        
        duid_and_vuids = dataset['vuids']
        duid_and_vuids.append(dataset['duid'])

        self.subscriptionClient.deleteDatasetSubscriptions(duid_and_vuids)


    def deleteDatasetVersionSubscriptions (self, dsn, version):
        """
        Removes all subscriptions of the given dataset version.
        
        (since 0.2.1)
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number
            (
            0 only of the latest version,
            -1 all dataset versions - NOT of the duid -,
            >0 only of the specific version
            ).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        # {'dataset_nameA': ['A_vuid_for_versionX']}
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        dataset = dict_get_item(dataset, dsn)
        
        if not len(dataset) > 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        # vuids will always be a list
        vuid = dataset['vuids'][0]
        self.subscriptionClient.deleteDatasetSubscriptions(vuid)


    def deleteFilesFromDataset (self, dsn, guids=[]):
        """
        Removes files from an existing dataset. Files are
        removed from the latest open version only.
        
        (since 0.2.1)
        
        @param dsn: is the dataset name.
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQClosedDatasetException is raised,
                in case the dataset version is closed.
            - DQFrozenDatasetException is raised,
                in case the dataset is frozen.
        
        @return: List of lfns that failed to be added since they are duplicates?
        """
        ### this part is now taken care of in the server-side
        #st = self.repositoryClient.getState(dsn)
        #
        # is closed!
        #if st == DatasetState.CLOSED:
        #    raise DQClosedDatasetException(dsn)
        #elif st == DatasetState.FROZEN:
        #    raise DQFrozenDatasetException(dsn)
        ###
        
        dataset = self.repositoryClient.queryDatasetByName(dsn)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        
        vuid = dataset['vuids'][0] # the latest version
        
        self.contentClient.deleteFilesFromDataset(vuid, dataset['vuids'], guids)


    def eraseDataset (self, dsn):
        """
        Marks the dataset as Deleted and removes the dataset entries in content, location and subscription catalogs.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name (can be used with wildcard).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case the dataset name has wildcards.
            - DQSecurityException is raised,
                in case the user has no permissions to delete the dataset.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
        """
        
        if dsn.find('*') != -1:
            # too dangerous to allow wildcards.
            # Comment this line out if we really want them
            raise DQInvalidRequestException('Wildcards are not supported in this operation!')
        
        #{'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1'], 'dataset_nameB': ['B_vuid_for_version1']}, where X > 0
        datasets = self.repositoryClient.queryDatasetByName(dsn)
        
        if len(datasets) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        # removing dataset one by one
        
        for dsname in datasets.keys():
            
            # get all dataset versions
            datasets = dict_get_item(datasets, dsname)
            duid = datasets['duid']
            vuids = datasets['vuids']
            
            self.repositoryClient.setState(dsname, DatasetState.DELETED)
            
            # delete the contents of each vuid
            #self.contentClient.deleteDataset(vuids)
            
            # delete all replicas from dq2.location catalog
            #self.locationClient.deleteDataset(vuids)
            
            # delete all subscriptions (dataset and dataset version)
            uids = vuids
            uids.append(duid)
            
            self.subscriptionClient.deleteDatasetSubscriptions(uids)
        
        return
        

    def freezeDataset (self, dsn):
        """
        Freezes a dataset.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQFrozenDatasetException is raised,
                in case the user is trying to freeze an already frozen dataset.
            - DQInvalidRequestException is raised,
                in case the given lfns and guids are not the same length.
            - DQSecurityException is raised,
                in case the given user cannot change the dataset version state.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        self.repositoryClient.setState(dsn, DatasetState.FROZEN)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
        dataset = dict_get_item(dataset, dsn)


    def getMetaDataAttribute (self, dsn, attributes, version=0):
        """
        Get the metadata information for the given dataset/dataset version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param attributes: is a list of dataset metadata attributes.
        @param version: is the dataset version (0 is the latest).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return Dictionary in the following format:
            {'attribute_1': value_1, ..., 'attribute_N': value_N}
        """
        
        if 'provenance' in attributes:
            if len(attributes) == 1:
                return {'provenance': self.locationClient.getMasterLocation(self.repositoryClient.getMetaDataAttribute(dsn, ['vuid'], version)['vuid'])}
            else:
                if 'vuid' in attributes:
                    m = self.repositoryClient.getMetaDataAttribute(dsn, attributes, version)
                    m['provenance'] = self.locationClient.getMasterLocation(m['vuid'])
                    return m
                else:
                    attributes.append('vuid')
                    m = self.repositoryClient.getMetaDataAttribute(dsn, attributes, version)
                    m['provenance'] = self.locationClient.getMasterLocation(m['vuid'])
                    del(m['vuid'])
                    return m
        else:
            return self.repositoryClient.getMetaDataAttribute(dsn, attributes, version)


    def getNumberOfFiles (self, dsn, version=0):
        """
        Returns the number of files in the given dataset (or dataversion).
        
        @since: 0.3.0
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number.
        
        Note: to get all files in the whole dataset use version=None.
        
        Note: to get the number of files added on the last version use version=0.
        
        """
        # get the vuid
        dataset = self.repositoryClient.queryDatasetByName(dsn, None)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        
        # get all versions until this one
        if version == 0:
            """get the number of files of the whole dataset"""
            vuids = [dataset['vuids'][0],]
        else:
            """get the number of files of the given version"""
            vuids = dataset['vuids'][-version:]
        
        return self.contentClient.getNumberOfFiles(vuids)


    def getState (self, dsn):
        """
        Returns the dataset state.
        
        @since: 0.3.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
        
        @return: The dataset state (check L{dq2.common.DQConstants.DatasetState<common.DQConstants.DatasetState>}).
        """
        return self.repositoryClient.getState(dsn)


    def listDatasetReplicas (self, dsn, version=0, complete=None, old=True):
        """
        @since: 0.2.0
        
        @author: Vincent Garonne
        @contact: vincent.garonne@cern.ch
        
        @param dsn is the dataset name.
        @param version is the dataset version number.
        @param complete is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
              B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
              @ if old is True returns: List of locations.
            {'dsn_A': ['site_A', ..., 'site_B'], 'dsn_B': [...]}
             else returns:
            {'site_A': [ {'versions': ,  '':}, ], 'site_B': [{'versions': ,  '':}, ...]}
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        if old:
            vuid = dataset['vuids'][0] # the latest version
            return self.locationClient.queryDatasetLocations([vuid], complete=complete)
        else:
            duid   = dataset['duid']
            return self.locationClient.listDatasetReplicas(duid)


    def listDatasets (self, dsn, version=0, onlyNames=False, p=None, rpp=None):
        """
        Used to return a list of datasets matching the given
        pattern and version.
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number.
        @param onlyNames: Option to return only the dataset names.
        @param rpp: Print rrp first results.        
        @param p: Specify page to print.
        
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        usage::
            listDatasets('myname') - returns all versions of the given dataset
            listDatasets('myname*') - returns all versions of the datasets that start by 'myname'.
            listDatasets('*myname') - returns all versions of the datasets that end by 'myname'.
        
            listDatasets('myname', 2) - returns the version 2 of dataset 'myname'.
            listDatasets('myname', 0) - returns the latest version of the dataset 'myname'.
            listDatasets('myname', <0) - returns all the versions of the dataset 'myname'.
            listDatasets('myname', ]-infinite, 0[) - returns all the versions of the dataset 'myname'.
        
            listDatasets('myname*', 2) - returns the version 2 of the datasets that start by 'myname'.
            listDatasets('*myname', None) - returns all the versions of the datasets that end with 'myname'.
        
        @return: Dictionary containing the dataset versions information.
            {
                'dataset_nameA': {'duid': duid, 'vuids': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
                'dataset_nameB': {'duid': duid, 'vuids': ['B_vuid_for_version1']}
            }, where X > 0
        """
        return self.repositoryClient.queryDatasetByName(dsn, version, onlyNames=onlyNames, p=p, rpp=rpp)


    def listDatasetsByCreationDate (self, seconds, criteria, dsn=None, location=None, complete=None):
        """
        Returns a dictionary mapping names to last created vuids between [now-<seconds>, now+<seconds>].
        
        @since: 0.2.0
        
        @param seconds: is the number of seconds counted from now [in the server side].
        @param criteria: is the criteria to be used (check dq2.common.DQConstants.DateCriteria).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: Dictionary containing the dataset versions information.
            {
                'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
                'dataset_nameB': ['B_vuid_for_version1']
            }, where X > 0
        """
        datasets_by_date = self.repositoryClient.queryDatasetByCreationDate(seconds, criteria, dsn=dsn)
        
        if location is not None:
            """querying by location"""
            datasets_by_location = {}
            new_datasets_by_date = {}
            #"""{'dsn': ['vuid_1', ... 'vuid_N']}"""
            datasets_by_location = self.locationClient.queryDatasetsInSite(location, complete=complete)
            # when querying by location one has to merge the results
            if len(datasets_by_location) > 0:
                """locations were retrieved: merge repository dsns with location vuids"""
                for eachDSN in datasets_by_date:
                    for vuid in datasets_by_date[eachDSN]:
                        if vuid in datasets_by_location:
                            """if a date vuid is in the location list it means we need it, else delete it"""
                            new_datasets_by_date[eachDSN] = datasets_by_date[eachDSN]
            
            return new_datasets_by_date
        else:
            return datasets_by_date

    def listDatasetsByGUIDs (self, guids):
        """
        Returns a dictionary mapping guid to dataset names.
        @since: 0.3.1
        
        @param guids: a list of guids
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        
        @return: Returns the guid->dataset names mapping.::
            {'guid': [dsnX, dsnY]}
            or
            {}
        """
        vuids = []
        for guid in guids:
            vuids.append((guid, self.contentClient.queryDatasetsWithFileByGUID(guid)))
        
        mapping = {}
        for guid,vuid in vuids:
            duids = []
            for vvuid in vuid:
                tmp = self.repositoryClient.queryDatasetByUID(vvuid)
                if tmp != {}:
                    duids.append(tmp['dsn'])
            mapping[guid] = duids
        
        return mapping

    def listDatasetsByMetaData (self, filter):
        """
        List the dataset versions that match the given criteria.
        
        @since: 0.2.0
        
        @param filter: list containing dictionaries of metadata attributes and values
            ({'attrname_0': attrvalue_0, ..., 'attrname_N': attrvalue_N}).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
        
        @return: List of tuples with (dataset name, version).
            [
                ('dataset_name_1', 'vuid_1'),
                (...),
                ('dataset_name_N', 'vuid_N')
            ]
        """
        return self.repositoryClient.queryDatasetByMetaData(filter)


    def listDatasetsInSite (self, site, complete=None, page=1, rpp=100):
        """
        List all the datasets and their versions available on
        the given site.
        
        @since: 0.2.0
        
        @param site: is the location to be searched for.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        @param page: is the page to be displayed.
        @param rpp: are the results per page.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: List of dataset versions.
            {'dsn': [version_numberX,... version_numberY]}
        """
        
        if page <= 0:
            page = 1
        if rpp <= 0:
            rpp = 100
        
        # get the vuids from the LocationCatalog
        
        tmp = self.locationClient.queryDatasetsInSite(site, complete, page, rpp)
        
        dsets = []
        for ds in tmp:
            dsets.append(ds)
        
        return self.repositoryClient.queryDatasetByVUIDs(dsets)


    def listFilesInDataset (self, dsn, version=None):
        """
        Given a dataset name, and optional version, the guids
        and lfns of the files in the dataset are returned.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number (0 => the latest version).
        
        B{Exceptions}:
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: Tuple containing the last timestamp and dictionary of guids mapped to lfns.::
            (
            {
                'guid_00': {'lfn': 'lfn_00', 'filesize': filesize_00, 'checksum': checksum_00},
                ...,
                'guid_n0': {'lfn': 'lfn_n0', 'filesize': filesize_n0, 'checksum': checksum_n0}
            },
            lastdate
            )
            where checksum is 'md5:<md5_32_character_string>'
        """
        
        # get all vuids to choose the one the user wants after
        dataset = self.repositoryClient.queryDatasetByName(dsn, version=0)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        if version == 0:
            """for the latest version use all vuids to get all diffs of the dataset"""
            vuids = dict_get_item(dataset, dsn)['vuids']
        elif version >= 0:
            vuids = dict_get_item(dataset, dsn)['vuids']
            vuids = vuids[-version:]
        else:
            vuids = dict_get_item(dataset, dsn)['vuids']
        
        
        # get the list of files
        return self.contentClient.queryFilesInDataset(vuids)


    def listFileReplicas (self, location, dsn, version=0):
        """
        
        @since: 0.3.6
        
        @author: Vincent Garonne
        @contact: vincent.garonne@cern.ch
        
        @param dsn is the dataset name.
        @param version is the dataset version number.
        @param location is the location place of the dataset
              B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
              @ return dictionnary e.g.:
        {'content': [guid1,...], 'transferState': 1, 'length': 46018142, 'checkstate': 6, 'found': 200, 'total': 200, 'immutable': 1}]
        """
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        vuid = dataset['vuids'][0] # the latest version
        return self.locationClient.listFileReplicas(vuid, location)


    def listMetaDataAttributes (self):
        """
        Returns a list containing all metadata attributes.
        
        @since: 0.2.0
        """
        return Metadata.DATASET + Metadata.DATASET_VERSION + Metadata.USER_VERSION


    def listSubscriptionInfo (self, dsn, location, version):
        """
        (since 0.2.11)
        """
        
        if version is not None and version > 0:
            """querying by vuid"""
            dict = self.repositoryClient.queryDatasetByName(dsn, version)
            dataset = dict_get_item(dict, dsn)
            uid = dataset['vuids'][0]
        else:
            """querying by duid [latest version always]"""
            uid = self.repositoryClient.resolveName(dsn)['duid']
        
        return self.subscriptionClient.getInfo(uid, location)


    def listSubscriptions (self, dsn, version=None, archived=SubscriptionArchivedState.__ANY__):
        """
        Return a list of sites that have subscribed the given dataset.
        
        (since 0.2.11)
        
        @param dsn: is the dataset name.
        @param version: is the dataset version number (0 is the latest).
        @param archived: is the dataset subscription state.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: List containing the sites that subscribed, at least, a version of the dataset.
        """
        
        if version is not None and version > 0:
            """querying by vuid"""
            
            output = self.repositoryClient.queryDatasetByName(dsn, version)
            
            if len(output) == 0:
                raise DQUnknownDatasetException(dsn)
            
            output = dict_get_item(output, dsn)
            uids = [output['vuids'][0]]
            
        else:
            """querying by duid and vuids"""
            output = self.repositoryClient.queryDatasetByName(dsn)
            
            if len(output) == 0:
                raise DQUnknownDatasetException(dsn)
            
            output = dict_get_item(output, dsn)
            
            uids = output['vuids']
            uids.append(output['duid'])
        
        output = self.subscriptionClient.querySubscriptions(uids)
        
        return output.keys()


    def listSubscriptionsInSite (self, site):
        """
        Returns a dict of all subscribed uids in a site containing all attributes.
        
        @since: 0.2.0
        
        @param site: is the dataset subscription dq2.location.
        @param archived: is the dataset subscription state.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: Returns a list of all subscribed uids in a site containing all attributes.
            {'dsn': [versionX, versionY]}
        """
        tmp = self.subscriptionClient.querySubscriptionsInSite(site)
        
        if len(tmp.keys()) == 0:
            return {}
        
        dsets = []
        for ds in tmp:
            dsets.append(ds)
         
        ds_subscriptions = self.repositoryClient.queryDatasetByDUIDs(dsets)
        vs_subscriptions =  self.repositoryClient.queryDatasetByVUIDs(dsets)
        
        for eachDataset in vs_subscriptions:
            if ds_subscriptions.has_key(eachDataset):
                ds_subscriptions[eachDataset].append(vs_subscriptions[eachDataset])
            else:
                ds_subscriptions[eachDataset] = vs_subscriptions[eachDataset]
        
        return ds_subscriptions


    def ping (self):
        """
        Checks if the DQ2 clients are well configured.
        
        @since 0.2.1
        
        
        B{Exceptions:}
            - DQInvalidConfigurationException is raised,
                in case a configured host is not responding or if it is an unknown host.
        
        @return: dictionary containing the client's configuration settings.::
            {
                'content'      : (url_insecure, url_secure, alive),
                'location'     : (url_insecure, url_secure, alive),
                'repository'   : (url_insecure, url_secure, alive),
                'subscription' : (url_insecure, url_secure, alive)
            }
        """
        clients = [
            self.contentClient,
            self.locationClient,
            self.repositoryClient,
            self.subscriptionClient
        ]
        
        import socket
        from urlparse import urlparse
        
        try:
            o = urlparse(self.contentClient.url)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((o[1].split(':')[0],int(o[1].split(':')[1])))
            s.close()
            contentAlive = True
        except:
            contentAlive = False
        
        try:
            o = urlparse(self.subscriptionClient.url)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((o[1].split(':')[0],int(o[1].split(':')[1])))
            s.close()
            subscriptionAlive = True
        except:
            subscriptionAlive = False
            
        try:
            o = urlparse(self.locationClient.url)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((o[1].split(':')[0],int(o[1].split(':')[1])))
            s.close()
            locationAlive = True
        except:
            locationAlive = False
            
        try:
            o = urlparse(self.repositoryClient.url)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((o[1].split(':')[0],int(o[1].split(':')[1])))
            s.close()
            repositoryAlive = True
        except:
            repositoryAlive = False
        
        # NOTE: the auto_configure gives the client configuration settings
        # not the user given configuration settings.
        result = {
            'content'      : (
                self.contentClient.url,
                self.contentClient.url_secure,
                contentAlive
            ),
            'location'     : (
                self.locationClient.url,
                self.locationClient.url_secure,
                locationAlive
            ),
            'repository'   : (
                self.repositoryClient.url,
                self.repositoryClient.url_secure,
                repositoryAlive
            ),
            'subscription' : (
                self.subscriptionClient.url,
                self.subscriptionClient.url_secure,
                subscriptionAlive
            ),
        }
        return result


    def registerDatasetLocation (self, dsn, location, version=0, complete=LocationState.INCOMPLETE, group=None):
        """
        Register new location of a dataset (which must already
        be defined in the repository).
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param location: is the dataset dq2.location.
        @param version: is the dataset version number.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQOpenedDatasetException is raised,
                in case of a opened dataset.
            - DQLocationExistsException is raised,
                in case a dataset version replica exists at the given dq2.location.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        if not dataset:
            raise DQUnknownDatasetException(dsn=dsn)
            
        # WARNING: central catalog result may have a different case -> use dict_get_item
        # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']        
        dataset = dict_get_item(dataset, dsn)
        vuid = dataset['vuids'][0] # the latest version
        
        # if asked to mark as complete
        if complete == LocationState.COMPLETE:
            # make sure dataset is closed
            st = self.repositoryClient.getState(dsn)
            
            # is not closed!
            if st == DatasetState.OPEN:
                raise DQOpenedDatasetException(dsn)
                     
        self.locationClient.addDatasetReplica(vuid=vuid, site=location, complete=complete, group=group)


    def registerDatasetSubscription (self, dsn, location, version=0, archived=SubscriptionArchivedState.UNARCHIVE, callbacks={}, sources={}, sources_policy=(SourcesPolicy.COMPLETE_SOURCES | SourcesPolicy.INCOMPLETE_SOURCES), wait_for_sources=0, destination=None, query_more_sources=0, sshare=None, group=None, activity=None):
        """
        Register a new subscription in the location catalog. If the
        version is not specified a duid is used.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param location: is the location where the dataset should be subscribed.
        @param version: is the dataset version number.
        @param archive: is the subscription state (dq2.common.DQConstants.SubscriptionArchivedState).
            is a bit indicating the archival bit for the dq2.subscription.
            Archival subscriptions are never deleted by the cache turnover
            service, while non-archival data may be deleted if the destination
            storage becomes full at some point. Possible values are
            SubscriptionArchivedState.ARCHIVE or SubscriptionArchivedState.UNARCHIVE.
        @param callbacks: is a dictionary which specifies, per subscription callback
            state, the list of HTTP URLs that should be triggered when the event
            occurs. e.g.::
                callbacks = {
                    CallbackType['FETCHER_VUID_COMPLETE']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_SKIP_VUID']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_FILE_NOT_QUEUED']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_FILES_QUEUED']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_UNKNOWN_DATASET']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FILE_PROPERTY_SET']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FILE_DONE']:
                        ['http://localhost:7777/monitor']
                }
        @param sources: is a dictionary indicating known sources for the
        @param subscription: and the strategy to look them up: either by doing a LRC
            lookup at the source, or by directly specifying a URL, e.g.::
                sources = {
                    'CERN'  : { 'policy': SourceResolverPolicy.LRC_LOOKUP },
                    'RAL'   : { 'policy' : SourceResolverPolicy.RELATIVE_SURL,
                    'rsurl' : 'srm://ral.uk/some/data/here/' }
                }
        @param sources_policy: may be one of dq2.common.DQConstants.SourcesPolicy.(ALL_SOURCES | KNOWN_SOURCES | CLOSE_SOURCES | COMPLETE_SOURCES | INCOMPLETE_SOURCES).
            This triggers the subscription services to change the strategy used
            for finding source replicas.
            KNOWN_SOURCES is required if 'sources' is specified as part of the dq2.subscription.
            It is possible to specify cumulative strategies: e.g.
            source_policy=SourcesPolicy.KNOWN_SOURCES | SourcesPolicy.COMPLETE_SOURCES
            will look for sources in the sites specified as part of the 'sources' field
            in the subscription, as well as in all sites known to have complete copies of the dataset.
        @param wait_for_sources: is a bit (True/False) indicating whether the subscription services
            should keep retrying to fulfill the subscription even if the sources files are missing.
            If True, subscription will not go to HOLD states even if sources are missing.
        @param destination: is a relative SURL where the destination files should be
            placed within the destination storage (e.g. '/my/path/').
        @param group: is to deleguate the group ownership. It needs the admin. rights to do that.
        @param activity: is a activity as defined in ToA.

        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQSubscriptionExistsException is raised,
                in case there is a subscription for this uid-dq2.location.
            - DQUnknownDatasetException is raised,
                in case the given dataset name doesn't exist.
            - DQUnknownDatasetVersionException is raised,
                in case the given version number doesn't exist for the given dataset.
        """
        uid = None
        # get the required vuid or duid => register the duid
        if version == 0:
            """registering version 0 is the same as registering the dataset (uid=duid)."""
            # if dataset doesn't exist it will throw a DQUnknownDatasetException
            duid = self.repositoryClient.resolveName(dsn)['duid']
            uid = duid
            
        else:
            """registering a specific dataset version (uid=vuid)."""
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            # WARNING: central catalog result may have a different case -> use dict_get_item
            # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
            dataset = dict_get_item(dataset, dsn)
            
            if len(dataset) == 0:
                """
                if dataset doesn't exist resolveName will throw a DQUnknownDatasetException
                if not then the dataset exists but the given version no => DQUnknowDatasetVersionException
                """
                self.repositoryClient.resolveName(dsn)
                raise DQUnknownDatasetVersionException(dsn, version)
            
            uid = dataset['vuids'][0]
        
        # register in subscription catalog
        self.subscriptionClient.addDatasetSubscription(
            uid, location, archived=archived, callbacks=callbacks, sources=sources, 
            sources_policy=sources_policy, wait_for_sources=wait_for_sources, 
            destination=destination, query_more_sources=query_more_sources, 
            sshare=sshare,group=group, activity=activity
        )


    def registerFilesInDataset (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
        """
        Add files to an existing dataset.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param lfns: is a list of logical filenames (LFN).
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param sizes: is a list of the file sizes.
        @param checksums: is a list of the file checksums.
            [md5:<md5_32_character_string>, ...]
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQClosedDatasetException is raised,
                in case the dataset version is closed.
            - DQFrozenDatasetException is raised,
                in case the dataset is frozen.
            - DQInvalidRequestException is raised,
                in case no files were added.
        """
        st = self.repositoryClient.getState(dsn)
        
        # is closed!
        if st == DatasetState.CLOSED:
            raise DQClosedDatasetException(dsn)
        elif st == DatasetState.FROZEN:
            raise DQFrozenDatasetException(dsn)
        
        dataset = self.repositoryClient.queryDatasetByName(dsn)
        # WARNING: central catalog result may have a different case -> use dict_get_item
        # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
        dataset = dict_get_item(dataset, dsn)
        
        duid = dataset['duid']
        vuid = dataset['vuids'][0] # latest version in on index 0
        
        # build the files structure
        files = build_file_dictionary(lfns, guids, sizes, checksums)
        
        self.contentClient.addFilesToDataset(vuid, dataset['vuids'], files)


    def registerFilesInDatasets (self, datasets):
        """
        @since: 0.3.0
        
        @param dataset: is a dictionary containing the dataset name and a list of its files.
            {'dsn': [{'guid', 'vuid', 'lfn', 'size', 'checksum'}]}
            where checksum is 'md5:<md5_32_character_string>'
        """
        
        
        for dsn in datasets:
            st = self.repositoryClient.getState(dsn)
            
            # is closed!
            if st == DatasetState.CLOSED:
                raise DQClosedDatasetException(dsn)
            elif st == DatasetState.FROZEN:
                raise DQFrozenDatasetException(dsn)
        
        bulk = []
        
        for dsn in datasets:
            dataset = self.repositoryClient.queryDatasetByName(dsn, 0)
            # WARNING: central catalog result may have a different case -> use dict_get_item
            # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
            dataset = dict_get_item(dataset, dsn)
            
            duid = dataset['duid']
            vuid = dataset['vuids'][0] # latest version in on index 0
            
            lfns = []
            guids = []
            sizes = []
            checksums = []
            
            for eachFile in datasets[dsn]:
                """"retrieve all file info to be inserted"""
                lfns.append(eachFile['lfn'])
                guids.append(eachFile['guid'])
                sizes.append(eachFile['size'])
                checksums.append(eachFile['checksum'])
            
            # build the files structure
            files = build_file_dictionary(lfns, guids, sizes, checksums)
            
            bulk.append({'vuid': vuid, 'vuids': dataset['vuids'], 'files': files})
        
        if len(bulk) > 0:
            self.contentClient.addFilesToDatasets(bulk)
        else:
            raise ValueError('There are no files to be registered.')


    def registerNewDataset (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
        """
        Register a brand new dataset and associated files (lists of lfns and guids).
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param lfns: is a list of logical filenames (LFN).
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param sizes: is a list of the file sizes.
        @param checksums: is a list of the file checksums.
            [md5:<md5_32_character_string>, ...]
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQDatasetExistsException is raised,
                in case there is a dataset with the given name.
        
        @return: Dictionary containing the dataset duid, vuid and version information.::
            {'duid': '...', 'vuid': '...', 'version': ...}
        """
        # add to repository and obtain vuid ({'vuid', 'version'})
        duid = dq2.common.generate_timed_uuid()
        vuid = dq2.common.generate_timed_uuid()
        
        self.repositoryClient.addDataset(dsn, duid, vuid)
        
        if len(lfns) > 0:
            files = build_file_dictionary(lfns, guids, sizes, checksums)
            
            self.contentClient.addFilesToDataset(vuid, [], files)
        
        return {'duid': duid, 'version': 1, 'vuid': vuid}


    def registerNewVersion (self, dsn, lfns=[], guids=[], sizes=[], checksums=[]):
        """
        Register a new version of the dataset with the
        given additional files (lists of lfns and guids).
        Plus, it notifies the subscription catalog for changes
        on the dataset and on dataset previous version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param lfns: is a list of logical filenames (LFN).
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param sizes: is a list of the file sizes.
        @param checksums: is a list of the file checksums.
            [md5:<md5_32_character_string>, ...]
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQFileExistsInDatasetException is raised,
                in case the given guid is already registered for the given dataset.
            - DQInvalidRequestException is raised,
                in case no files have been added to the content catalog.
            - DQSecurityException is raised,
                in case the user has no permissions to update the dataset.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: Dictionary containing the dataset version information.::
            {'vuid': vuid_1, 'version': 1, 'duid': duid}
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, 0) # returns the latest version
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)

        # WARNING: central catalog result may have a different case -> use dict_get_item
        # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
        dataset = dict_get_item(dataset, dsn)
        
        # register new version
        newvuid = dq2.common.generate_uuid()
        newvuid_dict = self.repositoryClient.updateVersion(dsn, newvuid)
        newvuid_dict['vuid'] = newvuid
        newversion = newvuid_dict['version']
        
        # register new files
        files = build_file_dictionary(lfns, guids, sizes, checksums)
        self.contentClient.addFilesToDataset(newvuid, dataset['vuids'], files)
        
        # notify dataset changes
        duid = newvuid_dict['duid']
        
        
        return newvuid_dict


    def resetSubscription (self, dsn, location, version=0):
        """
        Reset the dataset subscription registered at the given dq2.location.
        
        @since: 0.3.0
        
        @param dsn: is the dataset name.
        @param location: is the location where the dataset is subscribed.
        @param version: is the dataset version number.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the given dataset name doesn't exist.
            - DQUnknownDatasetVersionException is raised,
                in case the given version number doesn't exist for the given dataset.
            - DQUnknownSubscriptionException is raised,
                in case there are no subscriptions at the given site.
        """
        uid = None
        # get the required vuid or duid => register the duid
        if version == 0:
            """registering version 0 is the same as registering the dataset (uid=duid)."""
            # if dataset doesn't exist it will throw a DQUnknownDatasetException
            # but we have to handle it manually because a TypeError will precede it
            try:
                duid = self.repositoryClient.resolveName(dsn)['duid']
            except TypeError, e:
                raise DQUnknownDatasetException(dsn, version)
            uid = duid
            
        else:
            """registering a specific dataset version (uid=vuid)."""
            dataset = self.repositoryClient.queryDatasetByName(dsn, version)
            # WARNING: central catalog result may have a different case -> use dict_get_item
            # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
            dataset = dict_get_item(dataset, dsn)
            
            if len(dataset) == 0:
                """
                if dataset doesn't exist resolveName will throw a DQUnknownDatasetException
                if not then the dataset exists but the given version no => DQUnknowDatasetVersionException
                """
                self.repositoryClient.resolveName(dsn)
                raise DQUnknownDatasetVersionException(dsn, version)
            
            uid = dataset['vuids'][0]
        
        self.subscriptionClient.reset(uid, location)


    def resetSubscriptionsInSite (self, site):
        """
        Resets the subscriptions registered in the given site.
        
        @since: 0.3.0
        
        @param site: is the dataset subscription dq2.location.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownSubscriptionException is raised,
                in case there are no subscriptions at the given site.
        """
        
        subscriptions = self.subscriptionClient.querySubscriptionsInSite(site)
        
        if len(subscriptions) <= 0:
            """ there are no subscriptions at the given site """
            raise DQUnknownSubscriptionException('', site)
        
        for eachUID in subscriptions.keys():
            self.subscriptionClient.reset(eachUID, site)


    def startTransaction (self):
        """
        Starts a transaction.
        @since: 0.3.0
        """
        if self.tuid is None:
            #self.tuid = dq2.common.generate_uuid()
            self.tuid = USER + FMT_TIMESTAMP % time.gmtime()[0:7]
        self.contentClient.tuid = self.tuid
        self.locationClient.tuid = self.tuid
        self.repositoryClient.tuid = self.tuid
        self.subscriptionClient.tuid = self.tuid

    def setReplicaMetaDataAttribute (self, dsn, location, attrname, attrvalue):
        """
        Set the value of the given attribute to the given
        value for the given dataset replica. Operates on the current version.
        
        
        @param dsn: is the dataset name.
        @param location: is the location name.        
        @param attrname: is the metadata dataset attribute name.
        @param attrvalue: is the metadata dataset attribute value.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
            - DQSecurityException is raised,
                in case the user has no permissions to set metadata attributes on the dataset.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        
        return self.locationClient.setReplicaMetaDataAttribute(dsn, location,attrname, attrvalue)

    def setMetaDataAttribute (self, dsn, attrname, attrvalue):
        """
        Set the value of the given attribute to the given
        value for the given dataset. Operates on the current version.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param attrname: is the metadata dataset attribute name.
        @param attrvalue: is the metadata dataset attribute value.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequest is raised,
                in case the given parameters aren't valid.
            - DQSecurityException is raised,
                in case the user has no permissions to set metadata attributes on the dataset.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        if attrname.upper() == 'PROVENANCE':
            raise DQInvalidRequestException('Provenance attribute cannot be set by user!')
        
        return self.repositoryClient.setMetaDataAttribute(dsn, attrname, attrvalue)


    def verifyFilesInDataset (self, dsn, guids, version=None):
        """
        Verifies if the given files' global unique identifiers (GUIDS) are registered on the dataset.
        
        (since 0.4.0)
        
        @param dsn: is the dataset name.
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @param version: is the dataset version number (0 => the latest version).
        
        B{Exceptions}:
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: Dictionary with the following format:
            {
                GUIDX: True, # exist
                (...)
                GUIDY: False # don't exist
            }
        """
        
        # get all vuids to choose the one the user wants after
        dataset = self.repositoryClient.queryDatasetByName(dsn, version=0)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        if version == 0:
            """for the latest version use all vuids to get all diffs of the dataset"""
            vuids = dict_get_item(dataset, dsn)['vuids']
        elif version >= 0:
            """"""
            dataset = dict_get_item(dataset, dsn)
            vuids = dataset['vuids'][-version:]
        else:
            vuids = dict_get_item(dataset, dsn)['vuids']
        
        
        # get the list of files
        return self.contentClient.filesInDataset(vuids, guids)

    def listDatasetsByNameInSite (self, site, complete=None, name=None, p=None, rpp=None, group=None):
        """
        List dataset at site
        
        @since: 0.4.0
        """
        
        return self.locationClient.queryDatasetsByNameInSite(site=site, complete=complete, name=name, p=p, rpp=rpp, group=group)

        
    def getMasterReplicaLocation(self, dsn, version=0):
        """
        Returns the master replicas location.
        
        @since: 0.4.0
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)        
        if len(dataset) == 0:
            raise DQUnknownDatasetVersionException(dsn, version)            
        vuid = dataset[dsn]['vuids'][0] # the latest/given version        
            
        return self.locationClient.getMasterLocation (vuid)
        
    def checkDatasetConsistency(self,location,dsn, version=0, threshold=None):
        """
        Request a consistency check of a dataset replica.
        
        @since: 0.4.0
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetVersionException(dsn, version)
            
        vuid = dataset[dsn]['vuids'][0] # the latest/given version
        
        return self.locationClient.refreshReplicaCompleteness (vuid=vuid, location=location, threshold=threshold)

    def updateCompleteness (self, dsn, version, location, files):
        """
        Update dataset completeness
        
        @since: 0.4.0
        """        
        return self.locationClient.updateCompleteness (dsn=dsn, version=version, location=location, files=files)
    
        
    def listMetaDataReplica(self, location, dsn, version=0):
        """
        Returns a list containing all metadata attributes for dataset replicas.
        
        @since: 0.4.0
        """        
        
        # get the vuid
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetVersionException(dsn, version)
            
        vuid = dataset[dsn]['vuids'][0] # the latest/given version
                        
        return self.locationClient.queryDatasetReplicaMetadata (vuid=vuid, location=location)
                

    def listGarbageCollectedReplicas (self,  location, name=None, p=None, rpp=None):
        """
        Returns a list containing all garbage collected datasets at location.
        
        @since: 0.4.0
        """        
    
        return  self.locationClient.queryGarbageCollectedReplicas(location=location, name=name, p=p, rpp=rpp)                
    
    def listDeletedReplicas (self,  location, name=None, p=None, rpp=None):
        """
        Returns a list containing all deleted datasets at location.
        
        @since: 0.4.0
        """            
        return  self.locationClient.queryDeletedReplicas(location=location, name=name, p=p, rpp=rpp)

    def listGarbageCollectedFiles (self, dsn, location):
                    
        return self.locationClient.listGarbageCollectedFiles(dsn=dsn, location=location)
            
    def setDatasetReplicaToDeleted (self, dsn, location):
        """
        Declare a dataset to deleted into the deletion service.
        
        @since: 0.4.0
        """                    
        return self.locationClient.setDatasetReplicaToDeleted(dsn=dsn, location=location)

    def listDatasetReplicasInContainer (self, cn):
        """
        @return: a dictionary ontaining all dataset replicas for the container.
        { <dataset_1>: 
                   {<vuid>: {0: [<site_1>], 1: [<site_2>,<site_3>]}}, 
        <dataset_2>: 
                  {<vuid>: {0: [<site_1>], 1: [<site_2>,<site_3>]}}, 
        ...}
           
        @since: 0.4.6
        """            
        return  self.locationClient.listDatasetReplicasInContainer(cn=cn)    

    def queryStorageUsage (self, key=None, value=None, site=None, metaDataAttributes={}, locations=[]):
        """
        Returns a tuple containing storage usage infos .
        
        @since: 0.4.6
        """            
        return  self.locationClient.queryStorageUsage(key=key, value=value, site=site, metaDataAttributes=metaDataAttributes, locations=locations)
    
    def queryStorageUsageHistory (self, site, key='GRID', value='total'):
        """
        Returns a tuple containing storage usage evolution.
        @since: 0.4.*
        """    
        return  self.locationClient.queryStorageUsageHistory(key=key, value=value, site=site)
               
    def queryReplicaHistory (self, dsn, location):
        """
        Returns a tuple containing replica history.
        @since: 0.4.*
        """    
        return  self.locationClient.queryReplicaHistory(dsn=dsn, location=location)
    
    def listFileReplicasBySites (self, dsn, version=0, locations=[], threshold=None, timeout=None):
      """
      Iterator to list file replica with info refresh if needed.   
      @author: Vincent Garonne
      @contact: atlas-dq2-dev@cern.ch
   
      @param dsn: String - Dataset name to check.
      @param version: Number - Dataset version to check.
      @param locations: List of locations. Restrict result to a subset of locations.
      @param threshold:  in seconds. Refresh info if checkdate < sysdate - threshold.
      @param timeout:  in seconds.      
   
      @raise No replicas found, timeout
      """
      from dq2.location.DQLocationConstants import LocationState
      from dq2.location.DQLocationConstants import TransferState
      from dq2.location.DQLocationConstants import MutableState
      from dq2.location.DQLocationConstants import CheckState
      
      if timeout:
          endtime = time.time() + float(timeout)
      _min_sleep  = 0.001
      _max_sleep  = 0.05
      _multiplier = 2
      _delay      = _min_sleep / _multiplier
    
      ret = retry(self.listDatasetReplicas, dsn=dsn, version=version)
    
      if not ret: raise 'No replicas found for %s'%dsn
    
      sites = ret[ret.keys()[0]][LocationState.COMPLETE] + ret[ret.keys()[0]][LocationState.INCOMPLETE]
    
      if locations: sites = filter (lambda s: s in locations,sites)
    
      refresh = list()
      while sites:

        for site in sites:
          if threshold and (site,dsn,version) not in refresh:
            if retry(self.checkDatasetConsistency, location=site, dsn=dsn, version=version, threshold=threshold):
               refresh.append((site,dsn,version))

          metadata = retry (self.listMetaDataReplica, location=site, dsn=dsn, version=version)
          if (int(metadata ['transferState']) == TransferState.ACTIVE or metadata['immutable'] == MutableState.MUTABLE) and (site,dsn,version) not in refresh:
            if retry (self.checkDatasetConsistency, location=site, dsn=dsn, version=version):
               refresh.append((site,dsn,version))

          elif metadata ['checkState'] == CheckState.CHECKED: # CheckState.CHECKED == 6
             metadata ['transferState'] == TransferState.ACTIVE or metadata['immutable'] == MutableState.MUTABLE
             yield site, retry(self.listFileReplicas, dsn=dsn, location=site)[0]
             if (site,dsn,version) in refresh: refresh.remove ((site,dsn,version))
             if site in sites: sites.remove   (site)

          elif (site,dsn,version) not in refresh and metadata ['checkState'] not in (CheckState.CHECKING,CheckState.REQUESTED): # (1,2)
            if retry (self.checkDatasetConsistency, location=site, dsn=dsn, version=version):
              refresh.append((site,dsn,version))

        if timeout is None:
            _delay = min(_delay * _multiplier, _max_sleep)
        else:
            remaining = endtime - time.time()
            if remaining <= 0.0:
                raise 'Timeout'
            _delay = min(_delay * _multiplier, remaining, _max_sleep)
        sleep(_delay)
