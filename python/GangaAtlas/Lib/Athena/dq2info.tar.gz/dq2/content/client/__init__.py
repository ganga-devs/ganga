"""
Package contains all modules for the DQ2 content client component.

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2.0
@version: $Id: __init__.py,v 1.3.2.6.2.1.2.1 2007/12/12 09:50:08 psalgado Exp $
"""

__version__ = '$Name: dq2-content-client-0-3-7 $'

PACKAGE = 'dq2-content-client'