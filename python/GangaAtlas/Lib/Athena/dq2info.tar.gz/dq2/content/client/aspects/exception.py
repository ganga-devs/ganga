"""
Content client exception handling aspect.

(since 0.3.0)
"""

from dq2.common.aspects import wrap_around
from dq2.common.DQException import DQException
from dq2.common.dao.DQDaoException import DQDaoException
from dq2.common.dao.aspects.exception import handle


def wrap_package ():
    """
    Wraps client components
    
    (since 0.3.0)
    """
    from dq2.content.client.ContentClient import ContentClient
    
    # before sending a HTTP request a tuid should be assigned to the client
    wrap_around(ContentClient.addFilesToDataset, handle)
    wrap_around(ContentClient.deleteDataset, handle)
    wrap_around(ContentClient.deleteFilesFromDataset, handle)
    
    wrap_around(ContentClient.filesInDataset, handle)
    wrap_around(ContentClient.getNumberOfFiles, handle)
    wrap_around(ContentClient.queryDatasetsWithFileByGUID, handle)
    
    wrap_around(ContentClient.queryFilesInDataset, handle)
    wrap_around(ContentClient.queryFilesByCreationDate, handle)