"""
Content client validation aspect.

(since 0.3.0)
"""


from dq2.common.aspects import wrap_around

from dq2.content.aspects.validation import *


def wrap_package ():
    """
    Loads the validation aspect for the content client.
    (since 0.3.0)
    """
    from dq2.content.client.ContentClient import ContentClient
    
    wrap_around (ContentClient.addFilesToDataset, addFilesToDataset)
    
    wrap_around (ContentClient.deleteDataset, deleteDataset)
    wrap_around (ContentClient.deleteFilesFromDataset, deleteFilesFromDataset)
    
    wrap_around (ContentClient.filesInDataset, filesInDataset)
    wrap_around (ContentClient.getNumberOfFiles, getNumberOfFiles)
    
    wrap_around (ContentClient.queryDatasetsWithFileByGUID, queryDatasetsWithFileByGUID)
    wrap_around (ContentClient.queryFilesByCreationDate, queryFilesByCreationDate)
    wrap_around (ContentClient.queryFilesInDataset, queryFilesInDataset)
