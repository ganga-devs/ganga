"""
Content client transaction aspect.

(since 0.3.0)
"""

from dq2.common.aspects import wrap_around


def wrap_package ():
    """
    Loads the validation aspect for the content client.
    (since 0.3.0)
    """
    from dq2.content.client.ContentClient import ContentClient
    from dq2.common.dao.aspects.transaction import start_and_end, start_and_commit
    
    wrap_around (ContentClient.addFilesToDataset, start_and_end)
    wrap_around (ContentClient.deleteDataset, start_and_end)
    wrap_around (ContentClient.deleteFilesFromDataset, start_and_end)
    wrap_around (ContentClient.getNumberOfFiles, start_and_end)
    wrap_around (ContentClient.queryDatasetsWithFileByGUID, start_and_end)
#    wrap_around (ContentClient.queryDatasetsWithFileByLFN, start_and_end)
    wrap_around (ContentClient.queryFilesInDataset, start_and_end)
    wrap_around (ContentClient.queryFilesByCreationDate, start_and_end)