"""
Oracle content catalog test suite.

@author: Pedro Salgado <pedro.salgado@cern.ch>
@version: $Id: DQContentClientTestSuite.py,v 1.1.2.6.4.1 2008/04/07 13:28:11 psalgado Exp $

@since: 0.3.0
"""


"""
Oracle content catalog test suite.

@author: Pedro Salgado <pedro.salgado@cern.ch>
@version: $Id: DQContentClientTestSuite.py,v 1.1.2.6.4.1 2008/04/07 13:28:11 psalgado Exp $

@since: 0.3.0
"""


from dq2.common.client.testcase.DQClientTestSuite import DQClientTestSuite

from dq2.content.client.ContentClient import ContentClient
from dq2.content.testcase.DQContentTestCase import DQContentTestCase
from dq2.content.testcase.DQAddFilesToDatasetTestCase import DQAddFilesToDatasetTestCase
from dq2.content.testcase.DQDeleteFilesFromDatasetTestCase import DQDeleteFilesFromDatasetTestCase


class DQContentClientTestSuite (DQClientTestSuite):
    """
    @since: 0.3.0
    """


    def __init__ (self, specificTest=None):
        """
        @since: 0.3.0
        """
        
        self.suite = DQClientTestSuite.__init__(
            self,
            ContentClient(),
            [
                DQAddFilesToDatasetTestCase,
                DQDeleteFilesFromDatasetTestCase,
                DQContentTestCase
            ],
            specificTest=specificTest
        )


def main (test):
    """
    @since: 0.3.0
    """
    suite = DQContentClientTestSuite(test)
    
    import unittest
    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == '__main__':
    """
    Runs all tests in DQOracleContentTestSuite.
    
    @since: 0.3.0
    """
    import sys
    #from dq2.common.testcase import traceit
    #sys.settrace(traceit)
    test = None
    try:
        test = sys.argv[1]
    except:
        pass
    
    main(test)