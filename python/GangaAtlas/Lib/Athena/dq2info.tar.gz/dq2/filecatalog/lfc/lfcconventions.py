from dq2.filecatalog.lfc.LFCFileCatalogConfigurator import LFCFileCatalogConfigurator
import re

LFC_HOME = '/grid/atlas/'

def __strip_tag(tag):
    """
    Drop the _sub and _dis suffixes for panda datasets from the lfc path 
    they will be registered in 
    """
    import re

    suffixes_to_drop=['_dis','_sub','_tid']
    try:
        suffixes_to_drop.extend(LFCFileCatalogConfigurator().getTagSuffixesList())
    except:
        pass          
    
    stripped_tag=tag
    try:
        for suffix in suffixes_to_drop:
            stripped_tag=re.sub('%s.*$'%suffix,'',stripped_tag)
    except IndexError:        
        return stripped_tag
    
    return stripped_tag            


def __strip_dsn(dsn):
    """
    Drop the _sub and _dis suffixes for panda datasets from the lfc path 
    they will be registered in 
    """
    import re

    suffixes_to_drop=['_dis','_sub','_frag']
    try:
        suffixes_to_drop.extend(LFCFileCatalogConfigurator().getPandaSuffixesList())
    except:
        pass        
    
    fields=dsn.split('.')
    last_field=fields[-1]
    
    try:
        for suffix in suffixes_to_drop:            
            last_field=re.sub('%s.*$'%suffix,'',last_field)
    except IndexError:        
        return dsn
    
    fields[-1]=last_field
    stripped_dsn='.'.join(fields)        

    return stripped_dsn            

def to_native_lfn(dsn, lfn, prefix='dq2/'):
    """
    Return LFN with LFC hierarchical namespace.        
    """
    
    bpath = LFC_HOME
    if bpath[-1] != '/': bpath += '/'
    
    # add prefix
    bpath += prefix
    if bpath[-1] == '/': bpath = bpath[:-1]

    # check how many dots in dsn
    fields = dsn.split('.')
    nfields=len(fields)
    
    if nfields == 1:
        stripped_dsn=__strip_dsn(dsn)
        return '%s/other/%s/%s' % (bpath, stripped_dsn, lfn)

    elif nfields == 2:
        project = fields[0]    
        stripped_dsn=__strip_dsn(dsn)
        return '%s/%s/%s/%s' % (bpath, project, stripped_dsn, lfn)         
        
    elif nfields < 5 or re.match('user*|group*',fields[0]):
        project = fields[0]
        f2 = fields[1]
        f3 = fields[2]
        stripped_dsn=__strip_dsn(dsn)
        return '%s/%s/%s/%s/%s/%s' % (bpath, project, f2, f3, stripped_dsn, lfn)
             
    else: 
        project = fields[0]
        dataset_type = fields[4]
        if nfields==5:
            tag='other'
        else:
            tag = __strip_tag(fields[-1])                        
        stripped_dsn=__strip_dsn(dsn)
        return '%s/%s/%s/%s/%s/%s' % (bpath, project, dataset_type, tag, stripped_dsn, lfn)


