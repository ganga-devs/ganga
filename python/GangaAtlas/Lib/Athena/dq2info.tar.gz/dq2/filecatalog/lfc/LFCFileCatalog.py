"""
Contains the LFC File Catalog interface module.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""
import errno
import os
import re
import warnings
warnings.filterwarnings('ignore')

from dq2.filecatalog.FileCatalogInterface import FileCatalogInterface
from dq2.filecatalog.FileCatalogUnavailable import FileCatalogUnavailable
from dq2.filecatalog.lfc.lfcconventions import to_native_lfn
from dq2.filecatalog.lfc.LFCFileCatalogException import LFCFileCatalogException
from dq2.filecatalog.lfc.LFCFileCatalogConfigurator import LFCFileCatalogConfigurator
from dq2.subscription.DQSubscriptionConstants import SubscriptionArchivedState

from dq2.common import log as logging

def get_hostname (surl):
    """
    Returns string with hostname or empty
    string if hostname could not be derived
    
    @param surl: URL.
    @type surl: str
    
    @return: hostname.
    @rtype: str
    """
    reg = re.search('[^:]+:(/)*([^:/]+)(:[0-9]+)?(/)?.*', surl)
    try: return reg.group(2)
    except: return ''

def create_shards(lst, n):
    blk, i = [], 0
    for el in lst:
        blk.append(el)
        i += 1
        if i == n:
            yield blk
            blk, i = [], 0
    if i > 0: yield blk 
    
class LFCFileCatalog(FileCatalogInterface):
    """
    Class definition for LFC File Catalog.
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: LFCFileCatalog.py,v 1.33 2009/06/22 13:01:56 fbarreir Exp $
    """

    """
    Timeout for active connection (session or transaction) with LFC server.
    """
    _connectionTimeoutSecs = 90
    
    """
    Retries in case of connection failure with LFC server.
    """
    _connectionRetries = 0
    
    """
    Interval between connection retries in case of connection failure with LFC server.
    """
    _connectionRetryIntervalSecs = 0
    
    """
    The requests will be split into shards
    """
    _shardLimit=50


    def __init__(self, endpoint):
        """
        Constructor for the LFCFileCatalog object.
        
        Initializes LFC session on creation.
        """        
        self._endpoint = endpoint    
        
        connectionTimeoutSecs = LFCFileCatalogConfigurator().getConnectionTimeoutSeconds()
        if connectionTimeoutSecs is not None:
            self._connectionTimeoutSecs = connectionTimeoutSecs
        
        connectionRetries = LFCFileCatalogConfigurator().getConnectionRetries()
        if connectionRetries is not None:
            self._connectionRetries = connectionRetries

        connectionRetryIntervalSecs = LFCFileCatalogConfigurator().getConnectionRetryIntervalSeconds()
        if connectionRetryIntervalSecs is not None:
            self._connectionRetryIntervalSecs = connectionRetryIntervalSecs
            
        shardLimit = LFCFileCatalogConfigurator().getShardLimit()
        if shardLimit:
            self._shardLimit = shardLimit
            
        logger = logging.getLogger("dq2.filecatalog.lfc")
            
        os.environ['LFC_CONNTIMEOUT'] = str(self._connectionTimeoutSecs)
        os.environ['LFC_CONRETRY'] = str(self._connectionRetries)
        os.environ['LFC_CONRETRYINT'] = str(self._connectionRetryIntervalSecs)
        try:
            del os.environ['LFC_HOST']
        except KeyError:
            pass
        try:
            del os.environ['LFC_HOME']
        except KeyError:
            pass
        
        try:
            host, prefix = self._endpoint[self._endpoint.find('://')+3:].split(':')
            if prefix[-1] != '/':
                prefix += '/'
            self._host = host
            self._prefix = prefix
        except:
            raise LFCFileCatalogException('Error parsing LFC endpoint [%s]' % endpoint)
        
        try:
            # new clients should always initialize LFC multi-threaded
            self._lfc = __import__('lfcthr')
            self._lfc.init()
        except:
            raise LFCFileCatalogException('Python bindings missing')
        
        if LFCFileCatalogConfigurator().supportsJPMethod(self._host):
            from dq2.filecatalog.lfc.LFCBulkMethods import LFCBulkMethods            
            self._lfcmethods=LFCBulkMethods(endpoint, self._lfc, self._host, prefix, self._shardLimit, logger)
        else:
            from dq2.filecatalog.lfc.LFCSerialMethods import LFCSerialMethods
            self._lfcmethods=LFCSerialMethods(endpoint, self._lfc, self._host, prefix, self._shardLimit) 
                
    def __del__(self):
        """
        Destructor for the LFCFileCatalog object.
        """ 
        
    def connect(self):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.connect()}
        """
        if self._lfc.lfc_startsess(self._host, '') != 0:
            raise LFCFileCatalogException('Cannot connect to LFC [%s]' % self._endpoint)
    
    def disconnect(self):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.disconnect()}
        """
        self._lfc.lfc_endsess()   

    def bulkFindReplicas(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkFindReplicas(self, files)}
        """        
        return self._lfcmethods.bulkFindReplicas(files)
    
    def bulkRegisterFiles(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkRegisterFiles(self, files)}
        """
        return self._lfcmethods.registerFiles(files)
        
    def bulkUnlink (self, files):
        return self._lfcmethods.bulkUnlink(files)
    
    def bulkUnregisterFiles(self, files, replicaOnly=True):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkUnregisterFiles(self, files, replicaOnly=True)}
        """
        return self._lfcmethods.bulkUnregisterFiles(files,replicaOnly)
 
    def bulkTouchFiles(self, files, archival):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkTouchFiles(self, files, archival)}
        """
        # fake implementation for LFC as bit is not used.
        r = {}
        for guid in files:
            r[guid] = True
        return r

