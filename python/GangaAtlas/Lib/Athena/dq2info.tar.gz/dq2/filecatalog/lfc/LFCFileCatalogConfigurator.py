"""
Contains the class definition for Config objects.
"""
from dq2.common.Config import Config

import re


class LFCFileCatalogConfigurator:
    """
    Class definition for LFC File Catalog configurator.
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: LFCFileCatalogConfigurator.py,v 1.11 2009/07/13 13:28:11 fbarreir Exp $
    """
    
    """
    Holds the singleton reference.
    """
    _instance = None
    
    """
    Configuration objects
    """
    _supportsBulkMethod = {}
    _supportsJPMethod = {}
    _connectionTimeoutSecs = None
    _connectionRetries = None
    _connectionRetryIntervalSecs = None
    _shardLimit = None
    _tagSuffixesList = []
    _pandaSuffixesList = []
    
    
    def __new__(cls):
        """
        Invoked on every class instance creation.
        
        Makes sure that only one instance of this class ever exists.
        
        @return: A reference to the class singleton
        """
        if not cls._instance:
            cls._instance = object.__new__(cls)
        
        return cls._instance


    def __init__(self):
        """
        Object constructor.
        
        As this is a singleton, nothing is put in here (otherwise it would
        be constantly called).
        """
        pass


    def supportsBulkMethod(self, host):
        """
        Returns True if host has support for bulk method.
        
        Default is True.
        """
        if self._supportsBulkMethod.has_key(host):
            return self._supportsBulkMethod[host]
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            support = int(config.get('bulkLookupSupport', host))
            self._supportsBulkMethod[host] = bool(support)
        except:
            self._supportsBulkMethod[host] = True

        return self._supportsBulkMethod[host]


    def supportsJPMethod(self, host):
        """
        Returns True if host has support for bulk method.
        
        Default is False.
        """
        if self._supportsJPMethod.has_key(host):
            return self._supportsJPMethod[host]
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            support = int(config.get('JPLookupSupport', host))
            self._supportsJPMethod[host] = bool(support)
        except:
            self._supportsJPMethod[host] = False

        return self._supportsJPMethod[host]
        
        
    def getConnectionTimeoutSeconds(self):
        if self._connectionTimeoutSecs is not None:
            return self._connectionTimeoutSecs
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            self._connectionTimeoutSecs = int(config.get('dq2-filecatalog-lfc', 'connectionTimeoutSecs'))
        except:
            pass
        
        return self._connectionTimeoutSecs
        
        
    def getConnectionRetries(self):
        if self._connectionRetries is not None:
            return self._connectionRetries
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            self._connectionRetries = int(config.get('dq2-filecatalog-lfc', 'connectionRetries'))
        except:
            pass
        
        return self._connectionRetries
            
        
    def getConnectionRetryIntervalSeconds(self):
        if self._connectionRetryIntervalSecs is not None:
            return self._connectionRetryIntervalSecs
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            self._connectionRetryIntervalSecs = int(config.get('dq2-filecatalog-lfc', 'connectionRetryIntervalSecs'))
        except:
            pass
        
        return self._connectionRetryIntervalSecs      

    
    def getShardLimit(self):
        if self._shardLimit:
            return self._shardLimit
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            self._shardLimit = int(config.get('dq2-filecatalog-lfc', 'shardLimit'))
        except:
            pass
        
        return self._shardLimit
    
    def getTagSuffixesList(self):
        if self._tagSuffixesList:
            return self._tagSuffixesList
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            suffixesString=str(config.get('dq2-filecatalog-lfc', 'tagSuffixesList'))
            self._tagSuffixesList = suffixesString.split(',')
        except:
            pass
        
        return self._tagSuffixesList

    def getPandaSuffixesList(self):
        if self._pandaSuffixesList:
            return self._pandaSuffixesList
        
        config = Config().getConfig('dq2-filecatalog-lfc')
        
        try:
            suffixesString=str(config.get('dq2-filecatalog-lfc', 'pandaSuffixesList'))
            self._pandaSuffixesList = suffixesString.split(',')
        except:
            pass
        
        return self._pandaSuffixesList



      