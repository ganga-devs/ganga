"""
Contains the File Catalog base exception.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""
from dq2.common.DQException import DQException


class FileCatalogException(DQException):
    """
    Class representing any file catalog implementation.
    
    @see: L{dq2.filecatalog.FileCatalogException}
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: FileCatalogException.py,v 1.4 2007/12/11 12:22:40 mbranco Exp $
    """    
    pass
