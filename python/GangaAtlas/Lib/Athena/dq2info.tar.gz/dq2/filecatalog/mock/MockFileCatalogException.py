from dq2.filecatalog.FileCatalogException import FileCatalogException

class MockFileCatalogException(FileCatalogException):
    def __init__(self, desc):
        self.desc = desc
    def __str__(self):
        return "Mock catalog exception [%s]" % self.desc