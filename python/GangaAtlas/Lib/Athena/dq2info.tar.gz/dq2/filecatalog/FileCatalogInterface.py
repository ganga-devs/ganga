"""
Contains the File Catalog interface module.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""
from dq2.info import TiersOfATLAS
from dq2.filecatalog.FileCatalogException import FileCatalogException


class FileCatalogInterface(object):
    """
    Interface definition for the DQ2 File Catalog.
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: FileCatalogInterface.py,v 1.8 2008/02/21 08:49:02 mbranco Exp $
    """

    def __init__(self, lrcep):
        """
        Constructor for the FileCatalogInterface.
        
        Typical example on how to use class
        -----------------------------------
        
        from dq2.info import TiersOfATLAS
        from dq2.filecatalog import create_file_catalog

        siteID = 'CERNPROD'
        catalog = TiersOfATLAS.getLocalCatalog(siteID)
        if catalog is None:
            raise 'Site has no known catalog!'

        try:
            fileCatalog = create_file_catalog(catalog)
        except FileCatalogException, e:
            raise 'Failed creating file catalog instance for %s with %s' % (catalog, str(e))

        try:
            fileCatalog.connect()
        except FileCatalogException, e:
            raise 'Failed connecting to file catalog for %s with %s' % (catalog, str(e))

        # read file replicas. Although we queried CERNPROD catalogue only
        # we will accept back replicas present either on CERNPROD and CERNCAF
        # but not TIER0TAPE which also shares the same catalogue.
        filesToQuery = {'guid1': 'lfn1', 'guid2': 'lfn2'}
        try:
            replicas = fileCatalog.bulkFindReplicas(filesToQuery, ['CERNPROD', 'CERNCAF'])
        except FileCatalogException, e:
            raise 'Bulk query failed for %s with %s' % (catalog, str(e))
        
        # parse response
        for guid in filesToQuery:
            # guid not present in response
            if not dict_has_key(replicas, guid):
                print 'GUID %s not present on site' % guid
            else:
                # exception occurred for guid
                value = dict_get_item(replicas, guid)
                if isinstance(value, FileCatalogException):
                    print 'Error querying GUID %s with %s' % (guid, value)
                else:
                    # scan replicas
                    print 'Found GUID %s with attributes %s' % (guid, value)

        try:
            fileCatalog.disconnect()
        except FileCatalogException, e:
            raise 'Failed disconnecting from file catalog for %s with %s' % (catalog, str(e))
        
        """
        raise NotImplementedError("Class is abstract so method cannot be"
            + " called")

    def connect(self):
        """
        Connect to file catalog instance.
        """
        raise NotImplementedError("Class is abstract so method cannot be"
            + " called")

    def disconnect(self):
        """
        Disconnect from file catalog instance.
        """
        raise NotImplementedError("Class is abstract so method cannot be"
            + " called")

    def bulkFindReplicas(self, files):
        """
        Find replicas for files on site. Files is given
        by a dictionary mapping guid to lfn. For missing
        files on catalog no information is returned.

        Example query:
            { 'a_guid_1': 'a_lfn_1',
              'a_missing_guid_1': 'a_lfn_2',
              'a_bad_guid_1': 'a_lfn_3' }              

        Example response:
            { 'a_guid_1': { 'lfn': 'a_lfn_1',
                            'surls': ['srm://a_file'],
                            'fsize': 10000,
                            'checksum': None },
            'a_bad_guid_1': LFCReplicaCatalogException('some error') }

        Note that 'a_missing_guid1' is not returned.

        Returns dictionary with all found guids mapping to
        dictionary with lfn, surls, fsize and checksum. If error happened
        for some guid, the mapping is from guid to exception object. If
        guid was not found in catalog, it is not included in the response
        dictionary.
        
        @param files: Dictionary mapping each GUID to LFN.
        
        @return: Dictionary (see above for details)
        """
        raise NotImplementedError("Class is abstract so method cannot be"
            + " called")

    def filterSiteReplicas(self, files, sites):
        """
        Filters replicas from list of sites.
        
        Returns same structure as bulkFindReplicas
        but with filtered list of SURLs. If no replicas
        found, has again same behavior as bulkFindReplicas,
        excluding the GUID from the response.
        
        @param files: Dictionary mapping each GUID to LFN.
        @param sites: The list of sites as in Tiers of ATLAS.
        
        @return: Filtered list of files.
        """
        if sites is None or sites == []:
            return files
        
        assert(isinstance(sites, list))
        
        guids = files.keys()
        for guid in guids:
            if isinstance(files[guid], FileCatalogException):
                continue
            for surl in files[guid]['surls'][:]:
                fromSites = False
                for siteID in sites:
                    if TiersOfATLAS.isSURLFromSiteOrCloud(surl, siteID):
                        fromSites = True
                        break
                if not fromSites:
                    files[guid]['surls'].remove(surl)
            if files[guid]['surls'] == []:
                del files[guid]
        return files

    def bulkTouchFiles(self, files, archival):
        """
        Touch files on catalog (last modified date).
        Also sets archival bit for files.
        
        'files' is given by a dictionary mapping guid to
        a dictionary with lfn and surl.

        Example response:
            { 'a_guid_1': True,
              'a_guid_2': True,
              'a_missing_guid_1': LFCReplicaCatalogException('some error') }

        Returns dictionary of guid mapping to True if successful
        or exception if error occurred during registration.

        @param files: GUID mapping to dictionary with file attributes such
                      as 'lfn', 'surl'.
        
        @return: Dictionary (see above for details)        
        """
        raise NotImplementedError("Class is abstract so method cannot be"
            + " called")

    def bulkRegisterFiles(self, files):
        """Register files on local replica catalog.
        
        'files' is given by a dictionary mapping guid to a 
        dictionary with dsn, lfn, surl, fsize, checksum and archival bit.

        Example response:
            { 'a_guid_1': True,
              'a_guid_2': True,
              'a_missing_guid_1': LFCReplicaCatalogException('some error') }

        Returns dictionary of guid mapping to True if successful
        or exception if error occurred during registration.
        
        @param files: GUID mapping to dictionary with file attributes such
                      as 'dsn', 'lfn', 'surl', 'fsize', 'checksum' and 'archival'.
        
        @return: Dictionary (see above for details)
        """
        raise NotImplementedError("Class is abstract so method cannot be"
            + " called")
