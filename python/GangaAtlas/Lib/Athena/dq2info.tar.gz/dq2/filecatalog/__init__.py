"""
Package contains all modules for the DQ2 file catalog components.
Contains the File Catalog creation factory.

@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 
@version: $Id: __init__.py,v 1.9 2008/01/31 07:49:53 mbranco Exp $

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

from dq2.filecatalog.FileCatalogUnknownFactory import FileCatalogUnknownFactory


def create_file_catalog(endpoint):
    """
    Factory for creating file catalog instances.
    
    @param endpoint: The file catalog endpoint.
    
    @return: New file catalog instance.
    """
    if len(endpoint) > 0:
        if endpoint[:3] == 'lfc':
            from dq2.filecatalog.lfc.LFCFileCatalog import LFCFileCatalog
            return LFCFileCatalog(endpoint)
        elif endpoint[:4] == 'mock':
            from dq2.filecatalog.mock.MockFileCatalog import MockFileCatalog
            return MockFileCatalog(endpoint)
        elif endpoint[:5] == 'mysql':
            from dq2.filecatalog.lrc.LRCFileCatalog import LRCFileCatalog
            return LRCFileCatalog(endpoint)
        elif endpoint[:3] == 'rls':
            from dq2.filecatalog.rls.RLSFileCatalog import RLSFileCatalog
            return RLSFileCatalog(endpoint)
    raise FileCatalogUnknownFactory(endpoint)
