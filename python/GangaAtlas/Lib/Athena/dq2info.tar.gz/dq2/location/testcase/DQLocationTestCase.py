"""
(since 0.3.0)

$Id: DQLocationTestCase.py,v 1.4 2007/06/04 12:51:01 psalgado Exp $
"""
import dq2.common.validator.DQValidator

from dq2.location.DQLocationConstants import LocationState
from dq2.common.DQConstants import TestCaseData
from dq2.common.DQException import DQException, DQBackendException
from dq2.location.DQLocationException import DQLocationExistsException

from dq2.common.testcase.DQTestCase import DQTestCase

import dq2.info.TiersOfATLAS
SOURCES = dq2.info.TiersOfATLAS.getAllSources()


class DQLocationTestCase (DQTestCase):
    """
    
    (since 0.2.0)
    """


    def __init__ (self, name, instance):
        """
    
        (since 0.2.0)
        """
        DQTestCase.__init__(self, name)
        self.lc = instance


# PRIVATE METHODS


    def __del__ (self):
        """
        (since 0.3.0)
        """
        try:
            if self.lc._poolMonitor is not None:
                self.lc._poolMonitor.stop()
        finally:
            pass


    def _cleanup_database (self):
        """
        Removes all datasets used by DQLocationTestCase.
        (since 0.3.0)
        """
        try:
            self.lc.deleteDataset(TestCaseData.VUIDS)
        except:
            pass


# PUBLIC methods


    def setUp (self):
        """
    
        (since 0.2.0)
        """
        self._cleanup_database()


    def tearDown (self):
        """
    
        (since 0.2.0)
        """
        self._cleanup_database()


    def testCatalog (self):
        """
    
        (since 0.2.0)
        """
        
        # 0. no locations added
        result = self.lc.queryDatasetLocations([TestCaseData.VUIDS[0]])
        expected = {}
        self.assertEqual(expected, result, self._fmt_message('0. no locations added', expected, result))
        
        
        
        # 1.1 an incomplete dataset was added?
        self.lc.addDatasetReplica(TestCaseData.VUIDS[0], SOURCES[0], LocationState.INCOMPLETE)
        
        result = self.lc.queryDatasetLocations([TestCaseData.VUIDS[0]])
        expected = {TestCaseData.VUIDS[0]: {0: [SOURCES[0]], 1: []}}
        self.assertEqual(expected, result, self._fmt_message('1.1 an incomplete dataset was added?', expected, result))
        
        
        # 1.2 inserting an incomplete over an existing vuid raises an exception?
        self.assertRaises(DQLocationExistsException,
                          self.lc.addDatasetReplica,
                          TestCaseData.VUIDS[0], SOURCES[0], LocationState.INCOMPLETE)
        
        
        # 2.1 a complete dataset was added?
        self.lc.addDatasetReplica(TestCaseData.VUIDS[1], SOURCES[0], LocationState.COMPLETE)
        
        result = self.lc.queryDatasetLocations([TestCaseData.VUIDS[1]])
        expected = {TestCaseData.VUIDS[1]: {0: [], 1: [SOURCES[0]]}}
        self.assertEqual(expected, result, self._fmt_message('2.1 a complete dataset was added?', expected, result))
        
        
        # 2.2 an incomplete dataset was turned into complete?
        self.lc.addDatasetReplica(TestCaseData.VUIDS[2], SOURCES[0], LocationState.INCOMPLETE)
        self.lc.addDatasetReplica(TestCaseData.VUIDS[2], SOURCES[0], LocationState.COMPLETE)
        
        result = self.lc.queryDatasetLocations([TestCaseData.VUIDS[2]])
        expected = {TestCaseData.VUIDS[2]: {0: [], 1: [SOURCES[0]]}}
        self.assertEqual(expected, result, self._fmt_message('2.2 an incomplete dataset was turned into complete?', expected, result))
        
        
        # 3. a dataset SOURCES[0] was deleted?
        self.lc.deleteDatasetReplica(TestCaseData.VUIDS[0], [SOURCES[0]])
        
        result = self.lc.queryDatasetLocations([TestCaseData.VUIDS[0]])
        expected = {}
        self.assertEqual(expected, result, self._fmt_message('3. a dataset SOURCES[0] was deleted?', expected, result))


    def testQueryDatasetsInSite (self):
        """
        (since 0.3.0)
        
        # 1. query with no locations
        # 2. query datasets in site
        # 2.1 site
        # 2.2 completeness = LocationState.COMPLETE
        # 2.3 completeness = LocationState.INCOMPLETE
        """
        
        # 1. query with no locations
        result = self.lc.queryDatasetsInSite(SOURCES[0])
        expected = []
        self.assertEqual(TestCaseData.VUIDS[0] in result or TestCaseData.VUIDS[1] in result, False, self._fmt_message('1. query with no locations)', expected, result))
        
        
        self.lc.addDatasetReplica(TestCaseData.VUIDS[0], SOURCES[0], LocationState.INCOMPLETE)
        self.lc.addDatasetReplica(TestCaseData.VUIDS[0], SOURCES[1], LocationState.COMPLETE)
        self.lc.addDatasetReplica(TestCaseData.VUIDS[1], SOURCES[1], LocationState.INCOMPLETE)
        
        # 2. query datasets in site
        # 2.1 site
        result = self.lc.queryDatasetsInSite(SOURCES[0])
        expected = [TestCaseData.VUIDS[0]]
        self.assertEqual(TestCaseData.VUIDS[0] in result, True, self._fmt_message('2.1 query datasets in site', expected, result))
        
        # 2.2 completeness = LocationState.COMPLETE
        result = self.lc.queryDatasetsInSite(SOURCES[1], complete=LocationState.COMPLETE)
        expected = [TestCaseData.VUIDS[0]]
        self.assertEqual(TestCaseData.VUIDS[0] in result, True, self._fmt_message('2.2 query complete datasets in site', expected, result))
        
        # 2.3 completeness = LocationState.INCOMPLETE
        result = self.lc.queryDatasetsInSite(SOURCES[1], complete=LocationState.INCOMPLETE)
        expected = [TestCaseData.VUIDS[1]]
        self.assertEqual(TestCaseData.VUIDS[1] in result, True, self._fmt_message('2.3 query incomplete datasets in site', expected, result))