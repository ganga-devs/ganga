"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: DQLocationAPI.py,v 1.3 2007/11/25 18:49:43 vgaronne Exp $
"""

API = '0_3_0'
