"""

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Location validation aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: validation.py,v 1.11.2.21 2009/06/15 09:41:09 vgaronne Exp $
"""

from dq2.common.validator.DQValidator import *
from dq2.info.TiersOfATLASValidator import *
from dq2.location.DQLocationValidator import *
from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationConstants import TransferState


def addDatasetReplica (self, vuid, site, complete=LocationState.INCOMPLETE, transferState=TransferState.INACTIVE, owner=None, group=None):
    """
    @since: 0.3.0
    """
    is_uid([vuid])
    is_destination(site)
    
    return self.__proceed(vuid, site, complete, transferState, owner, group)

def getMasterLocation(self, vuid):
    """
    @since: 0.4.0
    
    """
    is_uid([vuid])    
    return self.__proceed(vuid)

def setTransferringStates (self, location, vuids, state):
    """
    @since: 0.3.0
    """
    is_uid(vuids)
    is_destination(location)    
    return self.__proceed(location, vuids, state)

def getTransferringState (self, vuid, location):
    """
    @since: 0.3.0
    """
    is_uid([vuid])
    is_destination(location)    
    return self.__proceed(vuid, location)

# Deletion methods
def deleteDataset (self, vuids):
    """
    @since: 0.3.0
    """
    
    is_uid(vuids)
    
    if len(vuids) == 0:
        raise DQInvalidRequestException('Datasets must be given!')
    
    return self.__proceed(vuids)


def deleteDatasetReplica (self, vuid, sites):
    """
    @since: 0.3.0
    """
    
    is_uid([vuid])
    is_list_of_destinations(sites)
    
    if len(sites) == 0:
        raise DQInvalidRequestException('Sites must be given!')
    
    return self.__proceed(vuid, sites)

# Query methods
def queryDatasetLocations (self, vuids=[], complete=None):
    """
    @since: 0.3.0
    """
    
    is_uid(vuids)
    if complete is not None:
        is_location_state([complete])
    
    if len(vuids) == 0:
        raise DQInvalidRequestException('The vuids cannot be empty!')
    
    return self.__proceed(vuids, complete)


def queryDatasetLocationsByDataset (self, uids):
    """
    @since: 0.4.0
    """ 
    is_uid(uids)   
    return self.__proceed(uids)


def queryDatasetsInSite (self, location, complete=None, page=1, rpp=100):
    """
    @since: 0.3.0
    """
    
    is_destination(location)
    is_integer([page, rpp])
    
    if complete is not None:
        is_location_state([complete])
    
    return self.__proceed(location, complete, page, rpp)

def listDatasetReplicas (self, duid):
    """
    @since: 0.4.*
    """
    
    is_uid([duid])
                
    return self.__proceed(duid)

def setReplicaMetaDataAttribute (self, dsn, location, attrname, attrvalue):
    """
    @since: 0.4.*
    """    
    is_list_of_destinations([location,])                
    is_dataset_name([dsn]) 
    return self.__proceed(dsn, location, attrname, attrvalue)

        
def listFileReplicas (self, vuid, location):
    """
    @since: 0.4.*
    """    
    is_uid([vuid])
    is_list_of_destinations([location,])                
    return self.__proceed(vuid, location)
  
def queryDatasetReplicaMetadata (self, vuid, location):
    """
    @since: 0.4.*
    """     
    is_uid([vuid])
    is_list_of_destinations([location,])                
    return self.__proceed(vuid, location)

def refreshReplicaCompleteness (self, vuid, location, threshold=None):
    """
    @since: 0.4.*
    """    
    is_uid([vuid])
    is_list_of_destinations([location,])                
    return self.__proceed(vuid, location, threshold)

def queryDatasetsByNameInSite (self,  site, complete=None, name=None, p=None, rpp=None, group=None):
    """
    @since: 0.4.*
    """
    is_destination(site)
    if complete is not None:
        is_location_state([complete])

    return self.__proceed(site, complete,  name, p, rpp, group)
  
def deleteDataset2(self, duid):
    """
    @since: 0.4.*
    """
    is_uid([duid])
    return self.__proceed(duid)
    
def deleteDatasetReplica2 (self, duid, locations):    
    """
    @since: 0.4.*
    """
    is_uid([duid])
    is_list_of_destinations(locations)
    return self.__proceed(duid, locations)

def bulkDeleteDatasetReplicas (self, pattern, locations):    
    """
    @since: 0.4.*
    """
    is_list_of_destinations(locations)
    return self.__proceed(pattern, locations)

def queryGarbageCollectedReplicas (self,  location, name=None, p=None, rpp=None):
    """
    @since: 0.4.*
    """
    is_destination(location)    
    return self.__proceed(location, name, p, rpp)

def countGarbageCollectedReplicas (self,  location, name=None):
    """
    @since: 0.4.*
    """
    is_destination(location)    
    return self.__proceed(location, name)

def queryDeletedReplicas (self,  location, name=None, p=None, rpp=None):
    """
    @since: 0.4.*
    """
    is_destination(location)    
    return self.__proceed(location, name, p, rpp)

def countDeletedReplicas (self,  location, name=None):
    """
    @since: 0.4.*
    """
    is_destination(location)    
    return self.__proceed(location, name)    

def listGarbageCollectedFiles (self, dsn, location):
    """
    @since: 0.4.*
    """
    is_dataset_name([dsn])     
    is_destination(location)    
    return self.__proceed(dsn, location)    

def setDatasetReplicaToDeleted (self, dsn, location):
    """
    @since: 0.4.*
    """
    is_dataset_name([dsn])     
    is_list_of_destinations([location,])                
    return self.__proceed(dsn, location)

def getDeletionReport(self):
    """
    @since: 0.4.*
    """
    return self.__proceed()

def updateCompleteness (self, dsn, version, location, files):
    """
    @since: 0.4.*
    """
    is_dataset_name([dsn])     
    is_list_of_destinations([location,])                
    return self.__proceed(dsn, version, location, files)
    
def listDatasetReplicasInContainer (self, cn):
    """
    @since: 0.4.*
    """
    is_dataset_name([dsn])    
    return self.__proceed(cn)

def queryStorageUsage (self, key=None, value=None, site=None, metaDataAttributes={}, locations=[]):
    """
    @since: 0.4.*
    """    
    return self.__proceed(key, value, site, metaDataAttributes, locations)

def queryStorageUsageHistory (self, site, key='GRID', value='total'):
    """
    @since: 0.4.*
    """    
    return self.__proceed(site, key, value)

def queryReplicaHistory (self, dsn , location):
    """
    @since: 0.4.*
    """    
    is_dataset_name([dsn])     
    is_list_of_destinations([location,])                
    return self.__proceed(dsn, location)
    

def rest (self, complete=None, creationdatemax=None, creationdatemin=None, modifieddatemax=None, modifieddatemin=None, site=None, vuid=None):
    """
    @since: 0.3.0
    """
    
    if complete is not None: is_location_state([complete])
    # if creationdatemax is not None: is_date([creationdatemax])
    # if creationdatemin is not None: is_date([creationdatemin])
    # if modifieddatemax is not None: is_date([modifieddatemax])
    # if modifieddatemin is not None: is_date([modifieddatemin])
    if site is not None: is_destination([site])
    if vuid is not None: is_uid([vuid])
    
    return self.__proceed(complete, creationdatemax, creationdatemin, dataset, modifieddatemax, modifieddatemin, site, vuid)
