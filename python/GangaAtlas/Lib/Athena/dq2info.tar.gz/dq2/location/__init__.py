"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.3 2007/11/25 18:49:45 vgaronne Exp $
"""

__version__ = '$Name: dq2-location-0-4-15 $'

API = '0_3_0'