"""
Load aspects for dq2.consistency.client package.

Warning: order is important!
"""

from dq2.location.client.aspects.validation import wrap_package
wrap_package()