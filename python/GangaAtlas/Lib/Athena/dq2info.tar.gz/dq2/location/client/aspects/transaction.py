"""
Location client transaction aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: transaction.py,v 1.5.2.4 2008/02/11 15:33:29 vgaronne Exp $
"""

from dq2.common.aspects import wrap_around

from dq2.location.client.LocationClient import LocationClient


def wrap_package ():
    """
    Loads the transaction aspect for the location client.
    
    @since: 0.3.0
    """
    from dq2.common.dao.aspects.transaction import start_and_end
    
    wrap_around (LocationClient.addDatasetReplica, start_and_end)    
    wrap_around (LocationClient.getMasterLocation,      start_and_end)

    #Deletion methods
    wrap_around (LocationClient.deleteDataset, start_and_end)
    wrap_around (LocationClient.deleteDatasetReplica, start_and_end)
    
    wrap_around (LocationClient.queryDatasetLocations,  start_and_end)
    wrap_around (LocationClient.queryDatasetsInSite,    start_and_end)
    wrap_around (LocationClient.searchDatasetLocations, start_and_end)        
    wrap_around (LocationClient.listDatasetReplicas,    start_and_end)    

    wrap_around (LocationClient.refreshReplicaCompleteness,    start_and_end)
    wrap_around (LocationClient.queryDatasetReplicaMetadata,   start_and_end)
    
    wrap_around (LocationClient.queryDatasetsByNameInSite,   start_and_end)
    