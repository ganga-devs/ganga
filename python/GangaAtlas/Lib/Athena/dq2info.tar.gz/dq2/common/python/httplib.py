"""
@since: 1.1.13
@version: $Id: httplib.py,v 1.1.2.1 2008/09/25 21:55:10 psalgado Exp $
"""


import httplib


# these constants are missing in httplib 2.3 (among others)
httplib.OK = 200
httplib.REQUEST_TIMEOUT = 408