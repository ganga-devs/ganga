"""
@deprecated: this module has been moved to the __init__.py file.
"""

from dq2.common.validator import *