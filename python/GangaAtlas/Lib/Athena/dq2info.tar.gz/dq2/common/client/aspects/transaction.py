"""
Client transaction aspects.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: transaction.py,v 1.2.2.4.2.2 2008/02/22 15:14:07 mbranco Exp $
"""


from dq2.common.aspects import wrap_around, wrap_around_re


def wrap_package ():
    """
    @since: 0.3.0
    """
    from dq2.common.client.DQClient import DQClient
    
    # before sending a HTTP request a tuid should be assigned to the client
    wrap_around (DQClient.send, wrap_send)


def wrap_send (self, *args, **kwargs):
    """
    Checks if the transaction unique identifier (tuid) exists
    and if it doesn't, it generates a new one and assigns it to the client.
    
    @since: 0.3.0
    """
    try:
        self.startTransaction()
        
        return self.__proceed(*args, **kwargs)
    finally:
        self.endTransaction()