"""
The curl implementation to contact the central catalogs.

@author: 
@contact: 
@since: 0.3.0
@version: $Id: DQCurl.py,v 1.10.2.22.2.1 2008/07/11 09:13:05 psalgado Exp $
"""


import dq2.common
import commands
import cPickle
import datetime
import re
import os
import time
import urllib
import warnings
import tempfile

# ignore os.tempnam() warning
warnings.filterwarnings('ignore')

import dq2.common
from dq2.common.DQException import *
from dq2.common.dao.DQDaoException import *
from dq2.common.client.DQClientException import DQInternalServerException
from StringIO import StringIO


class DQCurl:
    """
    Class responsible to establish and send HTTP requests to DDM servers using curl.
    
    @since: 0.3.0
    
    @cvar REG_CURL_ERROR: the regular expression to get curl errors.
    @type REG_CURL_ERROR: object
    """


    REG_CURL_ERROR = re.compile('^curl: \([0-9]+\) (.)*$')


    def __init__ (self, url, urlsec, proxy_cert, ca_path, timeout, headers, hostname='<unknown>'):
        """
        Constructs an instance of DQCurl.
        
        @since: 0.3.0
        
        @ivar url: is the non-secure URL of the host to be contacted.
        @type url: str
        @ivar urlsec: is the secure URL of the host to be contacted.
        @type urlsec: str
        @ivar proxy_cert: is the proxy certificate.
        @type proxy_cert:
        @ivar ca_path: is the directory where the Certification Authority certificates are located (by default it is /etc/grid-security/certificates but can be overriden by the X509_CERT_DIR environment variable.
        @type ca_path: str
        @ivar timeout : the client timeout (in seconds). (since 0.3)
        @type timeout: str
        @ivar hostname: is the client's hostname.
        @type hostname: str
        
        @raise DQSecurityException: in case of an invalid proxy certificate.
        """
        
        self.url = url
        self.urlsec = urlsec
        self.timeout = timeout
        self.hostname = hostname
        self.headers = headers
        
        self.options = {}
        self.options['--max-redirs'] = 5
        self.secoptions = {}
        
        if proxy_cert is not None:
            if proxy_cert == -1:
                err_msg = 'Invalid certificate!'
                raise DQSecurityException(err_msg)
            
            self.secoptions['-k'] = None # VERIFYHOST = 0
            #--capath will try to check the peer
            self.secoptions['--cert'] = proxy_cert
            self.secoptions['--key'] = proxy_cert
            self.secoptions['--sslv3'] = None


    def __del__ (self):
        """
        Closes DQCurl HTTP connection.
        
        @since: 0.2.0
        """
        pass


# PRIVATE methods


    def _process (self, com):
        """
        Process the response of the web service.
        
        @since: 0.3.0
        
        @param com: the curl command.
        @type com: str
        """
        
        curl_exit, tmp_response = commands.getstatusoutput(com)
        
        if curl_exit != 0:
            if curl_exit == 6 or curl_exit == 1536:
                err_msg = 'Unknown DDM server! Please check your configuration file.'
                raise DQInternalServerException(err_msg, self.url, self.urlsec, curl_error=curl_exit)
            if curl_exit == 7 or curl_exit == 1792:
                err_msg = 'The central catalog is not responding! The service is down or bad configuration (host port number)!'
                raise DQInternalServerException(err_msg, self.url, self.urlsec, curl_error=curl_exit)
            elif curl_exit == 23 or curl_exit == 5888:
                err_msg = 'The central catalog database is down!'
                raise DQInternalServerException(err_msg, self.url, self.urlsec, curl_error=curl_exit)
            elif curl_exit == 28 or curl_exit == 7168:
                err_msg = 'The client timed out!'
                raise DQInternalServerException(err_msg, self.url, self.urlsec, curl_error=curl_exit)
            elif curl_exit == 35 or curl_exit == 8960:
                err_msg = 'Proxy certificate expired!'
                raise DQInternalServerException(err_msg, curl_error=curl_exit)
            elif curl_exit == 52 or curl_exit == 13312:
                """empty reply from the server """
                err_msg = 'The central catalog sent an empty response!'
                raise DQBadServerResponse(err_msg, self.url, self.urlsec, curl_exit)
            elif curl_exit == 8960:
                """certificates have expired on the central catalog"""
                err_msg = 'certificates have expired on the central catalog or ServerName does not match the hostname!'
                raise DQInternalServerException(err_msg, curl_error=curl_exit)
            else:
                err_msg = 'Unknown curl error! [%s]' % (tmp_response)
                raise DQInternalServerException(err_msg, self.url, self.urlsec, curl_error=curl_exit)
        elif curl_exit == 0:
            if tmp_response.find('Mod_python error') > 0:
                raise DQBadServerResponse(tmp_response, self.url, self.urlsec, None)
        
        #parse the response of the server
        
        #check for proxy
        if tmp_response.startswith("HTTP/1.1 200 Connection established") or tmp_response.startswith("HTTP/1.0 200 Connection established"):
            tmp_response = tmp_response[tmp_response.find("\r\n\r\n")+4:]
        
        #check for multiple http response
        if tmp_response.startswith("HTTP/1.1 100 Continue") or tmp_response.startswith("HTTP/1.0 100 Continue"):
            tmp2 = tmp_response[tmp_response.find("\r\n\r\n")+4:]
            response = tmp2[tmp2.find("\r\n\r\n")+4:]
            st = int(tmp2[9:12])
        else:
            response = tmp_response[tmp_response.find("\r\n\r\n")+4:]
            st = int(tmp_response[9:12])
        
        
        if len(response) == 0:
            err_msg = 'The server sent an empty response:\n'
            raise DQBadServerResponse(response, self.url, self.urlsec, None)
        
        
        if st == 200:
            
            if re.findall(DQCurl.REG_CURL_ERROR, response):
                raise DQInternalServerException(response, self.url, self.urlsec)
            
            # ugly but only way is to grep for error string
            if response.find('Mod_python error') != -1:
                raise DQBadServerResponse(response, self.url, self.urlsec, None)
            
            # convert non strings to list, dict etc
            try:
                response = eval(response)
            except:
                """if it is a string it will come with an extra \n"""
                response = response[0:len(response)-1]
            
            return response
            
        else:
            
            try:
                raise cPickle.loads(response)
            except cPickle.UnpicklingError, e:
                if str(response).find('<!DOCTYPE') == 0:
                    err_msg = 'The server sent an invalid response:\n %s' % (response)
                    raise DQInternalServerException(err_msg, self.url, self.urlsec)
                err_msg = 'Unknown server error:\n %s' % (response)
                raise DQInternalServerException(err_msg, self.url, self.urlsec)


# PUBLIC methods


    def delete (self, request):
        """
        Does HTTP GET with 'delete=yes' field.
        
        @since: 0.3.0
        
        @param request: the URL.
        @type request: str
        """
        
        if request.find('?') != -1: request += '&delete=yes'
        else: request += '?delete=yes'
        
        return self.get(request, secure=True)


    def get (self, request, secure=False):
        """
        Does HTTP GET.
        
        @since: 0.3.0
        
        @param request: the URL.
        @type request: str
        @param secure: flag to indicate if the request should be secure.
        @type secure: bool
        """
        
        com = 'curl -i --silent --get '
        
        if self.timeout is not None:
            com += '--max-time %u ' % (self.timeout)
        
        for eachOption in self.options.keys():
            if self.options[eachOption] is None:
                com += ' %s ' % (eachOption)
            else:
                com += ' %s %s ' % (eachOption, self.options[eachOption])
        
        for eachHeader in self.headers:
            com += ' -H "%s"' % (eachHeader)
        
        if secure:
            for eachOption in self.secoptions.keys():
                if self.secoptions[eachOption] is None:
                    com += ' %s ' % (eachOption)
                else:
                    com += '%s %s ' % (eachOption, self.secoptions[eachOption])
            com += " --url '%s%s' " % (self.urlsec, request)
        else:
            com += " --url '%s%s' " % (self.url, request)
        
        
        
        return self._process(com)


    def post (self, request, params, secure=True):
        """
        Does HTTP POST. Expects list with fields (format per field is 'field1=value1').
        
        @since: 0.3.0
        
        @param request: the URL.
        @type request: str
        @param params: the parameters.
        @type params: dict
        @param secure: flag to indicate if the request should be secure.
        @type secure: bool
        """
        assert params != []
        
        com = 'curl -i --silent '
        
        if self.timeout is not None:
            com += '--max-time %u ' % (self.timeout)
        
        for eachOption in self.options.keys():
            if self.options[eachOption] is None:
                com += ' %s ' % (eachOption)
            else:
                com += ' %s %s ' % (eachOption, self.options[eachOption])
        
        for eachHeader in self.headers:
            com += ' -H "%s"' % (eachHeader)
        
        if secure:
            for eachOption in self.secoptions.keys():
                if self.secoptions[eachOption] is None:
                    com += ' %s ' % (eachOption)
                else:
                    com += '%s %s ' % (eachOption, self.secoptions[eachOption])
            com += " --url '%s%s' " % (self.urlsec, request)
        else:
            com += " --url '%s%s' " % (self.url, request)
        
        strData = ''
        for key in params.keys():
            strData += 'data="%s"\n' % urllib.urlencode({key:params[key]})
        
        
        # write data to temporary config file

        #proper security fix needs python 2.3: tempfile.mkstemp
        tmpName = tempfile.mktemp()
        tmpFile = open(tmpName,'w')
        tmpFile.write(strData)
        tmpFile.close()
        com += ' --config %s ' % tmpName
        
        try:
            r = self._process(com)
        except Exception, e:
            try:
                os.remove(tmpName)
            except:
                pass
            raise e
        
        try:
            os.remove(tmpName)
        except:
            pass
        return r


    def put (self, request, params):
        """
        Does HTTP POST with 'update=yes' field.
        
        @since: 0.3.0
        
        @param request: the URL.
        @type request: str
        @param params: the parameters.
        @type params: dict
        """
        assert params != {}
        
        # handling parameters
        params['update'] = 'yes'
        
        return self.post(request, params)
