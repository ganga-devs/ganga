"""
Runs lots of client requests to DQ2 catalogs
and measures the time to execute them. Inserts entries
using the given no of concurrent threads, then every QUERY_FREQ
inserts launches NO_QUERIES queries and reports the average times

@author: David Cameron
@contact: david.cameron@cern.ch
@since: 0.2.0
@version: $Id: DQStressTest.py,v 1.1.1.1.2.4 2007/11/21 09:36:28 psalgado Exp $
"""


import threading
import sys
import time
import commands
import random
import DQ2


from dq2.common.DQException import DQException, DQFatalError


QUERY_FREQ = 1000 # test queries after this many inserts
NO_QUERIES = 20 # no of queries to test each time


class TestThread (threading.Thread):
    """
    @author: David Cameron
    @contact: david.cameron@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1.1.1.2.4 $
    
    @cvar id:
    @type id: 
    """


    id = 0


    def __init__ (self, queries, filesperds):
        """
        Constructs a TestThread instance. 
        
        @since: 0.2.1
                
        queries ...
        filesperds ...
        
        @raise DQFatalError: in case the DDM Server is down.
        """
        
        threading.Thread.__init__(self)
        self.myid = TestThread.id
        TestThread.id += 1
        self.dq2 = DQ2.DQ2()

        # check if DDM server is running
        if not self.dq2.status():
            raise DQFatalError('DDM Server is down!')
        
        self.queries = queries
        self.datasetname = 'stest.t-'+str(self.myid)+'.'+self.uuid()
        self.filesperds = filesperds


    def runQueries (self, dsno):
        """
        Run NO_QUERIES querying files in dataset for random dataset
        numbers less than dsno
        
        @param dsno:
        @type dsno: 
        """
        
        start = time.time()
        
        for i in range(NO_QUERIES):
            randno = random.randint(0, dsno)
            self.dq2.listFilesInDataset(self.datasetname+'.'+str(randno))
        
        end = time.time()
        ave = (end-start)/NO_QUERIES
        print '%i datasets in catalog: ave query time %.3fs' % (dsno, ave)
            
        
    def run (self):
        """
        Add a dataset, query for it then delete it
        
        @since: 0.2.0
        @version: $Id: DQStressTest.py,v 1.1.1.1.2.4 2007/11/21 09:36:28 psalgado Exp $
        """
        
        stime = time.time()
        print 'starting at %s'% time.ctime()
        guidtemplate = self.datasetname[-28:-12]
        
        try:
            for i in range(self.queries):
                
                dsname = self.datasetname+'.'+str(i)
                
                # do this in two steps or one?
                # two steps is about 50% slower..
                
                #self.dq2.registerNewDataset(dsname)
                
                lfns = []
                guids = []
                for j in range(self.filesperds):
                    lfns.append(dsname+'.file'+str(j))
                    # don't want uuidgen time measured
                    guids.append('%08i%s%012i' % (j, guidtemplate, i))
                    
                self.dq2.registerNewDataset(dsname,
                                            lfns=lfns,
                                            guids=guids)
                
                if i % QUERY_FREQ == 0 and i != 0: # run queries
                    etime = time.time()
                    ave = (etime-stime)/QUERY_FREQ
                    print '%i datasets in catalog: ave insert time %.3fs' % (i, ave)
                    self.runQueries(i)
                    stime = time.time()
                
        except DQException, e:
            print str(e)


def runTest (datasets, filesperds, nthreads):
    """
    Launch a bunch of threads to issue requests
    
    @param datasets: 
    @type datasets: 
    @param filesperds: 
    @type filesperds: 
    @param nthreads: 
    @type nthreads: 
    """
    
    start = time.time()
    
    for i in range(nthreads):
        t = TestThread(datasets/nthreads, filesperds)
        t.start()
        
    for th in threading.enumerate()[1:]:
        th.join()
        
    end = time.time()
    
    print 'test took in total %f secs' % (end-start)


if __name__ == '__main__':
    """
    """
    main(sys.argv[1:])
