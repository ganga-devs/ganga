"""
DDM client logger aspects.
For more information about DDM logger check https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2Logging.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: logger.py,v 1.1.2.2 2007/12/04 13:41:15 psalgado Exp $
"""
from dq2.common.DQException import DQException

LOG = None
    

def get_logger ():
    """
    Returns a DQLog instance.
    
    @since: 0.3.0
    """
    global LOG
    
    if LOG is not None:
        return LOG
    
    from dq2.common.DQLog import DQLog
    return DQLog('dq2.common.client')


LOG = get_logger()