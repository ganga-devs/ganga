"""
@author: 
@contact: 
@since: 0.1.4
@version: $Id: x509.py,v 1.5.2.2 2007/10/18 14:35:49 psalgado Exp $
"""


import os
import sys
import commands

from dq2.common import parse_dn
from dq2.common.DQException import DQSecurityException


DEFAULT_CA_LOCATION = '/etc/grid-security/certificates'
KEY_X509_CERT_DIR = 'X509_CERT_DIR'


def get_ca_path ():
    """
    Returns the Certificate Authority certificates dq2.location.
    
    The location is, by default, /etc/grid-security/certificates but can overriden
    by setting up the X509_CERT_DIR environment variable.
    """
    # first see if X509_CERT_DIR is set
    
    if os.environ.has_key(KEY_X509_CERT_DIR):
        return os.environ[KEY_X509_CERT_DIR]
        
    elif os.path.isdir(DEFAULT_CA_LOCATION):
        return DEFAULT_CA_LOCATION
        
    else:
        err_msg = """
        Error: The Certificate Authority certificates location could not be found.
        Please set the X509_CERT_DIR environment variable to the location of the
        certificates.
        """
        raise DQSecurityException, err_msg


def get_dn ():
    """
    Returns the user GRID certificate identity.
    
    @since: 0.3.0
    """
    s, owner = commands.getstatusoutput('grid-proxy-info -identity')
    
    return parse_dn(owner)


def get_x509 ():
    """
    Look for a grid proxy certificate, either in the X509_USER_PROXY
    envionment variable or in the standard place in /tmp.
    """

    # first see if X509_USER_PROXY is set
    if 'X509_USER_PROXY' in os.environ:
        x509 = os.environ['X509_USER_PROXY']
        # check the file is there
        try:
            f = open(x509, 'r')
            f.close()
        except IOError:
            err_msg = """
    Error with file X509_USER_PROXY env variable points to
    (%s)
    doesn't exist or permission denied.
    """ % x509
            raise DQSecurityException, err_msg
            
    # if not look in the default place
    else:
        try:
            x509 = '/tmp/x509up_u%s' % os.getuid()
            f = open(x509, 'r')
            f.close()
        except IOError:
            err_msg = """
    Error: No valid grid proxy certificate found. Either run grid-proxy-init
    or set the X509_USER_PROXY environment variable to the location of the
    proxy if it is in a non-standard place (ie not /tmp/x509up_u%s)
            """ % os.getuid()
            raise DQSecurityException, err_msg
    
    # check to see if it's still valid
    s, o = commands.getstatusoutput('grid-proxy-info -timeleft')
    if s != 0:
        """handling error status code"""
        err_msg = """
    Error: Problem running grid-proxy-info. Make sure GLOBUS environment
    is properly set
        """
        raise DQSecurityException, err_msg
    
    elif o.strip() == '-1':
        """handling bad output"""
        err_msg = 'Error: Proxy certificate expired'
        raise DQSecurityException, err_msg
    
    else:
        """status code and output are ok"""
        return x509
    
    raise DQSecurityException, 'Error: Could not retrieve a proxy certificate'