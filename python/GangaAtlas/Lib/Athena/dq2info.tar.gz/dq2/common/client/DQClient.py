"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQClient.py,v 1.9.2.17.2.1 2007/12/12 12:52:30 psalgado Exp $

@see: http://www.gridsite.org/wiki/User_Guide
"""

import dq2.common.DQPing
import dq2.common
import dq2.common.validator.DQValidator

import socket
import time
import urllib
import x509


from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.common.DQConstants import HTTP
from dq2.common.dao.DQDao import DQDao
from dq2.common.DQException import DQInvalidRequestException
from dq2.common.DQException import DQConfigurationException


pycurl_available = False
try:
    from dq2.common.client.pycurl.DQPycurl import DQPycurl
    pycurl_available = True
except:
    pass


curl_available = False
try:
    from dq2.common.client.curl.DQCurl import DQCurl
    curl_available = True
except:
    pass


class DQClient (DQDao, Configurable):
    """
    Class to wrap HTTP request configurations.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.9.2.17.2.1 $
    
    @ivar ca_path: is the location of the Certification Authority certificates.
    @ivar certificate: is the proxy certificate.
    @ivar params: are the parameters to be sent with the request
        (USE dictionary for GET and DELETE and USE lists for POST and PUT).
    @ivar request: is the HTTP URL.
    @type request: str
    @ivar is_secure: send the HTTP request as secure (only applicable for GET and POST),
        by default GET is insecure and POST is secure.
    @type is_secure: bool
    @ivar type: is the type of HTTP request to send.
    @type type: str
    @ivar url: is the non-secure URL of the host to be contacted.
    @type url: str
    @ivar urlsec: is the secure URL of the host to be contacted.
    @type urlsec: str
    @ivar timeout : the client timeout (in seconds).
    @type timeout: int
    """


    implementation = None


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, suffix='/dq2', api=None, timeout=None):
        """
        Constructs a DQClient instance.
        
        @since: 0.2.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @type url: str
        @param urlsec: is the secure URL of the host to be contacted.
        @type urlsec: str
        @param certificate: location of the proxy certificate.
            if this value is None or omitted then only insecure calls will be possible.
        @type certificate: str
        @param ca_path: location of the Certification Authority certificates.
        @type ca_path: str
        @param suffix: string to be append to the given URLs (default='/dq2').
        @type suffix: str
        @param timeout : the client timeout (in seconds).
        @type timeout: int
        
        If the client is created without passing urls,
        the L{class default configuration<__configure__>} will be used instead.
        
        @todo: if not isinstance(self, dq2.clientapi.DQ2.DQ2):
            dq2.common.validator.DQValidator.is_http_url([url])
            dq2.common.validator.DQValidator.is_http_url([urlsec])
        
        """
        
        if url is None: url = self._getInsecureEndpoint()
        if urlsec is None: urlsec = self._getSecureEndpoint()
        if timeout is None: timeout = self._getTimeout()
        
        if url is not None:
            self.url = url + suffix
        if urlsec is not None:
            self.url_secure = urlsec + suffix
        
        self.certificate = certificate
        
        self.ca_path = ca_path
        self.tuid = None
        self.headers = []
        
        self.hostname = socket.gethostname()
        self.timeout = timeout
        
        self.api = api
        
        self._reset()


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.1
        """
        return """DQClient (%s, %s, %s)""" % (self.url, self.url_secure, self.timeout)


    def __configure__ ():
        """
        Configures the DQClient class.
        """
        try:
            DQClient.implementation = Config().getConfig('dq2-common-client').get('dq2-common-client', 'impl') 
        except:
            pass


    __configure__ = staticmethod(__configure__)


# PRIVATE methods


    def _get_host (self):
        """
        Returns the hostname for the given request.
        
        @since: 0.3.0
        """
        if self.is_secure:
            return dq2.common.DQPing.getHostname(self.url_secure)
        else:
            return dq2.common.DQPing.getHostname(self.url)


    def _getHosts (self):
        """
        Returns a tuple containing the insecure and secure hosts.
        
        @since: 0.2.1
        
        @return: tuple in the following format::
            (insecure_host, secure_host)
        """
        insecure_host = dq2.common.DQPing.getHostname(self.url)
        
        secure_host = dq2.common.DQPing.getHostname(self.url_secure)
        
        return (insecure_host, secure_host)


    def _getCURL (self, url, url_secure, certificate, ca_path, timeout, hostname, headers):
        """
        Get the appropriate CURL implementation.
        
        First reads implementation from configuration file and tries to use it.
        If configuration file implementation is badly defined (uses an implementation
        that is not installed) or is not set, the method prefers 'pycurl' and
        reverts to 'curl'. If no implementation found, raises exception.
        
        @since: 0.3.0
        """
        curl = None
        
        if DQClient.implementation == 'pycurl' and pycurl_available:
            curl = DQPycurl(url, url_secure, certificate, ca_path, timeout, headers, hostname)
        elif DQClient.implementation == 'curl' and curl_available:
            curl = DQCurl(url, url_secure, certificate, ca_path, timeout, headers, hostname)
        elif DQClient.implementation == 'python':
            from dq2.common.client.python.DQPython import DQPython
            curl = DQPython(url, url_secure, certificate, ca_path, timeout, headers, hostname)
        
        if curl is None and pycurl_available:
            curl = DQPycurl(url, url_secure, certificate, ca_path, timeout, headers, hostname)
        elif curl is None and curl_available:
            curl = DQCurl(url, url_secure, certificate, ca_path, timeout, headers, hostname)
        
        if curl is None:
            raise DQConfigurationException("DQ2 client for CURL/Python-CURL not installed")
        
        return curl


    def _getInsecureEndpoint (self):
        """
        @since: 0.3.0
        """
        try:
            return self.__class__.__dict__['insecure'] 
        except KeyError:
            pass
        
        return None


    def _getSecureEndpoint (self):
        """
        @since: 0.3.0
        """
        try:
            return self.__class__.__dict__['secure'] 
        except KeyError:
            pass
        
        return None


    def _getTimeout (self):
        """
        @since: 0.3.0
        """
        try:
            return self.__class__.__dict__['timeout'] 
        except KeyError:
            pass
        
        return None


    def _get_url (self):
        """
        Builds the HTTP request endpoint and the URL rewriting.
        
        @since: 0.2.0
        """
        
        first_slash = self.request.find('/')
        self.request = self.request[:first_slash+1] + self.request[first_slash+1:]
        
        # add the default API parameter
        self.params[HTTP.API] = self.api
        
        # remove parameters with None values
        for eachKey in self.params.keys():
            if self.params[eachKey] is None:
                """remove parameters whose value is None"""
                del self.params[eachKey]
        
        if self.type == HTTP.PUT or self.type == HTTP.POST:
            """for PUT and POST requests"""
            for eachKey in self.params.keys():
                if self.params[eachKey] is None:
                    del self.params[eachKey]
            #    if self.params[eachParam] is not None:
            #        self.params[eachParam] = urllib.quote_plus(str(self.params[eachParam]))
            return urllib.quote(self.request)
        
        elif self.type == HTTP.GET or self.type == HTTP.DELETE:
            """for GET and DELETE and requests."""
            params = urllib.urlencode(self.params)
            return urllib.quote(self.request) +'?'+ params
        
        raise DQInvalidRequestException('HTTP request %s is not a GET, POST, PUT or DELETE request!', self.type)


    def _reset (self):
        """
        Resets the destination request data.
        
        @since: 0.2.0
        """
        self.is_secure = None
        self.params = {}
        self.request = None
        self.type = None


    def _set_security (self, default=None):
        """
        @since: 0.2.0
        """
        
        # set default security                                                                                                                                        
        if self.is_secure is None:
            self.is_secure = default
        
        if not self.is_secure:
            """not a secure request"""
            return
        
        else:
            """secure request: setup environment if needed"""
            # setup GRID certificate and CA path - if necessary                                                                                                       
            if self.certificate is None:
                self.certificate = x509.get_x509()
            
            if self.ca_path is None:
                self.ca_path = x509.get_ca_path()


# PUBLIC methods


    def commitTransaction (self):
        """
        Commits a transaction.
        
        @since: 0.2.0
        """
        self.tuid = None


    def endTransaction (self):
        """
        Ends a transaction (without committing or rollingback).
        
        @since: 0.2.0
        """
        self.tuid = None


    def rollbackTransaction (self):
        """
        Rollsback a transaction.
        
        @since: 0.2.0
        """
        self.tuid = None


    def startTransaction (self):
        """
        Starts a transaction.
        
        @since: 0.2.0
        """
        if self.tuid is None:
            self.tuid = dq2.common.generate_uuid()
        
        self.headers = ['User-Agent: dqcurl', 'TUID: %s' % (self.tuid)]


    def send (self):
        """
        Sends the HTTP request to the destination.
        
        @since: 0.2.0
        
        @raise DQSecurityException: in case of an invalid proxy certificate.
        """
        request = self._get_url()
        
        if self.type == HTTP.GET:
            """GET are by default insecure."""
            
            self._set_security(False)
            c = self._getCURL(self.url, self.url_secure, self.certificate, self.ca_path, self.timeout, self.hostname, self.headers)
            output = c.get(request, self.is_secure)
            
        elif self.type == HTTP.POST:
            """POST are by default secure."""
            
            self._set_security(True)
            c = self._getCURL(self.url, self.url_secure, self.certificate, self.ca_path, self.timeout,  self.hostname, self.headers)
            output = c.post(request, self.params, self.is_secure)
            
        elif self.type == HTTP.PUT:
            """PUT are always secure."""
            self._set_security(True)
            c = self._getCURL(self.url, self.url_secure, self.certificate, self.ca_path, self.timeout,  self.hostname, self.headers)
            output = c.put(request, self.params)
            
        elif self.type == HTTP.DELETE:
            """DELETE are always secure."""
            
            self._set_security(True)
            
            c = self._getCURL(self.url, self.url_secure, self.certificate, self.ca_path, self.timeout,  self.hostname, self.headers)
            output = c.delete(request)
        
        self._reset()
        return output
