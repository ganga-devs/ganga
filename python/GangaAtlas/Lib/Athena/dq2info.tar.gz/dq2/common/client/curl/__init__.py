"""
@author: 
@contact: 
@since: 0.3.0
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/09/07 09:52:29 psalgado Exp $
"""

__version__ = '$NAME'