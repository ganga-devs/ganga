"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@version: $Id: DQFactory.py,v 1.5.2.12 2007/11/23 09:12:49 psalgado Exp $
@since: 0.2

@var DEFAULT_MAX_RETRIES: the default maximum number of retries to get a connection from pool.
@type DEFAULT_MAX_RETRIES: int
@var DEFAULT_SLEEP: default time between retries.
@type DEFAULT_SLEEP: int
"""


from dq2.common.Config import Config

from dq2.common.dao.DQDaoException import DQDaoException


DEFAULT_MAX_RETRIES = 5
DEFAULT_SLEEP = 1


def get_configuration (package, mypath=None):
    """
    @since: 0.3.0
    """
    try:
        impl = Config().getConfig(package, mypath=mypath).get(package, 'impl')
    except:
        impl = None
    try:
        host = Config().getConfig(package, mypath=mypath).get(package, 'host')
    except:
        host = None
    try:
        db = Config().getConfig(package, mypath=mypath).get(package, 'db')
    except:
        db = None
    try:
        user = Config().getConfig(package, mypath=mypath).get(package, 'user')
    except:
        err_msg = 'The database user is not defined! [%s]' % (package)
        raise DQDaoException(err_msg)
    try:
        passwd = Config().getConfig(package, mypath=mypath).get(package, 'passwd')
    except:
        err_msg = 'The database password is not defined! [%s]' % (package)
        raise DQDaoException(err_msg)
    try:
        dsn = Config().getConfig(package, mypath=mypath).get(package, 'dsn')
    except:
        dsn = None
    try:
        maxretries = Config().getConfig(package, mypath=mypath).get(package, 'maxretries')
    except:
        maxretries = DEFAULT_MAX_RETRIES
    
    try:
        sleep = Config().getConfig(package, mypath=mypath).get(package, 'sleep')
    except:
        sleep = DEFAULT_SLEEP
    
    return (impl, host, db, user, passwd, dsn, maxretries, sleep)


def get_dao_implementation (package, mypath=None):
    """
    @since: 0.3.0
    """
    return Config().getConfig(package, mypath=mypath).get(package, 'impl')


def get_pool_settings (package, mypath=None):
    """
    Retrieves the database connection pool settings.
    
    @since: 0.3.0
    @deprecated: this method will be deprecated on the next release.
    
    @return: tuple (
            minimum pool connections [default=1],
            maximum pool connections [default=2],
            incremental value [default=1],
            pool period [default=10800]
        ).
    """
    
    poolMin = 1
    poolMax = 2
    poolIncr = 1
    poolPeriod = 10800
    
    try:
        poolMin = int(Config().getConfig(package, mypath=mypath).get(package, 'poolMin'))
    except:
        pass
    
    try:
        poolMax = int(Config().getConfig(package, mypath=mypath).get(package, 'poolMax'))
    except:
        pass
    
    try:
        poolIncr = int(Config().getConfig(package, mypath=mypath).get(package, 'poolIncr'))
    except:
        pass
    
    try:
        poolPeriod = int(Config().getConfig(package, mypath=mypath).get(package, 'poolPeriod'))
    except:
        pass
    
    return (
        poolMin,
        poolMax,
        poolIncr,
        poolPeriod
    )


def _get_table_prefix (package, mypath=None):
    """
    
    @since: 0.3.0
    
    @param package: .
    """
    
    try:
        """try to retrieve if there is a configuration for the given table"""
        return Config().getConfig(package, mypath=mypath).get(package, 'table_prefix')
    except:
        pass
    
    return None


def _get_table_suffix (package, mypath=None):
    """
    
    @since: 0.3.0
    
    @param package: .
    """
    
    try:
        """try to retrieve if there is a configuration for the given table"""
        return Config().getConfig(package, mypath=mypath).get(package, 'table_suffix')
    except:
        pass
    
    return None


class DQFactory (object):
    """
    Class to provide generic constants and methods for the DQ catalog factories.
    
    @since: 0.2.0
    
    @cvar CATALOG_MYSQL:the name to used to create MySQL catalogs.
    @cvar CATALOG_MOCK: the name to used to create mock-up catalogs.
    @cvar CATALOG_ORACLE: the name to used to create Oracle catalogs.
    @cvar CATALOGS: is a list containing all possible catalog implementations.

    @warning: all DQ catalog factories should extend this class.
    
    @todo: move some of these to separate LRC subclass)
    """
    CATALOG_MYSQL = "mysql"
    CATALOG_MOCK = "mock"
    CATALOG_ORACLE = "oracle"
    
    CATALOGS = [CATALOG_MYSQL, CATALOG_MOCK, CATALOG_ORACLE]
