"""
Central catalogs transaction aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: transaction.py,v 1.1.1.1.2.2 2007/09/05 10:00:23 psalgado Exp $
"""


from dq2.common.DQException import DQException

from dq2.common.aspects import wrap_around, peel_around

from dq2.common.dao import READER, WRITER


def start_and_commit (self, *args, **kwargs):
    """
    Starts, executes an operation and commits/rollbacks the database transaction.
    
    @since: 0.3.0
    """
    self.whatpool = WRITER
    
    self.startTransaction()
    try:
        try:
            output = self.__proceed(*args, **kwargs)
            self.commitTransaction()
            return output
        except DQException, e:
            self.rollbackTransaction()
            raise e
    finally:
        self.endTransaction()


def start_and_end (self, *args, **kwargs):
    """
    Starts, executes an operation and ends the database transaction.
    
    @since: 0.3.0
    """
    self.whatpool = READER
    
    self.startTransaction()
    try:
        return self.__proceed(*args, **kwargs)
    finally:
        self.endTransaction()