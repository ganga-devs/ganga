"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.4.0
@version: $Id: exception.py,v 1.1.2.3 2007/09/05 10:00:23 psalgado Exp $
"""


from dq2.common.dao.DQDaoException import DQDaoException


def handle (self, *args, **kwargs):
    """
    Wrap all StandardError exception into a DQDaoException.
    
    @since: 0.3.0
    """
    try:
        return self.__proceed(*args, **kwargs)
    except StandardError, e:
        raise DQDaoException(None, root_cause=e)