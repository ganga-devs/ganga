"""


@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.1
@version: $Id: logger.py,v 1.1.2.3 2007/11/23 08:31:40 psalgado Exp $
"""


import time

from dq2.common.dao.DQFactory import DQFactory
from dq2.common.DQException import DQException

from dq2.common.server import get_tuid

LOG = None
COMPONENT_DB = 'DB'


def get_logger ():
    """
    Returns a DQLog instance.
    
    @since: 0.3.0
    """
    global LOG
    
    if LOG is not None:
        return LOG
    
    from dq2.common.DQLog import DQLog
    return DQLog('dq2.common.dao')


LOG = get_logger()


def db_0001 (self):
    """
    [DEBUG] [DB-0001] open database connection
    """
    
    try:
        return self.__proceed()
    except StandardError, e:
        LOG.error(
            str(e),
            tuid=self.tuid,
            component=COMPONENT_DB
        )
        raise e


def db_0002 (self, *args):
    """
    [DEBUG] [DB-0002] close database connection.
    """
    try:
        try:
            return self.__proceed(*args)
        except StandardError, e:
            LOG.error(
                str(e),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
            raise e
    finally:
        LOG.debug(
            'close database connection',
            tuid=self.tuid,
            component=COMPONENT_DB
        )


def db_0003 (self, *args):
    """
    [DEBUG] [DB-0003] start database transaction.
    """
    try:
        try:
            start = time.time()
            return self.__proceed(*args)
        except StandardError, e:
            LOG.error(
                'failed starting transaction! (%s)' % str(e),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
            raise e
    finally:
        end = time.time()
        
        LOG.performance(
            'start transaction: %s' % (end - start),
            tuid=self.tuid,
            component=COMPONENT_DB
        )
        LOG.debug(
            'start database transaction',
            tuid=self.tuid,
            component=COMPONENT_DB
        )


def db_0004 (self, *args):
    """
    [DEBUG] [DB-0004] commit database transaction.
    """
    try:
        try:
            return self.__proceed(*args)
        except StandardError, e:
            LOG.error(
                'commit database transaction failed! (%s)' % (str(e)),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
            raise e
    finally:
        LOG.debug(
            'commit database transaction',
            tuid=self.tuid,
            component=COMPONENT_DB
        )


def db_0005 (self, *args):
    """
    [DEBUG] [DB-0005] rollback database connection.
    """
    try:
        try:
            return self.__proceed(*args)
        except StandardError, e:
            LOG.error(
                'rollback transaction failed! (%s)' % (str(e)),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
            raise e
    finally:
        LOG.debug(
            'rollback database connection',
            tuid=self.tuid,
            component=COMPONENT_DB
        )


def db_0006 (self, *args):
    """
    [DEBUG] [DB-0006] end transaction.
    """
    try:
        try:
            return self.__proceed(*args)
        except StandardError, e:
            LOG.error(
                'end transation failed! (%s)' % (str(e)),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
            raise e
    finally:
        LOG.debug(
            'end transaction',
            tuid=self.tuid,
            component=COMPONENT_DB
        )


def db_0007 (self, sql):
    """
    [DEBUG] [DB-0007] SQL query | <query>
    """
    query = str(sql).strip()
    query = query.replace('\n', ' ')
    query = query.replace('\t', ' ')
    query = query.replace('  ', ' ')
    
    LOG.debug(
        "SQL query | %s" % (query),
        tuid=self.tuid,
        component=COMPONENT_DB
    )
    try:
        try:
            start = time.time()
            return self.__proceed(sql)
        except StandardError, e:
            LOG.error(
                'SQL query %s (%s)' % (query, str(e)),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
    finally:
        end = time.time()
        
        LOG.performance(
            'sql: %s' % (end - start),
            tuid=self.tuid,
            component=COMPONENT_DB
        )


def db_0008 (self, sql, bind_variable):
    """
    [DEBUG] [DB-0008] SQL query | <query> | <bind variables>
    """
    from dq2.common.server.aspects.logger import LOG
    
    query = str(sql).strip() + ' | ' + str(bind_variable).strip()
    query = query.replace('\n', ' ')
    query = query.replace('\t', ' ')
    query = query.replace('  ', ' ')
    
    LOG.debug(
        'SQL query | %s' % (query),
        tuid=self.tuid,
        component=COMPONENT_DB
    )
    
    try:
        try:
            start = time.time()
            return self.__proceed(sql, bind_variable)
        except StandardError, e:
            LOG.error(
                'SQL query %s (%s)' % (query, str(e)),
                tuid=self.tuid,
                component=COMPONENT_DB
            )
            raise e
    finally:
        end = time.time()
        
        LOG.performance(
            'sql with bind: %s' % (end - start),
            tuid=self.tuid,
            component=COMPONENT_DB
        )