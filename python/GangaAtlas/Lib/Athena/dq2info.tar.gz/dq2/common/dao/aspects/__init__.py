"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/09/05 10:00:23 psalgado Exp $
"""