"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.2
@version: $Id: __init__.py,v 1.3.2.7 2007/11/23 07:57:37 psalgado Exp $

@var READER: the constant to identify connection for reading.
@type READER: int
@var WRITER: the constant to identify connection for writing.
@type WRITER: int
"""

__version__ = '$Name: dq2-common-dao-0-3-1 $'


READER = 0
WRITER = 1