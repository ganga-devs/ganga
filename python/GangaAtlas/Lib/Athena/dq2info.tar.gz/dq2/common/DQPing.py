"""
@deprecated: moved into dq2.common.utils.
"""


from dq2.common import log as logging


#LOGGER = logging.getLogger(__name__)
#LOGGER.warning('application is using a deprecated module: dq2.common.DQPing!')


from dq2.common.utils.ping import *