"""
@deprecated: moved into dq2.common.constants.
"""


__package__ = __name__.replace('.', '-')
__version__ = '$Revision: 1.25.2.3 $'
# $Source $


from dq2.common import log as logging

#LOGGER = logging.getLogger(__package__)
#LOGGER.warning('application is using a deprecated module: dq2.common.DQConstants!')

from dq2.common.constants import *