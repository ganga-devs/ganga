"""
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.2.2.4 2009/09/28 09:30:22 vgaronne Exp $
"""

__version__ = '$Name: dq2-info-0-4-7 $'

class PermissionType:
    READ       = 'r'
    WRITE      = 'w'
    UPLOAD     = 'u'
    ADMIN      = 'a'
    DELETE     = 'd'
    __ALL__ = [READ, WRITE, ADMIN, DELETE, UPLOAD]