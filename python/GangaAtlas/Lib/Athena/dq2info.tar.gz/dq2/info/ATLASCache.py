"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.4.0
@version: $Id: ATLASCache.py,v 1.2 2008/11/28 10:14:40 mbranco Exp $
"""

caches = {}


import fcntl
import os
import re
import random
import socket
import stat
import sys
import time
import urllib2

from urllib2 import URLError
from threading import Semaphore

from dq2.info.TiersOfATLASException import TiersOfATLASException
from dq2.info.TiersOfATLASConfigurator import TiersOfATLASConfigurator


httpProxy = TiersOfATLASConfigurator().getHTTPProxy()


class ATLASCache (object):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.4.0
    @version: $Revision: 1.2 $
    """


    def __init__ (self, module_name, path, timeout, timeout_download, url):
        """
        Constructs a ATLASCache instance.
        
        @since: 0.4.0
        @version: $Revision: 1.2 $
        
        @param module_name: .
        @type module_name: str
        @param path: .
        @type path: str
        @param timeout: .
        @type timeout: int
        @param timeout_download: .
        @type timeout_download: int
        @param url: .
        @type url: str
        """
        self.semaphore = Semaphore()
        
        self.lastupdated = None
        self.module = None
        self.module_name = module_name
        self.origin = None
        self.path = path
        self.script = '%s/%s.py' % (self.path, self.module_name)
        self.timeout = timeout
        self.timeout_download = timeout_download
        self.url = url
        
        
        # 1.
        
        if self.path not in sys.path:
            sys.path.append(self.path)
        
        
        # 2.
        
        self.timeout_default = None
        try:
            """
            in some worker nodes this raises an AttributeError:
            'module' object has no attribute 'getdefaulttimeout'
            """
            self.timeout_default = socket.getdefaulttimeout()
        except:
            pass


# PRIVATE methods


    def _download (self):
        """
        Downloads a python cache file and saves a local copy to disk.
        
        @since: 0.3
        """
        global httpProxy
        
        self.origin = 'remote'
        res = None
        
        try:
            # change socket timeout settings
            try:
                socket.settimeout_default(self.timeout_download)
            except:
                pass
            
            # download cache python file
            if httpProxy is not None:
                proxyHandler = urllib2.ProxyHandler({'http': httpProxy})
                opener = urllib2.build_opener(proxyHandler)
                res = opener.open(self.url)
            else:
                
                req = urllib2.Request(self.url)
                
                try:
                    res = urllib2.urlopen(req)
                except URLError, e:
                    """"""
                    err_msg = "Couldn't download! [%s]" % (str(e))
                    raise TiersOfATLASException(err_msg)
            
        finally:
            # restore socket timeout settings
            try:
                socket.settimeout_default(self.timeout_default)
            except:
                pass
        
        codestr = res.read()
        
        import new
        #if self.module is not None:
        #    print len(self.module.__dict__.keys())
        self.module = new.module(self.module_name) ## create a new, empty module
        exec codestr in self.module.__dict__ ## exec code in module namespace
        #print len(self.module.__dict__.keys())
        
        self.lastupdated = time.time()
        
        # store a local copy
        self._store(codestr)


    def _elapsedSecsLocal (self):
        """
        @return: the time since the last modification of the local disk copy.
        @rtype: int
        """
        if self._existsLocalCopy():
            return time.time() - os.stat(self.script).st_mtime
        
        return None


    def _elapsedSecsModule (self):
        """
        @return: the time since the last modification of the memory copy.
        @rtype: int
        """
        try:
            return time.time() - self.lastupdated
        except:
            pass
        return None


    def _existsLocalCopy (self):
        """
        @return: True in case local copy exits; False otherwise.
        @rtype: bool
        """
        return os.path.exists(self.script)


    def _loadLocalCopy (self):
        """
        Loads the python cache disk copy into memory.
        
        @since: 0.3
        """
        
        self.origin = 'local'
        
        if self._existsLocalCopy():
            f = open(self.script, 'r')
            
            # lock file for exclusive access -> guarantee it's not in the middle of a refresh
            try:
                i = 0
                while i < 5:
                    try:
                        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                        
                        codestr = f.read()
                        
                        import new
                        self.semaphore.acquire()
                        try:
                            self.module = new.module(self.module_name) ## create a new, empty module
                            exec codestr in self.module.__dict__ ## exec code in module namespace
                        finally:
                            self.semaphore.release()
                        
                        # set module last update to file time
                        try:
                            self.lastupdated = os.stat(self.script).st_mtime
                        except:
                            self.lastupdated = time.time()
                        break
                    except IOError, e:
                        """cache is being refreshed!"""
                        i += 1
                        time.sleep(1) # couldn't get lock -> wait 1sec
                
                err_msg = "Couldn't read local %s file nor download it!" % (self.script)
                raise TiersOfATLASException(err_msg)
            finally:
                """always unlock and close the file"""
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                f.close()
            
        else:
            err_msg = "Local %s doesn't exist!" % (self.script)
            raise TiersOfATLASException(err_msg)


    def _store (self, code):
        """
        Stores a new cache python local disk copy.
        
        @since: 0.3
        """
        
        # creating directories for the local copy
        try:
            os.makedirs(self.path, 0700)
        except:
            pass
        
        # copying the downloaded content into the local copy
        try:
            f = open(self.script, 'w')
        except IOError, e:
            """
            on some worker nodes you may not have
            enough permissions to create a local copy.
            """
            return
        
        try:
            # lock file for exclusive access
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        except IOError, e:
            """
            couldn't lock cache python file
            other process is updating/reading it
            so exit
            other process will try to update it later!
            """
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            f.close()
            return
        
        try:
            f.write(code)
        finally:
            """in case an error occurred writing the file -> unlock it!!!"""
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        f.close()


    def _verifyIntegrity (self):
        """
        Verifies the integrity of the cache python file.
        
        @since: 0.3
        
        @warning: to be implemented by the subclasses
        
        @return: True in case cache python is correct; False otherwise.
        @rtype: bool
        """
        pass


# PUBLIC methods


    def refresh (self):
        """
        Auto-update cache.
        
        @see: http://mail.python.org/pipermail/python-list/2001-November/113142.html
        @see: http://docs.python.org/lib/module-new.html
        """
        
        lastException = None
        for i in range(0, 2): # always try more than once
            try:
                
                if self.module is None:
                    """[1] cache was never loaded: download it!"""
                    try:
                        self._download()
                    except:
                        """
                        in case of error, try a local disk copy:
                        probably it will also fail
                        unless another process loaded it in the meantime.
                        """
                        self._loadLocalCopy()
                
                elif not self._verifyIntegrity():
                    """[2] cache is corrupted: download it!"""
                    try:
                        self._download()
                    except:
                        """
                        in case of error, try a local disk copy:
                        probably it will also fail
                        unless another process loaded/fixed it in the meantime.
                        """
                        self._loadLocalCopy()
                
                elif self._elapsedSecsModule() is not None and self._elapsedSecsModule() <= self.timeout:
                    """[3] cache memory copy is up-to-date: use it (which means: don't load anything)!"""
                    origin = 'memory'
                    return
                
                elif self._elapsedSecsLocal() is not None and self._elapsedSecsLocal() <= self.timeout:
                    """
                    [4] cache local copy is up-to-date: use it!
                    This condition may happen if a process noticed the timeout
                    and already update the local disk copy.
                    """
                    try:
                        self._loadLocalCopy()
                    except:
                        pass
                    
                else:
                    """[5] cache local copy is *not* up-to-date: download it!"""
                    try:
                        self._download()
                    except:
                        """
                        in case of error, try a local disk copy:
                        the cache python although obsolete, it should be ok
                        and on the next time it will try to download it.
                        """
                        self._loadLocalCopy()
                    
            except:
                lastException = sys.exc_info()
                
            if self.module is not None:
                break
        
        if self.module is None or not self._verifyIntegrity():
            type, value, traceBack = lastException
            err_msg = 'Failed importing cache [%s: %s] [%s]' % (type, value, self.url)
            raise TiersOfATLASException(err_msg)
