"""
Testcase for the dq2.common.validator.DQValidator module.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since 0.2
@version: $Id: TiersOfATLASValidatorTestCase.py,v 1.3 2008/11/28 10:14:40 mbranco Exp $
"""

import dq2.info.TiersOfATLASValidator

from dq2.common.DQException import DQInvalidRequestException
from dq2.common.testcase.DQTestCase import DQTestCase
from dq2.common.DQConstants import TestCaseData

import dq2.info.TiersOfATLAS
DESTINATIONS = dq2.info.TiersOfATLAS.getAllDestinationSites()
SOURCES = dq2.info.TiersOfATLAS.getAllSources()


class TiersOfATLASValidatorTestCase (DQTestCase):
    """
    Testcase for the dq2.info.TiersOfATLASValidator module.
    
    @since: 0.2.1
    """


    def __init__ (self, name):
        """
        Constructs an instance of TiersOfATLASValidatorTestCase.
        
        @since: 0.2.1
        
        @param name: testcase name.
        @type name: str
        """
        DQTestCase.__init__(self, name)
        
        self.param_dict_0 = {}
        
        self.param_int__1 = -1
        self.param_int_0 = 0
        self.param_int_1 = 1
        
        self.param_lst_0 = []
        
        self.param_md5_01 = '9cf3329655f1bbe73340f7a60b0ff76c'
        self.param_md5_02 = 'ac5cf111f8300aa97ddc01842587f46b'
        
        self.param_invalid_md5_32 = '9cf3329655f1bbe73340f7a60b0ff76g'
        
        self.param_invalid_site_0 = '<invalid_site>'
        
        self.param_str_0 = ''
        self.param_str_1 = '1'
        self.param_str_10 = 'A' * 10
        self.param_str_11 = 'A' * 11
        self.param_str_33 = 'A' * 33
        self.param_str_36 = 'A' * 36
        self.param_str_37 = 'A' * 37
        self.param_str_50 = 'A' * 50
        self.param_str_51 = 'A' * 51
        self.param_str_255 = 'A' * 255
        self.param_str_256 = 'A' * 256
        
        self.param_invalid_dsn_0 = 'dqtest/invalid/name'
        
        self.param_invalid_lfn_0 = 'dqtest/invalid/name'
        
        self.param_tpl_0 = ()
        
        self.param_uuid_01 = dq2.common.generate_uuid()
        self.param_uuid_02 = '90c2a03b-5526-4616-8283-7d9d20c0214b'
        
        self.param_url_00 = 'http://www.cern.ch/'
        self.param_url_01 = 'http://www.cern.ch:8/'
        self.param_url_02 = 'http://www.cern.ch:80/'
        self.param_url_03 = 'http://www.cern.ch:800/'
        self.param_url_04 = 'http://www.cern.ch:8000/'
        self.param_url_05 = 'http://www.cern.ch:/'
        self.param_url_10 = 'http://www.cern.ch'
        self.param_url_11 = 'http://www.cern.ch:8'
        self.param_url_12 = 'http://www.cern.ch:80'
        self.param_url_13 = 'http://www.cern.ch:800'
        self.param_url_14 = 'http://www.cern.ch:8000'
        self.param_url_15 = 'http://www.cern.ch:'
        
        self.param_urlsec_00 = 'https://www.cern.ch/'
        self.param_urlsec_01 = 'https://www.cern.ch:8/'
        self.param_urlsec_02 = 'https://www.cern.ch:80/'
        self.param_urlsec_03 = 'https://www.cern.ch:800/'
        self.param_urlsec_04 = 'https://www.cern.ch:8000/'
        self.param_urlsec_05 = 'https://www.cern.ch:'
        self.param_urlsec_10 = 'https://www.cern.ch'
        self.param_urlsec_11 = 'https://www.cern.ch:8'
        self.param_urlsec_12 = 'https://www.cern.ch:80'
        self.param_urlsec_13 = 'https://www.cern.ch:800'
        self.param_urlsec_14 = 'https://www.cern.ch:8000'
        self.param_urlsec_15 = 'https://www.cern.ch:/'
        
        self.param_invalid_url_0 = 'htp://www.cern.ch:/'
        self.param_invalid_url_1 = 'htps://www.cern.ch:/'
        
        self.param_with_blanks_0 = ' A'
        self.param_with_blanks_1 = 'A A'
        self.param_with_blanks_2 = 'AA '
        
        self.param_date_criteria_0 = '<>'


# PUBLIC methods


    def setUp (self):
        """
        @since: 0.2.1
        """
        pass


    def tearDown (self):
        """
        @since: 0.2.1
        """
        pass


    def test_is_destination (self):
        """
        Tests dq2.info.TiersOfATLASValidator.is_destination method.
        
        @since: 0.2.9
        
        # 1. test entering valid parameters
        # 1.1 test entering a valid site
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid site string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a valid site
        expected = None
        for eachSite in DESTINATIONS:
            result = dq2.info.TiersOfATLASValidator.is_destination(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid site string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_invalid_site_0
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_destination,
            self.param_str_0
        )


    def test_is_site (self):
        """
        Tests dq2.info.TiersOfATLASValidator.is_site method.
        
        @since: 0.2.9
        
        # 1. test entering valid parameters
        # 1.1 test entering a valid site
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid site string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a valid site
        expected = None
        for eachSite in SOURCES:
            result = dq2.info.TiersOfATLASValidator.is_site(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        for eachSite in DESTINATIONS:
            result = dq2.info.TiersOfATLASValidator.is_site(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid site string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_invalid_site_0
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_site,
            self.param_str_0
        )


    def test_is_source (self):
        """
        Tests dq2.info.TiersOfATLASValidator.is_source method.
        
        @since: 0.2.9
        
        # 1. test entering valid parameters
        # 1.1 test entering a valid site
        # 2. test entering invalid parameters
        # 2.1 test entering a 51-character string
        # 2.2 test entering an integer
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        # 2.6 test entering a string with blank spaces
        # 2.7 test entering an invalid site string
        # 2.8 test entering empty string
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test entering a valid site
        expected = None
        for eachSite in SOURCES:
            result = dq2.info.TiersOfATLASValidator.is_source(eachSite)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        expected = 'DQInvalidRequestException'
        
        # 2.1 test entering a 256-character string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_str_51
        )
        
        # 2.2 test entering an integer
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_int_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_tpl_0
        )
        
        # 2.6 test entering a string with blank spaces
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_with_blanks_0
        )
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_with_blanks_1
        )
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_with_blanks_2
        )
        
        # 2.7 test entering an invalid site string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_invalid_site_0
        )
        
        # 2.8 test entering empty string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.info.TiersOfATLASValidator.is_source,
            self.param_str_0
        )


if __name__ == '__main__':
    """
    Runs all tests in TiersOfATLASValidatorTestCase.
    
    @since: 0.2.1
    """
    import unittest
    suite = unittest.makeSuite(TiersOfATLASValidatorTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
