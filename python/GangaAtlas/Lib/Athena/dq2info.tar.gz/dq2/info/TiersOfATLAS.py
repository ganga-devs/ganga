"""
Tiers of ATLAS

@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.2
@version: $Id: TiersOfATLAS.py,v 1.11.2.17 2009/09/28 09:38:50 vgaronne Exp $

This module contains the set of ATLAS sites and its organizational
structure in Tiers.

@warning: no direct reference should be done to dq2.info.TiersOfATLAS.ToACache module since it might be reloaded
and the old reference will still point to the old module.
"""

import dq2.info.TiersOfATLASValidator

import re
import os
import random

from dq2.info                          import PermissionType
from dq2.info.ATLASCache               import ATLASCache
from dq2.info.TiersOfATLASException    import TiersOfATLASException
from dq2.info.TiersOfATLASConfigurator import TiersOfATLASConfigurator


ToACache = None


class ToATLASCache (ATLASCache):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.4
    @version: $Revision: 1.11.2.17 $
    """


    def __init__ (self):
        """
        Constructs a ToATLASCache instance.
        
        @since: 0.4
        """
        
        
        path = TiersOfATLASConfigurator().getTiersOfATLASLocalPath()
        if path is None:
            user = ''
            try:
                user = os.environ['USER']
            except KeyError, e:
                pass
            path = os.path.expanduser('/var/tmp/.dq2%s/' % user)
        
        timeout = TiersOfATLASConfigurator().getCacheRenewalSecs()
        if timeout is None:
            timeout = 72000
        
        timeout_download = TiersOfATLASConfigurator().getDownloadTimeoutSecs()
        if timeout_download is None:
            timeout_download = 60
        
        url = TiersOfATLASConfigurator().getTiersOfATLASEndpoint()
        if url is None:
            url = 'http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py'
        
        
        ATLASCache.__init__ (self, 'ToACache', path, timeout, timeout_download, url)


    def _verifyIntegrity (self):
        """
        Verifies the integrity of the ToACache file.
        This check is done throught the comparison of the attributes in ToACache to the basic mandatory attributes.
        
        @since: 0.3
        @return: True in case ToACache is correct; False otherwise.
        """
        
        for eachAttribute in ['catalogsTopology', 'closeSitesTopology', 'dbcloud', 'sites', 'topology']:
            if eachAttribute not in dir(self.module):
                return False
        return True

cache = ToATLASCache()


def _refreshToACache():
    """
    Auto-update Tiers of ATLAS cache file.
    
    http://mail.python.org/pipermail/python-list/2001-November/113142.html
    http://docs.python.org/lib/module-new.html
    """
    global cache
    global ToACache
    
    cache.refresh()
    ToACache = cache.module


"""
ToA API
"""


def _resolveSites (id, start=None):
    """
    Resolves cloud (or site) to a list of 'sites'.
    
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @return: list of 'sites' matching id or empty list otherwise.
    """
    id = id.upper()
    
    # first cycle
    if start is None:
        nid = id
    else:
        nid = start
    
    # termination condition
    if ToACache.sites.has_key(nid):
        """the nid is itself a site: resolved!"""
        return [ nid ]
    
    # for all elements, aggregate sites
    if not ToACache.topology.has_key(nid):
        """the nid wasn't a site nor a cloud: send empty list"""
        return []
    
    # nid represents a cloud: need to iterate
    ids = []
    for el in ToACache.topology[nid]:
        response = _resolveSites(id, start=el)
        if response is not None:
            # remove repeated elements
            for id in response:
                if ids.count(id) == 0:
                    ids.append( id )
    return ids


getSites = _resolveSites

def getAllActivities():
    """
    @return: list with all valid activites
    """
    _refreshToACache()
    
    return ToACache.activities.keys()
    
def getAllDestinationSites():
    """
    @return: list with all valid destination sites
    """
    _refreshToACache()
    
    return ToACache.sites.keys()
    
    
def getAllSources():
    """
    @return: list with all valid source sites
    """
    _refreshToACache()
    
    # first get all sites
    s = ToACache.sites.keys()
    
    # then get clouds
    g = ToACache.topology.keys()
    for id in g:
        # only add unique entries
        if s.count(id) == 0:
            s.append(id)

    return s


def getTier1s():
    """
    @return: list with all Tier-1 sites
    """
    _refreshToACache()
    
    tier1s = []
    sites = ToACache.topology['TIER1S']
    for site in sites:
        cloudSites = getSites(site)
        for site in cloudSites:
            if site not in tier1s:
                tier1s.append(site)
    return tier1s
    

def getCloseSites (id):
    """
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @return: list of sites which are close to given site id,
    or empty list if no close sites found.
    
    Depends on definitions in 'closeSitesTopology'.
    If id is not explicit on 'closeSitesTopology', will
    use topology to resolve sites.
    """
    _refreshToACache()
    id = id.upper()
    closeSites = []
    for cloud in ToACache.closeSitesTopology:
        if id in _resolveSites(cloud):
            for closeCloud in ToACache.closeSitesTopology[cloud]:
                for site in _resolveSites(closeCloud):
                    if site not in closeSites:
                        closeSites.append(site)
    return closeSites


def getConnectedSites (id):
    """
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
       
    @return: list of sites which are connected to given site id,
    or empty list if no connected sites found.
       
    Depends on definitions in 'closeSitesTopology'.
    If id is not explicit on 'closeSitesTopology', will
    use topology to resolve sites.
    
    Returns list of sites which are well connected to given site id,
    or empty list if no close sites found.
       
    A well connected site is defined by the directly
    connected sites in the ToA.
    """      
    _refreshToACache()
     
    clouds = []
    for k, v in ToACache.closeSitesTopology.iteritems():
        if id in _resolveSites(k):
            clouds.extend(v)
    matches = []
    for cloud in clouds:
        sites = _resolveSites(cloud)
        for site in sites:
            if matches.count(site) == 0:
                matches.append(site) 
    return matches


def getSiteByCE (ce):
    """
    @return: the site id which hosts the CE.
    Brute force method: loop over all sites
    """
    sites = getAllDestinationSites()
    
    for site in sites:
        ces = getSiteProperty(site, 'ce')
        if ces and len(ces) > 0 and ce in ces:
            return site


def getSitesInCloud (cloud):
    """
    @param cloud: cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @return: a list of sites within the cloud.
    """
        
    if cloud not in ToACache.dbcloud:
        return []
    
    return _resolveSites(ToACache.dbcloud[cloud])


def getStorageInfo (cloud, closeSE):
    """
    @param cloud:  is the destination cloud the task is assigned to and closeSE
    is the hostname of the SE the task is actually running on.
    
    This method returns the LFC that output files should
    be registered to and a list of storages to store output files
    in order of preference
    
    - close SE if it is in the cloud
    - the cloud's T1 disk SE
    - other SEs in the cloud
    
    @return: a tuple (LFC endpoint, [list of storage endpoints])
    """
    
    _refreshToACache()
    storages = []
    
    # first find the site the local SE is in (ignoring TAPE sites)
    localSEsite = None
    for site in getAllDestinationSites():
        srm = getSiteProperty(site, 'srm')
        if site[-4:] != 'TAPE' and srm is not None and srm.find(closeSE) != -1: # quite loose matching for now
            localSEsite = site
            break
    
    # get the associated LFC to the cloud
    lfc = getLocalCatalog(ToACache.dbcloud[cloud])
    
    # get all the sites in the cloud
    sitesInCloud = getSitesInCloud(cloud)
    
    # check if local site is in cloud
    if localSEsite in sitesInCloud:
        storages.append(getSiteProperty(localSEsite, 'srm'))
    
    # go through all cloud sites, picking out T1
    cloudSEs = []
    for site in sitesInCloud:
        
        # ignore close SE and tape sites
        if site == localSEsite or site[-4:] == 'TAPE':
            continue
        
        se = getSiteProperty(site, 'srm')
        if se is not None and se != '':
            # if this is the T1 site add to storages list
            if site[-4:] == 'DISK' and site[:-4] in ToACache.topology['TIER1S']:
                storages.append(se)
            else:
                cloudSEs.append(se)
                
    # randomise and add the cloud SEs to the list
    random.shuffle(cloudSEs)
    storages.extend(cloudSEs)
    
    return (lfc, storages)


def getFTS (surl, site):
    """
    Finds FTS server serving source SURL to destination site.
    
    The 'fts' property for each site may either be:
    - a string with an FTS endpoint to use;
    - or a dictionary with multiple FTS endpoints.
    
    In the case of a dictionary, it maps 'cloud ID' to
    'FTS endpoint', e.g.
    
    { 'TIER1S' : 'some.fts.endpoint',
      ''       : 'default.fts.endpoint' }
      
    The empty string signals the default FTS endpoint to use. 
    
    @param surl: The source SURL.
    @param site: The destination site.
    
    @return: FTS endpoint or None.
    """
    _refreshToACache()
    
    value = getSiteProperty(site, 'fts')
    
    if isinstance(value, str):
        return value
    
    if isinstance(value, dict):
        for cloud in value:
            if cloud == '': continue # skip default
            
            if isSURLFromSiteOrCloud(surl, cloud):
                return value[cloud] # matches cloud
        
        # default value
        try:
            return value['']
        except:
            return None
    
    return None
    
    
def getLocalCatalog (id):
    """
    Find local catalog endpoint for site or virtual group of sites.
    
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @return: endpoint or None.
    """
    catalog = TiersOfATLASConfigurator().getSiteCatalog(id)
    if catalog is not None:
        return catalog
    
    # otherwise check ToA cache
    _refreshToACache()
    
    id = id.upper()
    
    # 'id' must be a site...
    if not id in getAllSources():
        return None
        
    # scan catalogs topology
    for k, v in ToACache.catalogsTopology.iteritems():
        
        for el in v: 
            
            # is explicit on catalogs topology
            if el == id:
                return k
                
            # otherwise is part of a cloud
            response = _resolveSites(el)
            if id in response:
                return k
                
    return None


def getRemoteCatalogs (id):
    """
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @return: list of catalogs associated with site or cloud.
    """
    _refreshToACache()
    
    id = id.upper()
    
    cats = []
    
    # scan catalogs topology
    for k, v in ToACache.catalogsTopology.iteritems():
        
        for nid in v:
            sites = _resolveSites(nid)
            if id in sites:
                return [k]
    
    # not explicit on catalogs topology
    sites = _resolveSites(id)
    
    # recursion termination condition
    if sites == [id]:
        return []
    else:    
        for nid in sites:
            ncats = getRemoteCatalogs(nid)
            
            # remove repeated elements
            for cat in ncats:
                if cats.count(cat) == 0:
                    cats.append(cat)
    
    return cats


def getSiteProperty (id, property):
    """
    Will find property for a site id.
    
    @param id: the site identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @param property: .
    @type property: string
    
    @todo: validation to see if id is really a site or not.
    
    @return: property value or None
    """
    _refreshToACache()
    
    id = id.upper()

    if property is not None:
        value = TiersOfATLASConfigurator().getSiteProperty(id, property)
        if value is not None:
            return value
        if ToACache.sites.has_key(id) and \
            ToACache.sites[id].has_key(property):
            return ToACache.sites[id][property]
            
    return None


def getToolAssigner (id):
    """
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    @todo: a validation should be done here to make sure id is really a site! -> if done on getSiteProperty... don't do here.
    
    @since: 0.3
    @return: the site tool assigner.
    """
    return getSiteProperty(id, 'toolAssigner')


def isSURLFromSiteOrCloud (surl, id):
    """
    @param surl: source URL.
    @type surl: string
    
    @param id: the site or cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    Checks if given SURL matches the domain
    specified for the given site or cloud.
    In case of cloud will need to resolve all
    sites within the cloud first.
    
    @return: True in case SURL belongs to the site or to a cloud.
    """
    _refreshToACache()
    
    id = id.upper()
    
    # check site first
    if ToACache.sites.has_key(id):
        if re.match(ToACache.sites[id]['domain'], surl):
            return True
    else:
        # not site, so check clouds
        ids = _resolveSites(id)
        for nid in ids:
            if ToACache.sites.has_key(nid) and \
                ToACache.sites[nid].has_key('domain') and \
                re.match(ToACache.sites[nid]['domain'], surl):
                return True
    
    return False


def listCEsInCloudByCloud (id):
    """
    Given the name of a cloud as defined in the dbcloud dictionary
    in the cache, return all the CEs in the cloud.
    
    @param id: the cloud identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    """
    
    _refreshToACache()
    
    id = id.upper()
    
    if not ToACache.dbcloud.has_key(id):
        return None
    
    els = []
    id = ToACache.dbcloud[id]
    
    if ToACache.topology.has_key(id):
        els = ToACache.topology[id]
    else:
        # find site in keys
        for k, v in ToACache.topology.iteritems():
            if id in _resolveSites(k):
                els = v
                break
    
    # find all sites
    sites = []
    for el in els:
        response = _resolveSites(el)
        for id in response:
            if sites.count(id) == 0:
                sites.append( id )
    
    ces = []
    for site in sites:
        celist = getSiteProperty(site, 'ce')
        if celist is not None:
            for ce in celist:
                if ce != '' and ce not in ces:
                    ces.append(ce)
    
    return ces


def listCEsInCloudByDomain (domain):
    """
    Given an expression of a domain (eg *.fr) return all the CE
    hostnames matching the epression
    
    @type domain: string
    """
    
    _refreshToACache()
    
    ces = []
    
    # make sure domain is correct python re syntax
    # assume nothing too complicated...
    i = domain.find('*')
    if i != -1 and (i == 0 or domain[i-1] != '.'):
        domain = domain.replace('*', '.*', 1)
    if domain[-1] != '$':
        domain = domain+'$'
    
    # go through all sites and match ce hostname against domain
    for site in getAllDestinationSites():
        celist = getSiteProperty(site, 'ce')
        if celist is not None:
            for ce in celist:
                if re.match(domain, ce):
                    ces.append(ce)
    
    return ces

def resolveGOC(sites):
    """
    Resolves a dictionary of GOCDB sitenames to their respective
    DQ2 sitenames.
    
    @param sites: dictionary mapping of gocSitename to None
    @type sites: dict
    
    @author: Mario Lassnig
    @since: 0.3
    
    @return sites: dictionary mapping of gocSitename to list of DQ2sitenames
    """
    
    _refreshToACache()
    
    if not isinstance(sites, dict):
        raise TiersOfATLASException('You must supply a dictionary mapping gocSitename:None')
    
    output = sites
    
    #build the list of dq2-sitenames for a given goc-sitename
    for key in sites.keys():

        returnList = []
        siteList = {}
        for toaSite in ToACache.sites:
            try:
                if key in ToACache.sites[toaSite]['alternateName'] and 'SCRATCH' in toaSite:
                    siteList[toaSite] = 0
                elif key in ToACache.sites[toaSite]['alternateName'] and 'USERDISK' in toaSite:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 1
                elif key in ToACache.sites[toaSite]['alternateName'] and 'GROUP' in toaSite:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 2
                elif key in ToACache.sites[toaSite]['alternateName'] and 'DATADISK' in toaSite:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 3
                elif key in ToACache.sites[toaSite]['alternateName'] and 'PRODDISK' in toaSite:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 4
                elif key in ToACache.sites[toaSite]['alternateName'] and 'MCDISK' in toaSite:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 5
                elif key in ToACache.sites[toaSite]['alternateName'] and 'TAPE' in toaSite:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 6
                elif key in ToACache.sites[toaSite]['alternateName']:
                    if not siteList.has_key(toaSite):
                        siteList[toaSite] = 7
            except:
                #sometimes alternateName is not set
                pass
            
        # merge it together and sort automatically
        for i in xrange(0, 7): 
            for site in siteList:
                if siteList[site] == i:
                    if site not in returnList:
                        returnList.append(site)

        output[key] = returnList
    
    return output


def whichCloud (site):
    """
    @param site: site identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @author: Pedro Salgado <pedro.salgado@cern.ch>
    @since: 0.3
    
    @return: the cloud where the site belongs.
    """
    dq2.info.TiersOfATLASValidator.is_site(site)
    for eachCloud in ToACache.dbcloud:
        if site in getSitesInCloud(eachCloud):
            return ToACache.dbcloud[eachCloud]
    return None

def  getPermissions (site, permission) :
    """
    @param site: the site identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @return: the list of FAQNs who can writer.
    """
    dq2.info.TiersOfATLASValidator.is_site(site)
    dq2.info.TiersOfATLASValidator.is_permission(permission)
    d = getSiteProperty(site, 'permissions')
    if not d: d = ToACache.defaultPermission
    return [k.lower() for k in d if permission.lower() in d[k]]

def getQuota (site, faqn):
    """
    @param site: the site identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type site: string

    @param faqn: the faqn identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type group: string   
 
    @return: the quota value in Tera.
    """
    dq2.info.TiersOfATLASValidator.is_site(site)

    quotas = getSiteProperty(site, 'quotas')
    if quotas:
        quotas = dict([(k.lower(), v) for k,v in quotas.iteritems()])        
        if faqn.lower() in quotas:
          return quotas[faqn.lower()]

def getFQANsPerQuota (site):   
    """
    @param site: the site identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type site: string
 
    @return: the list of fqans for which a quota is defined.
    """     
    dq2.info.TiersOfATLASValidator.is_site(site)
    quotas = getSiteProperty(site, 'quotas')
    if quotas:
        return [g.lower() for g in quotas]

def isTapeSite (site):
    """
    If 'tape' property is defined for a site, return its value.
    Otherwise, report as tape site if the site name includes
    substring 'TAPE'.
    
    @param site: site identifier as appears in TiersOfATLAS.
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type id: string
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @since: 0.4
    
    @return: True if Tape storage, False otherwise.
    """
    _refreshToACache()
    dq2.info.TiersOfATLASValidator.is_site(site)
    isTape = getSiteProperty(site, 'tape')
    if isTape:
        return isTape
    if 'TAPE' in site:
        return True
    return False


def getActivities ():
    """
    @author: Miguel Branco <miguel.branco@cern.ch>
    @since: 0.4
    
    @return: Tuple with default activity, dictionary of activities.
    """
    _refreshToACache()    
    return ToACache.defaultActivity, ToACache.activities 
        

def getActivityId (activity):
    """
    @author: Vincent Garonne <vincent.garonne@cern.ch>
    @since: 0.4
    
    @param activity: activity identifier 
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type activity: string    
    @return the activityId
        
    """
    defaultActivity, activities =  getActivities ()
    if activity:
      act        = dict([(a.lower(), activities[a])for a in activities])
      if activity.lower () in act:
        return act[activity.lower ()]    

def getActivity (activityId):
    """
    @author: Vincent Garonne <vincent.garonne@cern.ch>
    @since: 0.4
    
    @param activityId: activity id identifier 
    http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/TiersOfATLASCache.py
    @type activity: string    
    @return the activity
        
    """
    defaultActivity, activities =  getActivities ()
    for activity in activities:
        if activities[activity] == activityId: return activity
        
def getShares ():
    """
    @author: Miguel Branco <miguel.branco@cern.ch>
    @since: 0.4
    
    @return: Tuple with default share, dictionary of shares.
    """
    _refreshToACache()    
    return ToACache.defaultShare, ToACache.shares 

def listSpaceTokensPerSites ():
  """
  @return: the dictionnary {'site1': [list of space tokens], ...}.
  """
  endPoints = getAllDestinationSites()
  sites    = {}
  for e in endPoints:
      if '_' in e:
         site = e[:e.find('_')]
         if site not in sites: sites[site] = list()
         if not e.find('CERN-PROD')>-1:
            endpoint   =  getSiteProperty(e,'srm')
            if 'token:' in endpoint:
                spaceToken = getSiteProperty(e,'srm').split('token:')[1]
                if  spaceToken not in sites[site]: sites[site].append (getSiteProperty(e,'srm').split(':')[1])
  # remove empty list
  return dict (filter (lambda s: s[1], sites.items())) 

"""
Module settings
"""

ToACache = None
_refreshToACache()
