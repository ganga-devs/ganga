"""
Contains the class definition for Config objects.

@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.2
@version: $Id: TiersOfATLASConfigurator.py,v 1.3 2008/11/28 10:14:40 mbranco Exp $
"""
from dq2.common.Config import Config


class TiersOfATLASConfigurator:
    """
    Class definition for Tiers of ATLAS configurator.
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: TiersOfATLASConfigurator.py,v 1.3 2008/11/28 10:14:40 mbranco Exp $
    """
    
    """
    Holds the singleton reference.
    """
    _instance = None
    
    """
    Configuration objects
    """
    _siteCatalogs = {}
    _httpProxy = None
    _downloadTimeoutSecs = None
    _cacheRenewalSecs = None
    _url = None
    _localPath = None
    _siteProperty = {}
    
    def __new__(cls):
        """
        Invoked on every class instance creation.
        
        Makes sure that only one instance of this class ever exists.
        
        @return: A reference to the class singleton
        """
        if not cls._instance:
            cls._instance = object.__new__(cls)
        
        return cls._instance


    def __init__(self):
        """
        Object constructor.
        
        As this is a singleton, nothing is put in here (otherwise it would
        be constantly called).
        """
        pass


    def getSiteProperty(self, siteID, property):
        """
        Reads site property from config file.
        """
        if self._siteProperty.has_key(siteID) and self._siteProperty[siteID].has_key(property) and self._siteProperty[siteID][property]:
            return self._siteProperty[siteID][property]
        
        config = Config().getConfig('dq2-info')

        if not self._siteProperty.has_key(siteID):
            self._siteProperty[siteID] = {}
        if not self._siteProperty[siteID].has_key(property):
            self._siteProperty[siteID][property] = None
        
        try:
            self._siteProperty[siteID][property] = config.get('dq2-info', '%s_%s' % (property, siteID))
        except:
            pass
        return self._siteProperty[siteID][property]


    def getSiteCatalog(self, siteID):
        """
        Reads site local catalog endpoint.
        """
        if self._siteCatalogs.has_key(siteID):
            return self._siteCatalogs[siteID]
        
        config = Config().getConfig('dq2-info')
        
        try:
            self._siteCatalogs[siteID] = config.get('dq2-info', 'catalog_%s' % siteID)
        except:
            self._siteCatalogs[siteID] = None
        return self._siteCatalogs[siteID]

    
    def getHTTPProxy(self):
        """
        Read local proxy setting.
        """
        if self._httpProxy is not None:
            return self._httpProxy
            
        config = Config().getConfig('dq2-info')
        
        try:
            self._httpProxy = config.get('dq2-info', 'httpProxy')
        except:
            pass
        return self._httpProxy

    
    def getDownloadTimeoutSecs(self):
        """
        Read download timeout setting in seconds.
        """
        if self._downloadTimeoutSecs is not None:
            return self._downloadTimeoutSecs

        config = Config().getConfig('dq2-info')

        try:
            self._downloadTimeoutSecs = int(config.get('dq2-info', 'downloadTimeoutSecs'))
        except:
            pass
        return self._downloadTimeoutSecs


    def getCacheRenewalSecs(self):
        """
        Read cache renewal setting in seconds.
        """
        if self._cacheRenewalSecs is not None:
            return self._cacheRenewalSecs

        config = Config().getConfig('dq2-info')

        try:
            self._cacheRenewalSecs = int(config.get('dq2-info', 'cacheRenewalSecs'))
        except:
            pass
        return self._cacheRenewalSecs
    
    
    def getTiersOfATLASEndpoint(self):
        """
        Read Tiers of ATLAS URL from configuration file.
        """
        if self._url is not None:
            return self._url

        config = Config().getConfig('dq2-info')

        try:
            self._url = config.get('dq2-info', 'url')
        except:
            pass
        return self._url    


    def getTiersOfATLASLocalPath(self):
        """
        Read Tiers of ATLAS URL from configuration file.
        """
        if self._localPath is not None:
            return self._localPath

        config = Config().getConfig('dq2-info')

        try:
            self._localPath = config.get('dq2-info', 'localPath')
        except:
            pass
        return self._localPath    
