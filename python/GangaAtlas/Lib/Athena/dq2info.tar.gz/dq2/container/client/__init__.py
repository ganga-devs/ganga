"""


@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: __init__.py,v 1.7.2.2 2008/06/17 07:59:58 psalgado Exp $
"""


from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.common.DQConstants import HTTP
from dq2.common.client.DQClient import DQClient


API_030 = '030'
PACKAGE = 'dq2-container-client'


class ContainerClient (DQClient, Configurable):
    """
    @since: 1.0
    @version: $Revision: 1.7.2.2 $
    """


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, timeout=None):
        """
        Constructs a ContainerClient instance.
        
        @since: 1.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @param urlsec: is the secure URL of the host to be contacted.
        @param certificate: is the proxy certificate.
        @param ca_path: is the location of the Certification Authority certificates.
        @param timeout : the client timeout (in seconds).
        """
        if url is None:
            url = ContainerClient.insecure
        if urlsec is None:
            urlsec = ContainerClient.secure
        if timeout is None:
            timeout = ContainerClient.timeout
        
        DQClient.__init__(self, url, urlsec, certificate, ca_path, api=API_030, timeout=timeout)


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 1.0
        
        @warning: this method is necessary in case the user requests creates an instance of this class, without using the factory.
        """
        
        ContainerClient.insecure = Config().getConfig(PACKAGE).get(PACKAGE, 'insecure')
        ContainerClient.secure = Config().getConfig(PACKAGE).get(PACKAGE, 'secure')
        try:
            ContainerClient.timeout = int(Config().getConfig(PACKAGE).get(PACKAGE, 'timeout'))
        except:
            ContainerClient.timeout = 9999

    __configure__ = staticmethod(__configure__)


# PUBLIC methods


    def create (self, name, owner=None, datasets={}):
        """
        Create a container.
        
        @since: 1.0
        
        @param cuid: the container unique identifier.
        @type cuid: int (128-bit)
        @param name: name of the container.
        @type name: str
        
        @warning: user parameter is only to be used in testcases.
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0001
        
        @raise DQContainerExistsException:
            in case a container with the same name already exists.
        
        @return: None
        @rtype: NoneType
        """
        
        self.type = HTTP.POST
        self.is_secure = True
        self.request = '/ws_dq2/rpc'
        self.params = {'operation': 'container_create', 'name': name}
        
        return self.send()


    def register (self, name, datasets, user=None):
        """
        Register datasets into a container.
        
        @param name: name of the container.
        @type name: str
        @param datasets: list of datasets to be registered.
            {dsnA: versionA, ..., dsnN: versionN}
        @type datasets: dict
        
        @warning: user parameter is only to be used in testcases.
        
        @since: 1.0
        
        @raise DQContainerIsInStateException:
            in case the container is closed or archived.
        @raise DQContainerNotOwner:
            in case the user is not the owner of the container.
        @raise DQContainerUnknownException:
            in case the container does not exist.
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0003
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0010
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0011
        """
        
        self.type = HTTP.POST
        self.is_secure = True
        self.request = '/ws_dq2/rpc'
        self.params = {'operation': 'container_register', 'name': name, 'datasets': datasets}
        
        return self.send()


    def retrieve (self, name):
        """
        List datasets of a container.
        
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0006
        
        @raise DQContainerUnknownException:
            in case the container does not exist.
        @raise DQContainerIsInState:
            in case the container is archived.
        
        @return: {dsn: version,...,dsn: version}
        @rtype: tuple
        """
        
        self.type = HTTP.GET
        self.is_secure = False
        self.request = '/ws_dq2/rpc'
        self.params = {'operation': 'container_retrieve', 'name': name}
        
        return self.send()


    def unregister (self, name, datasets, user=None):
        """
        Remove datasets from a container.
        
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        @param datasets: list of datasets to be registered.
            {dsnA: versionA, ..., dsnN: versionN}
        @type datasets: dict
        
        @warning: user parameter is only to be used in testcases.
        
        @raise DQContainerIsInStateException:
            in case the container is closed or archived.
        @raise DQContainerNotOwner:
            in case the user is not the owner of the container.
        @raise DQContainerUnknownException:
            in case the container does not exist.
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0004
        """
        
        self.type = HTTP.POST
        self.is_secure = True
        self.request = '/ws_dq2/rpc'
        self.params = {'operation': 'container_unregister', 'name': name, 'datasets': datasets}
        
        return self.send()
