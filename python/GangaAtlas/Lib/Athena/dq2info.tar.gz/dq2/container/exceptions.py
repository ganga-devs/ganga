"""


@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: exceptions.py,v 1.2.2.4 2009/02/12 13:34:15 mlassnig Exp $
"""


from dq2.common.constants import ContainerState, DatasetState
from dq2.common.DQException import DQException, DQFatalError, DQNonFatalError, DQSecurityException, DQUserError

class DQContainerExistsException (DQException, DQUserError, DQFatalError):
    """
    DQException class for the cases when a container, for the given name, already exists.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.2.2.4 $
    """


    def __init__ (self, name, root_cause=None):
        """
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        @param root_cause: is the original error/exception.
        @type root_cause: object
        """
        self.name = name
        DQException.__init__(self, root_cause=root_cause)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 1.0
        """
        message = 'The container %s already exists!' % self.name
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQContainerAlreadyInStateException (DQException, DQUserError, DQNonFatalError):
    """
    DQException class for the cases when the container is already in the state the user wants it to be.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.2.2.4 $
    """


    def __init__ (self, name, state):
        """
        """
        self.name = name
        self.state = state
        DQException.__init__(self)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 1.0
        """
        message = 'The container %s is already in state %s!' % (self.name, DatasetState.DESCRIPTION[self.state])
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQContainerAlreadyHasDataset (DQException, DQUserError, DQNonFatalError):
    """
    """


    def __init__ (self, name):
        """
        """
        self.name = name
        DQException.__init__(self)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 1.0
        """
        message = 'The container %s already has one of the datasets!' % (self.name)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQContainerDoesNotHaveDataset (DQException, DQUserError, DQNonFatalError):
    """
    """


    def __init__ (self, name):
        """
        """
        self.name = name
        DQException.__init__(self)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 1.0
        """
        message = 'The container %s does not contain one of the datasets!' % (self.name)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)
    


class DQContainerIsInStateException (DQException, DQUserError, DQFatalError):
    """
    DQException class for the cases when a request is done over an archived container.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.2.2.4 $
    """


    def __init__ (self, name, state):
        """
        """
        self.name = name
        self.state = state
        DQException.__init__(self)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 1.0
        """
        message = 'The container %s is in state %s!' % (self.name, DatasetState.DESCRIPTION[self.state])
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQContainerNotOwner (DQException, DQUserError, DQFatalError):
    """    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.2.2.4 $
    """


    def __init__ (self, name, owner):
        """
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        @param root_cause: is the original error/exception.
        @type root_cause: object
        """
        self.name = name
        self.owner = owner
        DQException.__init__(self)


    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 1.0
        """
        message = 'Container %s can only be modified by %s or by an administrator!' % (self.name, self.owner)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


from dq2.common.exceptions import DQUnknownFileException