"""
@since: 0.1
@version: $Id: __init__.py,v 1.3 2007/11/20 16:21:42 psalgado Exp $
"""
