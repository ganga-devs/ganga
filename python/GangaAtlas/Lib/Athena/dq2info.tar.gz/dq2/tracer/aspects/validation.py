"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

"""
Location validation aspect.

@author: Mario Lassnig
@author: Pedro Salgado
@contact: mario.lassnig@cern.ch
@since: 0.3
@version: $Id: validation.py,v 1.2 2007/12/04 14:48:50 mlassnig Exp $
"""

from dq2.tracer.DQTracerValidator     import *


def addReport(self, report):
    """
    (since 0.4.0)
    """            
    return self.__proceed(report)