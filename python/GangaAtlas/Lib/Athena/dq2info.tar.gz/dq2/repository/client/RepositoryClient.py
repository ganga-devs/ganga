"""
Client to the dataset repository central catalog.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.1.4
@version: $Id: RepositoryClient.py,v 1.15.2.7.2.4 2009/06/29 08:07:22 vgaronne Exp $
"""

import os
import string
import sys
import urllib

from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.common.DQConstants import HTTP
from dq2.common.DQException import *

from dq2.common.client.DQClient import DQClient
from dq2.common.client.x509 import get_x509
from dq2.common.client.x509 import get_ca_path
from dq2.common.constants import API_030

from dq2.common.dao.DQDaoException import *

from dq2.repository.DQRepositoryException import *


class RepositoryClient (DQClient, Configurable):
    """
    Class to make requests to the dataset repository central catalog.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.15.2.7.2.4 $
    """


    insecure = None
    secure = None
    timeout = None


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, timeout=None):
        """
        Constructs a RepositoryClient instance.
        
        @since: 0.2.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @param urlsec: is the secure URL of the host to be contacted.
        @param certificate: is the proxy certificate.
        @param ca_path: is the location of the Certification Authority certificates.
        @param timeout : the client timeout (in seconds). @since: 0.3
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path, api=API_030, timeout=timeout)


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 0.3.0
        """
        RepositoryClient.insecure = Config().getConfig('dq2-repository-client').get('dq2-repository-client', 'insecure')
        RepositoryClient.secure = Config().getConfig('dq2-repository-client').get('dq2-repository-client', 'secure')
        try:
            RepositoryClient.timeout = int(Config().getConfig('dq2-repository-client').get('dq2-repository-client', 'timeout'))
        except:
            RepositoryClient.timeout = 9999
    
    __configure__ = staticmethod(__configure__)


# PUBLIC methods


    def addDataset (self, dsn, duid, vuid, owner=None):
        """
        Add a new dataset with version 1.
        
        RepositoryClient uses a secure POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param duid: is the dataset unique identifier.
        @param vuid: is the dataset version unique identifier.
        @param owner: <used only by the catalog> the user who requested the operation.
        
        B{Exceptions:}
            - DQDatasetExistsException is raised,
                in case there is a dataset with the given name.
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        """
        
        self.type = HTTP.PUT
        self.request = '/ws_repository/rpc'
        self.is_secure = True
        
        self.params = {'operation': 'addDataset', 'dsn': dsn, 'duid': duid, 'vuid': vuid}
        
        return self.send()


    def getMetaDataAttribute (self, dsn, attributes, version=0):
        """
        Returns the metadata information for the given dataset/dataset version.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        changed on 0.3 the return format to {'attribute_1': value_1, ..., 'attribute_N': value_N}
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param attributes: is a list of dataset metadata attributes.
        @param version: is the dataset version (0 is the latest).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name, invalid or missing arguments.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
                
        @return: Returns a dictionary containing the request metadata information.::
            {'attribute_1': value_1, ..., 'attribute_N': value_N}
        
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'getMetaDataAttribute', 'dsn': dsn, 'attributes': attributes, 'version': version}
        
        return self.send()


    def getState (self, dsn):
        """
        Returns the dataset state.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        
        @return: The dataset state (check dq2.common.DQConstants.DatasetState).
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'getState', 'dsn': dsn}
        
        return self.send()


    def getVersionMetadata (self, dsn, version=0):
        """
        Search for datasets.
        
        @since: 0.3.5
        
        @return: duid_10, state, owner, creationdate, latestversion, origin, lastoperationdn,
            lastoperationip, closeddate, frozendate, deleteddate, type, physicsgroup
            latestvuid, vuid_10, version, versioncreationdate, tier0state, tier0type,
            numberfiles, size
        @rtype: tuple
        """
        
        self.type = HTTP.GET
        self.request = '/ws_dq2/rpc'
        self.is_secure = False
        
        self.params = {'operation': 'version_metadata', 'dsn': dsn, 'version': version}
        
        return self.send()


    def queryDatasetByClosedDate (self, seconds, criteria, dsn=None):
        """
        Returns the datasets by closeddate, according to the given criteria.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param seconds: is the number of seconds counted from now [on the server side].
        @param criteria: is the criteria to be used (check dq2.common.DQConstants.DateCriteria).
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        
        @return: Dictionary containing the dataset versions information.::
            {
                'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
                'dataset_nameB': ['B_vuid_for_version1']
            }, where X > 0
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'queryDatasetByClosedDate', 'seconds': seconds, 'dsn': dsn, 'criteria': criteria}
        
        return self.send()


    def queryDatasetByCreationDate (self, seconds, criteria, dsn=None):
        """
        Returns the datasets by creationdate, according to the given criteria.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param seconds: is the number of seconds counted from now [time on server side].
        @param criteria: is the criteria to be used (check dq2.common.DQConstants.DateCriteria).
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: Dictionary containing the dataset versions information.::
            {
                'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
                'dataset_nameB': ['B_vuid_for_version1']
            }, where X > 0
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'queryDatasetByCreationDate', 'seconds': seconds, 'dsn': dsn, 'criteria': criteria}
        
        return self.send()


    def queryDatasetByFrozenDate (self, seconds, criteria, dsn=None):
        """
        Returns the datasets by frozendate, according to the given criteria.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param seconds: is the number of seconds counted from now [time on server side].
        @param criteria: is the criteria to be used (check dq2.common.DQConstants.DateCriteria).
        @param dsn: is the dataset name.
        
        @return: Dictionary containing the dataset versions information.::
            {
                'dataset_nameA': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']
                'dataset_nameB': ['B_vuid_for_version1']
            }, where X > 0
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'queryDatasetByFrozenDate', 'seconds': seconds, 'dsn': dsn, 'criteria': criteria}
        
        return self.send()


    def queryDatasetByMetaData (self, filterBy):
        """
        Returns the dataset versions that match the given criteria.
        
        RepositoryClient uses a POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param filter: list containing dictionaries of metadata attributes and values
        ({'attrname_0': attrvalue_0, ..., 'attrname_N': attrvalue_N}).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        
        @return: List of tuples with (dataset name, version)::
            ['dataset_name_1', ..., 'dataset_name_N']
        """
        
        self.type = HTTP.POST
        self.is_secure = False
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'queryDatasetByMetaData', 'filter': filterBy}
        
        return self.send()


    def queryDatasetByName (self, dsn, version=None, onlyNames=False, p=None, rpp=None):
        """
        Query Dataset Repository for dataset name(s) and version and return the matching vuids.
        
        If no version is given the latest one are returned.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name (accepts wildcards).
        @param version: is the dataset version, 0 means return the latest version.
        @param onlyNames: Option to return only the dataset names.
        @param rpp: Print rrp first results.        
        @param p: Specify page to print.
        
        usage::
            queryDatasetByName('myname') - returns all versions of the given dataset
            queryDatasteByName('myname*') - returns all versions of the datasets that start by 'myname'.
            queryDatasteByName('*myname') - returns all versions of the datasets that end by 'myname'.
        
            queryDatasetByName('myname', 2) - returns the version 2 of dataset 'myname'.
            queryDatasetByName('myname', 0) - returns the latest version of the dataset 'myname'.
            queryDatasetByName('myname', None) - returns all the versions of the dataset 'myname'.
            queryDatasetByName('myname', ]-infinite, 0[) - returns all the versions of the dataset 'myname'.
        
            queryDatasetByName('myname*', 2) - returns the version 2 of the datasets that start by 'myname'.
            queryDatasetByName('*myname', None) - returns all the versions of the datasets that end with 'myname'.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: Dictionary containing the dataset versions information.::
            {
                'dataset_nameA': {'duid': duid, 'vuids': ['A_vuid_for_version1+X', ..., 'A_vuid_for_version1']}
                'dataset_nameB': {'duid': duid, 'vuids': ['B_vuid_for_version1']}
            }, where X > 0
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'queryDatasetByName', 'dsn': dsn, 'version': version, 'onlyNames': int(onlyNames), 'p':p , 'rpp': rpp}
        
        return self.send()


    def queryDatasetByUID (self, uid):
        """
        Returns a list of uids containing all attributes.
        
        If uid is a duid then the dictionary value will be regarding the latest version.
        
        If uid is a vuid then the dictionary value will be regarding the given version.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param uid: is a dataset (duid)/dataset version (vuid) unique identifiers.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        
        @return: Returns the dataset and/or dataset version information.::
            {
                'duid': duid,
                'dsn': dsn,
                'owner': owner,
                'state': state,
                'vuids': [
                    {'vuid': vuidN, , 'version': N, 'cdate': cdate}
                    ...
                    {'vuid': vuid1, 'version': 1, 'cdate': cdate}
                ]
            }
            or
            {}
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.is_secure = False
        self.params = {'operation': 'queryDatasetByUID', 'uid': uid}
        
        return self.send()


    def queryDatasetByDUIDs (self, duids):
        """
        Returns a list of duids containing all attributes.
        
        RepositoryClient uses a POST HTTP request for this method.
        
        @since: 0.3.0
        
        @param uid: is a dataset (duid)/dataset version (vuid) unique identifiers.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        
        @return: Returns the dataset and/or dataset version information.::
            {'dsn': [versionX, versionY]}
            or
            {}
        """
        
        self.type = HTTP.POST
        self.request = '/ws_repository/rpc'
        self.is_secure = False
        self.params = {'operation': 'queryDatasetByDUIDs', 'duids': duids}
        
        return self.send()


    def queryDatasetByVUIDs (self, vuids):
        """
        Returns the dataset information for the given vuids.
        
        RepositoryClient uses a POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param vuids: is a list of dataset version (vuid) unique identifiers.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        
        @return: Returns the dataset and/or dataset version information.::
            {'dsn': [versionX, versionY]}
        """
        
        self.type = HTTP.POST
        self.request = '/ws_repository/rpc'
        self.is_secure = False
        self.params = {'operation': 'queryDatasetByVUIDs', 'vuids': vuids}
        
        return self.send()


    def resolveName (self, dsn):
        """
        Returns the duid and state for the given dataset name.
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
            - DQUnknownDatasetException is raised,
                in case there is no dataset or dataset version for this duid.
        
        @return: Dictionary with dataset duid and state.
            {'duid': duid, 's': state}
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'resolveName', 'dsn': dsn}
        
        return self.send()


    def resolveVUID (self, vuid):
        """
        Resolves the given vuid into its dataset name and version number.
        THIS METHOD SHOULD BE RESOLVEUID!!!
        
        RepositoryClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param vuid: is the dataset version unique identifier.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset or dataset version with this vuid.
        
        @return: The dataset name and version number.
            {'dsn': dsn, 'version': version}
        """
        
        self.type = HTTP.GET
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'resolveVUID', 'vuid': vuid}
        
        return self.send()


    def searchDatasets (self, what):
        """
        Search for datasets.
        
        @since: 0.3.4
        
        @return: (duid_10, name, state, owner, creationdate, datasettype, version, vuid, versioncreationdate)
        @rtype: tuple
        """
        
        self.type = HTTP.GET
        self.request = '/ws_dq2/rpc'
        self.is_secure = False
        
        self.params = {'operation': 'dataset_search', 'what': what}
        
        return self.send()


    def setMetaDataAttribute (self, dsn, attrname, attrvalue, owner=None, role=None):
        """
        Set the dataset metadata attribute to the given value.
        
        Attributes are always stored as strings (max= 10 characters).
        
        Conversion to other types must be done by the client.
        
        RepositoryClient uses a secure POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param attrname: the metadata attribute to be set ('tier0state', 'tier0nrpartitions', 'tier0type').
        @param attrvalue: the metadata attribute value (maximum 10 characters, the rest will be cut).
        @param owner: <used only by the catalog> the user who requested the operation.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case of an invalid attribute name, invalid or missing arguments.
            - DQSecurityException is raised,
                in case the user has no permissions to set metadata attributes on the dataset.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        
        self.type = HTTP.PUT
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'setMetaDataAttribute', 'dsn': dsn, 'attrname': attrname, 'attrvalue': attrvalue}
        
        self.send()


    def setState (self, dsn, state, owner=None, role=None, ip=None):
        """
        Sets the dataset state to Opened, Closed or Frozen.
        Check dq2.common.DQConstants.DatasetState.
        
        When state == dq2.common.DQConstants.DatasetState.CLOSED,
        the latest dataset version becomes immutable.
        
        To add new content to the dataset, a new dataset version must be added first.
        
        When state == dq2.common.DQConstants.DatasetState.FROZEN,
        the dataset becomes immutable.
        
        No new versions or files may be added to the dataset.
        
        RepositoryClient uses a secure POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param state: is the dataset version state (check dq2.common.DQConstants.DatasetState).
        
        B{Exceptions:}
            - DQClosedDatasetException is raised,
                in case the user is trying to closed an already closed dataset.
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQDatasetClosedException is raised,
                in case the user is trying to closed an already closed dataset.
            - DQDatasetNotClosedException is raised,
                in case the user is trying to open an already opened dataset.
            - DQFrozenDatasetException is raised,
                in case the user is trying to open an already opened dataset.
            - DQInvalidRequestException is raised,
                in case the user is trying to change the dataset to an invalid state.
            - DQOpenedDatasetException is raised,
                in case the user is trying to open an already opened dataset.
            - DQSecurityException is raised,
                in case the given user cannot change the dataset version state.
        """
        
        self.type = HTTP.PUT
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'setState', 'dsn': dsn, 'state': int(state)}
        
        self.send()


    def updateVersion (self, dsn, vuid, owner=None, role=None):
        """
        Finds the duid associated with the given name and
        assign a new version. Version number is automatically incremented by 1.
        
        The new version will be on the OPENED state and previous one
        will be set to CLOSED.
        
        All of the metadata associated to the previous will also
        be copied to the new version.
        
        Note: multithread safe method (racing condition on the version number is
        prevented using database UNIQUE index on duid+version number).
        
        RepositoryClient uses a secure POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param vuid: is the dataset unique identifier for the new version.
        @param owner: parameter is NOT used, it is here just for compatibility with catalog signature.
        
        B{Exceptions:}
            - DQDaoException is raised,
            in case there is a python or database error in the central catalogs.
            
            - DQSecurityException is raised,
            in case the user has no permissions to update the dataset.
        
        @return: Dictionary containing the dataset version information.::
        
            {'version': 1, 'duid': duid}
        """
        
        self.type = HTTP.POST
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'updateVersion', 'dsn': dsn, 'vuid': vuid}
        
        return self.send()


    def trashDataset (self, dsn):
        """
        Clears all dataset, dataset versions and dataset metadata for the given dataset.
        
        @since: 0.3.0
        """
        
        self.type = HTTP.DELETE
        self.request = '/ws_repository/rpc'
        self.params = {'operation': 'trashDataset', 'dsn': dsn}
        self.send()
