"""
Repository client transaction aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: transaction.py,v 1.1.2.2.2.1 2008/06/17 14:30:21 psalgado Exp $
"""

from dq2.common.aspects import wrap_around
from dq2.common.dao.aspects.transaction import start_and_end

from dq2.repository.client.RepositoryClient import RepositoryClient


def wrap_package ():
    """
    Loads the transaction aspect for the repository client.
    
    @since: 0.3.0
    """
    
    wrap_around (RepositoryClient.addDataset, start_and_end)
    
    wrap_around (RepositoryClient.getMetaDataAttribute, start_and_end)
    wrap_around (RepositoryClient.getState, start_and_end)
    
    wrap_around (RepositoryClient.queryDatasetByClosedDate, start_and_end)
    wrap_around (RepositoryClient.queryDatasetByCreationDate, start_and_end)
    wrap_around (RepositoryClient.queryDatasetByFrozenDate, start_and_end)
    wrap_around (RepositoryClient.queryDatasetByMetaData, start_and_end)
    wrap_around (RepositoryClient.queryDatasetByName, start_and_end)
    wrap_around (RepositoryClient.queryDatasetByUID, start_and_end)
    wrap_around (RepositoryClient.queryDatasetByDUIDs, start_and_end)
    
    wrap_around (RepositoryClient.resolveName, start_and_end)
    wrap_around (RepositoryClient.resolveVUID, start_and_end)
    
    wrap_around (RepositoryClient.setMetaDataAttribute, start_and_end)
    wrap_around (RepositoryClient.setState, start_and_end)
    
    wrap_around (RepositoryClient.trashDataset, start_and_end)
    
    wrap_around (RepositoryClient.updateVersion, start_and_end)
