"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2.0
@version: $Id: DQRepositoryClientTestCase.py,v 1.4.2.3 2007/11/12 16:02:02 psalgado Exp $
"""

import dq2.common.client.x509

from dq2.common.DQConstants import TestCaseData

from dq2.repository.client.RepositoryClient import RepositoryClient

from dq2.repository.testcase.DQRepositoryTestCase import DQRepositoryTestCase


class DQRepositoryClientTestCase (DQRepositoryTestCase):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.4.2.3 $
    """


    def __init__ (self, name, instance):
        """
        Constructs an instance of DQRepositoryClientTestCase.
        
        @since: 0.2.1
        
        @param name: testcase name.
        @type name: str
        """
        
        TestCaseData.OWNERS[0] = dq2.common.client.x509.get_dn()
        
        DQRepositoryTestCase.__init__(self, name, instance)


    def testBug19308 (self):
        """
        @since: 0.3.0
        
        1. testBug19308
        """
        
        # 1. testBug19308
        message = '1. testBug19308'
        sent_dn = TestCaseData.OWNERS[0] + '/CN=proxy/CN=proxy'
        
        self.rc.addDataset(TestCaseData.DSNS[0], TestCaseData.DUIDS[0], TestCaseData.VUIDS[0], sent_dn)
        
        result = self.rc.getMetaDataAttribute(TestCaseData.DSNS[0], ['owner'])
        expected = {'owner': TestCaseData.OWNERS[0]}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


# PUBLIC methods


if __name__ == '__main__':
    """
    Runs all tests in DQRepositoryCatalogTestCase.
    
    @since: 0.2.0
    """
    import sys
    
    test = DQRepositoryClientTestCase.main(
        'dq2.repository.client.testcase', 'DQRepositoryClientTestCase',
        sys.argv[1:]
    )
