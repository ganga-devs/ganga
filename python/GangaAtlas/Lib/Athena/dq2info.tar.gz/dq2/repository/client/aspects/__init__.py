"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/09/24 11:17:01 psalgado Exp $
"""