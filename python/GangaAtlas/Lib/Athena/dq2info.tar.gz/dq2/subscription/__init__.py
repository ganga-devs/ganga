"""
@author: 
@contact:
@since: 0.2
@version: $Id: __init__.py,v 1.1 2008/05/30 13:00:23 psalgado Exp $
"""

API_030 = '0_3_0'