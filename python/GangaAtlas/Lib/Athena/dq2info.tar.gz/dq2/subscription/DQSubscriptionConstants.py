"""
"8.2 State Guidelines
(...)
168. State Names Should Be Simple but Descriptive
(...)
Ideally, state names should also be written in present tense,
although names such as Proposed (past tense) are better than
Is Proposed (present tense).
", The Elements of UML Style - Scott W. Ambler
"""


class CallbackType:
    """
    (since 0.2.11)
    """
    DATASET_COMPLETE_EVENT       = 'DATASET_COMPLETE_EVENT'
    DATASET_BROKEN_EVENT         = 'DATASET_BROKEN_EVENT'    
    FILE_DONE_EVENT              = 'FILE_DONE_EVENT'
    FILES_ON_SITE_EVENT          = 'FILES_ON_SITE_EVENT'
    FILES_IN_DATASET_EVENT       = 'FILES_IN_DATASET_EVENT'
    SUBSCRIPTION_QUEUED_EVENT    = 'SUBSCRIPTION_QUEUED_EVENT'
    SUBSCRIPTION_CANCELLED_EVENT = 'SUBSCRIPTION_CANCELLED_EVENT'
    SUBSCRIPTION_IGNORED_EVENT   = 'SUBSCRIPTION_IGNORED_EVENT'
    FILES_CANCELLED_EVENT        = 'FILES_CANCELLED_EVENT'
    FILES_TRANSFER_EVENT         = 'FILES_TRANSFER_EVENT'
    ERROR_EVENT                  = 'ERROR_EVENT'
    
    __ALL__ = [DATASET_COMPLETE_EVENT, DATASET_BROKEN_EVENT,
               FILE_DONE_EVENT, FILES_ON_SITE_EVENT, FILES_IN_DATASET_EVENT,
               FILES_CANCELLED_EVENT, FILES_TRANSFER_EVENT,               
               SUBSCRIPTION_QUEUED_EVENT, SUBSCRIPTION_CANCELLED_EVENT, SUBSCRIPTION_IGNORED_EVENT,               
               ERROR_EVENT]


class SourcesPolicy:
    """
    @since: 0.2.0
    """
    ALL_SOURCES        = 000001
    KNOWN_SOURCES      = 000010
    CLOSE_SOURCES      = 000100
    COMPLETE_SOURCES   = 001000
    INCOMPLETE_SOURCES = 010000
    
    VALUES = [ALL_SOURCES, KNOWN_SOURCES, CLOSE_SOURCES, COMPLETE_SOURCES, INCOMPLETE_SOURCES]


class SourceResolverPolicy:
    """
    (since 0.2.2)
    """
    LRC_LOOKUP = 0
    RELATIVE_SURL = 1


class SubscriptionArchivedState:
    """
    
    @since: 0.2.0
    """
    __ANY__ = None
    ARCHIVE = 1
    UNARCHIVE = 0
    
    STATES = [UNARCHIVE, ARCHIVE]


