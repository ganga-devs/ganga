"""
DQ2 subscription catalog validation methods.

(since 0.2.2)
"""


from dq2.common.DQException import DQInvalidRequestException

from dq2.common.validator.DQValidator import *

from dq2.info.TiersOfATLASValidator import is_list_of_sources

from dq2.subscription.DQSubscriptionConstants import SourcesPolicy, SubscriptionArchivedState


def is_subscription_sources (args):
    """
    Tests if the given policy is a valid subscription sources.
    
    @since: 0.3.0
    
    @param args: is the list of arguments to be tested.
    
    B{Exceptions}
        - DQInvalidRequestException is raised,
            in case the policy is not a integer or
            if it is invalid policy value.
    """
    
    for arg in args:
        is_list_of_sources(arg.keys())
        is_dictionary(arg.values())


def is_subscription_sources_policy (args):
    """
    Tests if the given policy is a valid subscription policy (dq2.common.constants.SourcesPolicy).
    
    (since 0.2.1)
    
    @param args: is the list of arguments to be tested.
    
    B{Exceptions}
        - DQInvalidRequestException is raised,
            in case the policy is not a integer or
            if it is invalid policy value.
    """
    
    for arg in args:
        is_integer([arg])
        
        if arg < 1:
            err_msg = 'Parameter value [%s] is not a valid subscription source policy!' % (arg)
            raise DQInvalidRequestException(err_msg)


def is_subscription_state (args):
    """
    Tests if the given state is a valid subscription state (dq2.common.constants.SubscriptionArchivedState).
    
    (since 0.2.1)
    
    @param args: is the list of arguments to be tested.
    
    B{Exceptions}
        - DQInvalidRequestException is raised,
            in case the state is not a integer or
            if it is invalid state.
    """
    
    for arg in args:
        is_integer([arg])
    
        if not arg in SubscriptionArchivedState.STATES:
            err_msg = 'Parameter value [%s] is not a valid subscription state!' % (arg)
            raise DQInvalidRequestException(err_msg)