"""
Subscription validation aspect.

@since: 0.3.0

$Id: validation.py,v 1.2.2.5 2009/06/25 14:45:50 vgaronne Exp $
"""

from dq2.common.constants import *
from dq2.subscription.DQSubscriptionConstants import SourcesPolicy, SubscriptionArchivedState
from dq2.common.validator.DQValidator import *
from dq2.info.TiersOfATLASValidator import *
from dq2.subscription.DQSubscriptionValidator import *


def addDatasetSubscription (self, uid, location, archived=SubscriptionArchivedState.UNARCHIVE, callbacks={}, sources={}, sources_policy=SourcesPolicy.ALL_SOURCES, wait_for_sources=0, destination=None, query_more_sources=0, sshare=None, owner=None, group=None, activity=None):
    """
    @since: 0.3.0
    """
    
    is_uid([uid])
    is_destination(location)
    if destination is not None:
        is_string([destination])
    is_subscription_sources_policy([sources_policy])
    is_integer([wait_for_sources])
    is_dictionary([sources, callbacks])
    
    is_subscription_sources([sources])
    
    is_subscription_state([archived])
    
    # TODO: validate share
    
    if owner is not None: is_owner([owner])
    
    return self.__proceed(uid, location, archived=archived, callbacks=callbacks, sources=sources, sources_policy=sources_policy, wait_for_sources=wait_for_sources, destination=destination, query_more_sources=query_more_sources, sshare=sshare, owner=owner, group=group, activity=activity)


def deleteDatasetSubscription (self, uid, location):
    """
    @since: 0.3.0
    """
    is_uid([uid])
    is_source(location)
    
    return self.__proceed(uid, location)


def deleteDatasetSubscriptions (self, uids):
    """
    @since: 0.3.0
    """
    is_uid(uids)
    
    return self.__proceed(uids)


def getInfo (self, uid, location):
    """
    @since: 0.3.0
    """
    is_uid([uid])
    is_destination(location)
    
    return self.__proceed(uid, location)


def querySubscriptions (self, uids):
    """
    @since: 0.3.0
    """
    is_uid(uids)
    
    return self.__proceed(uids)


def querySubscriptionsInSite (self, location):
    """
    @since: 0.3.0
    """
    
    is_destination(location)
    
    return self.__proceed(location)


def reset (self, uid, location):
    """
    @since: 0.3.0
    """
    
    is_uid([uid])
    is_source(location)
    
    return self.__proceed(uid, location)


def setRequestState (self, duid, location, requestType, requestState, msg=''):
    """
    @since: 0.3.0
    """
    
    is_uid([duid])
    is_source(location)
    
    return self.__proceed(duid, location, requestType, requestState, msg)


def rest (self, creationdatemin=None, creationdatemax=None, modifieddatemin=None, modifieddatemax=None, site=None, vuid=None):
    """
    @since: 0.3.0
    """
    
    #if creationdatemin is None:
    #if creationdatemax is None:
    
    #if modifieddatemin is None:
    #if modifieddatemax is None:
    
    if site is None:
        is_destination([site])
    
    if vuid is None:
        is_uid([vuid])

