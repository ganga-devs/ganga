"""
Factory to create subscription client instances.

@author: Pedro Salgado
@contact: pedro.salgado.cern.ch
@since: 0.4.0
@version: $Id: SubscriptionClientFactory.py,v 1.1.2.1.2.1 2008/06/17 20:29:20 psalgado Exp $
"""

from dq2.common.Config import Config
from dq2.common import Configurable
from dq2.common.DQException import DQConfigurationException
from dq2.common.constants import API_030

from dq2.subscription.client import PACKAGE


LATEST_API = API_030


class SubscriptionClientFactory (Configurable):
    """
    Factory to create subscription client instances.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.4.0
    @version: $Id: SubscriptionClientFactory.py,v 1.1.2.1.2.1 2008/06/17 20:29:20 psalgado Exp $
    """


    insecure = None
    secure = None
    timeout = 9999


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 0.4.0
        """
        
        SubscriptionClientFactory.insecure = Config().getConfig(PACKAGE).get(PACKAGE, 'insecure')
        SubscriptionClientFactory.secure = Config().getConfig(PACKAGE).get(PACKAGE, 'secure')
        try:
            SubscriptionClientFactory.timeout = int(Config().getConfig(PACKAGE).get(PACKAGE, 'timeout'))
        except:
            SubscriptionClientFactory.timeout = 9999

    __configure__ = staticmethod(__configure__)


    def create (api=LATEST_API, certificate=None, ca_path=None):
        """
        Creates a subscription client instance.
        
        @since: 0.4.0
        
        @param certificate: the user's GRID certificate.
        @type certificate: ?
        @param ca_path: the Certificate Authority path.
        @type ca_path: str
        @param api: the client API to use.
        @type api: str
        """
        
        
        if api == API_030:
            from dq2.subscription.client.SubscriptionClient import SubscriptionClient
            return SubscriptionClient(url=SubscriptionClientFactory.insecure, urlsec=SubscriptionClientFactory.secure, certificate=certificate, ca_path=ca_path, timeout=SubscriptionClientFactory.timeout)
        
        elif not api < LATEST_API:
            """for some reason the subscription API is bigger than the client"""
            api = LATEST_API
        
        else:
            err_msg = "Configuration error: inexistent '%s' api for the subscription client. Check the configuration file." % (api)
            raise DQConfigurationException(err_msg)

    create = staticmethod(create)