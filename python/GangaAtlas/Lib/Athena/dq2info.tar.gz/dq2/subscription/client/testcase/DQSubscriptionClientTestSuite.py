"""
Subscription client test suite.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version $Id: DQSubscriptionClientTestSuite.py,v 1.1.2.2.2.1 2008/06/17 20:29:20 psalgado Exp $
"""

from dq2.common.client.testcase.DQClientTestSuite import DQClientTestSuite
from dq2.common.constants import API_030

from dq2.subscription.client.SubscriptionClientFactory import SubscriptionClientFactory
from dq2.subscription.testcase.DQSubscriptionTestCase import DQSubscriptionTestCase
from dq2.subscription.testcase.DQGetInfoTestCase import DQGetInfoTestCase


class DQSubscriptionClientTestSuite (DQClientTestSuite):
    """
    @since: 0.3.0
    """


    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQClientTestSuite.__init__(
            self,
            SubscriptionClientFactory(),
            API_030,
            [
                DQGetInfoTestCase,
                DQSubscriptionTestCase
            ]
        )


if __name__ == '__main__':
    """
    Runs all tests in DQSubscriptionClientTestSuite.
    
    @since: 0.3.0
    """
    import unittest
    suite = DQSubscriptionClientTestSuite()
    unittest.TextTestRunner(verbosity=2).run(suite)