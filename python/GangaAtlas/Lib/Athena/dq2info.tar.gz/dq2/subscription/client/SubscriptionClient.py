"""
Client to the dataset subscription central catalog.

@since: 0.1.4
@version: $Id: SubscriptionClient.py,v 1.9.2.8.2.6 2009/06/25 14:45:35 vgaronne Exp $
"""

import dq2.common.validator.DQValidator
import getopt
import os
import string
import sys


from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.common.DQConstants import HTTP
from dq2.common.DQException import DQException, DQInvalidRequestException, DQFatalError
from dq2.common.client.DQClient import DQClient
from dq2.common.client.x509 import get_ca_path
from dq2.common.client.x509 import get_x509
from dq2.common.constants import API_030

from dq2.subscription.DQSubscriptionConstants import CallbackType, SourcesPolicy, SourceResolverPolicy, SubscriptionArchivedState
from dq2.subscription.client import PACKAGE


class SubscriptionClient (DQClient, Configurable):
    """
    Class to make requests to the dataset subscription central catalog.
    
    @since: 0.2.0
    """


    insecure = None
    secure = None
    timeout = None


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, timeout=None):
        """
        Constructs a SubscriptionClient instance.
        
        @since: 0.2.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @param urlsec: is the secure URL of the host to be contacted.
        @param certificate: is the proxy certificate.
        @param ca_path: is the location of the Certification Authority certificates.
        @param timeout : the client timeout (in seconds). (since 0.3)
        """        
        DQClient.__init__(self, url, urlsec, certificate, ca_path, api=API_030, timeout=timeout)


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 0.3.0
        
        @deprecated: this method will be deprecated in 0.4 with the introduction of a client factory.
        """
        SubscriptionClient.insecure = Config().getConfig(PACKAGE).get(PACKAGE, 'insecure')
        SubscriptionClient.secure = Config().getConfig(PACKAGE).get(PACKAGE, 'secure')
        try:
            SubscriptionClient.timeout = int(Config().getConfig(PACKAGE).get(PACKAGE, 'timeout'))
        except:
            SubscriptionClient.timeout = 9999


    __configure__ = staticmethod(__configure__)


# PUBLIC methods


    def addDatasetSubscription (self, uid, location, archived=SubscriptionArchivedState.UNARCHIVE, callbacks={}, sources={}, sources_policy=SourcesPolicy.ALL_SOURCES, wait_for_sources=0, destination=None, query_more_sources=0, sshare=None, owner=None, group=None, activity=None):
        """
        Add a new dataset/dataset version subscription at the given dq2.location.
        
        @since: 0.2.0
        
        @param uid: is the dataset or dataset version unique identifier.
        @param location: is the subscriber dq2.location.
        @param owner: is the dataset owner.
        @param archived: is the subscription state (dq2.common.DQConstants.SubscriptionArchivedState).
            is a bit indicating the archival bit for the dq2.subscription.
            Archival subscriptions are never deleted by the cache turnover
            service, while non-archival data may be deleted if the destination
            storage becomes full at some point. Possible values are
            SubscriptionArchivedState.ARCHIVE or SubscriptionArchivedState.UNARCHIVE.
        @param callbacks: is a dictionary which specifies, per subscription callback
            state, the list of HTTP URLs that should be triggered when the event
            occurs. e.g.::
                callbacks = {
                    CallbackType['FETCHER_VUID_COMPLETE']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_SKIP_VUID']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_FILE_NOT_QUEUED']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_FILES_QUEUED']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FETCHER_UNKNOWN_DATASET']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FILE_PROPERTY_SET']:
                        ['http://localhost:7777/monitor'],
                    CallbackType['FILE_DONE']:
                        ['http://localhost:7777/monitor']
                }
        @param sources: is a dictionary indicating known sources for the
            subscription and the strategy to look them up: either by doing a LRC
            lookup at the source, or by directly specifying a URL, e.g.:
                sources = {
                    'CERN'  : { 'policy': SourceResolverPolicy.LRC_LOOKUP },
                    'RAL'   : { 'policy' : SourceResolverPolicy.RELATIVE_SURL,
                    'rsurl' : 'srm://ral.uk/some/data/here/' }
                }
        @param sources_policy: may be one of dq2.common.DQConstants.SourcesPolicy.(ALL_SOURCES | KNOWN_SOURCES | CLOSE_SOURCES | COMPLETE_SOURCES |
INCOMPLETE_SOURCES).
            This triggers the subscription services to change the strategy used
            for finding source replicas.
            KNOWN_SOURCES is required if 'sources' is specified as part of the dq2.subscription.
            It is possible to specify cumulative strategies: e.g.
            source_policy=SourcesPolicy.KNOWN_SOURCES | SourcesPolicy.COMPLETE_SOURCES
            will look for sources in the sites specified as part of the 'sources' field
            in the subscription, as well as in all sites known to have complete copies of the dataset.
        @param wait_for_sources: is a bit (True/False) indicating whether the subscription services
            should keep retrying to fulfill the subscription even if the sources files are missing.
            If True, subscription will not go to HOLD states even if sources are missing.
        @param destination: is a relative SURL where the destination files should be
            placed within the destination storage (e.g. '/my/path/').
        
        SubscriptionClient uses a secure POST HTTP request for this method.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
            - DQSubscriptionExistsException is raised,
                in case there is a subscription for this uid-dq2.location.
        """
        
        self.type = HTTP.PUT
        self.request = '/ws_subscription/rpc'
        if activity:
            self.params = {
                'operation': 'addDatasetSubscription',
                'uid': uid,
                'location': location,
                'archived': archived,
                'callbacks': callbacks,
                'sources': sources,
                'sources_policy': sources_policy,
                'wait_for_sources': wait_for_sources,
                'query_more_sources': query_more_sources,
                'destination': destination,
                'sshare': sshare,
                'group': group,
                'activity': activity
            }
        else:
            self.params = {
                'operation': 'addDatasetSubscription',
                'uid': uid,
                'location': location,
                'archived': archived,
                'callbacks': callbacks,
                'sources': sources,
                'sources_policy': sources_policy,
                'wait_for_sources': wait_for_sources,
                'query_more_sources': query_more_sources,
                'destination': destination,
                'sshare': sshare,
                'group': group
            }            
        self.send()


    def deleteDatasetSubscription (self, uid, location):
        """
        Deletes the dataset/dataset version subscription subscription at the given dq2.location.
        
        SubscriptionClient uses a secure GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param uid: is the dataset or dataset version unique identifier.
        @param location: the dataset version location to be copied to.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        """
        
        self.type = HTTP.DELETE
        self.request = '/ws_subscription/rpc'
        self.params = {'operation': 'deleteDatasetSubscription', 'uid': uid, 'location': location}
        self.send()


    def deleteDatasetSubscriptions (self, uids):
        """
        Deletes the given dataset/dataset version subscriptions from all locations.
        
        @param uids: is a list of dataset or dataset version unique identifiers.
        
        SubscriptionClient uses a secure POST HTTP request for this method.
        
        (since 0.2.1)
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        """
        
        self.type = HTTP.POST
        self.request = '/ws_subscription/rpc'
        self.params = {'operation': 'deleteDatasetSubscriptions', 'uids': uids}
        self.send()


    def getInfo (self, uid, location):
        """
        Retrieves all the information related to a dataset dq2.subscription.
        
        SubscriptionClient uses a GET HTTP request for this method.
        
        (since 0.2.11)
        
        @param uid: is a dataset version unique identifiers.
        @param location: is the dataset subscription location that were the uids were processed.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        
        @return: tuple containing the dataset subscription information is returned.::
            (uid, owner, location, destination, creationdate, modifieddate, callbacks, archived, sources_policy, wait_for_sources, sources, query_more_sources, share)
        """
        
        self.type = HTTP.GET
        self.request = '/ws_subscription/rpc'
        self.params = {'operation': 'getInfo', 'uid': uid, 'location': location}
        
        return self.send()


    def querySubscriptions (self, uids):
        """
        Return a list of dataset subscriptions for the given uid.
        
        @since: 0.2.0
        
        @param uids: is list of dataset or dataset version unique identifiers.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        
        @return: Dictionary containing the subscriptions information per dq2.location.::
            {
                'location': {
                    'sources': [],
                    'archival': True,
                    'waitForSources': True,
                    'sourcesPolicy': SourcesPolicy.ALL_SOURCES,
                    'callbacks': ['http://callback/1'],
                    'creationdate': creationdate,
                    'owner': owner,
                    'destination': destination,
                    'share': ...
                }
                (...)
                'locationN': {
                    'sources': [],
                    'archival': True,
                    'waitForSources': True,
                    'sourcesPolicy': SourcesPolicy.ALL_SOURCES,
                    'callbacks': ['http://callback/1'],
                    'creationdate': creationdate,
                    'owner': owner,
                    'destination': destination,
                    'share': ...
                }
            }
        """
        
        self.type = HTTP.POST
        self.is_secure = False
        self.request = '/ws_subscription/rpc'
        self.params = {'operation': 'querySubscriptions', 'uids': uids}
        
        return self.send()


    def querySubscriptionsInSite (self, location):
        """
        Return a list of dataset subscriptions at the given dq2.location.
        
        @since: 0.2.0
        
        @param location: is the subscription dq2.location.
        @param query: is a filter criteria to be appended to the SQL where clause.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        
        @return: List containing the subscribed datasets or dataset versions.:: 
            {
                'uid': {
                    'timestamp': ..., <= last modified date
                    'sources': ...,
                    'archival': ...,
                    'waitForSources': ...,
                    'sourcesPolicy': ...,
                    'callbacks': ...,
                    'owner': owner,
                    'destination': ...,
                    'creationdate': <= the dataset subscription creation date,
                    'share': ...
                }
            }
        """
        
        self.type = HTTP.GET
        self.request = '/ws_subscription/rpc'
        self.params = {'operation': 'querySubscriptionsInSite', 'location': location}
        
        return self.send()


    def reset (self, uid, location):
        """
        Resets the dataset/dataset version subscription subscription at the given dq2.location.
        
        SubscriptionClient uses a secure POST HTTP request for this method.
        
        @since: 0.3.0
        
        @param uid: is the dataset or dataset version unique identifier.
        @param location: the dataset version location to be copied to.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        """
        
        self.type = HTTP.POST
        self.request = '/ws_subscription/rpc'
        self.params = {'operation': 'reset', 'uid': uid, 'location': location}
        self.send()

    def setRequestState (self, duid, location, requestType, requestState, msg=''):
        """
        Update the request state  at the given dq2.location.
        
        SubscriptionClient uses a secure POST HTTP request for this method.
        
        @since: 0.3.0
        
        @param uid: is the dataset or dataset version unique identifier.
        @param location: the dataset version location to be copied to.
        
        @param requestType: is the request type.
        @param requestState: is the request state.

        """

        self.type = HTTP.POST
        self.request = '/ws_subscription/rpc'
        self.is_secure = True
        
        self.params = {'operation':     'setRequestState', 
                       'location':      location, 
                       'duid':          duid, 
                       'requestType':   requestType,
                       'requestState':  requestState,
                       'msg':           msg}
        return self.send()        