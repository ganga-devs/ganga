"""
Load aspects for dq2.subscription.client package.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.3.2.2 2007/09/24 10:22:52 psalgado Exp $

@warning: order is important!
"""

PACKAGE = 'dq2-subscription-client'


from dq2.subscription.client.aspects.transaction import wrap_package
wrap_package()

from dq2.subscription.client.aspects.validation import wrap_package
wrap_package()