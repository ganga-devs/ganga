"""


@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.2
@version: $Id: TiersOfATLASException.py,v 1.1.2.1 2007/10/22 09:52:03 psalgado Exp $
"""

from dq2.common.DQException import DQException


class TiersOfATLASException (DQException):
    """
    DQException class for the cases where ToA file is corrupted, missing, or failed to download
    
    @since: 0.2.10
    """


    def __init__(self, desc):
        """
        
        @since: 0.2.0
        """
        self.desc = desc
        DQException.__init__(self)    


    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        return "Tiers of ATLAS exception [%s]" % self.desc