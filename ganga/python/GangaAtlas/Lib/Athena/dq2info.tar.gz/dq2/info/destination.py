"""
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.3
@version: $Id: destination.py,v 1.1.2.3 2007/11/17 16:07:34 mbranco Exp $
"""

import time


def construct_surl(dsn, filename):
    """
    Defines relative SURL for new replica. This method
    contains DQ2 convention.
    
    For SC4-Tier0 data a special convention is used
      /sc4tier0/<month>/<day>/<filename>

    The convention relies on the dataset name containing 5 or more
    fields separated by dots. For these datasets the directory
    structure is

    /project/datasettype/datasetname/filename

    where
    project is the first field
    datasettype is the fifth field
    datasetname is the DQ2 dataset name whose subscription caused this
        file to be copied
    filename is the filename

    Example:
      construct_surl('csc11.005009.J0_pythia_jetjet.digit.RDO.v11004203',
                     'csc11.005009.J0_pythia_jetjet.digit.RDO.v11004203._009911.pool.root')

    returns
      /csc11/RDO/csc11.005009.J0_pythia_jetjet.digit.RDO.v11004203/csc11.005009.J0_pythia_jetjet.digit.RDO.v11004203._009911.pool.root

    Dataset names with between 1 and 4 dots inclusive will go to

    /project/datasetname/filename

    where these have the same meaning as above.
    
    User datasets go into a different area. The structure for user
    datasets is
    
    /user/username/datasetname/filename
    
    where
    user is the string 'user'
    username is the user distinguished name as is present on the dataset name
    datasetname is the DQ2 dataset name whose subscription caused this
        file to be copied
    filename is the filename

    Example:
      construct_surl('user.JoeUser.datasettest1', 'joetestfile.1')

    returns
      /user/JoeUser/user.JoeUser.datasettest1/joetestfile.1

    A dataset name with no dots goes to the other/ directory

    /other/datasetname/filename

    Example:
      construct_surl('mydataset1', 'file1')

    returns
      /other/mydataset1/file1
    
    @return: relative SURL for new replica. 
    @rtype: str
    """
    
    # Tier-0 test data convention
    if dsn[:3] == 'T0.':
        now = time.gmtime()
        return '/sc4tier0/%02d/%02d/%s' % (now[1], now[2], filename)

    # check how many dots in dsn
    dots = dsn.split('.')

    # if 'correct' convention for projects with 5 fields
    if len(dots) > 4 and dots[0] != 'user':
        project = dots[0]
        type = dots[4]
        return '/%s/%s/%s/%s' % (project, type, dsn, filename)
    
    # if 'correct' convention for projects with more than 1 field
    elif len(dots) > 1 and dots[0] != 'user':
        project = dots[0]
        return '/%s/%s/%s' % (project, dsn, filename)

    # if 'correct' convention for users
    elif len(dots) > 2 and dots[0] == 'user':
        name = dots[1]
        return '/user/%s/%s/%s' % (name, dsn, filename)
    
    # finally, no dots
    return '/other/%s/%s' % (dsn, filename)
