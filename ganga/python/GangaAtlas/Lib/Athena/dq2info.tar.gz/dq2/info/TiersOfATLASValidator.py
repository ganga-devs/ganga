"""
DQ2 common methods.

@since: 0.2.2
"""


import dq2.info.TiersOfATLAS

from dq2.common.DQException import DQInvalidRequestException
from dq2.common.validator.DQValidator import *
from dq2.common.DQConstants import TestCaseData


SITE_MAXLENGTH = 50


def is_destination (site):
    """
    Tests if the given site is a valid destination.
    
    @since: 0.2.9
    
    site is site name.
    
    DQInvalidRequestException is raised,
    in case site is not a string,
    exceeds the maximum length (dq2.common.DQConstants.SITE_MAXLENGTH) or
    ... .
    """
    is_string([site])
    
    if len(site) == 0:
        err_msg = 'Parameter value [%s] length is zero!' % (site)
        raise DQInvalidRequestException(err_msg)
    
    if len(site) > SITE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u)!' % (site, SITE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    if site.upper()[:4] == 'MOCK':
        return
    
    if not site.upper() in dq2.info.TiersOfATLAS.getAllDestinationSites():
        err_msg = 'Parameter value [%s] is not a Tiers of Atlas Destination!' % (site.upper())
        raise DQInvalidRequestException(err_msg)


def is_list_of_destinations (sites):
    """
    Tests if the given argument is a list containing valid destinations.
    
    @since: 0.2.10
    
    sites is a list of sites.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid site.
    """
    is_list([sites])
    for eachSite in sites:
        is_destination(eachSite)


def is_list_of_sites (sites):
    """
    Tests if the given argument is a list containing valid sites.
    
    @since: 0.2.9
    
    sites is a list of sites.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid site.
    """
    is_list([sites])
    for eachSite in sites:
        is_site(eachSite)


def is_list_of_sources (sites):
    """
    Tests if the given argument is a list containing valid sources.
    
    @since: 0.2.9
    
    sites is a list of sites.
    
    DQInvalidRequestException is raised,
    in case the argument is not a list or
    if one the elements is not a valid site.
    """
    is_list([sites])
    for eachSite in sites:
        is_source(eachSite)


def is_site (site):
    """
    Tests if the given site is a valid site.
    
    @since: 0.2.9
    
    site is site name.
    
    DQInvalidRequestException is raised,
    in case site is not a string,
    exceeds the maximum length (dq2.common.DQConstants.SITE_MAXLENGTH) or
    ... .
    """
    is_string([site])
    
    if len(site) == 0:
        err_msg = 'Parameter value [%s] length is zero!' % (site)
        raise DQInvalidRequestException(err_msg)
    
    if len(site) > SITE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u)!' % (site, SITE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)

    if site.upper()[:4] == 'MOCK':
        return
    
    sites = dq2.info.TiersOfATLAS.getAllSources() + dq2.info.TiersOfATLAS.getAllDestinationSites()
    if not site.upper() in sites:
        err_msg = 'Parameter value [%s] is not a Tiers of Atlas Source!' % (site.upper())
        raise DQInvalidRequestException(err_msg)


def is_source (site):
    """
    Tests if the given site is a valid source.
    
    @since: 0.2.9
    
    site is site name.
    
    DQInvalidRequestException is raised,
    in case site is not a string,
    exceeds the maximum length (dq2.common.DQConstants.SITE_MAXLENGTH) or
    ... .
    """
    is_string([site])
    
    if len(site) == 0:
        err_msg = 'Parameter value [%s] length is zero!' % (site)
        raise DQInvalidRequestException(err_msg)
    
    if len(site) > SITE_MAXLENGTH:
        err_msg = 'Parameter value [%s] exceeds the maximum length (%u)!' % (site, SITE_MAXLENGTH)
        raise DQInvalidRequestException(err_msg)
    
    if site.upper()[:4] == 'MOCK':
        return
    
    if not site.upper() in dq2.info.TiersOfATLAS.getAllSources():
        err_msg = 'Parameter value [%s] is not in Tiers of Atlas!' % (site.upper())
        raise DQInvalidRequestException(err_msg)
