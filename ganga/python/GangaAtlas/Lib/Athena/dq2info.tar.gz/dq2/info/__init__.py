"""
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/10/19 13:20:59 psalgado Exp $
"""


__version__ = '$Name: dq2-info-0-3-1_rc16 $'