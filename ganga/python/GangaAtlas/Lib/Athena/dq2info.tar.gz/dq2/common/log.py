"""
Contains the dashboard specific logging definitions.

In particular, it takes care of the logging configuration loading, looking in
the filesystem with the last one found having priority (overwriting previous 
values):
1) /opt/dq2/config/logging.cfg
2) $HOME/.dq2/config/logging.cfg
3) $DQ2_HOME/config/logging.cfg

@author: Ricardo Rocha
@contact: ricardo.rocha@cern.ch
@since: 0.3
@version: $Id: log.py,v 1.3.2.1 2007/09/28 11:27:07 psalgado Exp $
"""

try:
    import ConfigParser
    import logging
    import logging.config
    
    from dq2.common.Config import Config
    
    """
    This has to be done before importing the classes where the logger objects
    are class members.
    """
    try:
        logging.config.fileConfig(
            Config().getConfig(None).get('dq2', 'logging.config.file')
        )
    except ConfigParser.NoSectionError, e:
        pass
    
    _logger = logging.getLogger('dq2.common.log')
except:
    pass


def getLogger (logger):
    """
    @since: 0.3
    
    @param logger: .
    @type logger: 
    
    @return: logger.
    @rtype: object?
    """
    try:
        loggerObj = logging.getLogger(logger)
        if not loggerObj:
            _logger.error("Failed to get logger '%s'" % logger)
        return loggerObj
    except:
        # python 2.2 uses fake logging
        class FakeLogger:
            def info(self, *args):
                pass
            def debug(self, *args):
                pass
            def warning(self, *args):
                pass
            warn = warning
            def error(self, *args):
                pass
            def exception(self, *args):
                pass
            def critical(self, *args):
                pass
            def log(self, *args):
                pass
        return FakeLogger()