"""

@author: 
@contact: @
@since: 0.3
@version: $Id: DQLog.py,v 1.6.2.4 2007/11/20 16:20:35 psalgado Exp $
"""


import sys


from dq2.common import log as logging


class DQLog:
    """
    A generic class for output logs.
    
    @since: 0.3.0
    @version: $Revision: 1.6.2.4 $
    """


    def __init__ (self, instance):
        """
        Constructs a DQLog instance.
        
        @since: 0.3.0
        @param instance: .
        @type instance: 
        """
        self._logger = logging.getLogger(instance)


# PUBLIC methods


    def debug (self, message, tuid='', component=''):
        """
        Write a debug level message.
        
        @since: 0.3.0
        
        @param message: .
        @type message: 
        @param tuid: .
        @type tuid: 
        @param component: .
        @type component: 
        """
        self._logger.debug('[%s] [%s] %s' % (tuid, component, message))


    def error (self, message, tuid='', component=''):
        """
        Write an error message.
        
        @since: 0.3.0
        
        @param message: .
        @type message: 
        @param tuid: .
        @type tuid: 
        @param component: .
        @type component:
        """
        self._logger.error('[%s] [%s] %s' % (tuid, component, message.replace('\n', ' ')))


    def info (self, message, tuid='', component=''):
        """
        Write an info level message.
        
        @since: 0.3.0
        
        @param message: .
        @type message: 
        @param tuid: .
        @type tuid: 
        @param component: .
        @type component:
        """
        self._logger.info('[%s] [%s] %s' % (tuid, component, message))


    def performance (self, message, tuid='', component=''):
        """
        Write a performance message.
        
        @since: 0.3.0
        
        @param message: .
        @type message: 
        @param tuid: .
        @type tuid: 
        @param component: .
        @type component:
        """
        self._logger.info('PERFORMANCE [%s] [%s] %s' % (tuid, component, message))


    def trace (self, message, tuid='', component=''):
        """
        Write a trace message.
        
        @since: 0.3.0
        
        @param message: .
        @type message: 
        @param tuid: .
        @type tuid: 
        @param component: .
        @type component:
        """
        self._logger.debug('TRACE [%s] [%s] %s' % (tuid, component, message))