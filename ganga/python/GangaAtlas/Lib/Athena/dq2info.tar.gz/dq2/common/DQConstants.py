"""
"8.2 State Guidelines
(...)
168. State Names Should Be Simple but Descriptive
(...)
Ideally, state names should also be written in present tense,
although names such as Proposed (past tense) are better than
Is Proposed (present tense).
", The Elements of UML Style - Scott W. Ambler

@var tag: the DQ2 tag.
@type tag: str
@deprecated: the tag variable has been copied to dq2.common.__version__.
"""


tag = '$Name: dq2-common-0-3-1_rc24 $'


class DatasetState:
    """
    Class to reference dataset states.
    
    @since: 0.2.0
    @version: $Revision: 1.12.2.6 $
    
    @cvar CLOSED: constant for the dataset 'open' state.
    @type CLOSED: int
    @cvar FROZEN: constant for the dataset 'open' state.
    @type FROZEN: int
    @cvar DELETED: constant for the dataset 'open' state.
    @type DELETED: int
    @cvar OPEN: the constant for the dataset 'open' state.
    @type OPEN: int
    """
    CLOSED = 1
    FROZEN = 2
    DELETED = 3
    OPEN = 0
    
    STATES = [OPEN, CLOSED, FROZEN, DELETED]
    DESCRIPTION = ['open', 'closed', 'frozen']


class DateCriteria:
    """
    Class to reference date criterias.
    
    @since: 0.3
    @version: $Revision: 1.12.2.6 $
    
    @cvar LEQ: constant for the 'less or equal' criteria.
    @type LEQ: str
    @cvar GEQ: constant for the 'greater or equal' criteria.
    @type GEQ: str
    @cvar __ALL__: all of date criteria constants.
    @type __ALL__: list
    @cvar __ARGS__: command line tool arguments to specify date criterias.
    @type __ARGS__: list
    """
    LEQ = 'leq'
    GEQ = 'geq'
    
    __ALL__ = [LEQ, GEQ]
    __ARGS__ = ['--leq', '--geq']


class FileState:
    """
    Class to reference file operations in the content catalog.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3
    @version: $Revision: 1.12.2.6 $
    
    @cvar ADDED: constant to specify a file registration on a dataset version.
    @type ADDED: int
    @cvar DELETED: constant to specify a file deletion on a dataset version.
    @type DELETED: int
    @cvar HIDDEN: constant to completely remove a file from a dataset (unused).
    @type HIDDEN: int
    """

    HIDDEN = 0
    ADDED = 1
    DELETED = 2


class HTTP:
    """
    Class to reference HTTP methods and mandatory names for parameters and headers.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.12.2.6 $
    
    @cvar API: name of the api parameter.
    @type API: str
    @cvar DELETE: name of the HTTP DELETE method.
    @type DELETE: type
    @cvar GET: name of the HTTP GET method.
    @type GET: str
    @cvar POST: name of the HTTP POST method.
    @type POST: str
    @cvar PUT: name of the HTTP PUT method.
    @type PUT: str
    @cvar TUID: name of the tuid parameter.
    @type TUID: str
    @cvar USER_AGENT: the name of the User-Agent header.
    @type USER_AGENT: str
    """

    GET = 'GET'
    POST = 'POST'
    DELETE = 'DELETE'
    PUT = 'PUT'

    # assumes tag is of the form DQ2_x_y_z
    API = 'API'
    USER_AGENT = 'User-Agent: dqcurl %s' % (tag[11:-2].replace('_', '.'))

    TUID = 'TUID'


class Metadata:
    """
    Class to reference DQ2 specific metadata attributes.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.12.2.6 $
    
    @cvar DATASET: dataset metadata attributes.
    @type DATASET: list
    @cvar DATASET_VERSION: dataset version metadata attributes.
    @type DATASET_VERSION: list
    @cvar USER_VERSION: user dataset version metadata attributes.
    @type USER_VERSION: list
    """

    DATASET = ['duid', 'state', 'owner', 'creationdate', 'latestvuid', 'latestversion']
    DATASET_VERSION = ['vuid', 'version', 'versioncreationdate']
    USER_VERSION = ['tier0state', 'tier0nrpartitions', 'tier0type']


class TestCaseData:
    """
    Class to reference data for test purposes.
    
    @since: 0.2.0
    @version: $Revision: 1.12.2.6 $
    
    @cvar CHECKSUMS: MD5 file checksums to be used for testing purposes.
    @type CHECKSUMS: list
    @cvar DSNS: dataset names to be used for testing purposes.
    @type DSNS: list
    @cvar GUIDS: global unique identifiers to be used for testing purposes.
    @type GUIDS: list
    @cvar LFNS: logical file names to be used for testing purposes.
    @type LFNS: list
    @cvar INVERTED_VUIDS: .
    @type INVERTED_VUIDS: list
    @cvar OWNERS: dataset owners to be used for testing purposes.
    @type OWNERS: list
    @cvar SIZES: file sizes to be used for testing purposes.
    @type SIZES: list
    @cvar VUIDS: dataset version unique identifiers to be used for testing purposes.
    @type VUIDS: list
    """
    DSNS = [
        'test.dq2.' + 'a' * (255-len('test.dq2.')), #0
        'test.dq2.mcatnlo0310.005921.W+W-enuenu',
        'test.dq2.',
        'test.dq2.csc11.005025.J2_pythia_jetjet_NoISR-FSR-MI.evgen.EVNT.v11004205',
        'test.dq2.csc11.005025.J2_pythia_jetjet_NoISR_FSR_MI.evgen.EVNT.v11004206',
        'test.dq2.trig_misal_whatever' #5
    ]
    LFNS = [
        'test.dq2.lfn.00001.w+w-piupiutautaumumu._00001.tar.gz', #0
        'test.dq2.lfn.00001.w+w-piupiutautaumumu._00002.tar.gz',
        'test.dq2.lfn.00001.w+w-piupiutautaumumu._00003.tar.gz',
        'test.dq2.lfn.00002',
        'test.dq2.lfn.00003',
        'test.dq2.lfn.00004', #5
        'test.dq2.lfn.00005',
        'test.dq2.lfn.00006'
    ]
    GUIDS = [
        '00000000-c8dc-416c-b923-2c7f2c2f0400', #0
        '00000000-A6EC-4B36-91D6-10845288EA00',
        '00000000-1234-1234-1234-123456789000',
        '00000000-1234-1234-1234-123456789001',
        '00000000-1234-1234-1234-123456789002',
        '00000000-1234-1234-1234-123456789003', #5
        '00000000-1234-1234-1234-123456789004',
        '00000000-1234-1234-1234-123456789005',
        '00000000-1234-1234-1234-123456789006'
    ]
    SIZES = [
        long(1000), long(2000000000), long(3000), long(3000), long(3000), long(3000), long(3000), long(3000), long(3000)
    ]
    CHECKSUMS = [
        'md5:5479b5d005f65a792a029c5d4f096261', #0
        'md5:2fbb709bb3fd03440828d190abd489c3',
        'md5:0f85f74981f8cc8b9f45a9469c869940',
        'md5:0f85f74981f8cc8b9f45a9469c869940',
        'md5:0f85f74981f8cc8b9f45a9469c869940', #5
        'md5:0f85f74981f8cc8b9f45a9469c869940',
        'md5:0f85f74981f8cc8b9f45a9469c869940',
        'md5:0f85f74981f8cc8b9f45a9469c869940'
    ]
    OWNERS = ['/C=CH O=CERN P=DQ2 testcase owner/CN=DQ2 testcase owner']
    DUIDS = ['d0000000-0000-0000-0000-000000000000', 'd0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000003']
    VUIDS = ['f0000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000003', 'e0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000006', 'b0000000-0000-0000-0000-000000000007']
    INVERTED_VUIDS = VUIDS + []
    INVERTED_VUIDS.reverse()