"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/09/21 12:28:58 psalgado Exp $
"""


__version__ = '$Name: dq2-common-validator-0-3-1_rc4 $'