"""
DQ2 common utility methods configuration.

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: __init__.py,v 1.4.2.14 2007/11/20 16:20:36 psalgado Exp $
"""


from dq2.common.aspects.exception import wrap_package
wrap_package()


from dq2.common.DQException import DQFatalError

from dq2.common import uuid


import commands
import re
import string
import threading


__version__ = '$Name: dq2-common-0-3-1_rc24 $'


def generate_uuid ():
   """
   Generates a fixed 36 character unique identifier (in lowercase).
   
   @author: Miguel Branco
   @contact: miguel.branco@cern.ch
   @since: 0.2.0
   @version: $Id: __init__.py,v 1.4.2.14 2007/11/20 16:20:36 psalgado Exp $
   
   @raise DQFatalError: in case there is an error running uuidgen.
   
   @return: a 36 character unique identifier.
   @rtype: str
   """
   try:
       return str(uuid.uuid1()).lower()
   except:
       """python 2.2 compatibility"""
       s,o = commands.getstatusoutput('uuidgen')
       if s != 0:
           err_msg = 'Failed running uuidgen to generate UUID! [%s]' % (o)
           raise DQFatalError(err_msg)
       return string.strip(o).lower()


def dict_get_item (dictionary, key):
    """
    Returns a value from a dictionary in a case-insensitive way.
    
    @since: 0.2.0
    
    @param dictionary: the dictionary from where to retrieve the value.
    @type dictionary: dict
    @param key: the dictionary key.
    @type key: unknown
    
    @raise AssertionError: in case the dictionary is None.
    @raise AssertionError: in case the dictionary parameter is not a dictionary.
    @raise AssertionError: in case the key of the dictionary is None.
    @raise KeyError: in case the key cannot be found in the dictionary.
    """
    assert dictionary is not None
    assert type(dictionary) is dict
    assert key is not None
    
    for eachKey in dictionary.keys():
        """"""
        if eachKey.lower() == key.lower():
            return dictionary[eachKey]
    
    raise KeyError

get_dict_item = dict_get_item


def get_hostname (url):
    """
    Return hostname from URL.
    
    @since: 0.2.0
    
    @param url: the URL to be parsed.
    @type url: str
    
    @return: the hostname.
    @rtype: str
    """
    reg = re.search('[^:]+:(/)*([^:/]+)(:[0-9]+)?(/)?.*', url)
    host = ''
    try:
        host = reg.group(2)
    except:
        pass
    
    return host


def parse_dn (owner):
    """
    @since: 0.3.0
    
    @param owner: the certificate DN.
    @type owner: str
    
    @return: a parsed certificate DN.
    @rtype: str
    """
    if owner is not None:
        owner = owner.split('/CN=')
        if len(owner) >= 2:
            owner = owner[0] + '/CN=' + owner[1]
        else:
            owner = owner[0]
    return owner


class Singleton (object):
    """
    Class to be used to create singleton classes.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.4.2.14 $
    """


    def __new__ (cls, *args, **kwds):
        """
        @since: 0.3.0
        
        @return: the singleton.
        @rtype: object
        """
        
        instance = cls.__dict__.get('__instance__')
        if instance is not None:
            return instance
        cls.__instance__ = instance = object.__new__(cls)
        instance.init(*args, **kwds)
        return instance


    def init (self, *args, **kwds):
        """
        Method to be implemented by the subclasses.
        
        @since: 0.3.0
        """
        pass


class Configurable (object):
    """
    Class to be used to create configurable classes.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.4.2.14 $
    
    @cvar isConfigured: flag to determine if a class has been configured or not.
    @type isConfigured: bool
    @cvar lock: a lock to safely configure the class.
    @type lock: threading.Lock
    """


    isConfigured = False
    lock = threading.Lock()


    def __new__ (cls, *args, **kwds):
        """
        @since: 0.3.0
        """
        # get the subclass configured attribute
        try:
            isConfigured = cls.__dict__.get('isConfigured')
        except AttributeError, e:
            setattr(cls, 'isConfigured', False)
            
        if cls.isConfigured is None or cls.isConfigured is False:
            """no configuration present (yet) - if it was it would skip the lock -> more performant"""
            
            #LOCK: begin
            Configurable.lock.acquire()
            
            try:
                # a previous thread may had the lock and configured the class
                # need to verify again
                
                if not cls.isConfigured is True:
                    """still not configured"""
                    #print 'configuring %s...' % cls
                    cls.__configure__()
                    cls.isConfigured = True
            finally:
                Configurable.lock.release()
            #LOCK: end
        
        return super(Configurable, cls).__new__(cls)


    def __configure__ ():
        """
        Method to be implemented by the subclasses.
        
        @since: 0.3.0
        """
        pass

    __configure__ = staticmethod(__configure__)