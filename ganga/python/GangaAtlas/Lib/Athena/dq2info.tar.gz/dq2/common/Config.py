"""
Contains the class definition for Config objects.

@author: Ricardo Rocha
@contact: ricardo.rocha@cern.ch
@since: 0.3
@version: $Id: Config.py,v 1.2.2.2 2007/09/28 11:27:07 psalgado Exp $
"""
import os

try:
    from ConfigParser import SafeConfigParser
except:
    # python 2.2
    from ConfigParser import ConfigParser
from ConfigParser import ParsingError


class Config(object):
    """
    Class definition for a dq2 Config object.
    
    Current version looks for the config file in ''.
    
    @author: Ricardo Rocha
    @contact: ricardo.rocha@cern.ch
    @version: $Id: Config.py,v 1.2.2.2 2007/09/28 11:27:07 psalgado Exp $
    
    @cvar _configs: service configuration objects.
    @type _configs: dict
    @cvar _instance: holds the singleton reference.
    @type _instance: Config
    """


    _configs = {}
    _instance = None


    def __new__ (cls):
        """
        Invoked on every class instance creation.
        
        Makes sure that only one instance of this class ever exists.
        
        @return: A reference to the class singleton
        """
        if not cls._instance:
            cls._instance = object.__new__(cls)
        return cls._instance


    def __init__ (self):
        """
        Object constructor.
        
        As this is a singleton, nothing is put in here (otherwise it would
        be constantly called).
        """
        pass


    def getConfig (self, packageName, mypath=None):
        """
        Returns a reference to the configuration object for the given package.
        
        @param packageName: The name of the package for which to retrieve the configuration
        @type packageName: .
        @keyword mypath: an alternative path to search for a configuration file.
        @type mypath: str
        
        @change: the 'mypath' parameter was added to the original problem.
        
        @return: A reference to the config object of the requested package
        """
        # return the config immediately if we already have one for this package
        if not self._configs.has_key(packageName):
            
            # else load it and return afterwards
            if mypath is not None:
                configFiles = [mypath + 'etc/dq2.cfg']
            else:
                configFiles = [
                    '/opt/dq2/etc/dq2.cfg',
                    os.path.expanduser('~/.dq2/etc/dq2.cfg'),
                    '%s/etc/dq2.cfg' % os.environ.get('DQ2_HOME')
                ]
            
            # Extend with the package config files if provided
            if mypath is not None:
                packageFiles = [mypath + 'etc/%s/%s.cfg' % (packageName, packageName)]
            else:
                packageFiles = [
                    '/opt/dq2/etc/%s/%s.cfg' % (packageName, packageName),
                    os.path.expanduser('~/.dq2/etc/%s/%s.cfg' % (packageName, packageName)),
                    '%s/etc/%s/%s.cfg' % (os.environ.get('DQ2_HOME'), packageName, packageName)
                ]
            
            if packageName is not None:
                configFiles.extend(packageFiles)
            
            try:
                config = SafeConfigParser()
            except:
                # python 2.2
                config = ConfigParser()
            try:
                config.read(configFiles)
                self._configs[packageName] = config
            except ParsingError, msg:
                # @todo: we need to log the exception somewhere
                # problem is without loading the config we have no logger
                return None
        
        return self._configs[packageName]