"""
@since: 0.1
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/09/28 11:27:07 psalgado Exp $
"""