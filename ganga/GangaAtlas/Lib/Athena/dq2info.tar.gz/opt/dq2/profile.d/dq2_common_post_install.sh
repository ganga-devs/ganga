#!/bin/sh
#
# Script to configure DQ2
#
#  Author: Miguel Branco <miguel.branco@cern.ch>
#
#  $Id: dq2_common_post_install.sh,v 1.8.4.1 2008/07/31 10:12:08 psalgado Exp $
#

# 0 is ok
# 1 is warning
# 2 is bad
exit_code=0

if [ ! $DQ2_HOME ]; then
    if [ -d /opt/dq2 ]; then
        export DQ2_HOME=/opt/dq2
        echo 'Using DQ2 installation on /opt/dq2/.'
        echo 'You may set environment variable DQ2_HOME to override this.'
    else
        echo 'Cannot find DQ2 installation.'
        echo 'Please set environment variable DQ2_HOME.'
        return 2
    fi  
fi

. $DQ2_HOME/profile.d/dq2_common_env.sh

if [ ! $? -eq 0 ]; then
    return $?
fi

if [ ! $1 ]; then
    echo
    echo " Are you sure you want to configure DQ2 and"
    echo " potentially override ANY existing configuration files?"
    echo "  (answer exactly 'yes' to proceed)"
    read -p "  > "
    if [ ! "$REPLY" == "yes" ]; then
        return 1
    fi
fi

if [ ! -d $DQ2_HOME ]; then
    echo "DQ2 is not installed or \$DQ2_HOME not set! Giving up."
    return 2
fi
if [ ! -d $DASHBOARD_HOME ]; then
    echo "ARDA DDM dashboard is not installed or \$DASHBOARD_HOME not set! Giving up."
    return 2
fi

echo
echo

echo " - Overwriting $DQ2_HOME/etc with DEFAULT values"
mkdir -p $DQ2_HOME/etc/
for i in `/usr/bin/env ls $DQ2_HOME/doc/config/ | grep dq2`; do
    cp -r $DQ2_HOME/doc/config/$i $DQ2_HOME/etc/
done
cp -r $DQ2_HOME/doc/config/common/*.cfg $DQ2_HOME/etc/
cp -r $DQ2_HOME/doc/config/common/*.xml $DQ2_HOME/etc/ > /dev/null 2>&1

echo " - Overwriting $DASHBOARD_HOME/etc with DEFAULT values"
mkdir -p $DASHBOARD_HOME/etc/
for i in `/usr/bin/env ls $DASHBOARD_HOME/doc/config/ | grep -v common`; do
    mkdir -p $DASHBOARD_HOME/etc/dashboard-$i
    cp $DASHBOARD_HOME/doc/config/$i/* $DASHBOARD_HOME/etc/dashboard-$i/
done
cp -r $DASHBOARD_HOME/doc/config/common/*.cfg $DASHBOARD_HOME/etc/

echo
echo
echo "Done successfully."

return 0