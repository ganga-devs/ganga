#!/bin/sh
#
# Script to setup DQ2 environment
#
#  Author: Miguel Branco <miguel.branco@cern.ch>
#
#  $Id: dq2_common_env.sh,v 1.7.4.1 2008/07/31 10:12:08 psalgado Exp $
#

echo
echo
echo
echo '****************************************************'
echo '*                                                  *'
echo '* ATLAS DQ2 environment                            *'
echo '*                                                  *'
echo '****************************************************'
echo
echo

# 0 is ok
# 1 is warning
# 2 is bad
exit_code=0

if [ ! $DQ2_HOME ]; then
    if [ -d /opt/dq2 ]; then
        export DQ2_HOME=/opt/dq2
        echo 'Using DQ2 installation on /opt/dq2/.'
        echo 'You may set environment variable DQ2_HOME to override this.'
    else
        echo 'Cannot find DQ2 installation.'
        echo 'Please set environment variable DQ2_HOME.'
        return 2
    fi  
fi

if [ ! $DASHBOARD_HOME ]; then
    if [ -d /opt/dashboard ]; then
        export DASHBOARD_HOME=/opt/dashboard
        echo 'Using DASHBOARD installation on /opt/dashboard/.'
        echo 'You may set environment variable DASHBOARD_HOME to override this.'
    else
        echo 'Cannot find DASHBOARD installation.'
        echo 'Please set environment variable DASHBOARD_HOME.'
        return 2
    fi  
fi

echo '  Setting required enviroment:'
if [ -d $DQ2_HOME/bin ]; then
    export PATH=$DQ2_HOME/bin/:$PATH
    echo '  - added DQ2 binaries to the PATH'
else
    echo '  - ERROR: DQ2 binaries not found'
    exit_code=2
fi
if [ -d $DASHBOARD_HOME/bin ]; then
    export PATH=$DASHBOARD_HOME/bin/:$PATH
    echo '  - added ARDA DDM dashboard binaries to the PATH'
else
    echo '  - ERROR: ARDA DDM dashboard binaries not found'
    exit_code=2
fi

curlOK=0
python -c "import pycurl" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo '  - Python-CURL available'
    curlOK=1
fi
curlPath=`which curl`
if [ ! -z $curlPath ]; then
    echo '  - CURL binary available'
    curlOK=1
fi
if [ $curlOK -eq 0 ]; then
    echo '  - ERROR: Neither CURL nor Python-CURL found'
    exit_code=2
fi

if [ $exit_code -eq 0 ]; then
    echo
    echo 'DQ2 common environment looks OK.'
    echo
elif [ $exit_code -eq 1 ]; then
    echo
    echo 'WARNING(s) while setting DQ2 common environment !!'
else
    echo
    echo 'ERROR(s) while setting DQ2 common environment !!'
    echo
fi

return $exit_code