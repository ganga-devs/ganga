"""

@author: Vincent Garonne
@contact: vincent.garonne@cern.ch
@since: 1.0
@version: $Id: Location.py,v 1.1 2008/02/04 14:37:14 psalgado Exp $
"""

from dq2.common.python.uuid import uuid4


from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationException import *
from dq2.location.client.LocationClient import LocationClient


class Location (object):
    """
    
    @author: Vincent Garonne
    @contact: vincent.garonne@cern.ch
    @since: 1.0
    @version: $Revision: 1.1 $
    """


    def deleteDatasetReplicas (self, dsn, locations, version=0):
        """
        Delete the dataset replica from the given site. If it
        was the last replica, delete entries from the repository
        and dq2.content.
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param locations: is a list with the dataset replica locations.
        @param version: is the dataset version number.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case the dataset name doesn't exist.
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0 and version == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        vuid = dataset['vuids'][0] # the latest version retrieved by the catalog
        
        self.locationClient.deleteDatasetReplica(vuid, locations)


    def listDatasetReplicas (self, dsn, version=0, complete=None, old=True):
        """
        @since: 0.2.0
        
        @author: Vincent Garonne
        @contact: vincent.garonne@cern.ch
        
        @param dsn is the dataset name.
        @param version is the dataset version number.
        @param complete is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
              B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
              @ if old is True returns: List of locations.
            {'dsn_A': ['site_A', ..., 'site_B'], 'dsn_B': [...]}
             else returns:
            {'site_A': [ {'versions': ,  '':}, ], 'site_B': [{'versions': ,  '':}, ...]}
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetException(dsn=dsn)
        
        dataset = dict_get_item(dataset, dsn)
        if old:
            vuid = dataset['vuids'][0] # the latest version
            return self.locationClient.queryDatasetLocations([vuid], complete=complete)
        else:
            duid   = dataset['duid']
            return self.locationClient.listDatasetReplicas(duid)


    def listDatasetsInSite (self, site, complete=None, page=1, rpp=100):
        """
        List all the datasets and their versions available on
        the given site.
        
        @since: 0.2.0
        
        @param site: is the location to be searched for.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        @param page: is the page to be displayed.
        @param rpp: are the results per page.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
        
        @return: List of dataset versions.
            {'dsn': [version_numberX,... version_numberY]}
        """
        
        if page <= 0:
            page = 1
        if rpp <= 0:
            rpp = 100
        
        # get the vuids from the LocationCatalog
        
        tmp = self.locationClient.queryDatasetsInSite(site, complete, page, rpp)
        
        dsets = []
        for ds in tmp:
            dsets.append(ds)
        
        return self.repositoryClient.queryDatasetByVUIDs(dsets)


    def registerDatasetLocation (self, dsn, location, version=0, complete=LocationState.INCOMPLETE):
        """
        Register new location of a dataset (which must already
        be defined in the repository).
        
        @since: 0.2.0
        
        @param dsn: is the dataset name.
        @param location: is the dataset dq2.location.
        @param version: is the dataset version number.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error in the central catalogs.
            - DQOpenedDatasetException is raised,
                in case of a opened dataset.
            - DQLocationExistsException is raised,
                in case a dataset version replica exists at the given dq2.location.
            - DQUnknownDatasetException is raised,
                in case there is no dataset with the given name.
        """
        dataset = self.repositoryClient.queryDatasetByName(dsn, version)
        # WARNING: central catalog result may have a different case -> use dict_get_item
        # dataset will become {'duid': duid, 'vuids': ['B_vuid_for_version1']
        dataset = dict_get_item(dataset, dsn)
        
        if len(dataset) == 0:
            raise DQUnknownDatasetVersionException(dsn, version)
        
        vuid = dataset['vuids'][0] # the latest/given version
        
        # if asked to mark as complete
        if complete == LocationState.COMPLETE:
            # make sure dataset is closed
            st = self.repositoryClient.getState(dsn)
            
            # is not closed!
            if st == DatasetState.OPEN:
                raise DQOpenedDatasetException(dsn)
        
        self.locationClient.addDatasetReplica(vuid, location, complete)