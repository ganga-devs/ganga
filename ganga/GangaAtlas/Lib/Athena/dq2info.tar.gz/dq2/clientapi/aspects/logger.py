"""
Client logger aspects.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: logger.py,v 1.7 2009/10/15 13:06:48 angelos Exp $
"""

LOG = None
COMPONENT_CLIENT = 'CLIENT'


def get_logger ():
    """
    Returns a DQLog instance.
    
    @since: 0.3.0
    """
    global LOG
    
    if LOG is not None:
        return LOG
    
    from dq2.common.DQLog import DQLog
    return DQLog('dq2.clientapi')


LOG = get_logger()


from dq2.common.aspects import wrap_around, wrap_around_re


def wrap_package ():
    """
    @since: 0.3.0
    """
    
    wrap_dq2()


def wrap_dq2 ():
    """
    @since: 0.3.0
    """
    from dq2.clientapi.DQ2 import DQ2
    
    wrap_around (DQ2.closeDataset, trace)
    wrap_around_re (DQ2, '(delete.*)', trace)
    
    wrap_around (DQ2.eraseDataset, trace)
    wrap_around (DQ2.freezeDataset, trace)
    
    wrap_around_re (DQ2, '(get.*)', trace)
    
    wrap_around_re (DQ2, '(list.*)', trace)
    
    wrap_around_re (DQ2, '(register.*)', trace)
        
    wrap_around (DQ2.setMetaDataAttribute,     trace)
    wrap_around (DQ2.checkDatasetConsistency,  trace)
    wrap_around (DQ2.queryStorageUsage,        trace)

def error (e):
    """
    @since: 0.3.0
    """
    LOG.error(
        e,
        COMPONENT_CLIENT
    )


def request (classname, ddm_server, url, parameters):
    """
    @since: 0.3.0
    
    ddm_server is the DDM server name.
    url is the request URL.
    parameters is the URL parameters.
    """
    #  method time_spent ddm_client ddm_server OS PythonVersion
    message = "%s %s %s %s" % (classname, ddm_server, url, parameters)
    LOG.info(
        message,
        COMPONENT_CLIENT
    )


def trace (self, *args, **kwargs):
    """
    @since: 0.3.0
    """
    try:
        message = "%s %s " % (
            str(args),
            str(kwargs)
        )
        LOG.info(
            message,
            COMPONENT_CLIENT
        )
        return self.__proceed(*args, **kwargs)
    except StandardError, e:
        LOG.error(
            str(e),
            COMPONENT_CLIENT
        )
        raise e
