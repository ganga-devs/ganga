"""
DQ2 suite for stress tests.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQ2StressTestSuite.py,v 1.2 2009/10/15 13:06:48 angelos Exp $
"""

__all__ = ['DQ2StressTestSuite']

__author__ = "Pedro Salgado <pedro.salgado@cern.ch>"
__version__ = "0.3"
__date__ = "2007-06-13"


import unittest

from dq2.clientapi.DQ2 import DQ2


class DQ2StressTestSuite (unittest.TestSuite):
    """
    @since: 0.3.0
    """


    def __init__ (self):
        """
        @since: 0.3.0
        """
        unittest.TestSuite.__init__(self)
        
        self.implementation = DQ2
        
        for eachTestCase in []:
            for method in dir(eachTestCase):
                if method[0:4] == 'test':
                    """method name starts by 'test': add it to the test suite"""
                    self.addTest(eachTestCase(method, instance))


if __name__ == '__main__':
    """
    Runs all tests in DQ2StressTestSuite.
    
    @since: 0.3.0
    """
    suite = DQ2StressTestSuite()
    unittest.TextTestRunner(verbosity=2).run(suite)