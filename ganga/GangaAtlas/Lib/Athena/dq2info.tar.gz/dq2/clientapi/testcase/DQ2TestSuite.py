"""
DQ2 test suite.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQ2TestSuite.py,v 1.2 2009/10/15 13:06:48 angelos Exp $
"""


from dq2.clientapi.DQ2 import DQ2
from dq2.clientapi.testcase.DQ2TestCase import DQ2TestCase
from dq2.clientapi.testcase.DQDatasetTestCase import DQDatasetTestCase

from dq2.common.testcase.DQTestSuite import DQTestSuite


class DQ2TestSuite (DQTestSuite):
    """
    @since: 0.3.0
    """


    def __init__ (self):
        """
        @since: 0.3.0
        """
        self.suite = DQTestSuite.__init__(
            self,
            [
                DQDatasetTestCase,
                DQ2TestCase
            ]
        )


if __name__ == '__main__':
    """
    Runs all tests in DQ2TestSuite.
    
    @since: 0.3.0
    """
    
    import unittest
    suite = DQ2TestSuite()
    unittest.TextTestRunner(verbosity=2).run(suite)