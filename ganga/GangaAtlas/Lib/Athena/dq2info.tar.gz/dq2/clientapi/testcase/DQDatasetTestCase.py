"""
ContentCatalog.addFilesToDataset* tests.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: DQDatasetTestCase.py,v 1.2 2009/10/15 13:06:48 angelos Exp $
"""


from dq2.common.DQConstants import TestCaseData
from dq2.common.DQException import DQException, DQInvalidRequestException
from dq2.clientapi.DQ2 import DQ2
from dq2.common.testcase.DQTestCase import DQTestCase

from dq2.content.DQContentException import DQFileExistsInDatasetException

from dq2.repository.DQRepositoryException import DQDatasetExistsException, DQUnknownDatasetException


# file 1
f_struct_0 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[0],
    'size': TestCaseData.SIZES[0], 'checksum': TestCaseData.CHECKSUMS[0]
}

# file 2
f_struct_1 = {
    'guid': TestCaseData.GUIDS[1], 'lfn': TestCaseData.LFNS[1],
    'size': TestCaseData.SIZES[1], 'checksum': TestCaseData.CHECKSUMS[1]
}

# file 3
f_struct_2 = {
    'guid': TestCaseData.GUIDS[2], 'lfn': TestCaseData.LFNS[2],
    'size': TestCaseData.SIZES[2], 'checksum': TestCaseData.CHECKSUMS[2]
}

# file 1 with size=None
f_struct_01 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[0],
    'size': None, 'checksum': TestCaseData.CHECKSUMS[0]
}
# file 1 with checksum=None
f_struct_02 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[0],
    'size': TestCaseData.SIZES[0], 'checksum': None
}
# file 1 with size=None and checksum=None
f_struct_03 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[0],
    'size': None, 'checksum': None
}

# file 1 with wrong guid
f_struct_04 = {
    'guid': TestCaseData.GUIDS[1], 'lfn': TestCaseData.LFNS[0],
    'size': TestCaseData.SIZES[0], 'checksum': TestCaseData.CHECKSUMS[0]
}
# file 1 with wrong LFN
f_struct_05 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[1],
    'size': TestCaseData.SIZES[0], 'checksum': TestCaseData.CHECKSUMS[0]
}
# file 1 with wrong size
f_struct_06 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[0],
    'size': TestCaseData.SIZES[1], 'checksum': TestCaseData.CHECKSUMS[0]
}
# file 1 with wrong checksum
f_struct_07 = {
    'guid': TestCaseData.GUIDS[0], 'lfn': TestCaseData.LFNS[0],
    'size': TestCaseData.SIZES[0], 'checksum': TestCaseData.CHECKSUMS[1]
}

# new file with no size
f_struct_08 = {
    'guid': TestCaseData.GUIDS[4], 'lfn': TestCaseData.LFNS[4],
    'size': None, 'checksum': TestCaseData.CHECKSUMS[0]
}
# new files with no checksum
f_struct_09 = {
    'guid': TestCaseData.GUIDS[5], 'lfn': TestCaseData.LFNS[5],
    'size': TestCaseData.SIZES[0], 'checksum': None
}
# new files with no size nor checksum
f_struct_10 = {
    'guid': TestCaseData.GUIDS[6], 'lfn': TestCaseData.LFNS[6],
    'size': None, 'checksum': None
}


dict_guid0 = {
    'lfn': TestCaseData.LFNS[0], 'filesize': TestCaseData.SIZES[0], 'checksum': TestCaseData.CHECKSUMS[0]
}
dict_guid1 = {
    'lfn': TestCaseData.LFNS[1], 'filesize': TestCaseData.SIZES[1], 'checksum': TestCaseData.CHECKSUMS[1]
}
dict_guid2 = {
    'lfn': TestCaseData.LFNS[2], 'filesize': TestCaseData.SIZES[2], 'checksum': TestCaseData.CHECKSUMS[2]
}


class DQDatasetTestCase (DQTestCase):
    """
    Class for dataset level operations tests.
    
    @since: 0.3.0
    """


    def __init__ (self, name):
        """
        @since: 0.3.0
        """
        DQTestCase.__init__(self, name)
        
        self.dq2 = DQ2()
        self.dq2.tuid = 'testcase-0000-0000-0000-000000000000'


# PRIVATE METHODS


    def setUp (self):
        """
        Setup the test data.
        
        @since: 0.3.0
        
        
        Assumption:
            TestCaseData.VUIDS[0] is the initial version of the dataset (or version 1).
            TestCaseData.VUIDS[N] is the N-version of the dataset (or version N+1), where N > 0.
        
        """
        
        guids = [TestCaseData.GUIDS[0]]
        lfns = [TestCaseData.LFNS[0]]
        sizes = [TestCaseData.SIZES[0]]
        checksums = [TestCaseData.CHECKSUMS[0]]
        
        try:
            self.dq2.registerNewDataset(
                TestCaseData.DSNS[0],
                lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
            )
        except DQDatasetExistsException:
            try:
                self.dq2.registerFilesInDataset(
                    TestCaseData.DSNS[0],
                    lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
                )
            except DQFileExistsInDatasetException, e:
                pass
            except StandardError, e:
                print str(e)


    def tearDown (self):
        """
        @since: 0.3.0
        """
        
        # cleanup test datasets
        for eachDSN in TestCaseData.DSNS:
            try:
                self.dq2.eraseDataset(eachDSN)
            except DQUnknownDatasetException:
                pass
            except StandardError, e:
                print str(e)
            try:
                self.dq2.repositoryClient.trashDataset(eachDSN)
            except DQUnknownDatasetException:
                pass
            except StandardError, e:
                print str(e)


# TEST methods


    def testSetUp (self):
        """
        Verify if test data is well setup.
        
        @since: 0.3.0
        """
        
        
        # 1. test if files were added in the dataset
        
        message = '1. test if files were added in the dataset'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.1 test if number of files is correct
        message = '1.1 test if getNumberOfFiles'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.2.1 verifyFilesInDataset returns a correct response?
        message = '1.2.1 verifyFilesInDataset returns a correct response?'
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]])
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.2.2 verifyFilesInDataset returns a correct response? with version?
        message = '1.2.2 verifyFilesInDataset returns a correct response?'
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=0)
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=1)
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 2. user specified a version greater than the one existing on the central catalogs
        self.assertRaises(
            DQInvalidRequestException,
            self.dq2.verifyFilesInDataset,
            TestCaseData.DSNS[0],
            [TestCaseData.GUIDS[0]],
            3000
        )


    def scenarioDeleteAndAddFileInDifferentVersion (self):
        """
        Scenario: a file is deleted and added again on different versions of the same dataset.
        """
        
        
        # 1. delete file from the dataset
        
        self.dq2.registerNewVersion(TestCaseData.DSNS[0])
        self.dq2.deleteFilesFromDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]])
        
        # 1.1.1 listFilesInDataset returns a correct response?
        message = '1.1.1 listFilesInDataset returns a correct response?'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])
        expected = ()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.1.2 listFilesInDataset with version returns a correct response?
        message = '1.1.2 listFilesInDataset with version returns a correct response?'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0], version=1)
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0], version=2)
        expected = ()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.2.1 getNumberOfFiles returns a correct response?
        message = '1.2.1 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 0
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.2.2 getNumberOfFiles with version returns a correct response?
        message = '1.2.2 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], version=1)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], version=2)
        expected = 0
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.3.1 verifyFilesInDataset returns a correct response?
        message = '1.3.1 verifyFilesInDataset returns a correct response?'
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]])
        expected = {TestCaseData.GUIDS[0]: False}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.3.2 verifyFilesInDataset returns a correct response? with version?
        message = '1.3.2 verifyFilesInDataset returns a correct response? with version?'
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=0)
        expected = {TestCaseData.GUIDS[0]: False}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=1)
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 2. add file to the dataset
        
        guids = [TestCaseData.GUIDS[0]]
        lfns = [TestCaseData.LFNS[0]]
        sizes = [TestCaseData.SIZES[0]]
        checksums = [TestCaseData.CHECKSUMS[0]]
        
        
        self.dq2.registerNewVersion(
            TestCaseData.DSNS[0],
            lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
        )
        
        # 2.1.1 listFilesInDataset returns a correct response?
        message = '2.1.1 listFilesInDataset returns a correct response?'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.1.2 listFilesInDataset with version returns a correct response?
        message = '2.1.2 listFilesInDataset with version returns a correct response?'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0], version=1)
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0], version=2)
        expected = ()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0], version=3)
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.2.1 getNumberOfFiles returns a correct response?
        message = '2.2.1 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.2.2 getNumberOfFiles with version returns a correct response?
        message = '2.2.2 getNumberOfFiles with version returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], version=1)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], version=2)
        expected = 0
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0], version=3)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.3.1 verifyFilesInDataset returns a correct response?
        message = '2.3.1 verifyFilesInDataset returns a correct response?'
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]])
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.3.2 verifyFilesInDataset returns a correct response? with version?
        message = '2.3.2 verifyFilesInDataset returns a correct response? with version?'
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=0)
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=3)
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=2)
        expected = {TestCaseData.GUIDS[0]: False}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        result = self.dq2.verifyFilesInDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]], version=1)
        expected = {TestCaseData.GUIDS[0]: True}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def scenarioDeleteAndAddFileOnSameVersion (self):
        """
        Scenario: a file is deleted and added again on the same version of the dataset.
        """
        
        
        # 1. delete file from the dataset
        
        self.dq2.deleteFilesFromDataset(TestCaseData.DSNS[0], [TestCaseData.GUIDS[0]])
        
        # 1.1 listFilesInDataset returns a correct response?
        message = '1.1 listFilesInDataset returns a correct response?'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])
        expected = ()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.2 getNumberOfFiles returns a correct response?
        message = '1.2 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 0
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 2. add file to the dataset
        
        guids = [TestCaseData.GUIDS[0]]
        lfns = [TestCaseData.LFNS[0]]
        sizes = [TestCaseData.SIZES[0]]
        checksums = [TestCaseData.CHECKSUMS[0]]
        
        
        self.dq2.registerFilesInDataset(
            TestCaseData.DSNS[0],
            lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
        )
        
        # 2.1 listFilesInDataset returns a correct response?
        message = '2.1 listFilesInDataset returns a correct response?'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[0])
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.2 getNumberOfFiles returns a correct response?
        message = '2.2 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[0])
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def attemptInvalidFileRegistrations (self):
        """
        @since: 0.3.0
        
        # 1. try to add files on a closed dataset
        # 2. try to add files on a frozen dataset
        """
        pass


    def attemptInvalidStatePaths (self):
        """
        # 3. try to register a version on a frozen dataset
        """
        pass


    def attemptInvalidDatasetRegistrations (self):
        """
        @since: 0.3.0
        
        # 1. try to insert a already existing dataset
        """
        
        # 1. try to insert a already existing dataset
        
        self.assertRaises(
            DQDatasetExistsException,
            self.dq2.registerNewDataset,
            TestCaseData.DSNS[0]
        )


if __name__ == '__main__':
    """
    Runs all tests in DQDatasetTestCase.
    
    @since: 0.2.0
    """
    import sys
    #DQTestCase.debugEnabled = True
    
    test = DQDatasetTestCase.main(
        'dq2.clientapi.testcase', DQDatasetTestCase.__name__, sys.argv[1:]
    )