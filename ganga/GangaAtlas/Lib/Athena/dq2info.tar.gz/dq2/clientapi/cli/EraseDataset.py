"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: EraseDataset.py,v 1.6 2009/11/18 08:30:34 vgaronne Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class EraseDataset(DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> "
    
    version = "$Revision: 1.6 $"
    
    description = "Erase Dataset"

    toolOptions = [ ]


    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
 
 
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]
 
        
    def execute(self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
        
        dsn = self._get_parameters()
        
        ret    = dq.eraseDataset(dsn)
        status = True        
        if ret:
            if 'subscription' in ret:
                ss = list()
                r  = ret['subscription']
                if r:
                 for dsn in r:
                    for s in r[dsn]:
                        if r[dsn][s]['status']: 
                            ss.append (s)                         
                    
                
                 for dsn in r:
                    for s in r[dsn]:
                        if not r[dsn][s]['status']: 
                            print 'Dataset %s subscription at %s not deleted. Error: %s' % (dsn, s, str(r[dsn][s]['error']))
                            status = False                        

                if ss: print "Dataset %s subscription at [%s] deleted" % (dsn, ','.join(ss))
 
            if 'location' in ret:
                ls = [l for l in ret['location'] if 'status' in ret['location'][l] and ret['location'][l]['status']]
                if ls: print "Dataset %s replica at [%s] deleted" % (dsn, ','.join(ls))
                                        
                for l in ret['location']: 
                    if not ret['location'][l]['status'] and 'error' in ret['location'][l]:
                        print 'Dataset %s replica at %s not deleted. Error: %s' % (dsn, l, str(ret['location'][l]['error']))
                        status = False                        
            else:
                print "No dataset replicas deleted"

        if status:
            print "Dataset %(dsn)s erased" % locals ()
        else:
            print "Dataset %(dsn)s not erased" % locals ()
            
