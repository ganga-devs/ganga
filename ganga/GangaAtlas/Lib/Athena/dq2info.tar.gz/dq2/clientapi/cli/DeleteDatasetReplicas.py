"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: DeleteDatasetReplicas.py,v 1.13 2009/11/06 08:19:09 vgaronne Exp $
"""

import cliutil
import sys
from dq2.common import optparse

from dq2.common.DQException         import DQException
from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2, option_value


class DeleteDatasetReplicas(DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <DATASET> <SITENAME> ... <SITENAME>"
    
    version = "$Revision: 1.13 $"
    
    description = "Delete Dataset Replicas"

    toolOptions = [
        optparse.make_option(
            "-d", "--deep",
            action="store_true",
            dest="deep",            
            default=False,
            help="Submit physical deletion request"
        ),
        optparse.make_option(
            "-l", "--logical",
            action="store_true",
            dest="logical",            
            default=False,
            help="Submit logical deletion request(admin. role required)"
        ),
        optparse.make_option(
            "-f", "--force",
            action="store_true",
            dest="force",            
            default=False,
            help="Submit physical deletion request with no respect of overlapping datasets(admin. role required)"
        ),
        optparse.make_option(
            "-a", "--all",
            action="store_true",
            dest="all",            
            default=False,
            help="Submit physical deletion request for all replicas"
        ),
        #optparse.make_option(
        #    "-i", "--ignore_lifetime",
        #    action="store_true",
        #    dest="ignore_lifetime",            
        #    default=False,
        #    help="Ignore the replica lifetime attribute (admin. role required)"
        #),
         cliutil.opt_dataset_version
     ]


    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return (self.args[0], self.args[1:])
 
        
    def execute(self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
    
        dsn, sites = self._get_parameters()
        
        if not sites and not self.options.all:
            ltIdx = self.usage.find('<')    
            print 'please provide %s' % (self.usage[ltIdx:])            
            sys.exit(-1)

                    
        ret = dq.deleteDatasetReplicas(dsn=dsn, locations=sites, version=self.options.version, 
                                       deep=self.options.deep, logical=self.options.logical,
                                       force=self.options.force, all=self.options.all)
            
        if ret:
            ls = [l for l in ret if 'status' in ret[l] and ret[l]['status']]
            if ls: print "Dataset %s replica at [%s] deleted" % (dsn, ','.join(ls))
                                    
            for l in ret: 
                if not ret[l]['status'] and 'error' in ret[l]:
                    print 'Dataset %s replica at %s not deleted. Error: %s' % (dsn, l, str(ret[l]['error']))
        else:
            print "No dataset replicas deleted"
                   