"""
(since 0.3.0)

$Id: ListMetaDataReplica.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2
from dq2.clientapi.cli                  import cliutil
import string

class ListMetaDataReplica (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog [options] <DATASET> <SITE>"
    
    version = "$Revision: 1.2 $"
    
    description = "List MetaData Attributes for replicas"

    toolOptions = [cliutil.opt_dataset_version]
    
    
    def __init__(self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
        
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0],self.args[1]        
        
    def execute(self):
        """
        (since 0.3.0)
        """

        dq = getDQ2(self)

        dsn, location = self._get_parameters()
        
        out        = ''
        ret        = dq.listMetaDataReplica(location, dsn, self.options.version)
        provenance = dq.getMasterReplicaLocation(dsn, self.options.version)

        out += string.ljust('name', 25) +' : '+ str(dsn) +'\n'        
        for at in ret:
            if at == 'immutable' :  
                
                if ret[at] == 1:
                    out += string.ljust('state', 25) +' : '+ str('closed') +'\n'
                    
                if ret[at] == 0:
                    out += string.ljust('state', 25) +' : '+ str('open') +'\n'
                if ret[at] == 2:
                    out += string.ljust('state', 25) +' : '+ str('deleted') +'\n'
                    
            elif at == 'transferState' :
                if int(ret[at]) == 0:
                    out += string.ljust('transfer state', 25) +' : '+ str('active') +'\n'                    
                else:
                    out += string.ljust('transfer state', 25) +' : '+ str('inactive') +'\n'
                    
            elif at == 'checkState' :  
                if ret[at] == 6:
                    out += string.ljust('consistency check', 25) +' : '+ str('checked') +'\n'                    
                if ret[at] == 1:
                    out += string.ljust('consistency check', 25) +' : '+ str('waiting') +'\n'                    
                if ret[at] == 2:
                    out += string.ljust('consistency check', 25) +' : '+ str('checking') +'\n'                    
                if ret[at] == 0:
                    out += string.ljust('consistency check', 25) +' : '+ str('Not checked') +'\n'
                    
            elif at == 'checkdate' :  
                    out += string.ljust('consistencymodifieddate', 25) +' : '+ str(ret[at]) +'\n'                    

            elif at == 'transferdate' :  
                out += string.ljust('transfermodifieddate', 25) +' : '+ str(ret[at]) +'\n'
                    
            else:
                out += string.ljust(at.lower(), 25) +' : '+ str(ret[at]) +'\n'
                

        out += string.ljust('master replica', 25) +' : '+ str(provenance) +'\n'                    
                                                            
        print out