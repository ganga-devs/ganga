"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: ArchiveContainer.py,v 1.1 2008/02/04 16:55:03 psalgado Exp $
"""

from dq2.common.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class ArchiveContainer (DQDashboardTool):
    """
    @since: 1.0
    @version: $Revision: 1.1 $
    """
    
    usage = '%prog [options] <NAME> '
    
    version = '$Revision: 1.1 $'
    
    description = 'Archives a container.'

    toolOptions = [ ]


    def __init__(self):
        """
        @since: 1.0
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 1.0
        """
        return self.args[0]


    def execute (self):
        """
        @since: 1.0
        """
        
        dq = getDQ2(self)
        
        name = self._get_parameters()
        
        dq.archiveContainer(name)
        
        print 'Container %s is now archived.' % (name)