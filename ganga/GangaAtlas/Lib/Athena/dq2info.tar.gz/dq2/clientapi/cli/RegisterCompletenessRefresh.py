"""
(since 0.3.0)

$Id: RegisterCompletenessRefresh.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli                  import cliutil
from dq2.clientapi.cli.cliutil import getDQ2
from dq2.common                         import optparse

class RegisterCompletenessRefresh (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog [options] <DATASET> <SITE>"
    
    version = "$Revision: 1.2 $"
    
    description = "Register Files In Dataset"

    toolOptions = [cliutil.opt_dataset_version, 
                    optparse.make_option(
                    "-t", "--threshold",
                    dest="threshold",
                    default=None,
                    type='int',
                    help="Specify threshold"),

                   ]
    
    
    def __init__(self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0], self.args[1]


    def execute (self):
        """
        (since 0.3.0)
        """

        dq = getDQ2(self)

        pool = None
    
        dsn, location = self._get_parameters()
        

        status = dq.checkDatasetConsistency(location,dsn, version=self.options.version, threshold=self.options.threshold)
        
        if status:
            print "Refresh request took into account for Dataset %s " % (dsn)
        else:
            print "Refresh request was not taken into account for Dataset %s " % (dsn)            
            
