"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import commands, os, sys

class StorageThread:
    """
    @since: 0.3.0
    """    
    
    def __init__(self, command):
        """
        @since: 0.3.0
        """
        self.command = command
        
    def run(self):
        """
        @since: 0.3.0
        """
        
        self.__transfer()
        
        self.__validate()

    def __transfer(self):
        """
        @since: 0.3.0
        """

        self.alive = True

        print '%s: starting (you will not see output until the command is finished)'%self.command

        status, output = commands.getstatusoutput(self.command)
        
        if status:
            print '%s: exited with fatal error'%self.command
            print output
        else:
            print '%s: done'%self.command

    def __validate(self):
        """
        @since: 0.3.0
        """
        
        pass
       
    def die(self):
        """
        @since: 0.3.0
        """
        
        self.alive = False
        print '%s: killing remaining storagetool',self.name
        sys.stdout.flush()
        try:
            os.kill(self.pipe.pid, signal.SIGKILL)
        except:
            pass