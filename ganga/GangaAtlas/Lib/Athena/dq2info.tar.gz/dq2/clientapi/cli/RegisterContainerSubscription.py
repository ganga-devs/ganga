"""
Register container subscription command.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.9
@version: $Id: RegisterContainerSubscription.py,v 1.3 2009/10/27 13:08:55 vgaronne Exp $
"""


import cliutil

from dq2.common import optparse

from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common.DQException import DQException

from dq2.clientapi.cli.cliutil import getDQ2, option_value

from dq2.subscription.DQSubscriptionConstants import *


class RegisterContainerSubscription (DQDashboardTool):

    usage = "%prog [options] <CONTAINER> <SITE>"
    
    version = "$Revision: 1.3 $"
    
    description = "Register Container Subscription"

    toolOptions = [
        optparse.make_option(
            "-a", "--archive",
            action="store_true",
            dest="archive",
            default=False,
            help="archive container on destination site (by default false)"
        ),
        optparse.make_option(
            "-w", "--wait-for-source",
            action="store_true",
            dest="wait",
            default=0,
            help="wait for sources to appear (by default false)"
        ),
        optparse.make_option(
            "-s", "--sources",
            dest="sources",
            default=None,
            help="comma-separated list of possible user source sites (if not given it uses exclusively all possible complete and incomplete sources)"
        ),
        optparse.make_option(
            "-q", "--do-not-query-more-sources",
            action="store_false",
            dest="query",
            default=1,
            help="do not query more sources (if not given it will query)"
        ),
        optparse.make_option(
            "-d", "--destination",
            dest="destination",
            default=None,
            help="new destination base path"
        ),
        optparse.make_option(
            "-S", "--share",
            dest="sshare",
            default=None,
            help="subscription share"
        ),
        optparse.make_option(
            "-g", "--group",
            dest="group",
            default=None,
            help="Option to deleguate the group ownership. It needs the admin. rigths"
        ),

        optparse.make_option(
            "-c", "--activity",
            dest="activity",
            default=None,
            help="activity"
        ),
        
    ]
    
    
    def __init__ (self):
        """
        @since: 0.3.9
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 0.3.9
        """
        return (self.args[0], self.args[1])


    def execute (self):
        """
        @since: 0.3.9
        """

        dq = getDQ2(self)
    
        dsn, location = self._get_parameters()

        sources_policy = 0
        sources = {}
        callbacks = {}
        
        if self.options.sources is not None:
            """we support only LRC lookups on the cmd line tool for now"""
            sources_policy |= SourcesPolicy.KNOWN_SOURCES
            srcs = self.options.sources.split(',')
            for src in srcs:
                sources[src] = { 'policy': SourceResolverPolicy.LRC_LOOKUP }
        
        if sources_policy == 0:
            """user didn't specify policy => use COMPLETE and INCOMPLETE"""
            sources_policy = SourcesPolicy.COMPLETE_SOURCES | SourcesPolicy.INCOMPLETE_SOURCES
        
        if self.options.archive is False:
            """user didn't set archive option"""
            self.options.archive = SubscriptionArchivedState.UNARCHIVE
            txt_archive = 'unarchived'
        else:
            """user set archive option"""
            self.options.archive = SubscriptionArchivedState.ARCHIVE
       
        if self.options.query is False:
            self.options.query = 0
        elif self.options.query is True:
            self.options.query = 1
        
        if self.options.wait is False:
            self.options.wait = 0
        elif self.options.wait is True:
            self.options.wait = 1
        
        for dataset in dq.listDatasetsInContainer(dsn):
            """go through all data sets of the container"""
            
            try:
                dq.registerDatasetSubscription(dataset,
                                           location,
                                           archived=self.options.archive,
                                           sources=sources,
                                           callbacks=callbacks,
                                           sources_policy=sources_policy,
                                           wait_for_sources=self.options.wait,
                                           destination=self.options.destination,
                                           query_more_sources=self.options.query,
                                           sshare=self.options.sshare,
                                           group=self.options.group,
                                           activity=self.options.activity                                           
                )
                
                print "Dataset %s subscribed (archived: %s) to %s." % (dataset, self.options.archive, location)
                
            except DQException, e:
                print str(e)
