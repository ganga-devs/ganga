"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ListDatasetsByCreationDate.py,v 1.15 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common import optparse
from dq2.common.DQException import DQInvalidRequestException
from dq2.common.DQConstants import DateCriteria
from dq2.location.DQLocationConstants import LocationState

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class ListDatasetsByCreationDate (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] --younger|--older <SECONDS>"
    
    version = "$Revision: 1.15 $"
    
    description = "List Datasets By Creation Date"
    
    toolOptions = [
        optparse.make_option(
            "--dataset",
            dest="dataset", default=None,
            help="if given, specify a dataset name"
        ),
        optparse.make_option(
            "--site",
            dest="location", default=None,
            help="if given, specify a dataset location"
        ),
        optparse.make_option(
            "-i", "--incomplete",
            action="store_true",
            dest="incomplete",
            default=False,
            help="only list incomplete datasets"
        ),
        optparse.make_option(
            "-c", "--complete",
            action="store_true",
            dest="complete",
            default=False,
            help="only list complete datasets"
        ),
        optparse.make_option(
            "--younger",
            action="store_true",
            dest="criteria_leq",
            default=False,
            help="criteria less or equal to"
        ),
        optparse.make_option(
            "--older",
            action="store_true",
            dest="criteria_geq",
            default=False,
            help="criteria greater or equal to"
        )
    ]


    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]

        
    def execute (self):
        """
        @since: 0.3.0
        """
        

        dq = getDQ2(self)
        
        if (
            not self.options.criteria_leq
            and not self.options.criteria_geq
        ):
            raise DQInvalidRequestException('One and only one date criteria is mandatory: --younger|--older <SECONDS>')
            
        
        try:
            seconds = int(self._get_parameters())
        except:
            raise DQInvalidRequestException('Please provide the interval in seconds')
        
        # setup criteria value
        criteria = None
        if self.options.criteria_leq:
            criteria = DateCriteria.LEQ
        if self.options.criteria_geq:
            criteria = DateCriteria.GEQ
        
        # setup coomplete value
        complete = LocationState.__ANY__
        if self.options.complete and self.options.incomplete:
            raise DQInvalidRequestException('Complete and incomplete criteria are mutually exclusive')

        if self.options.complete:
            complete = LocationState.COMPLETE
        if self.options.incomplete:
            complete = LocationState.INCOMPLETE
        
        # executing command
        out = ''
        ret = dq.listDatasetsByCreationDate(
            seconds,
            criteria,
            dsn=self.options.dataset,
            location=self.options.location,
            complete=complete
        )

        for dsn in ret.keys():
            print '%s' % (dsn)