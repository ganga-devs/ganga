"""
Load aspects for dq2.clientapi.cli

Order is important
"""


from dq2.clientapi.cli.aspects.exception import wrap_package
wrap_package()