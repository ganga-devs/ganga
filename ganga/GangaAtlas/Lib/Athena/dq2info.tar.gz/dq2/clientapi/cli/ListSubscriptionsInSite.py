"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ListSubscriptionsInSite.py,v 1.9 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.subscription.DQSubscriptionConstants import SubscriptionArchivedState

from dq2.repository.client.RepositoryClient import RepositoryClient


class ListSubscriptionsInSite (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] <SITENAME> "
    
    version = "$Revision: 1.9 $"
    
    description = "List Subscriptions In Site"

    toolOptions = []
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]
        
        
    def execute (self):
        """
        @since: 0.3.0
        """
    
        dq = getDQ2(self)

        location = self._get_parameters()
        
        out = ''       
        ret = dq.listSubscriptionsInSite(site=location)
        
        for dsn in ret.keys():
            for version in ret[dsn]:
                print '%s' % version,
            print '\t%s' % dsn