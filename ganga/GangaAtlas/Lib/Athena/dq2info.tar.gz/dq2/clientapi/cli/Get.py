"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import os, sys, commands, time, getopt, md5, re, random, string, socket

import cliutil

from dq2.clientapi.DQ2 import DQ2

from dq2.common import optparse, generate_uuid
from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common.DQException import DQException

from dq2.common.threadpool import WorkRequest, ThreadPool

from dq2.clientapi.cli.util.Error import ErrorCode, ExceptionHandler
from dq2.clientapi.cli.util.GetDatasetThread import DatasetThread

from dq2.info import TiersOfATLAS, TiersOfATLASValidator

from dq2.location.DQLocationConstants import LocationState
from copy import deepcopy


from dq2.filecatalog import create_file_catalog

class Get(DQDashboardTool):
    """
    @since: 0.0.1

    @author: Mario Lassnig <mario.lassnig@cern.ch>
    @version: $Id: Get.py,v 1.9 2010/02/10 14:27:33 angelos Exp $
    """

    usage = "%prog [-h/--help | options] <DATASET>"

    version = "$Revision: 1.9 $"
    
    description = \
"""\
Get a dataset from grid mass storage to local disk.

For more information, go here: https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2ClientsHowTo
"""

    toolOptions = [
        cliutil.opt_dataset_version,
        optparse.make_option(
            '-L', '--local-site',
            dest='local',
            default=None,
            help='Override environment variable DQ2_LOCAL_SITE_ID'
        ),
        optparse.make_option(
            '-a', '--automatic',
            dest='automatic',
            action="store_true",
            default=False,
            help='Do not prompt - assume yes on all questions'
        ),
        optparse.make_option(
            '-d', '--debug',
            action='store_true',
            dest='debug',
            default=False,
            help='Print debug output' 
        ),
        optparse.make_option(
            '-D', '--no-directories',
            action='store_true',
            dest='noDirectories',
            default=False,
            help='Do not make directories per dataset' 
        ),
        optparse.make_option(
            '-F', '--read-from-file',
            dest='readFromFile',
            default=None,
            help='Read dataset names from textfile (limited usage yet)'
        ),
        optparse.make_option(
            '-s', '--site',
            dest='remote',
            default=None,
            help='Force remote site to copy from'
        ),
        optparse.make_option(
            '-i', '--incomplete',
            action='store_true',
            dest='incomplete',
            default=False,
            help='Only use incomplete datasets'
        ),
        optparse.make_option(
             '-c', '--complete',
             action='store_true',
             dest='complete',
             default=False,
             help='Only use complete datasets'
        ),
        optparse.make_option(
             '-f', '--files',
             dest='files',
             default=[],
             help='Select only single files from dataset (comma separated, no blanks)'
        ),
        optparse.make_option(
            '-n', '--nsample',
            dest='nsample',
            default=None,
            help='Get a random sample of n files from the dataset'
        ),
        optparse.make_option(
             '-p', '--protocol',
             dest='protocol',
             default='lcg',
             help='Force protocol (ng,lcg,lcg1,srm,dcap,rfio,castor,dpm,glite,xrd,custom)'
        ),
        optparse.make_option(
             '-P', '--pool-xml',
             dest='pool-xml',
             action='store_true',
             default=False,
             help='After a successful get, create the corresponding xml pool file catalogue'
        ),
        optparse.make_option(
             '-t', '--timeout',
             dest='timeout',
             default='600',
             help='Number of seconds to wait on a stalled transfer (default 600)'
        ),
        optparse.make_option(
             '-S', '--to-storage',
             dest='toStorage',
             default=None,
             help='Force to get into this SRMv2 location; must specify full SRMv2 path with port, manager and SFN (honors -D)'
        ),
        optparse.make_option(
             '-H', '--to-here',
             dest='toDirectory',
             default=None,
             help='Get the files directly into this directory'
        ),
        optparse.make_option (
             '-V', '--skip-check',
             dest='skipCheck',
             default=False,
             action='store_true',
             help='On subsequent get operations skip the verification of already downloaded files'
        ),
        optparse.make_option(
             '-k', '--space-token',
             dest='toStorageToken',
             default=None,
             help='Force space token for -S'
        ),
        optparse.make_option(
             '-T', '--threads',
             dest='threads',
             default='3,3',
             help='Number of concurrent dataset and file (D/F) threads, given in notation D,F (default 3,3)'
        ),
        optparse.make_option(
             '-N', '--client-id',
             dest='clientId',
             default=None,
             help='Client identification (6 characters max). Warning: DQ2 Externals ONLY!' 
        ),
        optparse.make_option(
            '-Y','--no-domain-check',
            dest='noDomainCheck',
            action='store_true',
            default=False,
            help='Warning: Batch-cluster ONLY!'
        ),
        optparse.make_option(
            '-Z','--dry-run',
            dest='dryRun',
            action='store_true',
            default=False,
            help='Only recheck already downloaded files'
        ),
    ]


    def __init__(self):
        """
        @since: 0.0.1
        """
        
        try:
            os.environ['DQ2_ENDUSER_SETUP'] 
        except:
            print 'Please setup the DQ2Clients environment!'
            print 'More information: https://twiki.cern.ch/twiki/bin/view/Atlas/DistributedDataManagement'
            sys.exit(-1)

        try:
            import urllib2
            urlstream = urllib2.urlopen('http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache/DQ2GETLATEST')
            remoteVersion = urlstream.read()
            if self.version.split()[1] != remoteVersion.replace('\n',''):
                print
                print 'You are not using the latest released stable version of the DQ2 clients!'
                print
                print 'Please check https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2Clients for the newest version number, go to the directory where you installed them and do:'
                print
                print '  pacman -get "http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache:DQ2Clients | version(\'version number\')"'
                print
                print 'For example:'
                print
                print '  pacman -get "http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache:DQ2Clients | version(\'0.1.13\')"'
                print
                print 'RPM installations can be upgraded with yum or apt.'
                print 'Please see the documentation for details.'
                print
        except:
            print 'Cannot verify client tools version! You might not use the latest released stable version!'

        DQDashboardTool.__init__(self)

        self.__dq2 = DQ2()

        self.t_results = [] # Stores execution status returned by threads

        self.DatasetHits = {}   # Dataset histogram, used for random sample 

    def __printVersion(self):
        """
        @since: 0.0.1
        """
        self.__debug('dq2-get %s'%self.version.split()[1])

    def __selectSite(self):
        """
        @since: 0.0.1
        """

        #are we overriding the environment?
        if self.options.local is not None:
            self.DQ2_LOCAL_SITE_ID = self.options.local
        else:
            #no? so check environment
            try:
                self.DQ2_LOCAL_SITE_ID = os.environ['DQ2_LOCAL_SITE_ID']
            except KeyError:
                raise Exception('You must set your TiersOfATLAS site - check with your system administrator! (Override with -L or environment variable DQ2_LOCAL_SITE_ID)')

        if self.DQ2_LOCAL_SITE_ID == 'ROAMING':
            print 'Using ROAMING profile'
            return

        #is it a valid Tiers of ATLAS site?
        TiersOfATLASValidator.is_site(self.DQ2_LOCAL_SITE_ID)
        self.report['localSite'] = self.DQ2_LOCAL_SITE_ID
        
        if len(TiersOfATLAS.getSites(self.DQ2_LOCAL_SITE_ID))>1:
            print 'Group of sites selected, skipping domain name check'
        else:    
            hostDomain = string.join(socket.gethostbyaddr(socket.gethostname())[0].split('.')[-2:], '.')
            toaDomain = TiersOfATLAS.getSiteProperty(self.DQ2_LOCAL_SITE_ID, 'domain')
            
            if toaDomain is None:
                print
                print 'Attention!'
                print
                print 'You have selected a site that is not in TiersOfATLAS.'
                print 'While this is not a problem for dq2-get, you will not be able to use dq2-put.'
                print 'Please ask your system administrator which sitename you should use.'
                print
                if not self.__yesno('Do you want to continue with this setting?'):
                    raise Exception('Aborted!')
            
            if self.DQ2_LOCAL_SITE_ID.startswith('CERN-PROD'):
                if hostDomain == 'unige.ch':
                    print 'CERN AFS override for unige.ch Tier-3'
                    return
            
            if not self.options.noDomainCheck:
                if toaDomain is not None and hostDomain not in toaDomain:
                    print
                    print 'Attention!'
                    print
                    print 'Your host-domain (%s) does not verify against the selected DQ2 site identification (%s)!'%(hostDomain, self.DQ2_LOCAL_SITE_ID)
                    print 'Though this is not fatal, it can seriously deteriorate dq2-get performance.'
                    print 'It is in your best interest to set the environment variable DQ2_LOCAL_SITE_ID to a correct value.'
                    print 'You can list all possible values for DQ2_LOCAL_SITE_ID with the command: dq2-sources'
                    print 'If you are not connected to any ToA site, please use ROAMING as your DQ2_LCOAL_SITE_ID.' 
                    print 'Change your environment to use the appropriate one.'
                    print
                    #print 'In case of questions, please contact atlas-dq2-support@cern.ch'
                    print 'In case of questions, please check in DQ2ClientsHowTo Twiki,'
                    print 'https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2ClientsHowTo' 
                    print
                    if not self.__yesno('Do you want to continue with the wrong setting?'):
                        raise Exception('Aborted!')
            
    def __checkForCertificate(self):
        """
        @since: 0.0.1
        """
        
        self.report['clientState'] = 'CHECK_CERT'
        
        proxycheck = 'voms-proxy-info'
        
        status, output = commands.getstatusoutput('%s -e'%proxycheck)

        if 'command not found' in output:
            print 'WARNING: Missing voms-proxy-init binary. Unable to verify proxy at the client. Continuing!'
            proxycheck = 'grid-proxy-info'
            status, output = commands.getstatusoutput('%s -e'%proxycheck)
            if 'command not found' in output:
                raise Exception('Missing both voms-proxy-info and grid-proxy-info binaries. Please use the correct setup.sh!')
                sys.exit(ErrorCode.ERROR)
        elif status != 0:
            raise Exception('Missing voms proxy. Create one with: voms-proxy-init -voms atlas')
            sys.exit(ErrorCode.ERROR)

        #anonymise the user identity
        m=md5.new()
        m.update(commands.getstatusoutput('%s -identity' %proxycheck)[1])
        self.report['usr'] = m.hexdigest()
        self.report['usrdn'] = commands.getstatusoutput('%s -identity' %proxycheck)[1]

    def __initReport(self):
        """
        @since: 0.0.1
        """

        eventType = 'get'
        if self.options.clientId is not None:
            eventType += '_%s'%self.options.clientId

        self.report = {
                      'uuid': generate_uuid().replace('-',''),
                      'eventType': eventType[:10],
                      'eventVersion': self.version.split()[1],
                      'remoteSite': None,
                      'localSite': None,
                      'timeStart': time.time(),
                      'catStart': None,
                      'relativeStart': None,
                      'transferStart': None,
                      'validateStart': None,
                      'timeEnd': None,
                      'duid': None,
                      'version': None,
                      'dataset': None,
                      'clientState': 'INIT_REPORT',
                      'protocol': None,
                      'filename': None,
                      'filesize': None,
                      'guid': None,
                      'usr': None,
                      'hostname': socket.gethostbyaddr(socket.gethostname())[0],
                      'ip': socket.gethostbyaddr(socket.gethostname())[2][0],
                      'suspicious': 0,
                      'appid': None,
                      'usrdn': None
                      }

    def __readFromFile(self, filename):
        """
        @since: 0.0.1
        
        Reading dataset names from files is limited yet.
        The file should have the following format:
        
        datasetname
        datasetname
        datasetname
        ...
        
        with optionally selecting files of a dataset like this:
        
        datasetname
        +file
        +file
        +file
        ...
        datasetname
        +file
        ...
        datasetname
        ...

        """
        
        print 'Reading dataset names from file'
        
        datasetList = []

        #read the file
        file = open(filename, 'r')
        fileString = file.readlines()
        file.close()
        
        #don't forget to strip the trailing \n and ignore empty lines
        for line in fileString:
            dataset = []
            if line != '\n':
                if not line[0].startswith('+'):
                    datasetList.append(line[:-1].strip())

        newDatasetList = {}
        
        #process possible wildcards and merge
        for dataset in datasetList:
            newDatasetList.update(self.__parseWildcards(dataset, 0))        
        
        #second parse to get the required files
        for dataset in newDatasetList:
            newDatasetList[dataset]['files'] = []
            
            count = 0
            for line in fileString:
                count += 1
                if dataset == line[:-1].strip():
                    for lineFile in fileString[count:]:
                        if lineFile.startswith('+'):
                            newDatasetList[dataset]['files'].append(lineFile[1:-1].strip())
                        else:
                            break
        
        return newDatasetList

    def __parseWildcards(self, pattern, version, message=True):
        """
        @since: 0.0.1
        """
        
        self.report['clientState'] = 'PARSE_WILDCARD'
        
        if message:
            print 'Querying DQ2 central catalogues to resolve datasetname',pattern
            sys.stdout.flush()
        
        #is this a container?
        if pattern.endswith('/') and '*' not in pattern:

            dsns = {}
            
            datasets = self.__dq2.listDatasetsInContainer(pattern)
            
            for ds in datasets:
                dsns[ds] = {'vuids':self.__dq2.listDatasets(ds)[ds]['vuids'],'duid':self.__dq2.listDatasets(ds)[ds]['duid']}
            
            return dsns
        
        #wildcard container?
        elif pattern.endswith('/') and '*' in pattern:
            
            collection = []
            dsns = {}
            
            collection = self.__dq2.listDatasets(dsn=pattern, version=version)
            
            datasets = []
            #make sure we extract only unique dataset names from all containers
            for dsorcontainer in collection:
                tmp = None
                try:
                    tmp = self.__dq2.listDatasetsInContainer(dsorcontainer)
                except:
                    pass
                if tmp is not None:
                    for t_tmp in tmp:
                        if t_tmp not in datasets:
                            datasets.append(t_tmp)
                    
            for ds in datasets:
                dsns[ds] = {'vuids':self.__dq2.listDatasets(ds)[ds]['vuids'],'duid':self.__dq2.listDatasets(ds)[ds]['duid']}
                    
            return dsns
            
        else:
            return self.__dq2.listDatasets(dsn=pattern, version=version)

    def handle_results(self, request, result):
        #print "**** Result from request #%s: %r" % (request.requestID, result)
        if result != None and result != []:
            self.t_results.append(result)

    
    def __workDatasets(self, datasetList):
        """
        @since: 0.0.1
        
        datasetList = (datasetname, version, [selected files] or None, complete, duid)
        """
        
        self.report['clientState'] = 'WORK_DATASET'
        
        datasetThreads = ThreadPool(self.options.nrDatasetThreads)
         
        #create all necessary threads
        for dataset in datasetList:
            if self.DatasetHits != {}:
                self.options.nsample = self.DatasetHits[dataset[0]]
             
            current = DatasetThread(dataset, self.options.noDirectories, self.DQ2_LOCAL_SITE_ID, self.options.nrFileThreads, deepcopy(self.report), self.options.timeout, self.options.debug, self.options.protocol, self.options.toStorage, self.options.skipCheck, self.options.toDirectory, self.options.nsample, self.options.toStorageToken, self.options.dryRun)
            work = WorkRequest(current.run, callback= self.handle_results)  
            datasetThreads.putRequest(work)

        datasetThreads.wait()
        datasetThreads.dismissWorkers(self.options.nrDatasetThreads)
        datasetThreads.joinAllDismissedWorkers() 
        
    def __printStatus(self):
        if self.options.debug == True:
            if self.t_results is not None:
                success_count = 0
                failed_count = 0
                for dataset in self.t_results:
                    print "Threads report:"
                    if dataset is not None:
                        for file in dataset:
                            if file[1]=='DONE':
                                print "File: %s, SUCCESSFUL" % file[0]
                                success_count += 1
                            else:
                                print "File: %s, FAILED" % file[0]
                                failed_count += 1
                total = success_count + failed_count
                if total != 0:
                    print "Total number of File download attempts reported by threads: %s" % total
                    print "Number of Successful File Attempts reported by threads: %s" % success_count
                    print "Number of Failed File Attempts reported by threads: %s" % failed_count
                else:
                    print "No attempts made by threads"
            else:
                print "No attempts made by threads"
        
    def __createPoolXML(self):
        """
        @since: 0.0.1
        """
        
        if self.options.pool:
            
            xmlHeader = \
"""<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<!DOCTYPE POOLFILECATALOG SYSTEM "InMemory">
<POOLFILECATALOG>
"""

            fileEntry = \
"""
<File ID="%s">
  <physical>
    <pfn filetype="ROOT_All" name="%s"/>
  </physical>
  <logical>
    <lfn name="%s"/>
  </logical>
</File>
"""
            xmlFooter = \
"""
</POOLFILECATALOG>
"""            
            
            xml = xmlHeader

            if self.DQ2_LOCAL_SITE_ID == 'ROAMING':
                print 'Please use dq2-ls to create a PoolFileCatalog.xml for ROAMING profiles (like Tier-3s, unmanaged storage, etc...)'
                
            else:
    
                for dataset in self.__parseWildcards(self.options.pattern, self.options.version, message=False):
    
                    print 'Processing %s with PoolFileCatalog.xml'%dataset
                    
                    catCheck = {}
                        
                    filesInDataset = self.__dq2.listFilesInDataset(dataset, version=self.options.version)
    
                    if len(filesInDataset) > 0:
                        for guid in filesInDataset[0]:
                            catCheck[guid] = filesInDataset[0][guid]['lfn']
    
                        
                        #bulk find replicas to the local catalogues
                        catalog = create_file_catalog(TiersOfATLAS.getLocalCatalog(str(self.DQ2_LOCAL_SITE_ID)))
                        catalog.connect()
                        tmp_response = catalog.bulkFindReplicas(catCheck)
                        response = catalog.filterSiteReplicas(tmp_response,[str(self.DQ2_LOCAL_SITE_ID)])
                        catalog.disconnect()
    
                        #only add new guids
                        if os.path.exists('PoolFileCatalog.xml'):
    
                            existingCatalog = open('PoolFileCatalog.xml','r')
                            existingLines = existingCatalog.readlines()                    
                            existingCatalog.close()
                            
                            toDelete = []
                            
                            for line in existingLines:
                                for guid in response:
                                    if guid in line and guid not in toDelete:
                                        toDelete.append(guid)
    
                            for deleteMe in toDelete:
                                del response[deleteMe]
            
                            toAdd = ''
                            for guid in response:
                                srm = str(random.choice(response[guid]['surls']))
                                if self.options.toDirectory is not None:
                                    localfilepath='/%s%s' % (self.options.toDirectory, srm[string.rfind(srm,'/'):])
                                elif self.options.toStorage is not None:
                                    localfilepath='%s/%s'%(self.toStorage, srm[string.rfind(srm,'/'):])
                                elif self.options.noDirectories:
                                    localfilepath='/%s%s' % (os.getcwd(), srm[string.rfind(srm,'/'):])
                                else:
                                    localfilepath='/%s/%s%s' % (os.getcwd(), dataset, srm[string.rfind(srm,'/'):])
                                toAdd = toAdd + fileEntry%(guid, localfilepath, response[guid]['lfn'])
                        
                            existingLines.insert(4, toAdd)
                            
                            os.unlink('PoolFileCatalog.xml')
                            newCatalog = open('PoolFileCatalog.xml','w')
                            for line in existingLines:
                                newCatalog.write(line)
                            newCatalog.close()
                        
                        else:
                            for guid in response:
                                srm = str(random.choice(response[guid]['surls']))
                                if self.options.toDirectory is not None:
                                    localfilepath='file:///%s%s' % (self.options.toDirectory, srm[string.rfind(srm,'/'):])
                                elif self.options.toStorage is not None:
                                    localfilepath='%s/%s'%(self.toStorage, srm[string.rfind(srm,'/'):])
                                elif self.options.noDirectories:
                                    localfilepath='file:///%s%s' % (os.getcwd(), srm[string.rfind(srm,'/'):])
                                else:
                                    localfilepath='file:///%s/%s%s' % (os.getcwd(), dataset, srm[string.rfind(srm,'/'):])
                                
                                xml = xml + fileEntry%(guid, localfilepath, response[guid]['lfn'])
                
                            xml = xml + xmlFooter
                
                            xmlFile = open('PoolFileCatalog.xml','w')
                            xmlFile.write(xml)
                            xmlFile.close()

    def execute(self):
        """
        @since: 0.0.1
        """
        
        self.options = Options(sys.argv[1:])
        
        self.__printVersion()

        if self.options.help:
            print self.usage
        else:
            
            try:
            
                self.__initReport()
            
                self.__selectSite()
                
                self.__checkForCertificate()       
        
                #do we want to put onto mass-storage? if yes, make sure that
                #it does not get put into dq2-managed areas
                if self.options.toStorage is not None:
                    domains=[]

                    for site in TiersOfATLAS.getAllDestinationSites():
                        try:
                            to_append=TiersOfATLAS.getSiteProperty(site, 'domain')
                            if to_append != '.*':
                                domains.append(to_append)
                        except:
                            pass #no domain entry
 
                    for site in domains:
                        result=re.match(site, self.options.toStorage)
                        if result is not None:
                            raise Exception('You are not allowed to dq2-get into this DQ2 managed area: %s'%site)

                datasetList = []
        
                if self.options.readFromFile is not None:
                    datasetList = self.__readFromFile(self.options.readFromFile)
                    print 'Note: If you have specified a file pattern for a dataset then the -f option is ignored!'
                else:
                    datasetList = self.__parseWildcards(self.options.pattern, self.options.version)
                
                if not len(datasetList):
                    raise Exception('No datasets found')
                else:
                    print 'Datasets found:',len(datasetList)
                
                DatasetFileNo = {} # Datasets and how many files they have
                Datasets = []      # List of Datasets that still have space
                
                # Random sample of files from random datasets
                if self.options.nsample is not None:
                    print "Generating random sample of datasets"
                    # First lets gets list of datasets and corresponding number of files 
                    for element in datasetList.keys():
                        DatasetFileNo[element] = DQ2().getNumberOfFiles(dsn=element)
                        self.DatasetHits[element] = 0
                        Datasets.append(element) 
                
                    # Second lets create a histogram of datasets
                    for i in range(0,self.options.nsample):
                        select_d, = random.sample(Datasets,1)
                        self.DatasetHits[select_d] += 1
                        if self.DatasetHits[select_d] == DatasetFileNo[select_d]: # If maximums reached
                            Datasets.remove(select_d)
                        if len(Datasets) == 0:
                            break;
                                      
                    
                    for i in self.DatasetHits.keys():
                        print str(i) + " " + str(self.DatasetHits[i])
                
               # for i in self.DatasetHits.keys():
               #    if self.DatasetHits[i] > 0:
                #        datasetList.append(i)
                
                
                newDatasetList = []
                
                #select only one if we have multiple datasets
   #             if self.options.nsample is not None:
  #                  selected = random.sample(datasetList,1)
 #                   tmp = {}
#                    tmp[selected[0]] = datasetList[selected[0]]
    #                datasetList = tmp

                for element in datasetList:

                    #do we filter from a file?
                    if 'files' in datasetList[element].keys():
                        if datasetList[element]['files'] != []:
                            self.options.files = datasetList[element]['files']  
                    
                    if self.options.nsample is not None:
                        if self.DatasetHits[element] !=0: # Run this if condition only if we are using random samples
                            newDatasetList.append((element,self.options.version, self.options.complete, self.options.files, self.options.remote, datasetList[element]['duid']))
                    else:
                        newDatasetList.append((element,self.options.version, self.options.complete, self.options.files, self.options.remote, datasetList[element]['duid']))
                self.__workDatasets(newDatasetList)

                #I hate this, but it's necessary to give Python time to
                #shutdown all threads correctly before dying
                #(fixed in Python 2.5.2, let's wait for the LCG release...)
                time.sleep(0.25)
               
                self.__createPoolXML()
                
                self.__printStatus() 
                
                print 'Finished'

            except:
                excType, excValue, excStack = sys.exc_info()
                print excValue
                
    def __debug(self, *messages):
        """
        @since: 0.0.1
        """
        
        if self.options.debug:
            for message in messages:
                print message,
                print

    def __yesno(self, *messages):
        """
        @since: 0.0.1
        """
        
        for message in messages:
            print message,
        print '(y/n)?',
        
        if self.options.automatic:
            print
            print 'Automatic confirm'
            return True
        
        else:
            response = raw_input()
            
            while response not in ['yes', 'y', 'Y', 'Yes', 'YES', 'no', 'n', 'N', 'No', 'NO']:
                print 'Invalid response! Please answer (y/n)?',
                response = raw_input()
    
            if response in ['yes', 'y', 'Y', 'Yes', 'YES']:
                return True
            else:
                return False

class Options:
        """
        @since: 0.0.1
        """

        def __init__(self, arguments):
            """
            @since: 0.0.1
            """
            
            self.help = False
            self.automatic = False
            self.version = 0
            self.pattern = None
            self.file = None
            self.noDirectories = False
            self.readFromFile = None
            self.local = None
            self.localcopy = False
            self.files = []
            self.remote = None
            self.complete = LocationState.__ANY__
            self.nrDatasetThreads = 3
            self.nrFileThreads = 3
            self.timeout = 600
            self.debug = False
            self.protocol = None
            self.pool = False
            self.toStorage = None
            self.skipCheck = False
            self.relativePath = None
            self.toDirectory = None
            self.nsample = None
            self.toStorageToken = None
            self.noDomainCheck = False
            self.clientId = None
            self.dryRun = False
            self.__parseArguments(arguments)

        def __parseArguments(self, arguments):
            """
            @since: 0.0.1
            """
            
            try:
                optlist, args = getopt.getopt(arguments, 'N:k:F:aidPn:DH:L:cs:f:v:t:T:p:S:VYZ',
                ['read-from-file=','space-token=','client-id=','to-storage=','automatic','no-domain-check','nsample=','pool-xml','to-here=','skip-check','threads=','timeout=','complete','protocol=','files=','site=','dataset-version=','no-directories','incomplete','local-site=','version=','debug','dry-run'])
                
                self.pattern = arguments[-1]
                
                #set the state according to the arguments
                for o, a in optlist:
                    if o in ('-h', '--help'):
                        self.help = True
                    if o in ('-a', '--automatic'):
                        self.automatic = True    
                    if o in ('-v', '--dataset-version'):
                        self.version = int(a)
                    if o in ('-F', '--read-from-file'):
                        self.readFromFile = str(a)
                    if o in ('-d', '--debug'):
                        self.debug = True    
                    if o in ('-D', '--no-directories'):
                        self.noDirectories = True
                    if o in ('-i', '--incomplete'):
                        self.complete = LocationState.INCOMPLETE
                    if o in ('-c', '--complete'):
                        self.complete = LocationState.COMPLETE                    
                    if o in ('-L', '--local-site'):
                        self.local = str(a)
                    if o in ('-s', '--site'):
                        self.remote = str(a)
                    if o in ('-f', '--files'):
                        self.files = a.split(',')
                    if o in ('-t', '--timeout'):
                        self.timeout = int(a)
                    if o in ('-n', '--nsample'):
                        self.nsample = int(a)
                    if o in ('-p', '--protocol'):
                        self.protocol = str(a)
                    if o in ('-P', '--pool-xml'):
                        self.pool = True
                    if o in ('-V', '--skip-check'):
                        self.skipCheck = True
                    if o in ('-H', '--to-here'):
                        self.toDirectory = str(a)
                        if '..' in self.toDirectory:
                            raise Exception('No relative paths allowed for -H option!')
                    if o in ('-S', '--to-storage'):
                        self.toStorage = str(a)
                    if o in ('-k', '--space-token'):
                        self.toStorageToken = str(a)
                    if o in ('-N', '--client-id'):
                        self.clientId = str(a)
                    if o in ('-Y', '--no-domain-check'):
                        self.noDomainCheck = True
                    if o in ('-Z', '--dry-run'):
                        self.dryRun = True
                    if o in ('-T', '--threads'):
                        try:
                            self.nrDatasetThreads = int(a.split(',')[0])
                            self.nrFileThreads = int(a.split(',')[1])
                        except:
                            raise Exception('Please use format D,F when giving number of threads!')

            except getopt.GetoptError, getoptError:
                ExceptionHandler(getoptError)
            except ValueError, valueException:
                ExceptionHandler(valueException)
            except IndexError, indexError:
                print('Usage: dq2-get [-h/--help | options] <DATASET>')
                ExceptionHandler(indexError)
            except Exception, exception:
                ExceptionHandler(exception)