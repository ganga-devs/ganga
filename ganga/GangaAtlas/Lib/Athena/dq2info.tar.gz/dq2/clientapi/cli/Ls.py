"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import os, sys, commands, getopt, random, re, string

import cliutil

from dq2.common import optparse
from dq2.common.DQException import DQException
from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.info import TiersOfATLAS, TiersOfATLASValidator
from dq2.clientapi.DQ2 import DQ2
from dq2.clientapi.cli.util.Error import ErrorCode, ExceptionHandler
from dq2.location.DQLocationConstants import LocationState
from dq2.filecatalog import create_file_catalog

class Ls (DQDashboardTool):
    """
    @since: 0.0.1

    @author: Mario Lassnig <mario.lassnig@cern.ch>
    @version: $Id: Ls.py,v 1.6 2009/12/09 14:22:34 angelos Exp $
    """

    usage = "%prog [-h/--help | options] <PATTERN>"

    version = "$Revision: 1.6 $"
    
    description = \
"""\
List information about datasets matching a given pattern. The pattern
may contain wildcards which represents any string. The wildcard symbol
is the asterisk *. By default it will use complete and incomplete datasets.

For more information, go here: https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2ClientsHowTo
"""

    toolOptions = [
        cliutil.opt_dataset_version,
        optparse.make_option(
            '-f', '--files',
            dest='nfiles',
            action="store_true",
            default=False,
            help='Print files per dataset'
        ),
        optparse.make_option(
            '-r', '--replicas',
            dest='files',
            action="store_true",
            default=False,
            help='Print sites with replicas per dataset'
        ),
        optparse.make_option(
            '-L', '--local-site',
            dest='local',
            default=None,
            help='Override environment variable DQ2_LOCAL_SITE_ID'
        ),
        optparse.make_option(
            '-s', '--sites',
            dest='sites',
            default=None,
            help='Print datasets in site (do not use for file checks, use -L for that)'
        ),
        optparse.make_option(
            '-p', '--pfn',
            dest='pfn',
            action="store_true",
            default=False,
            help='Display the PFN in addition to -f/--files'
        ),
        optparse.make_option(
            '-P', '--pool',
            dest='pool',
            action="store_true",
            default=False,
            help='Create a PoolFileCatalog.xml for the given pattern'
        ),
        optparse.make_option(
            '-n', '--number',
            dest='number',
            action="store_true",
            default=False,
            help='Print number of files per dataset'
        ),
        optparse.make_option(
            '-m', '--missing',
            dest='missing',
            action="store_true",
            default=False,
            help='Print missing files for a given dataset (respects -L)'
        ),
        optparse.make_option(
            '-i', '--incomplete',
            action='store_true',
            dest='incomplete',
            default=False,
            help='Use incomplete datasets'
        ),
        optparse.make_option(
             '-c', '--complete',
             action='store_true',
             dest='complete',
             default=False,
             help='Use complete datasets'
        ),
        optparse.make_option(
             '-C', '--replica-container',
             action='store_true',
             dest='debug',
             default=False,
             help='Print replicas in container'
        ),
        optparse.make_option(
             '-d', '--debug',
             action='store_true',
             dest='debug',
             default=False,
             help='Print debug output'
        ),
        optparse.make_option(
             '-R', '--replace-io',
             dest='replaceio',
             default=None,
             help='Replace SRM host via formatted string on PoolFileCatalog creation. String must be: "regularexpression^newvalue" For example: srm://uct2-dc1.uchicago.edu(:[0-9]+)(/srm/managerv2?SFN=)/pnfs/^dcap:/pnfs/'
        ),
        optparse.make_option(
            '-G', '--guess-local',
            action='store_true',
            dest='guess',
            default=False,
            help='Guess the local protocol on PoolFileCatalog creation. Mutually exclusive with -R.'
        ),
        optparse.make_option(
            '-T', '--three',
            dest='three',
            default=None,
            help='Create a local PoolFileCatalogue for a Tier-3'
        ),
        optparse.make_option(
            '-H', '--human-readable',
            dest='human',
            default=False,
            help='Filesize in human readable format'
        ),
        optparse.make_option(
            '-z', '--page',
            dest='page_no',
            default=None,
            help='Specify page to print'
        ),
        optparse.make_option(
            '-Z', '--rpp',
            dest='rpp_value',
            default=None,
            help='Print rrp results first'
        ),
        optparse.make_option(
            '-D', '--dcap',
            action='store_true',
            dest='dcapo',
            default=None,
            help='Use with -P option. Use lcg-gt to get dcap TURLS for XML Pool file.'
            )
    ]

    
    def __init__(self):
        """
        @since: 0.3.0
        """

        try:
            os.environ['DQ2_ENDUSER_SETUP'] 
        except:
            print 'Please setup the DQ2Clients environment!'
            print 'More information: https://twiki.cern.ch/twiki/bin/view/Atlas/DistributedDataManagement'
            sys.exit(-1)
        
        
        self.__dq2 = DQ2()
        
        self.alreadyGuessedPFN = None
        
        DQDashboardTool.__init__(self)

    def __printVersion(self):
        """
        @since: 0.3.0
        """
        self.__debug('dq2-ls %s'%self.version.split()[1])

    def __checkForCertificate(self):
        """
        @since: 0.0.1
        """
        
        proxycheck = 'voms-proxy-info'
        
        status, output = commands.getstatusoutput('%s -e'%proxycheck)

        if 'command not found' in output:
            print 'WARNING: Missing voms-proxy-init binary. Unable to verify proxy at the client. Continuing!'
            proxycheck = 'grid-proxy-info'
            status, output = commands.getstatusoutput('%s -e'%proxycheck)
            if 'command not found' in output:
                raise Exception('Missing both voms-proxy-info and grid-proxy-info binaries. Please use the correct setup.sh!')
                sys.exit(ErrorCode.ERROR)
        elif status != 0:
            raise Exception('Missing voms proxy. Create one with: voms-proxy-init -voms atlas')
            sys.exit(ErrorCode.ERROR)

    def __selectSite(self):
        """
        @since: 0.0.1
        """
        
        #are we overriding the environment?
        if self.options.local is not None:
            self.DQ2_LOCAL_SITE_ID = self.options.local
        else:
            #no? so check environment
            try:
                self.DQ2_LOCAL_SITE_ID = os.environ['DQ2_LOCAL_SITE_ID']
            except KeyError:
                raise Exception('You must set your TiersOfATLAS site - check with your system administrator! (Override with -L or environment variable DQ2_LOCAL_SITE_ID)')

            if self.DQ2_LOCAL_SITE_ID == 'ROAMING':
                if self.options.debug:
                    print 'Using ROAMING profile'
                return

        #is it a valid Tiers of ATLAS site?
        if self.DQ2_LOCAL_SITE_ID != 'ROAMING':
            TiersOfATLASValidator.is_site(self.DQ2_LOCAL_SITE_ID)

    def __guessPFNfromSURL(self, surl):
        """
        Guess the PFN for a given SURL
        
        @since: 1.1.2.24
        @return: PFN
        """

        lcgct='lcg-gt'
        if self.alreadyGuessedPFN is not None:
            return surl.replace(self.alreadyGuessedPFN[0], self.alreadyGuessedPFN[1])
                
        else:
        
            if commands.getstatusoutput('which %s'%lcgct.split()[0])[0]:
                raise Exception('FATAL: lcg-gt binary not found. Cannot continue!')
            
            protocol_list = TiersOfATLAS.getProtocols(self.DQ2_LOCAL_SITE_ID) # Read protocols from Tiers of ATLAS

            if protocol_list == None: # If no protocols specified in ToA, use the old way
                print "Protocols not specified in ToA, trying to guess from SURL"
                if 'pnfs' in surl or 'triumf' in surl:
                    status, output = commands.getstatusoutput('%s %s %s'%(lcgct, surl, 'dcap gsidcap'))
                elif 'dpm' in surl or 'castor' in surl:
                    status, output = commands.getstatusoutput('%s %s %s'%(lcgct, surl, 'rfio castor dpm'))
                else:
                    status, output = commands.getstatusoutput('%s %s %s'%(lcgct, surl, 'gridftp gsiftp ftp posix'))
            else:
                print "Protocols entry found in ToA, using them to establish TURL"
                protocol_string = ""
                for i in protocol_list: # Transform list of strings into one large string delimeted by space
                    protocol_string += i + " "  
                if protocol_list[0]=='xroot': # For protocols unsupported by lcg-gt , use regexp to translate SURL
                    reg_e = TiersOfATLAS.getProtocolRegexp(self.DQ2_LOCAL_SITE_ID,'xroot')
                    if reg_e is not None: # If regexp is defined then
                        print "Protocol xroot found, using REGEXP defined in ToA"
                        SULR_part, TURL_part = reg_e.split('^')
                        output = re.sub(SULR_part,TURL_part,surl)
                        status=0                  
                    else:
                        raise Exception('FATAL: xroot regexp not defined in ToA. Cannot continue!')
                elif TiersOfATLAS.getProtocolRegexp(self.DQ2_LOCAL_SITE_ID,protocol_list[0]) is not None:
                    print "REGEXP found for protocol '%s'. Using it to generate TURLs from SURLS" % protocol_list[0]  
                    reg_e = TiersOfATLAS.getProtocolRegexp(self.DQ2_LOCAL_SITE_ID,protocol_list[0])
                    SULR_part, TURL_part = reg_e.split('^')
                    output = re.sub(SULR_part,TURL_part,surl)
                    status=0
                else: # For protocols supported by lcg-gt
                    print "Using LCG-GT to get TURLs"
                    status, output = commands.getstatusoutput('%s %s %s'%(lcgct, surl, protocol_string))
            
            if status == 0:
                #first line is the PFN
                tmp = output.split()[0]
                
                # the question mark
                tmp = tmp.split('?')[0]
                
                #set up the replacement-strings (figure out the overlap of the strings backwards)
                stop = None
                tb = len(tmp)-1
                for i in xrange(len(surl)-1,-1,-1):
                    if surl[i] == tmp[tb]:
                        tb -= 1
                    else:
                        stop = tb+1
                        break
                
                #found it? then store the overlaps for later
                if stop is not None:
                    self.alreadyGuessedPFN = (surl[:i+1], tmp[:stop])

                #return the good one for now
                return tmp
            else:
                #nothing found, return the SURL as is
                return surl

    def __listDatasets(self):
        """
        @since: 0.3.0
        """
    
        try:
            ret = self.__dq2.listDatasets(dsn=self.options.pattern, version=self.options.version, onlyNames=True,p=self.options.page_no,rpp=self.options.rpp_value)
            
            #format printout
            if len(ret) > 0:
                print '\n'.join([dsn for dsn in ret])

        except DQException, dqexception:
            ExceptionHandler(dqexception)
        except Exception, exception:
            ExceptionHandler(exception)

    def __listMissingInDatasets(self):
        """
        @since 1.1.2.25
        """
        
        if self.DQ2_LOCAL_SITE_ID == 'ROAMING':
            raise Exception('ROAMING is not a valid DQ2 site identifier!')
        
        try:
            ret = self.__dq2.listDatasets(dsn=self.options.pattern, version=self.options.version,onlyNames=True,p=self.options.page_no,rpp=self.options.rpp_value)

            if len(ret) > 0:
                
                for dsn in ret:
                    
                    ret2 = self.__dq2.listDatasetReplicas(dsn=dsn, version=self.options.version)
                    
                    breakNow = False
                    for duid in ret2:
                        if self.DQ2_LOCAL_SITE_ID not in ret2[duid][0] and self.DQ2_LOCAL_SITE_ID not in ret2[duid][1]:
                            print '%s not replicated to %s!'%(dsn, self.DQ2_LOCAL_SITE_ID)
                            breakNow = True
                            continue

                    if breakNow:
                        continue

                    ret3 = self.__dq2.listFilesInDataset(dsn=dsn, version=self.options.version)

                    response = {}
                    lfc = TiersOfATLAS.getLocalCatalog(str(self.DQ2_LOCAL_SITE_ID))
                    if lfc is not None:
                        catalog = create_file_catalog(lfc)
                        catalog.connect()
                        response2 = catalog.bulkFindReplicas(ret3[0])
                        response = catalog.filterSiteReplicas(response2, [str(self.DQ2_LOCAL_SITE_ID)])
                        catalog.disconnect()
                    else:
                        raise Exception('FATAL - could not contact LFC!')

                    countFiles = 0
                    missingFiles = 0

                    print dsn

                    for guid in ret3[0].keys():
                        countFiles += 1
                        if guid not in response.keys():
                            print ret3[0][guid]['lfn']
                            missingFiles += 1
        
                    print 'total files:',countFiles
                    print 'missing files:',missingFiles
                    print
        
        except DQException, dqexception:
            ExceptionHandler(dqexception)
        except Exception, exception:
            ExceptionHandler(exception)            

    def __listFilesInDatasets(self):
        """
        @since: 0.3.0
        """
           
        try:
            ret = self.__dq2.listDatasets(dsn=self.options.pattern, version=self.options.version, onlyNames=True,p=self.options.page_no,rpp=self.options.rpp_value)

            #for each dataset matching the pattern display all files
            if len(ret) > 0:
            
                for dsn in ret:
                    
                    ret2 = self.__dq2.listFilesInDataset(dsn=dsn, version=self.options.version)

                    catCheck = {}
                    locals = []   
                    size = 0       
                    hadNone = False          

                    #for each guid pretty print locality, lfn, size, checksum
                    #and optionally the pfn
                    if len(ret2) > 0:

                        entry = ret2[0]

                        output = ['',dsn]
                                              
                        for guid in entry:
                            fs = entry[guid]['filesize']
                            if fs is None:
                                hadNone = True
                            else:
                                size += fs
                            catCheck[guid] = entry[guid]['lfn']
                        

                        response = {}
                        if self.DQ2_LOCAL_SITE_ID != 'ROAMING':
                            #bulk find replicas to the local catalogues
                            lfc = TiersOfATLAS.getLocalCatalog(str(self.DQ2_LOCAL_SITE_ID))
                            if lfc is not None:
                                catalog = create_file_catalog(lfc)
                                catalog.connect()
                                response2 = catalog.bulkFindReplicas(catCheck)
                                response = catalog.filterSiteReplicas(response2,[str(self.DQ2_LOCAL_SITE_ID)])
                                catalog.disconnect()

                        #gather the available lfn
                        for guid in response:
                            locals.append(response[guid]['lfn'])
                        
                        locallyAvailable = 0
                        #if we have a local copy of the file, mark it, print the rest
                        
                        linelist = []

                        for guid in entry:

                            linefile = []    

                            if len(response) > 0 and self.options.pfn:
                                try:
                                    for surl in response[guid]['surls']:
                                        linefile.append('%s'%surl)
                                except:
                                    linefile.append('PFN not available')
                        
                            else:
                                
                                if entry[guid]['lfn'] in locals:
                                    linefile.append('[X]')
                                    locallyAvailable += 1
                                else:
                                    linefile.append('[ ]'),
                                linefile.append(entry[guid]['lfn']),
                                linefile.append(guid)
                                if entry[guid]['checksum'] is not None:
                                    linefile.append(entry[guid]['checksum'])
                                if entry[guid]['filesize'] is not None:
                                    linefile.append(str(self.__human(entry[guid]['filesize'])))

                            linelist.append('\t'.join(linefile))

                        #sort by LFN or display the PFNs
                        if not self.options.pfn:
                            linelist.sort(lambda x, y: cmp(x[x.find('\t')],y[x.find('\t',x.find('\t'))+1]))
                        else:
                            linelist2 = []
                            for line in linelist:
                                if '[ ]' not in line:
                                    line.replace('\t','\n')
                                linelist2.append(line)
                            linelist = linelist2
                        
                        output.append('\n'.join(linelist))
                        
                        output.append('total files: %u' % len(entry))

                        if not self.options.pfn:
                            output.append('local files: %u' % locallyAvailable)

                        if not hadNone:
                            output.append('total size: %s' % self.__human(size))
                        if len(ret2) > 0:
                            output.append('date: %s' % (ret2[1]))
                       
                        print '\n'.join(output)

        except DQException, dqexception:
            ExceptionHandler(dqexception)
        except Exception, exception:
            ExceptionHandler(exception)

   
    def __getNumberOfFilesInDataset(self):
        """
        @since: 0.3.0
        """

        try:
            ret = self.__dq2.listDatasets(dsn=self.options.pattern, version=self.options.version, onlyNames=True,p=self.options.page_no)

            if len(ret) > 0:
                output = []
                for dsn in ret:
                    ret2 = self.__dq2.getNumberOfFiles(dsn=dsn, version=self.options.version)
                    output.append(str(ret2)+'\t'+dsn)
                print '\n'.join(output)

        except DQException, dqexception:
            ExceptionHandler(dqexception)
        except Exception, exception:
            ExceptionHandler(exception)

           
    def __listDatasetsInSite(self):
        """
        @since: 0.3.0
        """
        
        try:
            ret = self.__dq2.listDatasetsInSite(site=self.options.pattern, complete=self.options.complete)

            if len(ret) > 0:
                print '\n'.join([dsn for dsn in ret.keys()])

        except DQException, dqexception:
            ExceptionHandler(dqexception)
        except Exception, exception:
            ExceptionHandler(exception)

   
    def __listDatasetReplicasInContainer(self):
        """
        @since 1.1.2.26
        """
        
        name = self.options.pattern
        complete = self.options.complete
        
        ret    = self.__dq2.listDatasetReplicasInContainer(name)        
        report = {}
                
        out = ''
        for dataset in ret:
            out += '%s: \n'%(dataset)
            if ret[dataset]:
                if complete == LocationState.__ANY__ or complete == LocationState.INCOMPLETE:
                    out += "\t INCOMPLETE: " % ()
                    sites =  ret[dataset][ret[dataset].keys()[0]]
                    sites[LocationState.INCOMPLETE].sort()                 
                    for eachSite in sites[LocationState.INCOMPLETE]:
                        if not eachSite  in report: 
                            report[eachSite]= {LocationState.COMPLETE:  0 , LocationState.INCOMPLETE: 0}
                        report[eachSite][LocationState.INCOMPLETE] += 1
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)]
                out += '\n'
                if complete == LocationState.__ANY__ or complete == LocationState.COMPLETE:
                    out += "\t COMPLETE: " % ()
                    if  ret[dataset]:
                        sites =  ret[dataset][ ret[dataset].keys()[0]]
                        sites[LocationState.COMPLETE].sort()                    
                    for eachSite in sites[LocationState.COMPLETE]:
                        if not eachSite  in report: 
                            report[eachSite]= {LocationState.COMPLETE:  0 , LocationState.INCOMPLETE: 0}
                        report[eachSite][LocationState.COMPLETE] += 1                                                    
                        out += '%s,' % (eachSite)
                    out = out[0:(len(out)-1)] + '\n'
            else:
                out += ' No replicas found \n' 
       
        print out
        if ret:                    
            print 'Container name: %s' % (name)
            print 'Total  datasets: %u' % (len(ret))
            print 'Summary:'
            print '\t%s / %s / %s / %s '%(string.ljust('SITE', 25),string.ljust('# COMPLETE', 10), string.ljust('# INCOMPLETE', 10), string.ljust(' TOTAL', 10))
            print '\t----------------------------------------------------------------'            
            for site in report:
                print '\t%s    %s    %s    %s  '%(string.ljust(site, 25), 
                                               string.ljust(str(report[site][LocationState.COMPLETE]), 10),
                                               string.ljust(str(report[site][LocationState.INCOMPLETE]), 10),
                                               string.ljust(str(report[site][LocationState.COMPLETE]+report[site][LocationState.INCOMPLETE]), 10)                                                                                  
                                   ) 
        
   
    def __listDatasetReplicas(self):
        """
        @since: 0.3.0
        """
        
        
        try:
        
            #is it a container?
            if self.options.pattern.endswith('/'):
            
                #yes, so switch automatically
                self.__listDatasetReplicasInContainer()
            
            #it is a dataset
            else:
        
                ret = self.__dq2.listDatasets(dsn=self.options.pattern, version=self.options.version,p=self.options.page_no,rpp=self.options.rpp_value,onlyNames=True)
    
                if len(ret) > 0:
    
                    output = ['']
                    for dsn in ret:
    
                        output.append(dsn)
                        ret2 = self.__dq2.listDatasetReplicas(dsn=dsn, version=self.options.version, complete=self.options.complete)
                        
                        if len(ret2) > 0:
                            if self.options.complete == LocationState.__ANY__ or self.options.complete == LocationState.INCOMPLETE:
                                output.append(' INCOMPLETE:')
                                for eachSite in ret2[ret2.keys()[0]][LocationState.INCOMPLETE]:
                                    output.append('   '+eachSite)
                            if self.options.complete == LocationState.__ANY__ or self.options.complete == LocationState.COMPLETE:
                                output.append(' COMPLETE:')
                                for eachSite in ret2[ret2.keys()[0]][LocationState.COMPLETE]:
                                    output.append('   '+eachSite)
                        else:
                            output.append(' No replicas available!')
                        
                        output.append('\n')
            
                    print '\n'.join(output)
        
        except DQException, dqexception:
            ExceptionHandler(dqexception)
        except Exception, exception:
            ExceptionHandler(exception)

    def __createPoolFileCatalogue(self):
        """
        @since: 0.3.0
        """
            
        xmlHeader = \
"""<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<!DOCTYPE POOLFILECATALOG SYSTEM "InMemory">
<POOLFILECATALOG>
"""

        fileEntry = \
"""<File ID="%s">
  <physical>
    <pfn filetype="ROOT_All" name="%s"/>
  </physical>
  <logical>
    <lfn name="%s"/>
  </logical>
</File>
"""
        xmlFooter = \
"""</POOLFILECATALOG>
"""            
            
        xml = xmlHeader

        if self.options.three is not None:
            print 'Gathering list of datasets from directory', self.options.three
            sys.stdout.flush()
            tmp = [f for f in os.listdir(self.options.three) if os.path.isdir(os.path.join(self.options.three, f))]
        else:
            print 'Querying DQ2 central catalogues to resolve datasetname', self.options.pattern
            sys.stdout.flush()
            tmp = self.__dq2.listDatasets(dsn=self.options.pattern, version=self.options.version,p=self.options.page_no,rpp=self.options.rpp_value,onlyNames=True)

        for dataset in tmp:

            if dataset.endswith('/'):
                print "Ignoring Container %s" %dataset
            else:
    
                print 'Processing %s with PoolFileCatalog.xml'%dataset
                
                catCheck = {}
                    
                filesInDataset = self.__dq2.listFilesInDataset(dataset, version=self.options.version)
                
                if len(filesInDataset) > 0:
                    for guid in filesInDataset[0]:
                        catCheck[guid] = filesInDataset[0][guid]['lfn']
                    
                    response = {}

                    if self.options.three is None:
                        #bulk find replicas to the local catalogues
                        catalog = create_file_catalog(TiersOfATLAS.getLocalCatalog(str(self.DQ2_LOCAL_SITE_ID)))
                        catalog.connect()
                        tmp_response = catalog.bulkFindReplicas(catCheck)
                        response = catalog.filterSiteReplicas(tmp_response,[str(self.DQ2_LOCAL_SITE_ID)])
                        catalog.disconnect()
                    else:
                        tmp_files = [f for f in os.listdir(os.path.join(self.options.three, dataset)) if os.path.isfile(os.path.join(self.options.three, dataset, f))]
                        tmp_query = self.__dq2.listFilesInDataset(dataset)[0]

                        for lfn in tmp_files:
                            strip_lfn = re.sub("__(DQ|dq)2-\d+$","", lfn) # Strip any __dq2-timestamp
                            for guid in tmp_query:
                                if tmp_query[guid]['lfn'] == strip_lfn:
                                    response[guid] = {'lfn':strip_lfn, 'surls':[os.path.join(self.options.three, dataset, lfn)]}
                                    break

                    #only add new guids
                    if os.path.exists('PoolFileCatalog.xml'):
                        existingCatalog = open('PoolFileCatalog.xml','r')
                        existingLinesUnparsed = existingCatalog.readlines()   
                        existingCatalog.close()
                        
                        existingLines = []
                        toDelete = []
                        
                        for line in existingLinesUnparsed:
                            for guid in response:
                                if guid in line and guid not in toDelete:
                                    toDelete.append(guid)
                                    print "%s already exists. Not modified."%response[guid]['lfn']
                                    
                            if '</poolfilecatalog>' not in line.lower():
                                existingLines.append(line)
                        
                        for deleteMe in toDelete:
                            del response[deleteMe]
    
                        for guid in response:
                            if self.options.guess:
                                existingLines.append(fileEntry%(guid, self.__guessPFNfromSURL(str(random.choice(response[guid]['surls']))), response[guid]['lfn']))
                            elif self.options.replaceio is not None:
                                existingLines.append(fileEntry%(guid, re.sub(self.options.replaceio[0],self.options.replaceio[1],str(random.choice(response[guid]['surls']))), response[guid]['lfn']))
                            elif self.options.dcapo is not None:
                                # Convert SURL to DCAP TURL
                                dcapo = str(commands.getstatusoutput("lcg-gt "+str(random.choice(response[guid]['surls']))+" dcap")[1])
                                dcapo = dcapo.split()[0] # Remove reqtoken and just leave TURL using carridge return delimeter
                                existingLines.append(fileEntry%(guid, dcapo, response[guid]['lfn']))
                            else:
                                existingLines.append(fileEntry%(guid, str(random.choice(response[guid]['surls'])), response[guid]['lfn']))
                                
                        existingLines.append(xmlFooter)
    
                        os.unlink('PoolFileCatalog.xml')
                        newCatalog = open('PoolFileCatalog.xml','w')
                        for line in existingLines:
                            newCatalog.write(line)
                        newCatalog.close()
                    
                    else:

                        for guid in response:
                            if self.options.guess:
                                xml = xml + fileEntry%(guid, self.__guessPFNfromSURL(str(random.choice(response[guid]['surls']))), response[guid]['lfn'])
                            elif self.options.replaceio is not None:
                                xml = xml + fileEntry%(guid, re.sub(self.options.replaceio[0],self.options.replaceio[1],str(random.choice(response[guid]['surls']))), response[guid]['lfn'])
                            elif self.options.dcapo is not None:
                                # Convert SURL to DCAP TURL
                                dcapo = str(commands.getstatusoutput("lcg-gt "+str(random.choice(response[guid]['surls']))+" dcap")[1]) 
                                dcapo = dcapo.split()[0] # Remove reqtoken and just leave TURL using carridge return delimeter
                                xml = xml + fileEntry%(guid, dcapo, response[guid]['lfn'])
                            else:
                                xml = xml + fileEntry%(guid, str(random.choice(response[guid]['surls'])), response[guid]['lfn'])

                        xml = xml + xmlFooter
                
                        xmlFile = open('PoolFileCatalog.xml','w')
                        xmlFile.write(xml)
                        xmlFile.close()
   
   
    def __human(self, size):
        """
        @since 1.1.2.30
        """
   
        if self.options.human:
       
            for unit in ['bytes','KB','MB','GB','TB','PB']:
                if size < 1024.0:
                    return "%3.2f %s" % (size, unit)
                size /= 1024.0
       
        return size
   
    def execute(self):
        """
        @since: 0.3.0
        """
        
        self.options = Options(sys.argv[1:])
        
        self.__printVersion()

        if self.options.help:
            print self.usage
        else:
            
            try:
                
                self.__selectSite()

                self.__checkForCertificate()

                if self.options.pool or self.options.three is not None:
                    self.__createPoolFileCatalogue()
                elif self.options.replicaContainer:
                    self.__listDatasetReplicasInContainer()
                elif self.options.replica:
                    self.__listDatasetReplicas()
                elif self.options.missing:
                    self.__listMissingInDatasets()
                elif self.options.files:
                    self.__listFilesInDatasets()
                elif self.options.site is not None:
                    self.__listDatasetsInSite()
                elif self.options.number:
                    self.__getNumberOfFilesInDataset()
                else:
                    self.__listDatasets()
                    
            except:
                excType, excValue, excStack = sys.exc_info()
                print excValue

    def __debug(self, *messages):
        """
        @since: 0.0.1
        """
        
        if self.options.debug:
            for message in messages:
                print message,
                print

class Options:
    """
    @since: 0.3.0
    """

    #set the default state
    def __init__(self, arguments):
        """
        @since: 0.3.0
        """
        
        self.help = False
        self.debug = False
        self.files = False
        self.site = None
        self.replica = False
        self.complete = LocationState.__ANY__
        self.version = 0
        self.missing = False
        self.number = False
        self.local = None
        self.pattern = None
        self.pfn = False
        self.pool = False
        self.replaceio = None
        self.three = None
        self.guess = False
        self.replicaContainer = False
        self.human = False
        self.page_no = None
        self.rpp_value = None
        self.dcapo = None
        self.__parseArguments(arguments)

    def __parseArguments(self, arguments):
        """
        @since: 0.3.0
        """
        
        try:
            optlist, args = getopt.getopt(arguments, 'Z:z:GCdmpR:PiL:fhnT:crv:s:HD',
            ['debug','local-site=','pfn','guess-local','rpp=','replica-container','page_no=','missing','replaceio=','files','number','three=','pool','incomplete','help','complete','replica','version=','site','human-readable','dcap'])

            #set the pattern
            self.pattern = arguments[-1]

            #set the state according to the arguments
            for o, a in optlist:
                if o in ('-h', '--help'):
                    self.help = True
                if o in ('-d', '--debug'):
                    self.debug = True
                if o in ('-f', '--files'):
                    self.files = True
                if o in ('-i', '--incomplete'):
                    self.complete = LocationState.INCOMPLETE
                if o in ('-c', '--complete'):
                    self.complete = LocationState.COMPLETE
                if o in ('-r', '--replica'):
                    self.replica = True
                if o in ('-n', '--number'):
                    self.number = True
                if o in ('-m', '--missing'):
                    self.missing = True
                if o in ('-p', '--pfn'):
                    self.pfn = True
                if o in ('-C', '--replica-container'):
                    self.replicaContainer = True
                if o in ('-P', '--pool'):
                    self.pool = True
                if o in ('-v', '--version'):
                    self.version = int(a)
                if o in ('-s', '--site'):
                    self.site = str(a)
                if o in ('-L', '--local-site'):
                    self.local = str(a)
                if o in ('-R', '--replace-io'):
                    if '^' in str(a):
                        self.replaceio = str(a).split('^')
                if o in ('-T', '--three'):
                    self.three = str(a)
                if o in ('-G', '--guess-local'):
                    self.guess = True
                if o in ('-H', '--human-readable'):
                    self.human = True
                if o in ('-z', '--page'):
                    self.page_no = int(a)
                if o in ('-Z', '--rpp'):
                    self.rpp_value = int(a)
                if o in ('-D', '--dcap'):
                    self.dcapo = True

        except getopt.GetoptError, getoptError:
            ExceptionHandler(getoptError)
        except ValueError, valueException:
            ExceptionHandler(valueException)
        except IndexError, indexError:
            print('Usage: dq2-ls [ -h/--help | options ] <PATTERN>')
            ExceptionHandler(indexError)
        except Exception, exception:
            ExceptionHandler(exception)

