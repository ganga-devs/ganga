"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import os, sys, commands, getopt, re, string, socket, signal, time, zlib, md5, random, re

import cliutil

from dq2.common import optparse
from dq2.clientapi.DQ2 import DQ2
from dq2.common.DQException import DQException
from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.info import TiersOfATLAS, TiersOfATLASValidator, destination
from dq2.clientapi.cli.util.EndpointTool import EndpointTool
from dq2.clientapi.cli.util.Error import ErrorCode, ExceptionHandler
from dq2.clientapi.cli.util.PutStorageThread import StorageThread
from dq2.filecatalog import create_file_catalog
from dq2.filecatalog.FileCatalogException import FileCatalogException
from dq2.common import generate_uuid
from dq2.common.DQConstants import DatasetState
from dq2.location.DQLocationConstants import LocationState
from dq2.subscription.DQSubscriptionConstants import SubscriptionArchivedState
from dq2.tracer.client.TracerClient import TracerClient

from dq2.common.threadpool import WorkRequest
from dq2.common.threadpool import ThreadPool

from dq2.common.utils.proxy import get_fqans
from dq2.info import PermissionType
from dq2.info.TiersOfATLASValidator import has_permission
from dq2.common.DQException import DQInvalidRequestException

class Put(DQDashboardTool):
    """
    @since: 0.0.1

    @author: Mario Lassnig <mario.lassnig@cern.ch>
    @version: $Id: Put.py,v 1.8 2010/02/04 15:22:46 angelos Exp $
    """

    usage = "%prog [-h/--help | options] <DATASET>"

    version = "$Revision: 1.8 $"
    
    description = \
"""\
Create a dataset from a local directory or another dataset. This will put the files on a
mass-storage-system if necessary and register them to the central and local catalogues;
thus making them available to all ATLAS users via the grid.

If a file has '.pool.root' in his name, the GUID will be extracted from the file using ATHENA.
This means that you need to setup ATHENA before setting up DQ2.

For more information, go here: https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2ClientsHowTo
"""

    toolOptions = [
        optparse.make_option(
            '-d', '--debug',
            dest='debug',
            action='store_true',
            default=False,
            help='Print debug output'
        ),
        optparse.make_option(
            '-a', '--automatic',
            dest='automatic',
            action="store_true",
            default=False,
            help='Do not prompt - assume yes on all questions'
        ),
        optparse.make_option(
            '-L', '--local-site',
            dest='local',
            default=None,
            help='Override environment variable DQ2_LOCAL_SITE_ID'
        ),
        optparse.make_option(
            '-f', '--files',
            dest='files',
            default=None,
            help='List of files for the dataset (comma-separated, no blanks)'
        ),
        optparse.make_option(
            '-C', '--do-not-close',
            dest='close',
            action="store_true",
            default=True,
            help='Do not close created dataset version'
        ),
        optparse.make_option(
            '-F', '--freeze',
            dest='freeze',
            action='store_true',
            default=False,
            help='Freeze dataset once operation is finished'
        ),
        optparse.make_option(
            '-l', '--long-surls',
            dest='longSURLs',
            action='store_true',
            default=False,
            help='Use long SURLs with port and srm manager on file catalogue registration'
        ),
        optparse.make_option(
             '-p', '--protocol',
             dest='protocol',
             default='lcg',
             help='Force protocol (ng,lcg,lcg1,srm,dcap,rfio,dpm,xrd,custom)'
        ),
        optparse.make_option(
            '-s', '--source',
            dest='source',
            default=None,
            help='Source directory containing the files for the dataset. If the source is a dataset, use -D/--dataset-source instead'
        ),
        optparse.make_option(
            '-D', '--dataset-source',
            dest='datasetSource',
            default=None,
            help='Source dataset containing the files for the dataset. If the source is a directory, use -s/--source instead.'
        ),
        optparse.make_option(
             '-P', '--relative-path',
             dest='relativePath',
             default=None,
             help='Conditions internal: specify a relative path'
        ),
        optparse.make_option(
            '-g', '--guid',
            dest='guid',
            default=None,
            help='Conditions internal: give a GUID for a single file put'        
        ),
        optparse.make_option(
            '-m', '--mass-storage',
            dest='massStoragePut',
            default=None,
            help='Tier-0 internal: direct put'
        ),
        optparse.make_option(
            '-S', '--suffix',
            dest='suffix',
            default=None,
            help='Tier-0 internal: suffix for DSN'
        ),
        optparse.make_option(
            '-x', '--xml',
            dest='xml',
            default=False,
            action='store_true',
            help='Tier-0 internal: display XML status report'
        ),
        optparse.make_option(
             '-N', '--client-id',
             dest='clientId',
             default=None,
             help='Client identification (6 characters max). Warning: DQ2 Externals ONLY!' 
        ),
        optparse.make_option(
             '-X', '--skip-output-on-D',
             dest='skipOutputD',
             action='store_true',
             default=False,
             help='Do not output LFNs on -D (useful for random/jumbo selection)'
        ),
    ]

    def __init__(self):
        """
        @since: 0.0.1
        """

        try:
            os.environ['DQ2_ENDUSER_SETUP'] 
        except:
            print 'Please setup the DQ2Clients environment!'
            print 'More information: https://twiki.cern.ch/twiki/bin/view/Atlas/DistributedDataManagement'
            sys.exit(-1)

        try:
            import urllib2
            urlstream = urllib2.urlopen('http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache/DQ2PUTLATEST')
            remoteVersion = urlstream.read()
            if self.version.split()[1] != remoteVersion.replace('\n',''):
                print
                print 'You are not using the latest released stable version of the DQ2 clients!'
                print
                print 'Please check https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2Clients for the newest version number, go to the directory where you installed them and do:'
                print
                print '  pacman -get "http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache:DQ2Clients | version(\'version number\')"'
                print
                print 'For example:'
                print
                print '  pacman -get "http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache:DQ2Clients | version(\'0.1.13\')"'
                print
                print 'RPM installations can be upgraded with yum or apt.'
                print 'Please see the documentation for details.'
                print
        except:
            print 'Cannot verify client tools version! You might not use the latest released stable version!'

        DQDashboardTool.__init__(self)
        
        self.__errorCode = 0
        
        self.__dq2 = DQ2()

    def __printVersion(self):
        """
        @since: 0.0.1
        """
        self.__debug('dq2-put %s'%self.version.split()[1])

    def __selectSite(self):
        """
        @since: 0.0.1
        """

        #are we overriding the environment?
        if self.options.local is not None:
            self.DQ2_LOCAL_SITE_ID = self.options.local
        else:
            #no? so check environment - if not set, assume CERNPROD
            try:
                self.DQ2_LOCAL_SITE_ID = os.environ['DQ2_LOCAL_SITE_ID']
            except KeyError:
                raise Exception('You must set your site! (set with -L or environment variable DQ2_LOCAL_SITE_ID)')

        if self.DQ2_LOCAL_SITE_ID == 'ROAMING':
            raise Exception('ROAMING putting of file not yet available.')

        #is it a valid Tiers of ATLAS site?
        TiersOfATLASValidator.is_site(self.DQ2_LOCAL_SITE_ID)
        self.report['localSite'] = self.DQ2_LOCAL_SITE_ID
        self.report['remoteSite'] = self.DQ2_LOCAL_SITE_ID

        hostDomain = string.join(socket.gethostbyaddr(socket.gethostname())[0].split('.')[-2:], '.')
        toaDomain = TiersOfATLAS.getSiteProperty(self.DQ2_LOCAL_SITE_ID, 'domain')
        
        if toaDomain is None:
            print
            print 'Attention!'
            print
            print 'You have selected a site that is not in TiersOfATLAS.'
            print 'You will not be able to use dq2-put.'
            print 'Please ask your system administrator which sitename you should use.'
            print
            raise Exception('Aborted!')
        
        if not toaDomain.startswith('DESY'):
        
            if toaDomain is not None and hostDomain not in toaDomain:
                print
                print 'Attention!'
                print
                print 'Your host-domain (%s) does not verify against the selected DQ2 site identification (%s)!'%(hostDomain, self.DQ2_LOCAL_SITE_ID)
                print 'This means you are copying/registering files into the WRONG SITE!'
                print 'Please set the environment variable DQ2_LOCAL_SITE_ID to a correct value.'
                print 'You can list all possible values for DQ2_LOCAL_SITE_ID with the command: dq2-sources'
                print 'Change your environment to use the appropriate one.'
                print
                #print 'In case of questions, please contact atlas-dq2-support@cern.ch'
                print 'In case of questions, please check in DQ2ClientsHowTo Twiki,'
                print 'https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2ClientsHowTo' 
                print
                if not self.__yesno('Do you want to continue with the wrong setting? (ATTENTION: this is most likely a bad idea!)'):
                    raise Exception('Aborted!')

    def __checkForCertificate(self):
        """
        @since: 0.0.1
        """
 
        self.report['clientState'] = 'CHECK_CERT'
        
        proxycheck = 'voms-proxy-info'
        
        status, output = commands.getstatusoutput('%s -e'%proxycheck)

        if 'command not found' in output:
            print 'WARNING: Missing voms-proxy-init binary. Unable to verify proxy at the client. Continuing!'
            proxycheck = 'grid-proxy-info'
            status, output = commands.getstatusoutput('%s -e'%proxycheck)
            if 'command not found' in output:
                self.__errorCode = 1
                raise Exception('Missing both voms-proxy-info and grid-proxy-info binaries. Please use the correct setup.sh!')
                sys.exit(ErrorCode.ERROR)
        elif status != 0:
            self.__errorCode = 1
            raise Exception('Missing voms proxy. Create one with: voms-proxy-init -voms atlas')
            sys.exit(ErrorCode.ERROR)

        #anonymise the user identity
        m=md5.new()
        m.update(commands.getstatusoutput('%s -identity' %proxycheck)[1])
        self.report['usr'] = m.hexdigest()

    def __checkAvailableTools(self):
        """
        @since: 0.0.1
        """

        self.report['clientState'] = 'CHECK_TOOLS'
        destination = TiersOfATLAS.getSiteProperty(self.DQ2_LOCAL_SITE_ID, 'srm')  
        self.endpointTool = EndpointTool(EndpointTool.PUT, self.options.dataset, self.options.source, destination, self.DQ2_LOCAL_SITE_ID, self.DQ2_LOCAL_SITE_ID, None, self.options.protocol)
        self.__debug('Available protocols:', self.endpointTool.getAvailableProtocols())
        self.__debug('Chosen protocol:', self.endpointTool.rank())
        self.report['protocol'] = self.endpointTool.protocol
        self.endpointTool.prepare()

    def __checkDataset(self):
        """
        @since: 0.0.1
        """

        self.versionToCreate = 0  
        self.isOpen = False

        #only check if we are a dataset and not a container
        if not self.options.dataset.endswith('/'):
    
            self.report['clientState'] = 'CHECK_DATASET'
            self.report['validateStart'] = time.time()

            #does the dataset exist?
            ret={'latestversion': self.versionToCreate, 'state': DatasetState.OPEN}
            try:
                measureStart = time.time()
                ret = self.__dq2.getMetaDataAttribute(self.options.dataset, ['latestversion','state'])
                self.__DQ2time.append(time.time()-measureStart)
                self.versionToCreate = ret['latestversion']+1
            except:
                pass   
    
            self.report['version'] = self.versionToCreate
    
            #is the dataset frozen?
            if ret['state'] == DatasetState.FROZEN:
                raise Exception('Dataset is frozen. Aborting.')
            
            #if yes, version the dataset
            self.filesInDataset = None
            
            try:
                measureStart = time.time()
                ret = self.__dq2.getState(self.options.dataset)
                self.__DQ2time.append(time.time()-measureStart)            
                if ret == DatasetState.OPEN:
                    self.isOpen = True
                else:
                    self.isOpen = False
            except:
                pass
            
            if self.isOpen:
                print '%s is open, you are adding files to the current version'%self.options.dataset
            elif not self.isOpen and self.versionToCreate:
                if not self.options.automatic:
                    if not self.__yesno('Dataset %s exists already, confirm to create new version %s and add files'%(self.options.dataset, self.versionToCreate)):
                        raise Exception('Cancelled!')    
        
    def __checkSource(self):
        """
        @since: 0.0.1
        """
        
        filesInSource = []
         
        self.checkedFiles = {}
          
        self.report['relativeStart'] =  time.time()
          
        if self.options.datasetSource:
            
            self.report['clientState'] = 'CHECK_SOURCE_DS'
            self.report['protocol'] = 'merge'
            
            if '*' in self.options.datasetSource:
                raise Exception('Wildcards not supported (yet).')
            
            print 'Using dataset as input:', self.options.datasetSource

            tmp = self.__dq2.listDatasets(self.options.datasetSource)
            
            if tmp is not None:

                #if files are given for a dataset source automatically select them
                if self.options.files != []:
                    
                    inDataset = self.__dq2.listFilesInDataset(self.options.datasetSource)[0]

                    for file in inDataset:
                        if inDataset[file]['lfn'] in self.options.files:
                            self.checkedFiles[file] = {'dsn':self.options.dataset,
                                                       'lfn':inDataset[file]['lfn'],
                                                       'source':None,
                                                       'checksum':inDataset[file]['checksum'],
                                                       'fsize':long(inDataset[file]['filesize']),
                                                       'archival': SubscriptionArchivedState.__ANY__}
                    
                else:
                    
                    tmp = self.__dq2.listFilesInDataset(self.options.datasetSource)
    
                    #I hate this so much (but it's convenient for users to have sorted LFNs):
                    #create a tuple guid-lfn and sort by lfn only, then use
                    #the guid to create a counter for the dictionary
                    to_sort = []
                    for item in tmp[0]:
                        to_sort.append((tmp[0][item]['lfn'],item))
                    to_sort.sort()
                    
                    i = 0
                    new_tmp = {}
                    for elem in to_sort:
                        new_tmp[elem[1]] = {'lfn':tmp[0][elem[1]]['lfn'],'checksum':tmp[0][elem[1]]['checksum'],'filesize':tmp[0][elem[1]]['filesize'],'counter':i}
                        i += 1
                    
                    if len(new_tmp):
               
                        selection = []
                        
                        print
                        
                        #the price you have to pay. iterate the dictionary
                        #to find the current counter every time
                        #TODO: if this becomes a problem with jumbo datasets
                        #i will encode the counter into the key
                        if not self.options.skipOutputD:
                            for currentCount in range(0, len(new_tmp)):
                                for elem in new_tmp:
                                    if new_tmp[elem]['counter'] == currentCount:
                                        print "%s : %s (%s, %s, %s)"%(new_tmp[elem]['counter'], new_tmp[elem]['lfn'], elem, new_tmp[elem]['checksum'], new_tmp[elem]['filesize'])
                        
                        print
                        print 'Please select which files you want.'
                        print 'Files or range of files separated by commas (e.g.: 1,3,4-6 will select 1,3,4,5,6), r for random assortment of a random number of files, or rXX for a random assortment of XX files'
                        print '> ',
                
                        response = str(raw_input())
                        
                        while re.search('[^r0-9,-]+', response) or len(response) == 0:
                            print 'Invalid input, only r0-9,- allowed.'
                            print '> ',
                            response = str(raw_input())
                        
                        if 'r' in response:
                            
                            nr_r = response.split('r')[-1]
                            
                            try:
                                isinstance(int(nr_r.split('r')[-1]), int)
                                toSelect = int(nr_r)
                            except:
                                toSelect = random.randint(1, len(new_tmp))
                                
                            if toSelect > len(new_tmp):
                                toSelect = len(new_tmp)
                                
                            print 'Randomly selecting %s file(s)!'%toSelect
                            selection = [x for x in random.sample(new_tmp, toSelect)]
    
                        #parse 
                        else:
                            print
                            print 'Parsing...'
                          
                            tmp_split = response.split(',')
                            
                            selected = []
                            for elem in tmp_split:
                                if '-' in elem:
                                    lower=int(elem.split('-')[0])
                                    higher=int(elem.split('-')[1])
                                    for counter in range(lower,higher+1):
                                        selected.append(counter)
                                else:
                                    selected.append(int(elem))    
                            
                            for elem in selected:
                                for file in new_tmp:
                                    if new_tmp[file]['counter'] == elem:
                                        selection.append(file)
    
                        if selection:
                            print
                            print 'You have selected the following file(s):'
                            print
    
                            for file in selection:
                                print new_tmp[file]['lfn']
                            
                            if not self.__yesno('%s files, is this correct?'%len(selection)):
                                raise Exception('Aborted!')
    
                            #remove already existing files
                            if self.isOpen or self.versionToCreate:
                                filesInDataset = self.__dq2.listFilesInDataset(self.options.dataset)
                                if len(filesInDataset) > 0:
                                    selection = [elem for elem in selection if elem not in filesInDataset[0].keys()]  
                            
                                 
                            for file in selection:
                                self.checkedFiles[file]={'dsn': self.options.dataset,
                                                         'lfn': new_tmp[file]['lfn'],
                                                         'source': None,
                                                         'fsize': long(new_tmp[file]['filesize']),
                                                         'checksum': new_tmp[file]['checksum'],
                                                         'archival': SubscriptionArchivedState.__ANY__}
                                       
                            print
                
        elif self.options.massStoragePut:
        
            self.report['clientState'] = 'CHECK_SOURCE_MSS'

            filesInFile=[]
            try:
                inputFile=open(self.options.massStoragePut, 'r')
                lines=inputFile.readlines()
                inputFile.close()
            except:
                raise Exception('%s: there was a problem reading the file'%self.options.massStoragePut)
           
            for e in lines:
                    try:
                        filesInFile.append((e.split()[0],e.split()[1],e.split()[2],e.split()[3],e.split()[4]))
                    except:
                        #ignore malformed lines
                        pass

            datasetname = self.options.dataset
            
            if datasetname.endswith('/'):
                print 'Parsing input file (container mode)'

                try:
                    measureStart = time.time()
                    self.__dq2.registerContainer(self.options.dataset)
                    print 'Container %s registered'%self.options.dataset
                    self.__DQ2time.append(time.time()-measureStart)
                except:
                    print 'Container exists already'
                
                #add the suffix
                if self.options.suffix is not None:
                    datasetname='%s%s'%(self.options.dataset[:-1],self.options.suffix)
                else:
                    datasetname='%s_T%s'%(self.options.dataset[:-1],int(time.time()))
                
            else:
                print 'Parsing input file (dataset mode)'
           
            for file in filesInFile:
                self.checkedFiles[str(file[0])]={
                         'dsn': datasetname,
                         'lfn': str(file[1]),
                         'source': str('srm://srm-atlas.cern.ch'+file[2]),
                         'fsize': long(file[3]),
                         'checksum': str(file[4]),
                         'archival': SubscriptionArchivedState.__ANY__}
            
            #skip the GUID clash test, Tier-0 is clean
            return
        
        else:
            
            self.report['clientState'] = 'CHECK_SOURCE'
            
            if self.options.guid is not None and len(self.options.files) != 0 and len(self.options.files) != 1:
                raise Exception('If you use the GUID option you must give one and only one filename!') 
            
            #find all files in directory that are not directories themselves
            print 'Gathering list of files...',
            
            #direct put from castor
            if self.options.source.startswith('/castor'):
                
                try:
                    status, output = commands.getstatusoutput('nsls -l %s'%self.options.source)
                    if not status:
                        for line in output.split('\n'):
                            if line[0] == 'm' or line[0] == '-':
                                f = line.split()[8]
                                if '/' in f:
                                    f = f[f.rfind('/')+1:]
                                filesInSource.append(f)
                except:
                    pass
            
            #direct put from dpm
            elif self.options.source.startswith('/dpm'):
                
                try:
                    status, output = commands.getstatusoutput('dpns-ls -l %s'%self.options.source)
                    if not status:
                        for line in output.split('\n'):
                            if line[0] == 'm' or line[0] == '-':
                                f = line.split()[8]
                                if '/' in f:
                                    f = f[f.rfind('/')+1:]
                                filesInSource.append(f)
                except:
                    pass
                
                
            
            else:
            
                tmp = os.listdir(self.options.source)
                for file in tmp:
                    if os.path.isfile(self.options.source+'/'+file):
                        filesInSource.append(file)
            
            print 'done'
    
            if self.options.guid is not None and len(self.options.files) == 0 and len(filesInSource) != 1:
                raise Exception('If you use the GUID option you must have one and only one file in the source directory!')
    
            elif len(filesInSource) > 0:
                
                #only use the ones specified (if any)
                if len(self.options.files) > 0:
                    filesInSource = [elem for elem in self.options.files if elem in filesInSource]
        
                #if we have pool files, we need pool set up to get at the guids
                for file in filesInSource:
                    if '.pool.root' in file and self.options.clientId != 'pilot':
                        if commands.getstatusoutput('which pool_extractFileIdentifier')[0]:
                            raise Exception('FATAL - you are trying to register pool files without having Athena set up! Please source the Athena environment before sourcing the DQ2 environment!')
                        else:
                            break
                        
                #for every file generate uuids or extract them from the pool
                #and set the registration data
                #do not use the file if its length is zero
                #if we version, just add files that are not there already
                if self.isOpen or self.versionToCreate:
                    
                    filesInDataset = self.__dq2.listFilesInDataset(self.options.dataset)
                    
                    if len(filesInDataset) > 0:
                        oldFiles = []
                        for file in filesInDataset[0]:
                            oldFiles.append(filesInDataset[0][file]['lfn'])

                        filesInSource = [elem for elem in filesInSource if elem not in oldFiles]                    
                
                #get necessary information
                for file in filesInSource:
                    
                    print '%s: pre-checking file'%file
                    
                    pathfile = os.path.join(self.options.source, file)
                    
                    if self.options.source.startswith('/castor'):
                        fsize = long(commands.getstatusoutput('nsls -l %s'%pathfile)[1].split()[4])
                    elif self.options.source.startswith('/dpm'):
                        fsize = long(commands.getstatusoutput('dpns-ls -l %s'%pathfile)[1].split()[4])
                    else:
                        fsize = os.stat(pathfile).st_size
                    
                    if fsize > 0:
                        
                        if self.options.guid is not None:
                            
                            guid = self.options.guid
                        
                        elif '.pool.root' in file:
                            status, output = commands.getstatusoutput('pool_extractFileIdentifier %s'%pathfile)
                            
                            if 'segmentation violation' in output:
                                raise Exception('Your pool_extractFileIdentifier command is broken. Please check and fix your environment. We cannot proceed without a proper pool environment when registering pool.root files. Here is the output of the broken command:\n%s'%output)
                            
                            #the guid is always on the last line and there might be errors before
                            guid = output[output.rfind('\n')+1:].split()[0]
                            try:
                                TiersOfATLASValidator.is_uid([guid])
                            except:
                                print 'Could not extract GUID from pool.root file:'
                                print output
                                raise Exception('FATAL! pool.root file could not be read or file possibly not a pool.root file (try running pool_extractFileIdentifier on it)!')
                        else:
                            guid = generate_uuid()
                        
                        #check the sequence number for direct guid puts
                        if self.options.guid is not None:
                            file = '%s._%04i.pool.root' % (self.options.dataset, self.__getFileSeq())
                        
                        self.checkedFiles[guid]={'dsn': self.options.dataset,
                                                 'source': os.path.abspath(pathfile),
                                                 'lfn': file,
                                                 'checksum': 'ad:'+self.__adler32(pathfile),
                                                 'fsize': fsize,
                                                 'archival': SubscriptionArchivedState.__ANY__}
                    else:
                        print '%s: not used due to zero length'%file


        #check for duplicate guids (if we are not making overlapping datasets)
        
        if self.options.datasetSource is not None:
        
            print 'Creating overlapping datasets, skipping GUID clash check\n'
        
        else:
            
            print '\nChecking for GUID clashes\n'
            duplicates = self.__dq2.listDatasetsByGUIDs(self.checkedFiles.keys())
            
            duplicateFound = False
            for duplicate in duplicates.values():
                if len(duplicate) > 0:
                    duplicateFound = True
                    break
            
            if duplicateFound:
                print 'GUID clashes detected:'
                for duplicate in duplicates:
                    print '%s: %s'%(duplicate, duplicates[duplicate])
                if not self.__yesno('GUID clashes detected, confirm to continue with transfer. WARNING! This will   -- FAIL --   registration to catalogues! Continue?'):
                    raise Exception('Cancelled!')   

    def __getFileSeq(self):
        """
        @since: 0.0.1
         
        Modified from Richard Hawkings' registration tool
         
        Extract the next file sequence number to be used for the dataset
        assuming LFNs are of the standard form *._nnnn.* where right-most
        field starting with _ is the sequence number. Error indicated by
        throwing Exceptions.
        """
         
        dsfiles=[]
         
        #if there is no dataset yet, ignore
        try:
            dsfiles=self.__dq2.listFilesInDataset(self.options.dataset)
        except:
            pass
         
        # if no files, first seq number is 1
        if (len(dsfiles)==0):
            return 1
         
        # files is a dictionary with GUID as key, value is sub-dict with lfn
        files=dsfiles[0]
        highseq=0
         
        for (guid,idict) in files.items():
             
            lfn=idict['lfn']
         
            if (guid.upper()==self.options.guid):
                # attempt to register file with same GUID - stop
                raise Exception('GUID %s already assigned to registered file %s - STOP' % (guid,lfn),True)
             
            # if the file is 'native' to this dataset, extract number
            if (lfn[:len(self.options.dataset)]==self.options.dataset):
                 
                fields=lfn.split('.')

                for i in range(len(fields)-1,0,-1):
                     
                    field=fields[i]
                     
                    if field[0]=='_':
                        try:
                            seq=int(field[1:])
                            if (seq>highseq): highseq=seq
                        except Exception:
                            raise Exception('Filename with unexpected format: %s' % lfn)
         
                        # once the rightmost field with _ is found, get out
                        break
         
        return highseq+1

    def __confirm(self):
        """
        @since: 0.0.1
        """

        if not len(self.checkedFiles):
            raise Exception('No files selected, aborting!')
        
        if self.options.massStoragePut and self.options.dataset.endswith('/'):
            print '%s -- confirm creating dataset in container %s'%(self.checkedFiles[self.checkedFiles.keys()[0]]['dsn'],self.options.dataset),        
        elif self.isOpen:
            print '%s -- confirm adding files to dataset'%self.options.dataset,
        elif self.versionToCreate > 0:
            print '%s -- confirm versioning dataset'%self.options.dataset,
        else:
            print '%s -- confirm creating dataset'%self.options.dataset,
        
        if len(self.checkedFiles) == 1:
            print '(1 file):'
        else:
            print '(%s files):'%len(self.checkedFiles)

        reportFiles = []
        for file in self.checkedFiles:
            reportFiles.append(file)
            print ' ('+file+' '+self.checkedFiles[file]['checksum']+' '+str(self.checkedFiles[file]['fsize'])+')\t'+self.checkedFiles[file]['lfn']+''
        
        if self.__yesno('Confirm'):
            print 'Confirmed'
        else:
            raise Exception('Cancelled!')
        
        
    def __transfer(self):
        """
        @since: 0.0.1
        """

        self.report['clientState'] = 'START_TRANSFER'
        self.report['transferStart'] = time.time()
        
        if self.options.datasetSource is not None:
            
            print 'Registering files already in another dataset. No transfer'
        
        elif self.options.massStoragePut is not None:
            
            print 'Registering files already on mass storage. No transfer.'
            
        else:
            storageThreads = ThreadPool(3)
    
            #take one to find out how to name the directory
            #then produce create-directory command and make sure we run first
            destination = self.endpointTool.prepareMkdir(self.checkedFiles.values()[0]['dsn'], relative=self.options.relativePath) 
            mkdir = self.endpointTool.mkdir(destination)
            
            #if there is no mkdirtool registered, we don't need it for that protocol 
            if mkdir[0] != ' ':
                current = StorageThread(mkdir)
                work = WorkRequest(current.run)
                storageThreads.putRequest(work)
                storageThreads.wait()
            
            #now go through all of them and put them in threads 

            # but first do the first do first file and wait (to create dirs with lcg_cp if necessary, etc)
            wait_flag = True
            
            for file in self.checkedFiles:
                destination = self.endpointTool.preparePut(self.checkedFiles[file]['lfn'], self.options.relativePath)
                current = StorageThread(self.endpointTool.cp('file:///'+self.checkedFiles[file]['source'], destination))
                work = WorkRequest(current.run)
                storageThreads.putRequest(work)
                if wait_flag == True:     # On the first run
                    storageThreads.wait() # Wait until finished before continue
                    wait_flag = False
            
            if len(self.checkedFiles) != 1: # If there only one thread spawned this is not necessary since already done
                storageThreads.wait()
            
            storageThreads.dismissWorkers(3)
            storageThreads.joinAllDismissedWorkers

    def __constructSURLs(self):
        """
        @since: 0.0.1
        """
    
        self.report['clientState'] = 'CONSTRUCT_SURL'
        
        failedFiles = {}

        endpoint = TiersOfATLAS.getSiteProperty(self.DQ2_LOCAL_SITE_ID, 'srm')
        
        for file in self.checkedFiles:
            
            surl = self.endpointTool.preparePut(self.checkedFiles[file]['lfn'], self.options.relativePath)

            #do not verify SURLs in Tier0 usecase
            if self.options.massStoragePut:            
                self.checkedFiles[file]['surl'] = self.checkedFiles[file]['source']

            elif self.options.datasetSource:
                pass
                
            elif 'gsiftp' in surl:
                self.checkedFiles[file]['surl'] = surl
            
            else:
                print '%s: verifying'%self.checkedFiles[file]['lfn']
                
                srmSize, isCached, status = self.endpointTool.getMetadata(surl)
    
                if status:
                    print '%s: verify failed'%self.checkedFiles[file]['lfn']
                    failedFiles[self.checkedFiles[file]['lfn']]={'guid':file,'srmSize':srmSize,'localSize':self.checkedFiles[file]['fsize']}
                
                elif long(srmSize) != long(self.checkedFiles[file]['fsize']):
                    print '%s: remote size wrong'%self.checkedFiles[file]['lfn']
                    failedFiles[self.checkedFiles[file]['lfn']]={'guid':file,'srmSize':srmSize,'localSize':self.checkedFiles[file]['fsize']}

                self.checkedFiles[file]['surl'] = surl
                
        if len(failedFiles) > 0:
            
            print
            print 'The following filesize mismatches have been found (local -> remote).'
            print 'If the remote filesize is a string instead of a number there might be something wrong with your setup or even something worse.'
            
            for file in failedFiles:
                print '%s: %s -> %s'%(file, failedFiles[file]['localSize'], failedFiles[file]['srmSize'])
                       
            print
            
            if self.__yesno('Some files failed verification. Do you want to try to delete these files (they will not be registered in any case)?'):
                for toDelete in failedFiles:
                    
                    status, output = commands.getstatusoutput(self.endpointTool.rm(self.checkedFiles[failedFiles[toDelete]['guid']]['surl']))

                    if not status:
                        print 'Deleted: ', toDelete
                    else:
                        print 'Deletion failed (please check manually): %s (%s, %s)'%(toDelete, failedFiles[toDelete]['guid'], self.checkedFiles[failedFiles[toDelete]['guid']]['surl'])

                    self.checkedFiles.pop(failedFiles[toDelete]['guid'])
            else:
                raise Exception('Aborted!')
    
    def __registerFilesToLFC(self):
        """
        @since: 0.0.1
        """
        #guid:dsn,lfn,surl,fsize,checksum
        
        if self.options.datasetSource is not None:
            
            print 'No registration to LFC necessary. Skipping.'
        
        elif not self.checkedFiles:
            
            print 'No files to register to LFC. Skipping.'
        
        else:
            
            self.report['clientState'] = 'REGISTER_LFC'
            self.report['catStart'] = time.time()

            catalogue = TiersOfATLAS.getLocalCatalog(self.DQ2_LOCAL_SITE_ID)
            
            if catalogue is None:
                raise Exception('Site has no LFC attached! Please contact DDM-Ops immediately!')

            catalogue = create_file_catalog(catalogue)
    
            #are we using a local protocol? if yes, make sure the SRM path gets registered
            
            self.checkedFiles = self.endpointTool.createSRMforLocal(self.checkedFiles)
    
            #long or short SURLs?
            if not self.options.longSURLs:
                for entry in self.checkedFiles:
                    self.checkedFiles[entry]['surl'] = self.endpointTool.fixSurl(self.checkedFiles[entry]['surl'])            
    
            try:
                measureStart = time.time()
                catalogue.connect()
                lfcResponse = catalogue.bulkFindReplicas(self.checkedFiles)
                catalogue.disconnect()
                self.__LFCtime.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print excValue
                self.__errorCode = 1
                raise
    
            #if we find an md5sum in lfc already, get the checksum and modify the input parameters 
            if lfcResponse:
                for lfcFile in lfcResponse:
                    if lfcResponse[lfcFile]['checksum'] is not None and lfcFile in self.checkedFiles and lfcResponse[lfcFile]['checksum'].startswith('md5'):
                        self.checkedFiles[lfcFile]['checksum'] = lfcResponse[lfcFile]['checksum']

            try:    
                measureStart = time.time()
                catalogue.connect()
                lfcResponse = catalogue.bulkRegisterFiles(self.checkedFiles)
                catalogue.disconnect()
                self.__LFCtime.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print excValue
                self.__errorCode = 1
                raise
    
            failedFiles = []
            successFiles =[]
    
            for guid in lfcResponse:
                if not isinstance(lfcResponse[guid], FileCatalogException):
                    successFiles.append(guid)
                else:
                    failedFiles.append((guid,lfcResponse[guid]))
    
            for guid in successFiles:
                print '%s: OK (%s)'%(self.checkedFiles[guid]['lfn'], guid)
    
            for guidfailed in failedFiles:
                print '%s: %s'%(self.checkedFiles[guidfailed[0]]['lfn'], guidfailed[1])
    
            if len(failedFiles) > 0:
                raise Exception('FATAL - Error registering files in the LFC!')

        
    def __registerDataset(self):
        """
        @since: 0.0.1
        """

        self.report['clientState'] = 'REGISTER_DATASET'

        lfns = []
        guids = []
        sizes = []
        checksums = []  

        if not self.checkedFiles:
            if self.__yesno('There are no files to register, do you want to abort (Answering no will create the dataset) ?'):
                raise Exception('Aborted!')

        for file in self.checkedFiles:
            lfns.append(self.checkedFiles[file]['lfn'])
            guids.append(file)
            sizes.append(long(self.checkedFiles[file]['fsize']))
            checksums.append(self.checkedFiles[file]['checksum'])
        
        #if we create an overlapping dataset then make sure that the location
        #matches one of the existing sites
        if self.options.datasetSource is not None:
            tmp = self.__dq2.listDatasetReplicas(self.options.datasetSource)
            a = tmp[tmp.keys()[0]][LocationState.INCOMPLETE]
            b = tmp[tmp.keys()[0]][LocationState.COMPLETE]
            self.DQ2_LOCAL_SITE_ID = str(random.sample(set(a+b), 1)[0])
        
        #do the registration
        if self.isOpen:   
            
            try:
                measureStart = time.time()
                reg = self.__dq2.registerFilesInDataset(self.options.dataset, lfns, guids, sizes, checksums)
                self.__DQ2time.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem adding files to dataset'
                self.__errorCode = 1
                raise
            
        elif not self.isOpen and self.versionToCreate:
            try:
                measureStart = time.time()
                reg = self.__dq2.registerNewVersion(self.options.dataset, lfns, guids, sizes, checksums)
                self.__DQ2time.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem registering dataset version'
                self.__errorCode = 1
                raise
            
        else:
            
            #if we register a new one for Tier-0 use the datasetname and not the container name for the dsn
            datasetname=self.options.dataset
            if self.options.massStoragePut and self.options.dataset.endswith('/'):
                datasetname=self.checkedFiles[self.checkedFiles.keys()[0]]['dsn']
            
            try:
                measureStart = time.time()
                reg = self.__dq2.registerNewDataset(datasetname, lfns, guids, sizes, checksums)
                self.__DQ2time.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem registering dataset:', excValue
                self.__errorCode = 1
                raise

        if not self.isOpen and not self.versionToCreate:
            self.report['duid'] = reg['duid'].replace('-', '')
        else:
            self.report['duid'] = self.__dq2.getMetaDataAttribute(self.options.dataset, ['duid'])['duid'].replace('-', '')
            
        if self.isOpen: 
            print 'Dataset %s updated'%(self.options.dataset),
            try:
                datasetname=self.options.dataset
                self.__dq2.registerDatasetLocation(datasetname, self.DQ2_LOCAL_SITE_ID)
                print 'Dataset %s registered at location %s'%(datasetname, self.DQ2_LOCAL_SITE_ID),
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem registering dataset location:', excValue
                self.__errorCode = 1
                raise
                
        elif self.versionToCreate and not self.isOpen:
            print 'Dataset %s versioned to %u'%(self.options.dataset, reg['version']),
            try:
                datasetname=self.options.dataset
                self.__dq2.registerDatasetLocation(datasetname, self.DQ2_LOCAL_SITE_ID)
                print 'Dataset %s registered with version %u at location %s'%(datasetname, reg['version'], self.DQ2_LOCAL_SITE_ID),
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem registering dataset:', excValue
                self.__errorCode = 1
                raise
        else:
            try:
                datasetname=self.options.dataset
                if self.options.massStoragePut and self.options.dataset.endswith('/'):
                    datasetname=self.checkedFiles[self.checkedFiles.keys()[0]]['dsn']
                measureStart = time.time()
                #raise Exception("asd")
                self.__dq2.registerDatasetLocation(datasetname, self.DQ2_LOCAL_SITE_ID)
                self.__DQ2time.append(time.time()-measureStart)
                print 'Dataset %s registered with version %u at location %s'%(datasetname, reg['version'], self.DQ2_LOCAL_SITE_ID),
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem registering dataset:', excValue
                self.__errorCode = 1
                raise
        datasetname=self.options.dataset
        if self.options.massStoragePut and self.options.dataset.endswith('/'):
            datasetname=self.checkedFiles[self.checkedFiles.keys()[0]]['dsn']

        closed = False
        frozen = False        
        if self.options.close and not self.options.freeze:
            measureStart = time.time()
            self.__dq2.closeDataset(datasetname)
            self.__DQ2time.append(time.time()-measureStart)
            print 'with status CLOSED'
            closed = True
        if self.options.freeze:
            measureStart = time.time()
            self.__dq2.freezeDataset(datasetname)
            self.__DQ2time.append(time.time()-measureStart)
            print 'with status FROZEN'
            frozen = True
        if not closed and not frozen:
            print 'with status OPEN'

        self.report['clientState'] = 'DONE'

        for file in self.checkedFiles:           
            self.report['filename'] = self.checkedFiles[file]['lfn']
            self.report['guid'] = file.replace('-', '')
            self.report['filesize'] = self.checkedFiles[file]['fsize']
            self.__sendReport()

    def __registerDatasetInContainer(self):
        """
        @since: 0.0.1
        """
        
        if self.options.massStoragePut and self.options.dataset.endswith('/'):
            
            datasetname=self.checkedFiles[self.checkedFiles.keys()[0]]['dsn']
            
            print 'Freezing dataset %s and registering into container %s'%(datasetname, self.options.dataset)

            try:
                measureStart = time.time()
                self.__dq2.freezeDataset(datasetname)
                self.__DQ2time.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem freezing dataset'
                self.__errorCode = 2
                raise
            
            try:
                measureStart = time.time()
                self.__dq2.registerDatasetsInContainer(self.options.dataset, [datasetname])
                self.__DQ2time.append(time.time()-measureStart)
            except:
                excType, excValue, excStack = sys.exc_info()
                print 'Fatal problem registering dataset into container'
                self.__errorCode = 2
                raise
    
    def __initMeasurement(self):
        """
        @since: 0.0.1
        """
        
        self.__LFCtime = []
        self.__DQ2time = []
    
    def __XMLreport(self):
        """
        @since: 0.0.1
        """
        
        if self.options.xml:
            
            dq2Time = 0.0
            for element in self.__DQ2time:
                dq2Time += element
            lfcTime = 0.0
            for element in self.__LFCtime:
                lfcTime += element
                        
            print
            print '<returnValue>'
            
            print ' <errorCode>'
            print '  <int>%s</int>'%self.__errorCode
            print ' </errorCode>'
            
            if len(self.__DQ2time):
            
                print ' <dq2>'
                print '  <float>%s</float>'%dq2Time
                print ' </dq2>'

            if len(self.__LFCtime):
            
                print ' <lfc>'
                print '  <float>%s</float>'%lfcTime
                print ' </lfc>'
            
            print '</returnValue>'
            print
          
    def __checkForPermissions(self):
        """
        @since: 0.3.0
        """
        # remove comments when PermissionType attribute 'PUT' exists.
        user_fqans = get_fqans()    
        
        # If list returned is empty then that means user does not have permissions to perform get 
        if not has_permission(fqans=user_fqans,site=self.DQ2_LOCAL_SITE_ID,permission=PermissionType.UPLOAD):
            err_msg = 'Missing the right role to write to end-point ' + self.DQ2_LOCAL_SITE_ID
            self.report['CLIENTSTATE'] = 'NO_PERM'
            self.__errorCode = 1
            raise DQInvalidRequestException(err_msg)       
            
    def execute(self):
        """
        @since: 0.0.1
        """
        
        self.options = Options(sys.argv[1:])
        
        self.__printVersion()

        if self.options.help:
            print self.usage
        else:
            
            try:

                self.__initReport()
  
                self.__initMeasurement()

                self.__selectSite()
    
                self.__checkForCertificate()
           
                self.__checkForPermissions()
           
                self.__checkAvailableTools()
                
                self.__checkDataset()
                
                self.__checkSource()
                
                self.__confirm()
                
                self.__transfer()

                self.__constructSURLs()

                self.__registerFilesToLFC()
    
                self.__registerDataset()
                
                self.__registerDatasetInContainer()
                
                print 'Finished'

                self.__XMLreport()

            except:
                excType, excValue, excStack = sys.exc_info()
                print excValue
                self.__sendReport()
                self.__XMLreport()
                sys.exit(ErrorCode.ERROR)
        
    def __debug(self, *messages):
        """
        @since: 0.0.1
        """
        
        if self.options.debug:
            for message in messages:
                print message,
            print
    
    def __yesno(self, *messages):
        """
        @since: 0.0.1
        """
        
        for message in messages:
            print message,
        print '(y/n)?',
        
        if self.options.automatic:
            print
            print 'Automatic confirm'
            return True
        
        else:
            response = raw_input()
            
            while response not in ['yes', 'y', 'Y', 'Yes', 'YES', 'no', 'n', 'N', 'No', 'NO']:
                print 'Invalid response! Please answer (y/n)?',
                response = raw_input()
    
            if response in ['yes', 'y', 'Y', 'Yes', 'YES']:
                return True
            else:
                return False

    def __adler32(self, file):
        """
        @since: 0.0.1
        """

        manualChecksum = False
        
        #adler starting value is _not_ 0
        adler=1L
        
        try:
    
            if file.startswith('/castor') or file.startswith('/dpm'):
                openFile = os.popen(self.endpointTool.mssCat(file), 'rb')
            else:
                openFile = open(file, 'rb')
            
            for line in openFile:
                adler=zlib.adler32(line, adler)

        except:
            raise Exception('FATAL - could not get checksum of file %s'%file)

        openFile.close()

        #backflip on 32bit
        if adler < 0:
            adler = adler + 2**32

        return str('%08x'%adler) #return as hexified string, padded to 8 values

    def __initReport(self):
        """
        @since: 0.0.1
        """

        eventType = 'put'
        if self.options.clientId is not None:
            eventType += '_%s'%self.options.clientId

        self.report = {
                      'uuid': generate_uuid().replace('-',''),
                      'eventType': eventType[:10],
                      'eventVersion': self.version.split()[1],
                      'remoteSite': None,
                      'localSite': None,
                      'timeStart': time.time(),
                      'catStart': None,
                      'relativeStart': None,
                      'transferStart': None,
                      'validateStart': None,
                      'timeEnd': None,
                      'duid': None,
                      'version': None,
                      'dataset': self.options.dataset,
                      'clientState': 'INIT_REPORT',
                      'protocol': None,
                      'filename': None,
                      'filesize': None,
                      'guid': None,
                      'usr': None
                      }

    def __sendReport(self):
        """
        @since: 0.0.1
        """

        self.report['timeEnd'] = time.time()

        try:
            TracerClient().addReport(self.report)
        except:
            pass

class Options:
        """
        @since: 0.0.1
        """

        def __init__(self, arguments):
            """
            @since: 0.0.1
            """
            
            self.help = False
            self.automatic = False
            self.local = None
            self.close = True
            self.dataset = None
            self.checksumfile = None
            self.files = []
            self.automatic = False
            self.debug = False
            self.source = None
            self.freeze = False
            self.massStoragePut = None
            self.protocol = None
            self.xml = False
            self.guid = None
            self.relativePath = None
            self.longSURLs = False
            self.datasetSource = None
            self.suffix = None
            self.clientId = None
            self.skipOutputD = False
            self.__parseArguments(arguments)

        def __parseArguments(self, arguments):
            """
            @since: 0.0.1
            """
            
            try:
                optlist, args = getopt.getopt(arguments, 'axg:MN:D:m:dFS:lp:Cs:f:P:L:X',
                ['local-site=', 'do-not-close', 'guid=', 'client-id=','suffix=', 'dataset-source=','long-surls', 'xml','relative-path=','source=','freeze', 'mass-storage=', 'protocol=', 'files=', 'automatic', 'debug','skip-output-on-D'])
                
                self.dataset = arguments[-1]
                
                if '*' in self.dataset:
                    raise Exception('No wildcards allowed in dataset name!')
                
                #set the state according to the arguments
                for o, a in optlist:
                    if o in ('-h', '--help'):
                        self.help = True
                    if o in ('-a', '--automatic'):
                        self.automatic = True      
                    if o in ('-d', '--debug'):
                        self.debug = True
                    if o in ('-C', '--do-not-close'):
                        self.close = False         
                    if o in ('-F', '--freeze'):
                        self.freeze = True     
                    if o in ('-L', '--local-site'):
                        self.local = str(a)
                    if o in ('-p', '--protocol'):
                        self.protocol = str(a)
                    if o in ('-P', '--relative-path'):
                        self.relativePath = str(a)
                    if o in ('-l', '--long-surls'):
                        self.longSURLs = True
                    if o in ('-s', '--source'):
                        self.source = str(a)
                        if '*' in self.source:
                            raise Exception('No wildcards allowed in source directory name!')
                    if o in ('-m', '--mass-storage'):
                        self.massStoragePut = str(a)
                    if o in ('-g', '--guid'):
                        self.guid = str(a)
                    if o in ('-x', '--xml'):
                        self.xml = True
                    if o in ('-f', '--files'):
                        self.files = a.split(',')
                    if o in ('-D', '--dataset-source'):
                        self.datasetSource = str(a)
                    if o in ('-S', '--suffix'):
                        self.suffix = str(a)
                    if o in ('-N', '--client-id'):
                        self.clientId = str(a)
                    if o in ('-X', '--skip-output-on-D'):
                        self.skipOutputD = True

                if self.source is None:
                    self.source = '.'

            except getopt.GetoptError, getoptError:
                ExceptionHandler(getoptError)
            except ValueError, valueException:
                ExceptionHandler(valueException)
            except IndexError, indexError:
                print('Usage: dq2-put [-h/--help | options] <DATASET>')
                ExceptionHandler(indexError)
            except Exception, exception:
                ExceptionHandler(exception)
