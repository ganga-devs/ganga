"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: SetMetaDataAttribute.py,v 1.5 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class SetMetaDataAttribute (DQDashboardTool):
    """
    @since: 0.3.0
    """
    
    usage = "%prog [options] <DATASET> <ATTRIBUTE> <VALUE>"
    
    version = "$Revision: 1.5 $"
    
    description = "Set MetaData Attribute"

    toolOptions = [ ]
    
    def __init__ (self):
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """

        return (self.args[0], self.args[1], self.args[2])
        
    def execute (self):
        """
        @since: 0.3.0
        """
        try:
            dq = getDQ2(self)
        
            dsn, attribute, value = self._get_parameters()
            
            dq.setMetaDataAttribute(dsn, attribute, value)
        
            print "Metadata attribute %s set with value %s for %s" % (attribute, value, dsn)
        except IndexError:
            print "please provide <DATASET> <ATTRIBUTE> <VALUE>"