"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: UnregisterElementsInContainer.py,v 1.2 2008/03/03 16:12:16 psalgado Exp $
"""


from dq2.common.DQDashboardTool import DQDashboardTool
from dq2.clientapi.cli.cliutil import getDQ2


class UnregisterElementsInContainer (DQDashboardTool):
    """
    @since: 1.0
    """


    description = 'Unregister elements from container'
    toolOptions = []
    usage = '%prog [options] <CONTAINER> (dataset version)'
    version = '$Revision: 1.2 $'


    def __init__(self):
        """
        Constructs a UnregisterElementsInContainer instance.
        
        @since: 1.0
        @version: $Revision: 1.2 $
        """
        DQDashboardTool.__init__(self)


    def _get_parameters (self):
        """
        @since: 1.0
        """
        return (self.args[0], self.args[1:])


    def execute (self):
        """
        @since: 1.0
        """
        
        dq = getDQ2(self)
        
        container, args = self._get_parameters()
        
        elements = {}
            
        for i in range(0, len(args), 2):
            elements[args[i]] = int(args[i+1])
        
        warnings = dq.unregister(container, elements)
        
        for w in warnings:
            print w
        
        print "Container %s has been updated." % (container)