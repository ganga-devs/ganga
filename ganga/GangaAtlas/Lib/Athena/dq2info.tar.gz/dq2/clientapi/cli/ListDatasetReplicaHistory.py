"""
@since: 0.3.0

$Id: ListDatasetReplicaHistory.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""

"""
(since 0.3.0)

$Id: ListDatasetReplicaHistory.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""

import string 

from dq2.common import optparse

from dq2.common.DQDashboardTool import DQDashboardTool

from  dq2.clientapi.cli         import cliutil
from dq2.clientapi.cli.cliutil import getDQ2, option_value
    

class ListDatasetReplicaHistory (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog  <DATASET> <SITE>"
    
    version = "$Revision: 1.2 $"
    
    description = "List Dataset Replica History"

    toolOptions = [
     ]
    
    
    def __init__ (self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
        
        
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0], self.args[1]
    
        
    def execute (self):
        """
        (since 0.3.0)
        """
     
        dq = getDQ2(self)
    
        dsn, location = self._get_parameters()        
        out  = ''                
        rows = dq.queryReplicaHistory (dsn=dsn, location=location)
        for r in rows:
	        timeentry       = r['timeentry']
	        lastoperationip = r['lastoperationip']
	        lastoperationdn = r['lastoperationdn']
	        del r['timeentry']
	        del r['lastoperationip']
	        del r['lastoperationdn']
	        out += '------------------------------------------------------------------------\n'
	        out += '%(timeentry)s | %(lastoperationdn)s | %(lastoperationip)s \n' % locals ()
	        for i in r:
	           out += string.ljust(i.lower(), 25) +' : '+ str(r[i]) +'\n'
        print out