"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

import string, commands, re, os, string

from dq2.info import TiersOfATLAS, destination

class EndpointTool:
    """
    @author Mario Lassnig
    @since: 0.0.1
    
    Provide methods to communicate with ATLAS endpoints.
    """
    
    GET = 0
    PUT = 1
    
    #                  protocol: [ ls                       cp                                  mkdir,                  rm]
    __configuration = {'dcap'    :['ls -l',                 'dccp',                             'mkdir -p -m 775',      'rm'],
                       'gsidcap' :['ls -l',                 'dccp',                             'mkdir -p -m 775',      'rm'],
                       'posix'   :['ls -l',                 'cp',                               'mkdir -p -m 775',      'rm'],
                       'bestman' :['srm-ls',                'srm-copy',                         'srm-mkdir',            'srm-rm'],
                       'storm'   :['clientSRM',             'clientSRM',                        'clientSRM',            'clientSRM'],
                       'srm'     :['srmls -2',              'srmcp -2 -retry_num=3',            'srmmkdir -2',          'srmrm -2'],
                       'rfio'    :['rfdir',                 'rfcp',                             'rfmkdir -p -m 775',    'rfrm'],
                       'dpm'     :['dpns-ls -l',            'rfcp',                             'dpns-mkdir -p -m 775', 'rfrm'],
                       'lcg'     :['lcg-ls -l -b -D srmv2', 'lcg-cp -v --vo atlas -b -D srmv2', '',                     'lcg-del -v --vo atlas -b -D srmv2'],
                       'lcg1'    :['lcg-ls -l -b -D srmv1', 'lcg-cp -v --vo atlas -b -D srmv1', '',                     'lcg-del -v --vo atlas -b -D srmv1'],
                       'xrd'     :['',                      'xrdcp -f',                         '',                     ''],
                       'ng'      :['ngls -l',               'ngcp',                             '',                     'ngrm']}

    def __init__(self, operation, dataset, source, destination, localSite, remoteSite, toStorageToken, protocol=None):
        """
        @since: 0.0.1
        
        Configure everything based on local site, remote site and available tools.
        Get additional endpoint information from ToA and select a protocol.
        """
        
        self.operation = operation
        
        self.localSite = localSite
        self.remoteSite = remoteSite
        
        self.source = source
        self.destination = destination
        
        self.dataset = dataset
        
        self.toStorageToken = toStorageToken
        
        if protocol is not None and protocol not in self.__configuration.keys():
            raise Exception('Unknown protocol selected - use one of: %s'%self.__configuration.keys())
        
        self.protocol = protocol
        self.spaceToken, self.endpoint = self.__parseSpaceToken(TiersOfATLAS.getSiteProperty(self.remoteSite, 'srm'))
        self.toaPort = self.__parsePort(TiersOfATLAS.getSiteProperty(self.remoteSite, 'srm'))
        self.toaSRMServer = self.__parseSRMServer(TiersOfATLAS.getSiteProperty(self.remoteSite, 'srm'))

        self.tokenAlreadyPut = False
        
        self.availableProtocols = None
        
        availableProtocols = []

        #is a custom protocol defined? if yes, trust the user
        self.__checkCustomProtocol()

        #but check it nevertheless :)
        if self.__configuration['custom'] != ['', '', '', '']:
            self.protocol = 'custom'
            if not self.__available('custom'):
                raise Exception('FATAL! Custom commands not available! Check your environment!')
        
        else:
            #check for each protocol if it is available
            for protocolConfig in self.__configuration:
                if self.__available(protocolConfig):
                    availableProtocols.append(protocolConfig)
        
            if len(availableProtocols) == 0:
                raise Exception('FATAL! No suitable transfertools available!')
            
            else:
                self.availableProtocols = availableProtocols
    
    def getAvailableProtocols(self):
        """
        @since: 0.0.1
        """
        
        return self.availableProtocols

    def rank(self):
        """
        @since: 0.0.1
        """
        
        #no protocol was forced
        if self.protocol is None:

            self.__identifyAndRank()
       
            #take the first available one from the ranked vs. available
            for tool in self.ranking:
                if tool in self.availableProtocols:
                    self.protocol = tool
                    break
        
            if self.protocol is None:
                raise Exception('FATAL! No suitable transfertools available for the selected endpoint!')
        
        #check protocol that user wants
        else:
            
            if not self.__available(self.protocol):
                raise Exception('FATAL! The transfertool you selected is not available!')
            
        return self.protocol

    
    def __parseSpaceToken(self, srmString):
        """
        @since: 0.0.1
        
        Parse the spacetoken and endpoint from the SRM string
        """
        
        spaceToken = None
        endpoint = srmString
        
        if srmString is None:
            raise Exception('FATAL! - The selected site does not have a correct srm entry in TiersOfATLAS!')
        
        if srmString.startswith('token:'):
            spaceToken = srmString.split(':')[1]
            endpoint = srmString[len(spaceToken)+7:] #jump ahead 'token' plus two times ':'
        
        return (spaceToken, endpoint)
    
    def __parsePort(self, srmString):
        """
        @since: 0.0.1
        
        Parse the port from the SRM string
        """
        
        try:
            for substr in srmString.split(':'):
                if substr[0] in string.digits:
                    return substr.split('/')[0]
        except:
            #if we cannot find the port, then return a sane default
            return '8443'

    def __parseSRMServer(self, srmString):
        """
        @since: 0.0.1
        
        Parse the port from the SRM string
        """
        
        try:
            for substr in srmString.split(':'):
                if substr[0] in string.digits:
                    return substr.split('=')[0][5:]
        except:
            #if we cannot find the port, then return a sane default
            return 'srm/managerv2?SFN'
        
    
    def __checkCustomProtocol(self):
        """
        @since: 0.0.1
        
        Build the datastructure for the custom commands
        """
        
        envCustom = []
        try:
            envCustom.append(os.environ['DQ2_LS_COMMAND'])
        except:
            envCustom.append('')
        try:
            envCustom.append(os.environ['DQ2_COPY_COMMAND'])
        except:
            envCustom.append('')
        try:
            envCustom.append(os.environ['DQ2_MKDIR_COMMAND'])
        except:
            envCustom.append('')
        try:
            envCustom.append(os.environ['DQ2_RM_COMMAND'])
        except:
            envCustom.append('')

        self.__configuration['custom'] = envCustom
    
    def __identifyAndRank(self):
        """
        @since: 0.0.1

        Try to identify of remote endpoint storage system.
        This will rank the protocols in order of preference
        with lcg as a fallback solution everywhere.
        
        If we start to get inconsistency issues, we will need
        to add a storageTypeIdentifier to ToA. (finally: will be in AGIS!)
        """

        # testing hooks
        if self.localSite in ['CERN-DPMTEST']:
            self.ranking = ['dpm']
            return
        
        if self.localSite in ['CERN-DCACHETEST']:
            self.ranking = ['dcap', 'gsidcap']
            return
        
        if self.localSite in ['CERN-XRDTEST']:
            self.ranking = ['xrd']
            return
        
        if self.localSite in ['CERN-CASTORTEST']:
            self.ranking = ['rfio']
            return

        # proper decision
        if self.operation == EndpointTool.GET:
    
            #roaming users
            if self.localSite == 'ROAMING':
                self.ranking = ['ng', 'lcg']
            
            #remote sites default
            elif self.remoteSite != self.localSite:
                self.ranking = ['ng', 'lcg']
    
            #if it is a space-token site
            elif self.spaceToken is not None:
                self.ranking = ['ng','lcg']
    
            #castor
            elif '/castor/' in self.source:
                self.ranking = ['rfio', 'ng', 'lcg']
            #dcache
            elif '/pnfs/' in self.source and 'ndgf' not in self.source:
                self.ranking = ['dcap', 'gsidcap', 'ng', 'lcg']
            #lustre
            elif '/lustre/' in self.source:
                self.ranking = ['lcg']
            #nfs
            elif '/nfs/' in self.source:
                self.ranking = ['posix', 'ng', 'lcg']
            #dpm
            elif '/dpm/' in self.source:
                self.ranking = ['dpm', 'ng', 'lcg']
            #dpm
            elif 'storm' in self.source:
                self.ranking = ['lcg']
            #xrootd
            elif 'root' in self.source or 'xrd' in self.source:
                self.ranking = ['xrd', 'lcg']
            #gpfs
            elif '/gpfs1/' in self.source:
                self.ranking = ['lcg']
            #ifs?
            elif '/ifs1/' in self.source:
                self.ranking = ['lcg']
            #ibrix
            elif '/ibrix/' in self.source:
                self.ranking = ['lcg']
            #nordugrid
            elif 'ndgf' in self.source:
                self.ranking = ['ng', 'lcg']
            #noclue
            else:
                self.ranking = ['ng', 'lcg']
                
        elif self.operation == EndpointTool.PUT:
            
            #roaming users
            if self.localSite == 'ROAMING':
                self.ranking = ['lcg']
            
            #if it is a space-token site
            #(ng cannot put into remote castor sites, so let's prefer to lcg only)
            elif self.spaceToken is not None:
                self.ranking = ['lcg','ng']
            
            #castor
            elif '/castor/' in self.destination:
                self.ranking = ['rfio', 'ng', 'lcg']
            #dcache
            elif '/pnfs/' in self.destination and 'ndgf' not in self.destination:
                self.ranking = ['dcap', 'gsidcap', 'ng', 'lcg']
            #lustre
            elif '/lustre/' in self.destination:
                self.ranking = ['ng', 'lcg']
            #nfs
            elif '/nfs/' in self.destination:
                self.ranking = ['posix', 'ng', 'lcg']
            #dpm
            elif '/dpm/' in self.destination:
                self.ranking = ['dpm', 'ng', 'lcg']
            #dpm
            elif 'storm' in self.destination:
                self.ranking = ['lcg']
            #xrootd
            elif 'root' in self.destination or 'xrd' in self.destination:
                self.ranking = ['xrd', 'lcg']
            #gpfs
            elif '/gpfs1/' in self.destination:
                self.ranking = ['lcg']
            #ifs?
            elif '/ifs1/' in self.destination:
                self.ranking = ['lcg']
            #ibrix
            elif '/ibrix/' in self.destination:
                self.ranking = ['lcg']
            #nordugrid
            elif 'ndgf' in self.destination:
                self.ranking = ['ng', 'lcg']
            #noclue
            else:
                self.ranking = ['ng', 'lcg']
                
            
    def __available(self, protocol):
        """
        @since: 0.0.1
        
        Checks if the transfertools of the selected protocol are available.
        """

        for command in self.__configuration[protocol]:
            if command != '':
                #split in case of mandatory arguments, then take status portion of returntuple
                if commands.getstatusoutput('which %s'%command.split()[0])[0]:
                    return False
                    
        return True   
     
    def prepare(self):
        """
        @since1.1.2.26
        
        Necessary setup to be done only once
        """
        
        #srm requires an internal space token value, so let's query that one
        if self.protocol in ['srm'] and self.spaceToken is not None:
            status, output = commands.getstatusoutput('srm-get-space-tokens -2 -space_desc=%s %s'%(self.spaceToken, self.endpoint))
            if status != 0: 
                raise Exception('FATAL! Could not query SRM space token!')
            
            self.spaceToken = output.split()[-1]

        elif self.protocol in ['bestman'] and self.spaceToken is not None:
            status, output = commands.getstatusoutput('srm-sp-tokens -userdesc %s -serviceurl %s '%(self.spaceToken, self.endpoint))
            if status != 0:
                raise Exception('FATAL! Could not query SRM space token!')
            
            self.spaceToken = output.split()[-1].split('=')[-1]

    def ls(self, file):
        """
        @since: 0.0.1
        
        Return the ls command.
        """

        return string.join([self.__configuration[self.protocol][0], file])
    
    def cp(self, source, destination):
        """
        @since: 0.0.1
        
        Return the cp command.
        """

        #in xrd we only want the source to be a posix-style pathname. strip the "file:" part
        #but xrdcp wants options _after_ the destination, so just add it
        if self.protocol in ['xrd']:
            
            if source.find(':'):
                source = source[source.find(':')+1:]
            
            while source.startswith('//'):
                source = source[1:]
    
            #take care of the castor stager hosts
            if 'castor' in destination:
                destination = destination + '"-ODstagerHost=$STAGE_HOST&svcClass=$STAGE_SVCCLASS"'

        #dcache
        elif self.protocol in ['dcap', 'gsidcap']:
            
            #strip the file prefix and take care of possible double slashes
            destination = destination[destination.find('file://')+7:].replace('//','/')

        #do we want posix-style pathnames? 
        elif self.protocol in ['rfio', 'dpm', 'posix']:
    
            #take care of spacetokens

            if source.find(':'):
                source = source[source.find(':')+1:]
            
            if destination.find(':'):
                destination = destination[destination.find(':')+1:]
    
            while source.startswith('//'):
                source = source[1:]
    
            while destination.startswith('//'):
                destination = destination[1:]
    
            #remove the hostname as well if we only want (rf)cp
            if self.protocol in ['posix']:
                source = re.sub('/[^/]+/', '/', source)
    
        elif self.protocol in ['srm']:
            
            #if we get directly to storage, and a space token is forced, we need to add it
            if self.operation == EndpointTool.GET and self.toStorageToken is not None and not self.tokenAlreadyPut:
                self.tokenAlreadyPut = True
                self.__configuration[self.protocol][1] = self.__configuration[self.protocol][1]+' -space_token='+self.toStorageToken+' '
            
            #if we put with lcg, we need to add the space token if needed 
            if self.operation == EndpointTool.PUT and self.spaceToken is not None and not self.tokenAlreadyPut:
                self.tokenAlreadyPut = True
                self.__configuration[self.protocol][1] = self.__configuration[self.protocol][1]+' -space_token='+self.spaceToken+' '

        elif self.protocol in ['bestman']:
            
            #if we get directly to storage, and a space token is forced, we need to add it
            if self.operation == EndpointTool.GET and self.toStorageToken is not None and not self.tokenAlreadyPut:
                self.tokenAlreadyPut = True
                self.__configuration[self.protocol][1] = self.__configuration[self.protocol][1]+' -spacetoken '+self.toStorageToken+' '
            
            #if we put with lcg, we need to add the space token if needed 
            if self.operation == EndpointTool.PUT and self.spaceToken is not None and not self.tokenAlreadyPut:
                self.tokenAlreadyPut = True
                self.__configuration[self.protocol][1] = self.__configuration[self.protocol][1]+' -spacetoken '+self.spaceToken+' '
    
        elif self.protocol in ['lcg']:
            
            #if we get directly to storage, and a space token is forced, we need to add it
            if self.operation == EndpointTool.GET and self.toStorageToken is not None and not self.tokenAlreadyPut:
                self.tokenAlreadyPut = True
                self.__configuration[self.protocol][1] = self.__configuration[self.protocol][1]+' -S '+self.toStorageToken+' '
            
            #if we put with lcg, we need to add the space token if needed 
            if self.operation == EndpointTool.PUT and self.spaceToken is not None and not self.tokenAlreadyPut:
                self.tokenAlreadyPut = True
                self.__configuration[self.protocol][1] = self.__configuration[self.protocol][1]+' -S '+self.spaceToken+' '

        #the file protocol needs the correct number of /
        #but the file protocol im SRM is broken and needs 4 /
        if not self.protocol in ['srm']:
            source = source.replace('////','///')

        if not self.protocol in ['srm']:
            destination = destination.replace('////','///')
        
        #if the source is castor or dpm, set the local SRM endpoint in front of it
        if source.startswith('file:///castor') or source.startswith('file:///dpm'):
            source='%s=%s'%(self.endpoint[:self.endpoint.find('=')], source[7:])

        if 'managerv1' in source:
            self.protocol='lcg1'

        return string.join([self.__configuration[self.protocol][1], source, destination])

    def mkdir(self, directory):
        """
        @since: 0.0.1
        
        Return the mkdir command.
        """
        
        #ngcp does not create directories automatically on castor
        if self.protocol in ['ng'] and 'castor' in directory:
            return 'rfmkdir -p -m 775 %s'%directory.split('SFN=')[1]
        
        return string.join([self.__configuration[self.protocol][2], directory])
    
    def rm(self, file):
        """
        @since: 0.0.1
        
        Return the rm command.
        """
        
        return string.join([self.__configuration[self.protocol][3], file])
    
    def mssCat(self, file):
        """
        @since: 0.0.1
        
        Command for catting the file from mass storage
        """
        
        if '/castor' in file:
            return 'rfcat %s'%file
        
        elif '/dpm' in file:
            return 'rfcat %s'%file
        
        else:
            raise
    
    def prepareGet(self, surl):
        """
        @since: 0.0.1
        
        Prepare the SURL to return the final SURL for get.
        """
        
        #only return the castor ns path
        if self.protocol in ['rfio']:
            surl = surl[surl.find('/castor/'):]
        
        #only return the dpm ns path
        elif self.protocol in ['dpm']:
            surl = surl[surl.find('/dpm/'):]
        
        #only return the dcache part
        elif self.protocol in ['dcap', 'gsidcap']:
            surl = surl[surl.find('/pnfs/'):]
        
        #mangle the SURL
        elif self.protocol in ['ng', 'lcg', 'lcg1', 'custom']:
            
            #stupid fallback
            if self.toaPort is None:
                self.toaPort='8443' 
            if self.toaSRMServer is None:
                self.toaSRMServer='srm/managerv2?SFN'
            
            #check if SFN or port or both or none are in the SURL and correct to ToA values
            if 'SFN' not in surl and ':' not in surl[4:]:
                surl = re.sub('(?P<srm>^srm://[^:/]+)/', '\g<srm>:%s/%s=/'%(self.toaPort, self.toaSRMServer), surl)

            elif 'SFN' not in surl and ':' in surl[4:]:
                surl = re.sub('(?P<srm>^srm://[^/]+:)[0-9]+/', '\g<srm>%s/%s=/'%(self.toaPort, self.toaSRMServer), surl)

            elif 'SFN' in surl and ':' not in surl[4:]:
                surl = re.sub('(?P<srm>^srm://[^/]+)/.*=', '\g<srm>:%s/%s='%(self.toaPort, self.toaSRMServer), surl)
            
            elif 'SFN' in surl and ':' in surl[4:]:
                surl = re.sub('(?P<srm>^srm://[^/]+:)[0-9]+/.*SFN=/', '\g<srm>%s/%s=/'%(self.toaPort, self.toaSRMServer), surl)         
        
            #take addition care of nordugrid
            if self.protocol in ['ng']:
                if 'castor' in self.endpoint:
                    surl = re.sub('(?P<host>.*:.*):(?P<port>[^/]*)/(?P<rest>.*)','\g<host>:\g<port>\;spacetoken=%s\;protocol=gssapi/\g<rest>'%self.spaceToken, surl)
                else:
                    surl = re.sub('(?P<host>.*:.*):(?P<port>[^/]*)/(?P<rest>.*)','\g<host>:\g<port>\;spacetoken=%s/\g<rest>'%self.spaceToken, surl)
        
        #no clue
        else:
            pass
        
        return surl
    
    def prepareMkdir(self, dataset, relative=None):
        """
        @since: 0.0.1
        
        Prepare the directory path to return the final URL for mkdir.
        """        
    
        if relative is None:
            tmp = self.__mangleEndpointPut() + destination.construct_surl(self.dataset, dataset)
        else:
            tmp = self.__mangleEndpointPut() + relative + destination.construct_surl(self.dataset, dataset)
        
        #remove the hostname and add relative path
        if self.protocol in ['dpm'] and '=' in tmp:
            tmp = tmp.split('=')[1]
            
            if relative is not None:
                tmp = '%s/%s'%(relative, tmp)

        return  tmp[:tmp.rfind('/')]
    
    def __mangleEndpointPut(self):
        """
        @since: 0.0.1
        
        Take care of SURLs for the copy command.
        """        
        
        newSURL = self.endpoint
        
        #remove the host
        if self.protocol in ['rfio','dpm','dcap','gsidcap','posix']:
            newSURL = self.endpoint.split('=')[1]
        
        else:
        
            if 'SFN' not in self.endpoint and ':' not in self.endpoint[4:]:
                newSURL = re.sub('(?P<srm>^srm://[^:/]+)/', '\g<srm>:%s/%s=/'%(self.toaPort, self.toaSRMServer), self.endpoint)
    
            elif 'SFN' not in self.endpoint and ':' in self.endpoint[4:]:
                newSURL = re.sub('(?P<srm>^srm://[^/]+:)[0-9]+/', '\g<srm>%s/%s=/'%(self.toaPort, self.toaSRMServer), self.endpoint)
    
            elif 'SFN' in self.endpoint and ':' not in self.endpoint[4:]:
                newSURL = re.sub('(?P<srm>^srm://[^/]+)/.*=', '\g<srm>:%s/%s='%(self.toaPort, self.toaSRMServer), self.endpoint)
            
            elif 'SFN' in self.endpoint and ':' in self.endpoint[4:]:
                newSURL = re.sub('(?P<srm>^srm://[^/]+:)[0-9]+/.*SFN=/', '\g<srm>%s/%s=/'%(self.toaPort, self.toaSRMServer), self.endpoint)         
   
        #ng needs to encode the space token (and castor fix) in the final SURL
        if self.protocol in ['ng']:
            if 'castor' in self.endpoint:
                newSURL = re.sub('(?P<host>.*:.*):(?P<port>[^/]*)/(?P<rest>.*)','\g<host>:\g<port>\;spacetoken=%s\;protocol=gssapi/\g<rest>'%self.spaceToken, newSURL)
            else:
                newSURL = re.sub('(?P<host>.*:.*):(?P<port>[^/]*)/(?P<rest>.*)','\g<host>:\g<port>\;spacetoken=%s/\g<rest>'%self.spaceToken, newSURL)
   
        return newSURL
    
    def preparePut(self, file, relativePath=None):
        """
        @since: 0.0.1
        
        Prepare the file path to return the final URL for put.
        """
        
        if relativePath is not None:
            
            return self.__mangleEndpointPut() + relativePath + destination.construct_surl(self.dataset, file)
        
        return self.__mangleEndpointPut() + destination.construct_surl(self.dataset, file)[1:]
    
    
    def createSRMforLocal(self, surls):
        """
        @since: 1.1.2.23
        
        If we use a local protocol, make sure that we use the SRM paths on registering to catalogues
        
        @return SRM-enabled SURLs
        """
    
        #prepend SRM server
        if self.protocol in ['rfio','dpm','dcap','gsidcap','posix']:
            
            #take care of the overlap and the single additional slash
            overlap = self.endpoint[self.endpoint.find(self.toaSRMServer)+len(self.toaSRMServer)+1:-1]
            
            for file in surls:
                surls[file]['surl'] = '%s%s'%(self.endpoint, surls[file]['surl'][len(overlap)+1:])
    
        return surls
    
    def fixSurl(self, surl):
        """
        Shorten SURLs.
        
        Port and extension from dq2.transfertool to remove dependency
        
        @return: Short SURL.
        """
        
        #take care of nordugrid extensions on registration 
        if self.protocol in ['ng']:
            if surl.count(';') == 2:
                surl = re.sub('(?P<pre>.*)(?P<ng>\\\;spacetoken=.*\\\;protocol=gssapi)(?P<post>.*)','\g<pre>\g<post>', surl)
            elif surl.count(';') == 1 and 'spacetoken' in surl:
                surl = re.sub('(?P<pre>.*)(?P<ng>\\\;spacetoken=[^/]*)/(?P<post>.*)','\g<pre>/\g<post>', surl)
            elif surl.count(';') == 1 and 'protocol' in surl:
                surl = re.sub('(?P<pre>.*)(?P<ng>\\\;protocol=gssapi)(?P<post>.*)','\g<pre>\g<post>', surl)
        
        
        # SRM
        surl = re.sub(':[0-9]+/', '/', surl)
        surl = re.sub('/srm/managerv1\?SFN=', '', surl)
        surl = re.sub('/srm/managerv2\?SFN=', '', surl)
        surl = re.sub('/srm/v2/server\?SFN=', '', surl)
        
        # GSIFTP
        surl = re.sub('^sfn:', 'gsiftp:', surl)
        surl = re.sub('(?P<gsiftp>^gsiftp://[^:/]+)/', '\g<gsiftp>:2811//', surl)
        return surl
    
    def getMetadata(self, file):
        """
        @since: 0.0.1
        
        Returns a tuple (size, cached, status) for a given file.
        If return values are None, then no information could be retrieved.
        """

        status = 1
        srmSize = None
        isCached = None
        
        #if the protocol is gsiftp we cannot know where to look for metadata
        if 'gsiftp' in file:
            pass
        
        elif self.protocol in ['srm']:
            
            try:
                
                status, output = commands.getstatusoutput(self.ls(file))
                
                output = output.split()
                
                srmSize = output[-2]

                try:
                    if output[10] == 'ONLINE' or output[10] == 'NEARLINE':
                        isCached = True
                    else:
                        isCached = False
                except:
                    isCached = False
                
            except:
                #if the tool is not available don't forget to reset metadata
                status = 1
                srmSize = None
                isCached = None             
        
        elif self.protocol in ['ng']:

            if 'castor' in self.endpoint:
                file = re.sub('(?P<host>.*:.*):(?P<port>[^/]*)/(?P<rest>.*)','\g<host>:\g<port>\;spacetoken=%s\;protocol=gssapi/\g<rest>'%self.spaceToken, file)
            else:
                file = re.sub('(?P<host>.*:.*):(?P<port>[^/]*)/(?P<rest>.*)','\g<host>:\g<port>\;spacetoken=%s/\g<rest>'%self.spaceToken, file)
            
            try:
                
                status, output = commands.getstatusoutput(self.ls(file))
                
                output = output.split()
                
                srmSize = output[2]
                
                if srmSize == '*':
                    srmSize = None

                try:
                    if output[10] == 'ONLINE' or output[10] == 'NEARLINE':
                        isCached = True
                    else:
                        isCached = False
                except:
                    isCached = False
                
            except:
                #if the tool is not available don't forget to reset metadata
                status = 1
                srmSize = None
                isCached = None               
        
        elif self.protocol in ['dpm']:
            
            try:
                
                status, output = commands.getstatusoutput(self.ls(file))
                
                output = output.split()
                srmSize = output[4]
                
            except:
                #if the tool is not available don't forget to reset metadata
                status = 1
                srmSize = None
                isCached = None    
        
        #fallback to configured ls
        else:

            try:
                status, output = commands.getstatusoutput(self.ls(file))
                
                output = output.split()
                srmSize = output[4]
            
                if output[5] == 'ONLINE' or output[5] == 'NEARLINE' or output[5] == 'ONLINE_AND_NEARLINE':
                    isCached = True
                else:
                    isCached = False
            
            except:
                #if the tool is not available don't forget to reset metadata
                status = 1
                srmSize = None
                isCached = None
                
        return (srmSize, isCached, status)