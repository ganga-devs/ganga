"""
(since 0.3.0)

$Id: ListGarbageCollectedFiles.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""

import sys
import cliutil

from   sets      import Set

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.location.DQLocationConstants import TransferState
from dq2.location.DQLocationConstants import MutableState


class ListGarbageCollectedFiles (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog <DATASET> <SITE>"
    
    version = "$Revision: 1.2 $"
    
    description = "List Files In Dataset Replica"

    toolOptions = [
                   cliutil.opt_dataset_version
                   ]
    
    
    def __init__ (self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0], self.args[1]
    
    
    def execute (self):
        """
        (since 0.3.0)
        """
    
        dq = getDQ2(self)
        
        
        dsn, location = self._get_parameters()
        out = ''

        
        ret = dq.listGarbageCollectedFiles(dsn=dsn,  location=location)
        
        if not ret:
            print 'No files found'
            sys.exit(-1)
                      
        for guid in ret:
            print '%s' % (guid)
        
