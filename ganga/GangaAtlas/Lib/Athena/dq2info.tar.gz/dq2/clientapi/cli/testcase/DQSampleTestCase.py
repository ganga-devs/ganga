"""
ContentCatalog.addFilesToDataset* tests.

(since 0.3)

$Id: DQSampleTestCase.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
"""


from dq2.common.DQConstants import TestCaseData
from dq2.common.testcase.DQTestCase import DQTestCase

from dq2.clientapi.DQ2 import DQ2
from dq2.clientapi.cli.Sample import ERROR_DATASET_NAME_TOO_BIG, ERROR_DATASET_HAS_NO_FILES, ERROR_TOO_MANY_FILES, ERROR_UNKNOWN_DATASET, OK, Sample

from dq2.content.DQContentException import DQFileExistsInDatasetException

from dq2.repository.DQRepositoryException import DQDatasetExistsException, DQUnknownDatasetException


dict_guid0 = {
    'lfn': TestCaseData.LFNS[0], 'filesize': TestCaseData.SIZES[0], 'checksum': TestCaseData.CHECKSUMS[0]
}
dict_guid1 = {
    'lfn': TestCaseData.LFNS[1], 'filesize': TestCaseData.SIZES[1], 'checksum': TestCaseData.CHECKSUMS[1]
}
dict_guid2 = {
    'lfn': TestCaseData.LFNS[2], 'filesize': TestCaseData.SIZES[2], 'checksum': TestCaseData.CHECKSUMS[2]
}
dict_guid3 = {
    'lfn': TestCaseData.LFNS[3], 'filesize': TestCaseData.SIZES[3], 'checksum': TestCaseData.CHECKSUMS[3]
}

class DQSampleTestCase (DQTestCase):
    """
    @since: 0.3.0
    """


    def __init__ (self, name):
        """
        @since: 0.3.0
        """
        DQTestCase.__init__(self, name)
        
        self.dq2 = DQ2()
        self.dq2.tuid = 'testcase-0000-0000-0000-000000000000'


# PRIVATE METHODS


    def _execute_and_test (self, tool, status_code):
        """
        Executes the tool and verifies if the expected status code is returned.
        
        @since: 0.3.0
        """
        
        # 0. execute returns a correct status code?
        
        message = '0. execute returns a correct status code?'
        
        result = None
        try:
            tool.execute()
        except SystemExit, e:
            result = int(str(e))
        expected = OK
        
        self.assertEqual(status_code, result, self._fmt_message(message, status_code, result))


# PUBLIC METHODS


    def setUp (self):
        """
        Setup the test data.
        
        @since: 0.3.0
        
        
        Assumption:
            TestCaseData.VUIDS[0] is the initial version of the dataset (or version 1).
            TestCaseData.VUIDS[N] is the N-version of the dataset (or version N+1), where N > 0.
        
        """
        
        
        try:
            self.dq2.registerNewDataset(
                TestCaseData.DSNS[1]
            )
        except DQDatasetExistsException, e:
            pass
        
        
        guids = [TestCaseData.GUIDS[0]]
        lfns = [TestCaseData.LFNS[0]]
        sizes = [TestCaseData.SIZES[0]]
        checksums = [TestCaseData.CHECKSUMS[0]]
        
        try:
            self.dq2.registerNewDataset(
                TestCaseData.DSNS[3],
                lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
            )
        except DQDatasetExistsException, e:
            try:
                print 0
                self.dq2.registerFilesInDataset(
                    TestCaseData.DSNS[3],
                    lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
                )
            except DQFileExistsInDatasetException, e:
                pass
            except StandardError, e:
                print str(e)
        
        guids = TestCaseData.GUIDS[0:4]
        lfns = TestCaseData.LFNS[0:4]
        sizes = TestCaseData.SIZES[0:4]
        checksums = TestCaseData.CHECKSUMS[0:4]
        
        
        try:
            self.dq2.registerNewDataset(
                TestCaseData.DSNS[4],
                lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
            )
        except DQDatasetExistsException, e:
            try:
                self.dq2.registerFilesInDataset(
                    TestCaseData.DSNS[4],
                    lfns=lfns, guids=guids, sizes=sizes, checksums=checksums
                )
            except DQFileExistsInDatasetException, e:
                pass


    def tearDown (self):
        """
        @since: 0.3.0
        """
        
        # cleanup test datasets
        for eachDSN in TestCaseData.DSNS:
            try:
                self.dq2.eraseDataset(eachDSN)
            except DQUnknownDatasetException:
                pass
            except StandardError, e:
                print str(e)
            try:
                self.dq2.repositoryClient.trashDataset(eachDSN)
            except DQUnknownDatasetException:
                pass
            except StandardError, e:
                print str(e)


# TEST methods


    def testSetUp (self):
        """
        Verify if test data is well setup.
        
        @since: 0.3.0
        """
        
        
        # 1. test if files were added in the dataset 1
        
        message = '1. test if files were added in the dataset'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[1])
        expected = ()
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 1.1 test if number of files is correct
        
        message = '1.1 test if getNumberOfFiles'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[1])
        expected = 0
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 2. test if files were added in the dataset 3
        
        message = '2. test if files were added in the dataset'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[3])
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 2.1 test if number of files is correct
        
        message = '2.1 test if getNumberOfFiles'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[3])
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 3. test if files were added in the dataset 4
        
        message = '3. test if files were added in the dataset'
        
        result = self.dq2.listFilesInDataset(TestCaseData.DSNS[4])
        result = result[0]
        expected = {
            TestCaseData.GUIDS[0]: dict_guid0,
            TestCaseData.GUIDS[1]: dict_guid1,
            TestCaseData.GUIDS[2]: dict_guid2,
            TestCaseData.GUIDS[3]: dict_guid3
        }
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        # 3.1 test if number of files is correct
        
        message = '3.1 test if getNumberOfFiles'
        
        result = self.dq2.getNumberOfFiles(TestCaseData.DSNS[4])
        expected = 4
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def scenarioCreateASample (self):
        """
        Scenario: verify a dq2-sample execution.
        
        @since: 0.3.0
        
        """
        
        
        # 1. creating a sample of the latest version
        
        tool = Sample()
        tool.args = [TestCaseData.DSNS[3]]
        self._execute_and_test(tool, OK)
        
        
        # 1.1 listFilesInDataset returns a correct response?
        
        message = '1.1 listFilesInDataset returns a correct response?'
        
        result = self.dq2.listFilesInDataset(tool.newdsn)
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.2 getNumberOfFiles returns a correct response?
        
        message = '1.2 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(tool.newdsn)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.3 listDatasets returns a correct response? in the end there should always be one sample per user
        
        message = '1.3 listDatasets returns a correct response? in the end there should always be one sample per user'
        
        result = self.dq2.listDatasets(tool.patterndsn)
        result = len(result)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def scenarioCreateASampleTwice (self):
        """
        Scenario: verify that after a duplicate dq2-sample execution there is always one sample in the end.
        
        @since: 0.3.0
        
        """
        
        
        # 1. creating 2 samples of the latest version
        
        tool = Sample()
        tool.args = [TestCaseData.DSNS[3], 1]
        self._execute_and_test(tool, OK)
        self._execute_and_test(tool, OK)
        
        
        # 1.1 listFilesInDataset returns a correct response?
        
        message = '1.1 listFilesInDataset returns a correct response?'
        
        result = self.dq2.listFilesInDataset(tool.newdsn)
        result = result[0]
        expected = {TestCaseData.GUIDS[0]: dict_guid0}
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.2 getNumberOfFiles returns a correct response?
        
        message = '1.2 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(tool.newdsn)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.3 listDatasets returns a correct response? in the end there should always be one sample per user
        
        message = '1.3 listDatasets returns a correct response? in the end there should always be one sample per user'
        
        result = self.dq2.listDatasets(tool.patterndsn)
        result = len(result)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def scenarioCreateSmallerSample (self):
        """
        Scenario: verify a dq2-sample execution when user specifies the number of files.
        
        @since: 0.3.0
        
        """
        
        
        # 1. creating a smaller sample of the latest version with a specific number of files
        
        tool = Sample()
        tool.args = [TestCaseData.DSNS[4]]
        tool.options.nfiles = 2
        self._execute_and_test(tool, OK)
        
        
        # 1.1 listFilesInDataset returns a correct response?
        
        message = '1.1 listFilesInDataset returns a correct response?'
        
        output = self.dq2.listFilesInDataset(tool.newdsn)
        output = output[0]
        
        for eachGUID in output.keys():
            result = eachGUID in TestCaseData.GUIDS[0:4]
            expected = True
            
            self.assertEqual(expected, result, self._fmt_message(message, TestCaseData.GUIDS[0:4], output.keys()))
        
        
        # 1.2 getNumberOfFiles returns a correct response?
        
        message = '1.2 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(tool.newdsn)
        expected = 2
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.3 listDatasets returns a correct response? in the end there should always be one sample per user
        
        message = '1.3 listDatasets returns a correct response? in the end there should always be one sample per user'
        
        result = self.dq2.listDatasets(tool.patterndsn)
        result = len(result)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def scenarioCreateRandomSample (self):
        """
        Scenario: verify a dq2-sample execution when user specifies the number of files.
        
        @since: 0.3.0
        
        """
        
        
        # 1. creating a smaller sample of the latest version with a specific number of files.
        
        tool = Sample()
        tool.args = [TestCaseData.DSNS[4]]
        tool.options.nfiles = 2
        tool.options.random = True
        
        self._execute_and_test(tool, OK)
        
        # 1.2 listFilesInDataset returns a correct response?
        
        message = '1.2 listFilesInDataset returns a correct response?'
        
        output = self.dq2.listFilesInDataset(tool.newdsn)
        output = output[0]
        
        for eachGUID in output.keys():
            result = eachGUID in TestCaseData.GUIDS[0:4]
            expected = True
            
            self.assertEqual(expected, result, self._fmt_message(message, TestCaseData.GUIDS[0:4], output.keys()))
        
        
        # 1.3 getNumberOfFiles returns a correct response?
        
        message = '1.3 getNumberOfFiles returns a correct response?'
        
        result = self.dq2.getNumberOfFiles(tool.newdsn)
        expected = 2
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        
        # 1.4 listDatasets returns a correct response? in the end there should always be one sample per user
        
        message = '1.4 listDatasets returns a correct response? in the end there should always be one sample per user'
        
        result = self.dq2.listDatasets(tool.patterndsn)
        result = len(result)
        expected = 1
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def attemptToSample (self):
        """
        Scenario: verify a dq2-sample execution when:
        
        1. number of files, specified by user, is greater than number of files in dataset
        2. dataset has no files
        3. dataset name is too big
        4. dataset doesn't exist
        
        @since: 0.3.0
        
        """
        
        
        # 1. number of files, specified by user, is greater than number of files in dataset
        
        tool = Sample()
        tool.args = [TestCaseData.DSNS[3]]
        tool.options.nfiles = self.dq2.getNumberOfFiles(TestCaseData.DSNS[3]) + 1
        
        self._execute_and_test(tool, ERROR_TOO_MANY_FILES)
        
        
        # 2. dataset has no files
        
        tool.options.nfiles = None
        tool.args = [TestCaseData.DSNS[1]]
        
        self._execute_and_test(tool, ERROR_DATASET_HAS_NO_FILES)
        
        
        # 3. dataset name is too big
        
        tool.args = [TestCaseData.DSNS[0]]
        
        self._execute_and_test(tool, ERROR_DATASET_NAME_TOO_BIG)
        
        
        # 4. dataset doesn't exist
        
        tool.args = [TestCaseData.DSNS[5]]
        self._execute_and_test(tool, ERROR_UNKNOWN_DATASET)


if __name__ == '__main__':
    """
    Runs all tests in DQSampleTestCase.
    
    (since 0.2.0)
    """
    import sys
    
    tests = sys.argv[1:]
    if len(tests) == 0:
        tests = [
            'testSetUp', 'scenarioCreateASample', 'scenarioCreateASampleTwice',
            'scenarioCreateSmallerSample', 'scenarioCreateRandomSample',
            'attemptToSample'
        ]
    
    test = DQSampleTestCase.main(
        'dq2.clientapi.cli.testcase', DQSampleTestCase.__name__, tests, debug=True
    )
