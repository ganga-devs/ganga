"""
USAGE
dq2-sample <dsn> <number of files> 


NAME
dq2-sample - copies a portion of an existing dataset and registers it into DQ2.

SYNOPSIS 
dq2-sample 
dataset name 
number of files 

options: 
-r pick files randomly 


DESCRIPTION 

dq2-sample is a tool specifically designed to create a smaller sample from an existing dataset.

It will read the original dataset files and replica information. 
After it creates a new sample dataset registering only the user defined number of files and mark the sample dataset replicas on the DQ2 central catalogs. 

The sample dataset name will be generated automatically using the following pattern: 

user.<user_DN>.sample.<timestamp>.<original_dataset_name>

A user can only have a sample dataset per dataset.

@since: 0.3.0

$Id: Sample.py,v 1.2 2009/10/06 13:23:17 angelos Exp $
"""


import cliutil
import optparse
import random
import sys
import time


from dq2.common import dict_get_item, optparse
from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common.client.x509 import get_dn

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.repository.DQRepositoryException import DQUnknownDatasetException


OK = 0
ERROR_DATASET_NAME_TOO_BIG = -1
ERROR_TOO_MANY_FILES = -2
ERROR_DATASET_HAS_NO_FILES = -3
ERROR_UNKNOWN_DATASET = -4


class Sample (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog <DATASET> "
    
    version = "$Revision: 1.2 $"
    
    description = 'Create a smaller sample from an existing dataset'
    
    toolOptions = [
        cliutil.opt_dataset_version,
        optparse.make_option(
            '-n', '--number-files',
            dest='nfiles',
            default=None,
            help='specify the number of files to be copied'
        ),
        optparse.make_option(
            '-r', '--random',
            action='store_true',
            dest='random',
            default=False,
            help='specify if the files should be picked randomly'
        )

    ]


    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)


    def __del__ (self):
        """
        Everytime you create an instance DQDashboardTool will try to setup
        
        @since: 0.3.0
        """
        Sample.toolOptions = []


    def __str__ (self):
        """
        @since: 0.3.0
        """
        return 'dq2-sample :: %s : version=%s' % (str(self.args), self.options.version)


    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]


    def execute (self):
        """
        @since: 0.3.0
        """
        
        
        # 1.1 retrieving parameters
        
        dn = get_dn()
        hindex = dn.rfind('CN=')
        if hindex > 0:
            cn = dn[hindex+3:]
        else:
            cn = dn
	cn = cn.replace(' ', '')
        
        dsn = self._get_parameters()
        dsn.replace('*', '')
        
        
        # 1.2 instantiating DQ and producing a new timestamp
        
        dq = getDQ2(self)
        time_now = '%04i_%02i_%02i' % time.gmtime()[0:3]
        
        
        # 2. cleaning up old samples of the same dataset
        
        self.newdsn = 'user.%s.sample.%s.%s' % (cn, dsn, time_now)
        self.patterndsn = 'user.%s.sample.%s.*' % (cn, dsn)
        
        if len(self.patterndsn) > 255:
            sys.stderr.write('Error: cannot create sample of this dataset. its dataset name is too big!\n')
            sys.exit(ERROR_DATASET_NAME_TOO_BIG)
        
        sampled_datasets = dq.listDatasets(self.patterndsn)
        
        if len(sampled_datasets) > 0:
            for eachSample in sampled_datasets.keys():
                dq.eraseDataset(eachSample)
                dq.repositoryClient.trashDataset(eachSample)
                sys.stdout.write('deleted sample %s ...\n' % (eachSample))
        
        
        # 3. retrieving files
        
        try:
            ret = dq.listFilesInDataset(dsn, version=self.options.version)
        except DQUnknownDatasetException, e:
            sys.stderr.write(str(e))
            sys.exit(ERROR_UNKNOWN_DATASET)
        
        
        try:
            files = ret[0]
        except IndexError, e:
            sys.stderr.write('Error: dataset has no files!\n')
            sys.exit(ERROR_DATASET_HAS_NO_FILES)
        
        if self.options.nfiles is None:
            
            self.options.nfiles = 0
            rate = 0.1
            
            while self.options.nfiles == 0:
                
                self.options.nfiles = int(len(files) * rate)
                rate = rate + 0.1
                
                if rate >= 1:
                    self.options.nfiles = len(files)
        
        if self.options.nfiles > len(files):
            sys.stderr.write('Error: the dataset has (%u) files which is less than the number (%u) specified by the user!\n' % (len(files), self.options.nfiles))
            sys.stdout.write('Help: choose a number lower or equal than %u...\n' % (len(files)))
            sys.exit(ERROR_TOO_MANY_FILES)
        
        guids, lfns, sizes, checksums = [], [], [], []
        
        
        if not self.options.random:
            """choose the first nfiles"""
            for guid in files.keys():
                guids.append(guid)
                lfns.append(files[guid]['lfn'])
                sizes.append(long(files[guid]['filesize']))
                checksums.append(files[guid]['checksum'])
                
                if len(guids) >= self.options.nfiles:
                    break
            
        else:
            """random file selection"""
            while len(guids) < self.options.nfiles:
                guid = random.choice(files.keys())
                guids.append(guid)
                lfns.append(files[guid]['lfn'])
                sizes.append(long(files[guid]['filesize']))
                checksums.append(files[guid]['checksum'])
                
                del files[guid] # do not use this file any more
        
        
        # 4. creating a new sample of the dataset
        
        dq.registerNewDataset(self.newdsn, guids=guids, lfns=lfns, sizes=sizes, checksums=checksums)
        
        sys.stdout.write('created sample %s ...' % (self.newdsn))
        sys.exit(OK)
