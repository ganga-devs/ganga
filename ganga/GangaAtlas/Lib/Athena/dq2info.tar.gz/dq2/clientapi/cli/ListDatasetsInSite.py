"""
(since 0.3.0)
"""

from dq2.common import optparse
from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli                  import cliutil
from dq2.clientapi.cli.cliutil          import getDQ2

from dq2.location.DQLocationConstants import LocationState

class ListDatasetsInSite (DQDashboardTool):
    """
    (since 0.3.0)
    """

    usage = "%prog [options] <SITENAME> "
    
    version = "$Revision: 1.7 $"
    
    description = "List Datasets In Site"

    toolOptions = [
                   optparse.make_option(
                    "-r", "--resultPerPage",
                    dest="rpp",
                    default=None,
                    type='int',
                    help="Print rrp first results"),
			        optparse.make_option(
            		"-i", "--incomplete",
		            action="store_true",
        		    dest="incomplete",
		            default=False,
        		    help="only list incomplete datasets"
			        ),
			        optparse.make_option(
		             "-c", "--complete",
        		     action="store_true",
		             dest="complete",
		             default=False,
        		     help="only list complete datasets"
			         ),                    
                   optparse.make_option(
                    "-p", "--page",
                    dest="p",
                    default=None,
                    type='int',
                    help="Specify page to print"),
                    optparse.make_option(
                    "-n", "--name",
                    dest="name",
                    default=None,
                    type='str',
                    help="Specify a dataset name pattern"),
                    optparse.make_option(
                    "-g", "--group",
                    dest="group",
                    default=None,
                    type='str',
                    help="Specify a group name")
                    
    ]
    
    
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0]
 
    
    def __init__ (self):
        """
        (since 0.3.0)
        """
        DQDashboardTool.__init__(self)
    
    
    def _get_parameters (self):
        """
        (since 0.3.0)
        """
        return self.args[0]
        
        
    def execute(self):
        """
        (since 0.3.0)
        """

        dq = getDQ2(self)
    
        location = self._get_parameters()
        
        complete = None
        if self.options.complete:
            complete = LocationState.COMPLETE
        if self.options.incomplete:
            complete = LocationState.INCOMPLETE
        
        
        out = ''
        ret = dq.listDatasetsByNameInSite(site=location, complete=complete, name=self.options.name, p=self.options.p, rpp=self.options.rpp, group= self.options.group)
              
        for dsn in ret:
            print '%s' % (dsn)
