"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ListDatasetsByMetaData.py,v 1.9 2009/10/06 13:23:18 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common.DQException import DQException
from dq2.common import DQConstants

from dq2.clientapi.cli.cliutil import getDQ2


class ListDatasetsByMetaData (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options] (<ATTRIBUTE1> <VALUE1> <ATTRIBUTE2> <VALUE2>...)"
    
    version = "$Revision: 1.9 $"
    
    description = "List Datasets by Metadata"

    toolOptions = []

    def __init__(self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)

    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0:]

    def execute(self):
        """
        @since: 0.3.0
        """
        
        dq = getDQ2(self)
 
        filter = {}
        
        try:
            
            argv = self._get_parameters()

            if len(argv) == 0:
                raise IndexError

            for i in range(0, len(argv), 2):
                filter[argv[i]] = argv[1+i]

            #resolve the state
            if filter.has_key('state'):
                for i in DQConstants.DatasetState.DESCRIPTION:
                    if filter['state'] == i:
                        filter['state'] = DQConstants.DatasetState.DESCRIPTION.index(i)

            #are we still a string?
            dummy = int(filter['state'])

            ret = dq.listDatasetsByMetaData(filter)
            
            for i in ret:
                print i
                
        except IndexError, e:
            print "please provide <ATTRIBUTE1> <VALUE1> <ATTRIBUTE2> <VALUE2>..."
        except ValueError, e:
            print "You have given a wrong state. Use 'open','closed' or 'frozen'."