"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ListFilesInDataset.py,v 1.11 2009/10/06 13:23:18 angelos Exp $
"""

import sys
import cliutil

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2


class ListFilesInDataset (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog <DATASET> "
    
    version = "$Revision: 1.11 $"
    
    description = "List Files In Dataset"

    toolOptions = [
                   cliutil.opt_dataset_version
                   ]
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
    
    def _get_parameters (self):
        """
        @since: 0.3.0
        """
        return self.args[0]
    
    
    def execute(self):
        """
        @since: 0.3.0
        """
        dq = getDQ2(self)
        
        
        dsn = self._get_parameters()
        out = ''
        hadNone = False
        count = 0
        size = 0
        
        ret = dq.listFilesInDataset(dsn, version=self.options.version)
        
        try:
            entry = ret[0]
        except IndexError, e:
            sys.exit(0)
        
        for guid in entry:
            fs = entry[guid]['filesize']
            print entry[guid]['lfn'],
            print "\t%s" % guid,
            if entry[guid]['checksum'] is not None:
                print "\t%s" % entry[guid]['checksum'],
            if fs is not None:
                print "\t%s" % fs,
            print
            count += 1
            if fs is None:
                hadNone = True
            else:
                size += fs
        print out
        print 'total files: %u' % (count)
        if not hadNone:
            print 'total size: %u' % (size)
        print 'date: %s' % (ret[1])