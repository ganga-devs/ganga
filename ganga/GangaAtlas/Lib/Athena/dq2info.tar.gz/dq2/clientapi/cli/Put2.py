"""
Copyright (c) ATLAS Distributed Data Management project, 2009.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""


import commands
import errno
import getopt
import logging
import md5
import os
import string
import socket
import sys
import traceback
import urllib2
import zlib

from dq2.clientapi.DQ2 import DQ2
from dq2.common import generate_uuid
from dq2.common import log
from dq2.common import optparse
from dq2.common.cli.DQDashboardTool import DQDashboardTool
from dq2.common.DQConstants import DatasetState
from dq2.filecatalog import create_file_catalog
from dq2.filecatalog.lfc.lfcconventions import to_native_lfn
from dq2.filecatalog.FileCatalogException import FileCatalogException
from dq2.info import destination
from dq2.info import TiersOfATLAS
from dq2.info import TiersOfATLASValidator
from dq2.subscription.DQSubscriptionConstants import SubscriptionArchivedState



""" error codes for Tier-0 XML response """
__EOK__ = 0
__EWARN__ = 1
__EFATAL__ = 2


class Put2(DQDashboardTool):
    """
    @since 1.1.2.1
    
    @author: Mario Lassnig <mario.lassnig@cern.ch>
    @version: $Id: Put2.py,v 1.2 2009/10/06 13:23:18 angelos Exp $
    """

    usage = "dq2-put [-h/--help | options] <DATASET>"

    version = "$Revision: 1.2 $"
    
    description = \
"""\
Create a dataset from a local directory or another dataset. This will put the files on a
mass-storage-system if necessary and register them to the central and local catalogues;
thus making them available to all ATLAS users via the grid.

If a file has '.pool.root' in his name, the GUID needs to be extracted from the file using POOL.
This means that you need to setup ATHENA before setting up DQ2.

For more information, go here: https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2ClientsHowTo
"""
 
    toolOptions = [
        optparse.make_option(
            '-d', '--debug',
            dest='debug',
            action='store_true',
            default=False,
            help='Enable debug output'
        ),
        optparse.make_option(
            '-L', '--local-site',
            dest='local',
            default=None,
            help='Override environment variable DQ2_LOCAL_SITE_ID'
        ),
        optparse.make_option(
            '-a', '--automatic',
            dest='automatic',
            action="store_true",
            default=False,
            help='Do not prompt - assume yes on all questions'
        ),
        optparse.make_option(
            '-p', '--partition-size',
            dest='partition',
            default=None,
            help='Set partition size (default: 10)'
        ),
        optparse.make_option(
            '-s', '--source',
            dest='source',
            default=None,
            help='Source directory containing the files for the dataset'
        ),
        optparse.make_option(
            '-F', '--freeze',
            dest='freeze',
            action="store_true",
            default=False,
            help='Freeze the dataset upon successful completion'
        ),
    ]
    
    
    def __init__(self):
        """
        @since 1.1.2.1
        """
        
        self.__logger = log.getLogger('dq2.clientapi.cli')
        
        #sanity check without dependencies and hard kill
        try:
            os.environ['DQ2_ENDUSER_SETUP'] 
        except:
            self.__logger.critical('Please setup the DQ2Clients environment!')
            self.__logger.critical('More information: https://twiki.cern.ch/twiki/bin/view/Atlas/DistributedDataManagement')
            sys.exit(1)

        #ok, we should be set-up, so check version of the clients
        try:
            urlstream = urllib2.urlopen('http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache/DQ2PUT2LATEST')
            remoteVersion = urlstream.read()
            if self.version.split()[1] != remoteVersion.replace('\n',''):
                self.__logger.warn('\nYou are not using the latest released stable version of the DQ2 clients!\n')
                self.__logger.warn('Please check https://twiki.cern.ch/twiki/bin/view/Atlas/DQ2Clients for the newest version number, go to the directory where you installed them and do:\n')
                self.__logger.warn('  pacman -get "http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache:DQ2Clients | version(\'version number\')"')
                self.__logger.warn('\nFor example:\n')
                self.__logger.warn('  pacman -get "http://atlas.web.cern.ch/Atlas/GROUPS/DATABASE/project/ddm/releases/pacman/cache:DQ2Clients | version(\'0.1.13\')"\n')
                self.__logger.warn('RPM installations can be upgraded with yum or apt.')
                self.__logger.warn('Please see the documentation for details.')
                
        except:
            self.__logger.warn('Cannot verify client tools version! You might not use the latest released stable version!')

        DQDashboardTool.__init__(self)

        self.__logger.setLevel(logging.INFO)
                
        self.__errorCode = __EOK__
        self.__dq2 = DQ2()
        
        
    def execute(self):
        """
        @since: 1.1.2.1
        """
        
        try:

            self.options = Options(sys.argv[1:], self.__logger)
            
            if self.options.debug:
                self.__logger.setLevel(logging.DEBUG)
    
            if self.options.help:
                self.__logger.info(self.usage)
            else:

                self.__logger.debug('dq2-put2 %s'%self.version.split()[1])

                self.__validateEnvironment()
                
                self.__selectModeOfOperation()
                
                self.__validateFiles()
                
                self.__operationBegin()
                
                self.__copyAndRegister()
                
                self.__operationEnd()
                
        except:
            self.__logger.fatal(sys.exc_info()[1])
            self.__errorCode = __EFATAL__
            self.__sendTrace()


    def __validateEnvironment(self):
        """
        @since: 1.1.2.2
        """
        
        self.__logger.debug('Step: Validating environment')

        #are we overriding the environment?
        if self.options.local is not None:
            self.DQ2_LOCAL_SITE_ID = self.options.local
        else:
            #no? so check environment
            try:
                self.DQ2_LOCAL_SITE_ID = os.environ['DQ2_LOCAL_SITE_ID']
            except KeyError:
                raise Exception('You must set your site! (set with -L or environment variable DQ2_LOCAL_SITE_ID)')

        if self.DQ2_LOCAL_SITE_ID == 'ROAMING':
            raise Exception('ROAMING putting of files not possible.')

        #is it a valid Tiers of ATLAS site?
        TiersOfATLASValidator.is_site(self.DQ2_LOCAL_SITE_ID)

        hostDomain = string.join(socket.gethostbyaddr(socket.gethostname())[0].split('.')[-2:], '.')
        toaDomain = TiersOfATLAS.getSiteProperty(self.DQ2_LOCAL_SITE_ID, 'domain')
        
        if toaDomain is None:
            str = '\nAttention!\n\n'
            str += 'You have selected a site that is not in recognised by DQ2 (not in Tiers of ATLAS or AGIS).\n'
            str += 'You will not be able to use dq2-put2.\n'
            str += 'Please ask your system administrator which sitename you should use.\n\n'
            self.__logger.warn(str)
            raise Exception('Aborted!')
        
        if not toaDomain.startswith('DESY'):
        
            if toaDomain is not None and hostDomain not in toaDomain:
                str = '\nAttention!\n\n'
                str += 'Your host-domain (%s) does not verify against the selected DQ2 site identification (%s)!\n'%(hostDomain, self.DQ2_LOCAL_SITE_ID)
                str += 'This means that you are copying/registering files into the WRONG SITE!\n'
                str += 'Please set the environment variable DQ2_LOCAL_SITE_ID to a correct value.\n'
                str += 'You can list all possible values for DQ2_LOCAL_SITE_ID with the command: dq2-sources\n'
                str += 'Change your environment to use the appropriate one.\n\n'
                str += 'In case of questions, please contact atlas-dq2-support@cern.ch\n'
                self.__logger.warn(str)

                if not self.__yesno('Do you want to continue with the wrong setting? (ATTENTION: this is most likely a bad idea!) (y/n):'):
                    raise Exception('Aborted!')

        self.__logger.debug('Shell okay, validating certificate')
        
        proxycheck = 'voms-proxy-info'
        
        status, output = commands.getstatusoutput('%s -e'%proxycheck)

        if 'command not found' in output:
            self.__logger.warning('Missing voms-proxy-init binary. Unable to verify proxy on the client-side. Trying with grid-proxy-init but you may run into permission problems!')
            proxycheck = 'grid-proxy-info'
            status, output = commands.getstatusoutput('%s -e'%proxycheck)
            if 'command not found' in output:
                self.__errorCode = __EFATAL__
                raise Exception('Missing both voms-proxy-info and grid-proxy-info binaries. Please source the correct setup script (source setup[.sh,.csh,.zsh])!')
        elif status != 0:
            self.__errorCode = __EFATAL__
            raise Exception('Missing voms proxy. Create one with: voms-proxy-init -voms atlas')

        #anonymise the user identity
        m=md5.new()
        m.update(commands.getstatusoutput('%s -identity' %proxycheck)[1])
        
        self.__logger.debug('Environment okay, checking site information')

        self.spaceToken = None
        self.srmEndpoint = TiersOfATLAS.getSiteProperty(self.DQ2_LOCAL_SITE_ID, 'srm')
        
        if self.srmEndpoint is None:
            raise Exception('Site does not have an SRM entry')
        
        if self.srmEndpoint.startswith('token:'):
            self.spaceToken = self.srmEndpoint.split(':')[1]
            self.srmEndpoint = self.srmEndpoint[len(self.spaceToken)+7:]
            
        self.__logger.debug('Site information okay (srm=%s, spacetoken=%s), proceeding'%(self.srmEndpoint, self.spaceToken))


    def __selectModeOfOperation(self):
        """
        @since: 1.1.2.2
        """
        
        self.__logger.debug('Step: Mode of operation')
        
        #self.__logger.debug('Direct registration mode')
        #self.__logger.debug('Conditions mode')
        self.__logger.debug('User mode')


    def __validateFiles(self):
        """
        @since: 1.1.2.2
        """

        self.__logger.debug('Step: Validating files')

        filesInSource = []
        
        if os.getcwd().startswith('/pnfs'):
            raise Exception('Direct put from dCache not possible yet with dq2-put2')
        
        if self.options.source is not None:
            if self.options.source.startswith('/castor') or self.options.source.startswith('/dpm'):
                raise Exception('Direct put from CASTOR or DPM is not possible yet with dq2-put2')
        
        if self.options.source is None:
            self.__logger.debug('Gathering list of files in current directory: %s', os.getcwd())
            for file in os.listdir(os.getcwd()):
                if os.path.isfile(file) and os.path.getsize(file)>0:
                    filesInSource.append(file)
        else:
            self.__logger.debug('Gathering list of files in: %s', self.options.source)
            for file in os.listdir(self.options.source):
                if os.path.isfile(self.options.source+'/'+file) and os.path.getsize(self.options.source+'/'+file)>0:
                    filesInSource.append(file)

        self.__logger.debug('Check for pool.root files')
        
        needPool = False
        for file in filesInSource:
            if 'pool.root' in file:
                needPool = True
                break
            
        if needPool:
            if commands.getstatusoutput('which pool_extractFileIdentifier')[0]:
                raise Exception('FATAL - You are trying to register pool.root files without having POOL set up! Please source the Athena environment before sourcing the DQ2 environment!')
        
        
        self.checkedFiles = {}
        for file in filesInSource:
        
            self.__logger.info('Pre-checking file: %s'%file)

            if self.options.source is not None:
                pathfile = os.path.join(self.options.source, file)
            else:
                pathfile = os.path.join(os.getcwd(), file)
            
            guid = generate_uuid()
            fsize = os.path.getsize(pathfile)

            if '.pool.root' in file:
                try:
                    status, output = commands.getstatusoutput('pool_extractFileIdentifier %s'%pathfile)
                except:
                    self.__logger.fatal('Could not get GUID from pool.root file')
                    raise
                            
                if 'segmentation violation' in output:
                    raise Exception('Your pool_extractFileIdentifier command is broken. Please check and fix your environment. We cannot proceed without a proper POOL environment when registering pool.root files. Here is the output of the broken command:\n%s'%output)
                            
                #the guid is always on the last line and there might be errors before
                guid = output[output.rfind('\n')+1:].split()[0]
        
            self.checkedFiles[guid]={'dsn': self.options.dsn,
                                     'source': os.path.abspath(pathfile),
                                     'lfn': file,
                                     'checksum': None,
                                     'fsize': fsize,
                                     'archival': SubscriptionArchivedState.__ANY__,
                                     'partition': None}
        
    
    def __operationBegin(self):
        """
        @since: 1.1.2.2
        """

        self.__logger.debug('Step: Operation setup')

        self.__logger.debug('Dataset operation')

        self.__logger.debug('Creating/versioning dataset: %s', self.options.dsn)
        
        createDataset = False
        self.__datasetVersioning = { 'latestversion': 0, 'state': DatasetState.OPEN }
        try:
            self.__datasetVersioning = self.__dq2.getMetaDataAttribute(self.options.dsn, ['latestversion','state'])
            self.__logger.debug('Dataset exists, re-using it')
        except:
            self.__logger.debug('Dataset does not exist, creating it')
            createDataset = True
        
        if createDataset:
            try:
                self.__logger.info('Creating dataset')
                self.__dq2.registerNewDataset(self.options.dsn)
            except:
                self.__logger.fatal('Dataset could not be created')
                raise
        else:
            try:
                self.__logger.info('Versioning dataset to %s'%(int(self.__datasetVersioning['latestversion'])+1))
                self.__dq2.registerNewVersion(self.options.dsn)
            except:
                self.__logger.fatal('Dataset could not be versioned')
                raise

        self.__logger.info('Setting dataset location: %s', self.DQ2_LOCAL_SITE_ID)
        try:
            self.__dq2.registerDatasetLocation(self.options.dsn, self.DQ2_LOCAL_SITE_ID, (int(self.__datasetVersioning['latestversion'])+1))
            self.__logger.info('Dataset location set')
        except:
            self.__logger.fatal('Dataset location information (%s, %s, %s) could not be set'%(self.options.dsn, self.DQ2_LOCAL_SITE_ID, (int(self.__datasetVersioning['latestversion'])+1)))
            raise

        self.__logger.debug('Partitioning into %s files per bulk'%self.options.partition)

        count = 0
        currentPartition = 1
        
        #n files per partition
        for file in self.checkedFiles:
            count += 1
            self.checkedFiles[file]['partition'] = currentPartition
            if count == self.options.partition:
                currentPartition += 1
                count = 0
        
        #remove superfluous partitions
        self.nrPartitions = currentPartition
        if count == 0:
            self.nrPartitions -= 1


    def __copyAndRegister(self):
        """
        @since: 1.1.2.2
        """

        self.__logger.debug('Step: Transferring and registering files')

        datasetOpen = False
        
        output = 'Internal dq2-put2 error'
        status = -1
                    
        if self.spaceToken is None:
            exe = 'LFC_HOST=%s lcg-cr -v --vo atlas -D srmv2 -b -d %s -g %s -l lfn:%s file://%s'
        else:
            exe = 'LFC_HOST=%s lcg-cr -v --vo atlas -D srmv2 -b -d %s -s %s -g %s -l lfn:%s file://%s'

        self.__logger.debug('Trying to get LFC instance')
        catalogue = None
        try:
            catalogue = create_file_catalog(TiersOfATLAS.getLocalCatalog(self.DQ2_LOCAL_SITE_ID))
        except:
            self.__logger.fatal('Could not create LFC connection for %s'%self.DQ2_LOCAL_SITE_ID)
            raise
        if catalogue is None:
            raise Exception('No LFC found for %s'%self.DQ2_LOCAL_SITE_ID)

        self.__logger.info('Making sure LFC directory exists and/or is writable')
        lfn = to_native_lfn(self.options.dsn, self.checkedFiles[self.checkedFiles.keys()[0]]['lfn'])
        try:
            status, output = commands.getstatusoutput('LFC_HOST=%s lfc-mkdir -m 775 -p %s'%(catalogue._host, lfn[:lfn.rfind('/')]))
        except:
            self.__logger.fatal('Could not create LFC directory')
            raise        
        if 'Permission denied' in output:
            raise Exception('No writing permissions for LFC')


        for partition in xrange(1, self.nrPartitions+1):
            self.__logger.info('Working partition %s/%s'%(partition, self.nrPartitions))

            try:
                self.__logger.debug('Checking dataset state')
                ret = self.__dq2.getState(self.options.dsn)
                if ret == DatasetState.OPEN:
                    datasetOpen = True
                else:
                    datasetOpen = False
            except:
                self.__logger.fatal('Could not check dataset state')
                raise

            toVersion = False
            if datasetOpen:
                self.__logger.info('Adding files to current version')
            else:
                self.__logger.info('Versioning dataset')
                toVersion = True
                
            if toVersion:
                try:
                    self.__dq2.registerNewVersion(self.options.dsn)
                except:
                    self.__logger.fatal('Dataset could not be versioned')
                    raise

            self.__logger.info('Getting file checksums')
            try:
                for file in self.checkedFiles:
                    if self.checkedFiles[file]['partition'] == partition:
                        self.__logger.debug('Getting adler32: %s'%self.checkedFiles[file]['lfn'])
                        self.checkedFiles[file]['checksum'] = 'ad:%s'%self.__adler32(self.checkedFiles[file]['source'])
            except:
                self.__logger.fatal('Could not get adler32 checksum of file')
                raise

            self.__logger.info('Registering partition files to dataset')
            try:
                lfns = []
                guids = []
                sizes = []
                checksums = []
                
                for file in self.checkedFiles:
                    if self.checkedFiles[file]['partition'] == partition:
                        lfns.append(self.checkedFiles[file]['lfn'])
                        guids.append(file)
                        sizes.append(self.checkedFiles[file]['fsize'])
                        checksums.append(self.checkedFiles[file]['checksum'])
                
                self.__dq2.registerFilesInDataset(self.options.dsn, lfns, guids, sizes, checksums)
            except:
                self.__logger.fatal('Could not add files to dataset')
                raise

            for file in self.checkedFiles:
                if self.checkedFiles[file]['partition'] == partition:
                    self.__logger.info('Copy and register file: %s'%self.checkedFiles[file]['lfn'])
                    
                    output = 'Internal dq2-put2 error'
                    status = -1
                    
                    surl = '%s%s'%(self.srmEndpoint[:-1],destination.construct_surl(self.options.dsn, self.checkedFiles[file]['lfn']))
                    lfn = to_native_lfn(self.options.dsn, self.checkedFiles[file]['lfn'])
                    
                    if self.spaceToken is None:
                        fexe = exe%(catalogue._host, surl, file, lfn, self.checkedFiles[file]['source'])
                    else:
                        fexe = exe%(catalogue._host, surl, self.spaceToken, file, lfn, self.checkedFiles[file]['source'])
                    
                    output = 'Internal dq2-put2 error'
                    status = -1

                    self.__logger.debug('Executing: %s', fexe)
                    status, output = commands.getstatusoutput(fexe)

                    if status != 0:
                        self.__logger.fatal(output)
                        raise Exception('Could not copy and register file')
                    
                    self.__logger.info('Add checksum information to LFC')
                    
                    rc = 0
                    try:
                        catalogue._lfc.lfc_startsess(catalogue._host, '')
                        rc = catalogue._lfc.lfc_setfsizeg(file, long(self.checkedFiles[file]['fsize']), 'AD', self.checkedFiles[file]['checksum'][3:])
                        catalogue._lfc.lfc_endsess()
                    except:
                        self.__logger.fatal('Could not set checksum in LFC')
                        raise
            
                    if rc != 0:
                        raise Exception('LFC ERROR: %s'%catalogue._lfc.sstrerror(catalogue._lfc.cvar.serrno))
                        
            
            self.__logger.info('Closing dataset')
            try:
                self.__dq2.closeDataset(self.options.dsn)
            except:
                self.__logger.warn('Dataset could not be closed')
                raise

        
    def __operationEnd(self):
        """
        @since: 1.1.2.2
        """
        
        self.__logger.debug('Step: Operation end')
    
        self.__logger.debug('Verify dataset')

        if self.options.freeze:
            self.__logger.info('Freezing dataset')
            try:
                self.__dq2.freezeDataset(self.options.dsn)
            except:
                self.__logger.fatal('Could not close dataset')
                raise

    def __sendTrace(self):
        """
        @since: 1.1.2.2
        """
        pass


    def __yesno(self, *messages):
        """
        @since: 1.1.2.2
        """
        
        for message in messages:
            self.__logger.info(message)
        
        if self.options.automatic:
            self.__logger.info('Automatic confirm')
            return True
        
        else:
            response = raw_input()
            
            while response not in ['yes', 'y', 'Y', 'Yes', 'YES', 'no', 'n', 'N', 'No', 'NO']:
                self.__logger.info('Invalid response! Please answer (y/n)?')
                response = raw_input()
    
            if response in ['yes', 'y', 'Y', 'Yes', 'YES']:
                return True
            else:
                return False


    def __adler32(self, file):
        """
        @since: 0.0.1
        """

        manualChecksum = False
        
        #adler starting value is _not_ 0
        adler=1L
        
        try:
    
            #if file.startswith('/castor') or file.startswith('/dpm'):
            #    openFile = os.popen(self.endpointTool.mssCat(file), 'rb')
            #else:
            openFile = open(file, 'rb')
            
            for line in openFile:
                adler = zlib.adler32(line, adler)

        except:
            raise Exception('FATAL - Could not get checksum of file: %s'%file)

        openFile.close()

        #backflip on 32bit
        if adler < 0:
            adler = adler + 2**32

        return str('%08x'%adler) #return as hexified string, padded to 8 values
    

class Options(object):
    """
    @since: 1.1.2.1
    """

    help = False
    debug = False
    local = None
    automatic = False
    partition = 10
    source = None
    freeze = False


    def __init__(self, arguments, logger):
        """
        @since: 1.1.2.1
        """
        
        try:
        
            optlist = getopt.getopt(arguments, 'dL:ap:s:F',
            ['debug','local-site=','automatic','partition=','source=','freeze'])[0]
            
            if arguments and not arguments[-1].startswith('-'):
                self.dsn = arguments[-1]
            else:
                self.help = True
                return
            
            if '*' in self.dsn:
                raise Exception('No wildcards allowed in dataset name!')
            
            for o, a in optlist:
                if o in ('-h', '--help'):
                    self.help = True
                if o in ('-d', '--debug'):
                    self.debug = True
                if o in ('-L', '--local-site'):
                    self.local = str(a)
                if o in ('-a', '--automatic'):
                    self.automatic = True
                if o in ('-p', '--partition'):
                    self.partition = int(a)
                if o in ('-s', '--source'):
                    self.source = str(a)
                if o in ('-F', '--freeze'):
                    self.freeze = True

        except:
            raise
