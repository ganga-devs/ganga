"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: ListSources.py,v 1.3 2009/10/06 13:23:17 angelos Exp $
"""

from dq2.common.cli.DQDashboardTool import DQDashboardTool

from dq2.clientapi.cli.cliutil import getDQ2

from dq2.info import TiersOfATLAS


class ListSources (DQDashboardTool):
    """
    @since: 0.3.0
    """

    usage = "%prog [options]"
    
    version = "$Revision: 1.3 $"
    
    description = "List Possible Sources"

    toolOptions = []
    
    
    def __init__ (self):
        """
        @since: 0.3.0
        """
        DQDashboardTool.__init__(self)
        
     
    def execute (self):
        """
        @since: 0.3.0
        """

        dq = getDQ2(self)
        
        out = ''
        sources = TiersOfATLAS.getAllSources()
        sources.sort()
        for id in sources:
            out += ' %s\n' % id
    
        print out