"""
@author: Mario Lassnig
@contact: mlassnig@cern.ch
@since: 0.3
@version: $Id: cliutil.py,v 1.6 2009/10/06 13:23:18 angelos Exp $
"""

import string

from dq2.clientapi.DQ2 import DQ2
from dq2.common.Config import Config
from dq2.common.DQException import DQInvalidRequestException

from dq2.common import optparse

opt_dataset_version = optparse.make_option(
    "-v", "--dataset-version",
    dest="version",
    default=0,
    type='int',
    help="specify version of the dataset"
)


def getDQ2(self):
        """
        @since: 0.3.0
        """
        return DQ2 (
            con_url = Config().getConfig('dq2-content-client').get('dq2-content-client', 'insecure'),
            con_urlsec = Config().getConfig('dq2-content-client').get('dq2-content-client', 'secure'),
            
            loc_url = Config().getConfig('dq2-location-client').get('dq2-location-client', 'insecure'),
            loc_urlsec = Config().getConfig('dq2-location-client').get('dq2-location-client', 'secure'),
            
            rep_url = Config().getConfig('dq2-repository-client').get('dq2-repository-client', 'insecure'),
            rep_urlsec = Config().getConfig('dq2-repository-client').get('dq2-repository-client', 'secure'),
            
            sub_url = Config().getConfig('dq2-subscription-client').get('dq2-subscription-client', 'insecure'),
            sub_urlsec = Config().getConfig('dq2-subscription-client').get('dq2-subscription-client', 'secure'),
        )


def option_value (self, names=[], default=None, typ=str, lowercase=False, uppercase=False):
        """
        Returns the option value or the default one.
        
        @since: 0.3.0
        
        names is the parameter name to be checked.
        default is the default value to be returned in case the parameter wasn't sent.
        typ is the type of the parameter.
        lowercase is a flag to perform a lowercase into the parameter.
        uppercase is a flag to perform a uppercase into the parameter.
        """
        for eachName in names:
            if eachName in self.options.keys():
                """option found"""
                value = str(self.options[eachName])
                if lowercase: value = string.lower(value)
                if uppercase: value = string.upper(value)
                
                if typ is dict or typ is list or typ is tuple:
                    """return type is dict, list or tuple"""
                    value = eval(value)
                    
                    if type(value) is not typ:
                        """evaluated type is not the one expected"""
                        err_msg = 'parameter type [%s] is not %s!' % (type(value), typ)
                        raise DQInvalidRequestException(err_msg)
                elif typ is int:
                    try:
                        return int(value)
                    except ValueError:
                        err_msg = 'parameter [%s] is not an integer!' % (value)
                        raise DQInvalidRequestException(err_msg)
                
                return value
        
        # treat default value and return it
        if default is not None and default is str:
            """lowercase or uppercase default value return it"""
            if lowercase: default = string.lower(default)
            if uppercase: default = string.upper(default)
            return default
        else:
            return default