"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0
@version: $Id: Container.py,v 1.10 2009/10/15 13:06:49 angelos Exp $
"""

#from dq2.common.DQConstants import DatasetState


class Container (object):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 1.0
    @version: $Revision: 1.10 $
    """


#
# Container-level operations
#


    def registerContainer (self, name, datasets=[]):
        """
        Creates a container.
        
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        @param datasets: list of datasets to be registered.
            [dataset_name1, ..., dataset_nameN]
        @type datasets: list
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0001
        
        @raise DQContainerExistsException:
            in case a container with the same name already exists.
        
        @return: None
        @rtype: NoneType
        """
        
        self.containerClient.create(name)
        if datasets:
            self.containerClient.register(name, datasets)


#
# Container-element operations
#


    def registerDatasetsInContainer (self, name, datasets):
        """
        Register datasets into a container.
        
        @param name: name of the container.
        @type name: str
        @param datasets: list of datasets to be registered.
            [dataset_name1, ..., dataset_nameN]
        @type datasets: list
        
        @since: 1.0
        
        @raise DQContainerIsInStateException:
            in case the container is closed or archived.
        @raise DQContainerNotOwner:
            in case the user is not the owner of the container.
        @raise DQContainerUnknownException:
            in case the container does not exist.
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0003
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0010
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0011
        """
        
        return self.containerClient.register(name, datasets)


    def listDatasetsInContainer (self, name):
        """
        List datasets of a container.
        
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0006
        
        @raise DQContainerUnknownException:
            in case the container does not exist.
        @raise DQContainerIsInState:
            in case the container is archived.
        
        @return: [dsn1,...,dsnN] 
        @rtype: list
        """
        
        return self.containerClient.retrieve(name)


    def deleteDatasetsFromContainer (self, name, datasets):
        """
        Remove datasets from a container.
        
        @since: 1.0
        
        @param name: name of the container.
        @type name: str
        @param datasets: list of datasets to be registered.
            [dataset_name1, ..., dataset_nameN]
        @type datasets: list
        
        @raise DQContainerIsInStateException:
            in case the container is closed or archived.
        @raise DQContainerNotOwner:
            in case the user is not the owner of the container.
        @raise DQContainerUnknownException:
            in case the container does not exist.
        
        @see: https://twiki.cern.ch/twiki/bin/view/Atlas/DonQuijote2ContainerCatalogUC0004
        """
        
        return self.containerClient.unregister(name, datasets)