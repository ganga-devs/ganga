"""
Contains the Mock File Catalog module.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""
from threading import Lock

from dq2.common import log as logging

from dq2.info import TiersOfATLAS
from dq2.filecatalog.FileCatalogInterface import FileCatalogInterface
from dq2.filecatalog.mock.MockFileCatalogException import MockFileCatalogException

"""
Holds in-memory information.
"""
import dq2.filecatalog


CATALOGUES_LOCK = Lock()
CATALOGUES = {}

class MockFileCatalog(FileCatalogInterface):
    """
    Class definition for Mock File Catalog.
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: MockFileCatalog.py,v 1.7 2008/02/21 08:49:02 mbranco Exp $
    """
    _logger = logging.getLogger("dq2.filecatalog.mock.MockFileCatalog")

    def __init__(self, endpoint):
        """
        Constructor of the MockFileCatalog object.
        """
        self._endpoint = endpoint
        CATALOGUES_LOCK.acquire()
        if self._endpoint not in CATALOGUES:
            CATALOGUES[self._endpoint] = {}
        CATALOGUES_LOCK.release()
        
        self._sites = TiersOfATLAS.getAllDestinationSites()

    def connect(self):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.connect(self)}
        """
        pass

    def disconnect(self):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.disconnect(self)}
        """
        pass

    def bulkFindReplicas(self, files):
        """
        Mock implementation that either reads in-memory values or creates
        empty entry to be filled after by 'filterSiteReplicas'.
        
        Returns a file as found if the lfn contains the site name.
        
        @see L{dq2.filecatalog.FileCatalogInterface.bulkFindReplicas(self, files, sites=None)}
        """
        r = {}
        CATALOGUES_LOCK.acquire()
        for guid in files:
            lfn = files[guid]
            if guid not in CATALOGUES[self._endpoint]:
                 CATALOGUES[self._endpoint][guid] = {'lfn': lfn,
                                                     'surls': [],
                                                     'fsize': None,
                                                     'checksum': None}
            entryCopy = {'lfn': CATALOGUES[self._endpoint][guid]['lfn'],
                         'fsize': CATALOGUES[self._endpoint][guid]['fsize'],
                         'checksum': CATALOGUES[self._endpoint][guid]['checksum'],
                         'surls': CATALOGUES[self._endpoint][guid]['surls'][:]}
            for site in self._sites:
                if lfn.find(site) != -1: # LFN contains SITE so it is a match!
                    entryCopy['surls'].append('mock://%s/%s' % (site.lower(), lfn))
            self._logger.info('found SURLs %s for guid %s' % (str(entryCopy), guid))
            r[guid] = entryCopy
        CATALOGUES_LOCK.release()
        return r
        
    def bulkTouchFiles(self, files, archival):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkTouchFiles(self, files, archival)}
        """                
        r = {}
        for guid in files:
            r[guid] = True
            #r[guid] = MockFileCatalogException('Mock file touch exception')
        return r
        
    def bulkRegisterFiles(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkRegisterFiles(self, files)}
        """
        r = {}
        CATALOGUES_LOCK.acquire()
        for guid in files:
            if guid not in CATALOGUES[self._endpoint]:
                 CATALOGUES[self._endpoint][guid] = {'lfn': files[guid]['lfn'],
                                                     'surls': [],
                                                     'fsize': files[guid]['fsize'],
                                                     'checksum': files[guid]['checksum']}
            CATALOGUES[self._endpoint][guid]['surls'].append(files[guid]['surl'])
            self._logger.info('added SURL %s for guid %s' % (files[guid]['surl'], guid))
            self._logger.info('now has SURLs %s for guid %s' % (str(CATALOGUES[self._endpoint][guid]['surls']), guid))
            r[guid] = True
            #r[guid] =  MockFileCatalogException('Mock file registration exception')
        CATALOGUES_LOCK.release()
        return r
