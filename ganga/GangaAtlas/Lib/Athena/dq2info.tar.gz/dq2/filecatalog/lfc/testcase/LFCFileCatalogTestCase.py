import unittest
import commands

from dq2.subscription.DQSubscriptionConstants import SubscriptionArchivedState

from dq2.common.testcase.DQTestCase import DQTestCase

class LFCFileCatalogTestCase(DQTestCase):

    def testLFCConventions(self):
        """
        Test LFC conventions
        """
        from dq2.filecatalog.lfc.lfcconventions import to_native_lfn
        
        lfn = 'something.for.test.fitting.convention._00001.pool.root'
        dsn = 'something.for.test.fitting.convention'
        assert(to_native_lfn(dsn, lfn) == '/grid/atlas/dq2/something/convention/something.for.test.fitting.convention/something.for.test.fitting.convention._00001.pool.root')
        
        lfn = 'something.for.test._00001.pool.root'
        dsn = 'something.for.test'
        assert(to_native_lfn(dsn, lfn) == '/grid/atlas/dq2/something/something.for.test/something.for.test._00001.pool.root')
        
        lfn = 'other-possibility._00001.pool.root'
        dsn = 'other-possibility'
        assert(to_native_lfn(dsn, lfn) == '/grid/atlas/dq2/other/other-possibility/other-possibility._00001.pool.root')
        
        
    def testLFC(self):
        """
        Test complete cycle using LFC
        
        - register one file (first entry for LFN/GUID pair)
        - register replica for same lfn
        - find two replicas for lfn
        - try to register same lfn with different guid (check error)
        - touch existing files setting one of the replicas as permanent
        - unregister files
        - try to unregister files again (check error)
        
        """
        from dq2.filecatalog.lfc.LFCFileCatalog import LFCFileCatalog, LFCFileCatalogException
        
        self.lfc = LFCFileCatalog('lfc://lfc-atlas.cern.ch:/grid/atlas')
        
        guid1 = commands.getoutput('uuidgen').strip()
        guid2 = commands.getoutput('uuidgen').strip()
        
        lfn = 'dq2.unittest._00000.lfc._%s' % guid1
        
        surl1 = 'srm://srm.cern.ch/castor/cern.ch/grid/atlas/test1_%s' % lfn
        surl2 = 'srm://srm.cern.ch/castor/cern.ch/grid/atlas/test2_%s' % lfn
        surl3 = 'srm://srm.cern.ch/castor/cern.ch/grid/atlas/test3_%s' % lfn
        surl4 = 'srm://srm.cern.ch/castor/cern.ch/grid/atlas/test4_%s' % lfn

        dsn1 = 'dq2test.dataset.%s' % guid1
        dsn2 = 'dq2test.dataset.%s' % guid2
        
        # register one file (first LFN entry)
        
        file1 = {guid1: {'dsn': dsn1,
                         'lfn': lfn,
                         'surl': surl1,
                         'fsize': 1000000,
                         'checksum': 'md5:4229b813c45ac64172bd8ca6aee167f5',
                         'archival': SubscriptionArchivedState.UNARCHIVE}}
        r = self.lfc.bulkRegisterFiles(file1)
        assert(r.has_key(guid1))
        assert(r[guid1])
        
        # register replica for same lfn
        
        file2 = {guid1: {'dsn': dsn1,
                         'lfn': lfn,
                         'surl': surl2,
                         'fsize': 1000000,
                         'checksum': 'md5:4229b813c45ac64172bd8ca6aee167f5',
                         'archival': SubscriptionArchivedState.UNARCHIVE}}
        
        r = self.lfc.bulkRegisterFiles(file2)
        assert(r.has_key(guid1))
        assert(r[guid1])
        
        # register replica for same lfn but different dataset
        
        file3 = {guid1: {'dsn': dsn2,
                         'lfn': lfn,
                         'surl': surl3,
                         'fsize': 1000000,
                         'checksum': 'md5:4229b813c45ac64172bd8ca6aee167f5',
                         'archival': SubscriptionArchivedState.UNARCHIVE}}
        
        r = self.lfc.bulkRegisterFiles(file3)
        assert(r.has_key(guid1))
        assert(r[guid1])

        # find replicas for lfn
        
        replicas = self.lfc.bulkFindReplicas({guid1: lfn})
        assert(replicas.has_key(guid1))
        assert(replicas[guid1]['lfn'] == lfn)
        assert(replicas[guid1]['fsize'] == 1000000)
        assert(replicas[guid1]['checksum'] == 'md5:4229b813c45ac64172bd8ca6aee167f5')
        assert(len(replicas[guid1]['surls']) == 3)
        assert(replicas[guid1]['surls'].count(surl1) == 1)
        assert(replicas[guid1]['surls'].count(surl2) == 1)
        assert(replicas[guid1]['surls'].count(surl3) == 1)
        
        # try to register same lfn with different guid (check error)
        
        file4 = {guid2: {'dsn': dsn1,
                         'lfn': lfn,
                         'surl': surl4,
                         'fsize': 1000000,
                         'checksum': 'md5:4229b813c45ac64172bd8ca6aee167f5',
                         'archival': SubscriptionArchivedState.UNARCHIVE}}
        
        r = self.lfc.bulkRegisterFiles(file4)
        assert(r.has_key(guid2))
        assert(isinstance(r[guid2], LFCFileCatalogException))
        
        # touch existing files setting one of the replicas as permanent
        #
        #r = self.lfc.bulkTouchFiles({guid1: {'lfn': lfn, 
        #                                'surl': surl2}},
        #                        SubscriptionArchivedState.ARCHIVE)
        #assert(r.has_key(guid1))
        #assert(r[guid1] == True)
        #
        # unregister files
        #
        r = self.lfc.bulkUnregisterFiles(file1)
        assert(r.has_key(guid1))
        assert(r[guid1])

        # raises exception since one replica remains
        r = self.lfc.bulkUnregisterFiles(file2, replica_only=False)
        assert(r.has_key(guid1))
        assert(isinstance(r[guid1], LFCFileCatalogException))

        # remove final replica
        r = self.lfc.bulkUnregisterFiles(file3, replica_only=False)
        assert(r.has_key(guid1))
        assert(r[guid1])


    def testInvalidLFC(self):
        """
        Test invalid LFC endpoint. Should raise an exception.
        """
        from dq2.filecatalog.lfc.LFCFileCatalog import LFCFileCatalog, LFCFileCatalogException
        
        self.lfc = LFCFileCatalog('lfc://lfc-INVALID.cern.ch:/grid/atlas')
        
        self.assertRaises(LFCFileCatalogException, self.lfc.bulkFindReplicas, {'guid1': 'lfn1', 'guid2': 'lfn2'})

        # Should also test individual GUID errors!
        

if __name__ == '__main__':
    """
    Runs all tests in LFCFileCatalogTestCase
    
    (since 0.3.0)
    """
    import sys
    test = LFCFileCatalogTestCase.main(
        'dq2.filecatalog.lfc.testcase', LFCFileCatalogTestCase.__name__, sys.argv[1:]
    )
