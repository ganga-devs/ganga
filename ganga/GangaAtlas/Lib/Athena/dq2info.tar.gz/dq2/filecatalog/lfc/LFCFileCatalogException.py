"""
Contains the LFC File Catalog exception.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""
from dq2.filecatalog.FileCatalogException import FileCatalogException


class LFCFileCatalogException(FileCatalogException):
    """
    Class representing a LFC file catalog exception.
    
    @see: L{dq2.filecatalog.FileCatalogException}
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: LFCFileCatalogException.py,v 1.5 2007/12/11 12:01:27 mbranco Exp $
    """    
    
    def __init__(self, description):
        """
        Constructor for the LFCFileCatalogException object.
        """
        self._description = description
        
    def __str__(self):
        """
        String representation of the LFCFileCatalogException exception.
        """
        return "LFC exception [%s]" % self._description
