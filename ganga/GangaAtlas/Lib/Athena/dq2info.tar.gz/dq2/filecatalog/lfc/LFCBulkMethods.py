from dq2.common.host import get_hostname
from dq2.filecatalog.lfc.lfcconventions import to_native_lfn
import errno

from dq2.filecatalog.FileCatalogUnavailable import FileCatalogUnavailable
from dq2.filecatalog.lfc.LFCFileCatalogException    import LFCFileCatalogException
from dq2.filecatalog.lfc.LFCFileCatalogConfigurator import LFCFileCatalogConfigurator

import time

class LFCBulkMethods(object):

    def __init__(self, endpoint, lfc, host, prefix, shardLimit, logger):
        """
        Constructor for the LFCBulkMethods object.        
        """
        self.__endpoint = endpoint         
        self.__lfc = lfc
        self.__host = host
        self.__prefix = prefix        
        self.__shardLimit = shardLimit
        self.__logger=logger

    def __isCatalogDownOrSessionExpired(self, code):
        """
        Returns whether catalogue is down or session
        has expired.
        
        @return: True if reconnect required, False otherwise.
        """
        if code in [1001,    # Host unknown
                    1002,    # Service unknown
                    1018,    # Communication error
                    1401,    # ...
                    1015]:   # Internal error (e.g. session expired)
            return True
        return False
            
    def __createShards(self, lst, n):
        blk, i = [], 0
        for el in lst:
            blk.append(el)
            i += 1
            if i == n:
                yield blk
                blk, i = [], 0
        if i > 0: yield blk   
        
    def __parseChecksum(self, checksum):    
        csumtype=''
        csumvalue=''
        
        #Primary check
        if not checksum:
            return csumtype, csumvalue
        try: #It should not except after the primary check  
            if checksum[:4].upper()=='MD5:':
                csumtype = 'MD'
                csumvalue = checksum[4:]
            elif checksum[:3].upper()=='AD:':
                csumtype = 'AD'
                csumvalue = checksum[3:]            
        except (IndexError, TypeError): 
            return csumtype, csumvalue
        
        return csumtype, csumvalue
    
    
    def __deletePath(self, flfn):
        """
        Delete path from LFC. This is a clean-up function needed to delete paths 
        created and not used, because there was another guid on another path due to the
        LFN convention change. 
        The function will start deleting from higher paths until it arrives to a point
        where the directory is not empty.
        
        @param dsn: The dataset's name the file belongs to.
        @param lfn: The file's logical file name.
        
        @return: True/False whether replica was added or not.          
        """
                
        dirs = flfn[:flfn.rfind('/')][len(self.__prefix):].split('/')                        
        
        # build up directory starting from upper level
        for i in xrange(0, len(dirs)):            
            if i==0:
                path = self.__prefix+('/'.join(dirs[:]))
            else:
                path = self.__prefix+('/'.join(dirs[:-i]))                        
            
            s = self.__lfc.lfc_rmdir(path)
            if s == -1: #Error
                errcode = self.__lfc.cvar.serrno
                if errcode == errno.EEXIST: #Arrived to not-empty directory. Stop condition
                    if i!=0:
                        deletedpath = self.__prefix+('/'.join(dirs[:(-i+1)]))
                        self.__logger.debug('[LFCBulkMethods] Deleted path: %s' %deletedpath)                                                                
                    return True
                else: #Report that problem occured
                    self.__logger.warning('[LFCBulkMethods] Impossible to clean path [%s] with error [%s]' %(path,self.__lfc.sstrerror(errcode)))
                    return False                    
    
    def __createPath(self, flfn, start=0):
        """
        Create path on LFC.
        
        First goes down from higher path until it creates successfully
        a directory. Then goes back up to create all missing directories
        in a recursive way.
        
        @param dsn: The dataset's name the file belongs to.
        @param lfn: The file's logical file name.
        
        @return: True if replica added.
        """
        
        dirs = flfn[:flfn.rfind('/')][len(self.__prefix):].split('/')                        
        
        # build up directory starting from upper level
        for i in xrange(start, len(dirs)):
            
            if i == 0:
                path = self.__prefix+('/'.join(dirs))
            else:
                path = self.__prefix+('/'.join(dirs[:-i]))            
            
            s = self.__lfc.lfc_mkdir(path, 0775)
            if s == 0:
                if i == 0:
                    return True
                else:
                    return self.__createPath(flfn, start=i-1)
            
            errcode = self.__lfc.cvar.serrno
            if errcode == errno.ENOENT:
                # Path does not exist is acceptable
                continue
            elif errcode == errno.EEXIST:
                # Path exists already
                return True                
            elif self.__isCatalogDownOrSessionExpired(errcode):
                raise FileCatalogUnavailable(self.__endpoint)
            else:
                raise LFCFileCatalogException("Could not create path with error %s [%s]" % \
                                              (self.__lfc.sstrerror(errcode), path))
                            
        raise LFCFileCatalogException("Could not create path [%s]" % path)     

    def __tryAddReplica(self, lfn, guid, sfn, server):
        """        
        """
        self.__logger.warning('[LFCBulkMethods] Suspect guid exists with other lfn. Will try addreplica for lfn %s and guid %s. (LFC: %s)' % (lfn, guid, self.__host))
                
        s = self.__lfc.lfc_addreplica(guid, None, server, sfn, '-', 'P', '', '')
        if s == 0:
            self.__logger.debug('[LFCBulkMethods] addreplica succeeded for sfn %s and guid %s (LFC: %s).' % (sfn, guid, self.__host))
            return True
        errcode = self.__lfc.cvar.serrno
        if errcode == errno.EEXIST:
            # Replica exists is safe to ignore
            self.__logger.debug('[LFCBulkMethods] addreplica found existing replica for sfn %s or guid %s. This fact is accepted and file will be reported as registered. (LFC: %s)' % (sfn, guid, self.__host))
            return True
        
        #In any other case return an exception
        self.__logger.debug('[LFCBulkMethods] addreplica failed for sfn %s and guid %s (LFC: %s).' % (sfn, guid, self.__host))
        return LFCFileCatalogException('Could not register file after addreplica with error: %s. [LFN:%s, GUID: %s, LFC: %s]' % \
                                                      (self.__lfc.sstrerror(errcode), lfn, guid, self.__host))          
    
    def __processPathsAndRetry(self, lfcfiles_retry,files_dictionary,r):
        directories={}
        #First remove redundant paths
        for lfcfile in lfcfiles_retry:                
            #Check which paths have to be generated
            flfn=lfcfile.lfn            
            path=flfn[:flfn.rfind('/')][len(self.__prefix):].split('/')
            path = self.__prefix+('/'.join(path))
            
            if not directories.has_key(path):
                directories[path]=[lfcfile]      
            else:
                directories[path].append(lfcfile)  
                                        
        self.__logger.debug('[LFCBulkMethods] __processPathsAndRetry will try to create paths: %s (LFC: %s)' % (directories.keys(), self.__host))
        
        #Now try to create the paths
        lfcfiles_retry_filtered=[]
        st = time.time()        
        nok=0
        nerr=0
        for path in directories:       
            try:
                self.__createPath(directories[path][0].lfn)                                  
                lfcfiles_retry_filtered.extend(directories[path])
                nok+=1                              
            except LFCFileCatalogException,e:                
                #Files related to paths that could not be created are not retried
                for file in directories[path]:                  
                    r[file.guid]=e
                nerr+=1
        elapsed = round(time.time()-st, 2)
        self.__logger.debug('[LFCBulkMethods] processPathsAndRetry created %d and failed %d paths in LFC %s (took %.02f)' % (nok, nerr, self.__host, elapsed))
                                                                
        #Register files related to the paths that could be created
        st = time.time()            
        result, list = self.__lfc.lfc_registerfiles(lfcfiles_retry_filtered)
        elapsed = round(time.time()-st, 2)                        
        if result == 0: #OK            
            nok=list.count(0)
            nerr=len(list)-nok
            self.__logger.debug('[LFCBulkMethods] Retry call to lfc_registerfiles succeeded with %d successes and %d errors in LFC %s (took %0.2f sec).' % (nok, nerr, self.__host, elapsed))
            #Check which files succeeded        
            indexlist=range(0,len(lfcfiles_retry))
            for errcode,j in zip(list,indexlist):
                if errcode == 0:
                    r[lfcfiles_retry[j].guid]=True
                
                #If we get EEXIST after creating the path it is a sign that the guid is assigned to another lfn
                #This problem is generated by LFN convention changes 
                elif errcode == errno.EEXIST:
                    r[lfcfiles_retry[j].guid]=self.__tryAddReplica(lfcfiles_retry[j].lfn,lfcfiles_retry[j].guid,lfcfiles_retry[j].sfn,lfcfiles_retry[j].server)                                                                                                                  
                else:
                    r[lfcfiles_retry[j].guid]=LFCFileCatalogException('Could not register file after retrying with error: %s. [LFN:%s, GUID: %s, LFC: %s]' % \
                                                                  (self.__lfc.sstrerror(errcode), lfcfiles_retry[j].lfn, lfcfiles_retry[j].guid, self.__host))                      
            return r
          
        #If the bulkregistration failed
        else:
            self.__logger.debug('[LFCBulkMethods] Call to lfc_registerfiles failed for LFC %s (took %0.2f sec).' % (self.__host, elapsed))
            errcode = self.__lfc.cvar.serrno
            if self.__isCatalogDownOrSessionExpired(errcode):
                raise FileCatalogUnavailable(self.__endpoint)
            else:
                raise LFCFileCatalogException("Could not complete bulk-registration in LFC %s: %s" % (self.__host, lfc.sstrerror(errcode)))
            
    def __treatOutput(self, r, error_list, files_list):            
        indexlist=range(0,len(files_list))
        files_retry=[]
        nok=0
        nerr=0
    
        for errcode,j in zip(error_list,indexlist):
            if errcode == 0:
                r[files_list[j].guid]=True
                nok+=1
                
            elif errcode == errno.EEXIST:                
                r[files_list[j].guid]=self.__tryAddReplica(files_list[j].lfn, files_list[j].guid, files_list[j].sfn, files_list[j].server)
                if r[files_list[j].guid]==True:
                    nok+=1
                else:                              
                    nerr+=1
                                  
            elif errcode == errno.EINVAL:        
                r[files_list[j].guid]=LFCFileCatalogException('LFN exists with different GUID, checksum or filesize [%s, %s, %s:%s, %s] in LFC %s' % \
                                              (files_list[j].lfn, files_list[j].guid, files_list[j].csumtype, files_list[j].csumvalue, files_list[j].size, self.__host))
                nerr+=1

            elif errcode == errno.ENOENT: #We have to try to create the directory and register again          
                files_retry.append(files_list[j])
                nerr+=1
                
            else:
                r[files_list[j].guid]=LFCFileCatalogException('Error while registering file [%s, %s, %s:%s, %s] with errcode:%s in LFC %s' % \
                                              (files_list[j].lfn, files_list[j].guid, files_list[j].csumtype, files_list[j].csumvalue, files_list[j].size, self.__lfc.sstrerror(errcode), self.__host))
                nerr+=1                                
                
        return r,files_retry,nok,nerr

            
    def registerFiles(self, files_dictionary):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkRegisterFiles(self, files)}
        """             
        r = {} 
        for shard in self.__createShards(files_dictionary, self.__shardLimit):
            
            self.__logger.debug('LFCBulkMethods will try to register in LFC %s shard: %s' %(self.__host, shard))
               
            #We prepare the list of files we want to register into the LFC
            lfcfiles_list=[]

            for guid in shard:
    
                lfcfile = self.__lfc.lfc_filereg()
                lfcfile.lfn = to_native_lfn(files_dictionary[guid]['dsn'],files_dictionary[guid]['lfn'])
                lfcfile.sfn = files_dictionary[guid]['surl']
                lfcfile.guid = guid
                lfcfile.mode = 0775
                lfcfile.size = files_dictionary[guid]['fsize']            
                lfcfile.server = get_hostname(files_dictionary[guid]['surl'])
                lfcfile.csumtype, lfcfile.csumvalue=self.__parseChecksum(files_dictionary[guid]['checksum'])
    
                #Append the ready-to-register file
                lfcfiles_list.append(lfcfile)
                     
            #Register the files saving the output
            st = time.time()                                           
            result, error_list = self.__lfc.lfc_registerfiles(lfcfiles_list)
            elapsed = round(time.time()-st, 2)        

            if result == 0: #OK                                
                #Check which files succeeded and which ones didn't                 
                r,lfcfiles_retry,nok,nerr=self.__treatOutput(r,error_list,lfcfiles_list)                
                self.__logger.debug('[LFCBulkMethods] Call to lfc_registerfiles succeeded with %d successes and %d errors for LFC %s (took %0.2f sec).' % (nok, nerr, self.__host, elapsed))                
                #If there are files which should be retried            
                if lfcfiles_retry:
                    self.__processPathsAndRetry(lfcfiles_retry,files_dictionary,r)
                                                       
            #If the bulkregistration failed
            else:
                self.__logger.debug('[LFCBulkMethods] Call to lfc_registerfiles failed for LFC (took %0.2f sec).' % (self.__host, elapsed))                
                errcode = self.__lfc.cvar.serrno
                if self.__isCatalogDownOrSessionExpired(errcode):
                    raise FileCatalogUnavailable(self.__endpoint)
                else:
                    raise LFCFileCatalogException("Could not complete bulk-registration %s for LFC %s" % (self.__lfc.sstrerror(errcode), self.__host))
                    
        return r        

    
    def __bulkFindReplicas(self, files):
        """        
        @see L{dq2.filecatalog.FileCatalogInterface.bulkFindReplicas(self, files)}
        """
        nfiles = {}

        for shard in self.__createShards(files, self.__shardLimit):                          
            # do bulk search of GUIDs
            (result, list) = self.__lfc.lfc_getreplicas(shard, '')
            if result != 0:
                errcode = self.__lfc.cvar.serrno
                
                if self.__isCatalogDownOrSessionExpired(errcode):
                    raise FileCatalogUnavailable(self.__endpoint)
                
                raise LFCFileCatalogException('[LFCBulkMethods] Failed bulk files lookup on LFC %s [%s]' % (self.__host, self.__lfc.sstrerror(errcode)))
            else:
                for i in list:
                    if i.guid not in files:
                        continue
                    if i.errcode in [0, errno.ENOENT, errno.EINVAL]:
                        if not nfiles.has_key(i.guid):
                            checksum = None
                            if i.csumvalue not in [None, '', 0]:
                                if i.csumtype == 'MD':
                                    checksum = 'md5:%s' % i.csumvalue
                                elif i.csumtype == 'AD':
                                    checksum = 'ad:%s' % i.csumvalue
                            nfiles[i.guid] = {'lfn': files[i.guid],
                                              'fsize': i.filesize,
                                              'surls': [],
                                              'checksum': checksum}
                        if i.errcode == 0:
                            nfiles[i.guid]['surls'].append(i.sfn)
                    else:
                        nfiles[i.guid] = LFCFileCatalogException('Failed looking up file on LFC %s [errcode: %s]' % (self.__host, i.errcode))
        
        return nfiles

    
    def bulkFindReplicas(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkFindReplicas(self, files)}
        """        
        response = None
        
        if vars(self.__lfc).has_key('lfc_getreplicas'):
            if LFCFileCatalogConfigurator().supportsBulkMethod(self.__host):
                response = self.__bulkFindReplicas(files)
                    
        return response
    
        
    def bulkUnlink (self, files):
        r = {}
        for guid in files:
            stat = self.__lfc.lfc_filestatg()
            s = self.__lfc.lfc_statg ("",guid,stat)
            if s != 0:
                errcode = self.__lfc.cvar.serrno
                r[guid] = LFCFileCatalogException("Could not unlink in guid in LFC %s with error %s [%s]" % \
                                                  (self.__host, self.__lfc.sstrerror(errcode), guid))
                continue
            else:
                path = " ".ljust (self.__lfc.CA_MAXPATHLEN+1)                                
                s = self.__lfc.lfc_getpath ("", stat.fileid, path)
                if s != 0:
                    errcode = self.__lfc.cvar.serrno
                    r[guid] = LFCFileCatalogException("Could not unlink guid in LFC %s with error %s [%s]" % \
                                                      (self.__host, self.__lfc.sstrerror(errcode), guid))
                    continue
                else:                    
                    path = '%s'%path.strip()[:-1]
                    s = self.__lfc.lfc_unlink(path)                
                    if s != 0:
                        errcode = self.__lfc.cvar.serrno
                        r[guid] = LFCFileCatalogException("Could not unlink lfn in LFC %s with error %s [%s]" % \
                                                          (self.__host, self.__lfc.sstrerror(errcode), path))
                        continue
            r[guid] = True
        return r

    
    def bulkUnregisterFiles(self, files, replicaOnly=True):
        r = {} 
        
        #We prepare the list of files we want to delete from the LFC
        guids=[]
        sfns=[]        
        for guid in files:
            for surl in files[guid]['surls']: 
                guids.append(guid)
                sfns.append(surl)
                
        for guids_shard,sfns_shard in zip(self.__createShards(guids, self.__shardLimit),self.__createShards(sfns, self.__shardLimit)):
            self.__logger.debug('LFCBulkMethods will try to Unregister in LFC %s shard: %s' %(self.__host, guids_shard))
                                                               
            #Delete the files              
            result, error_list = self.__lfc.lfc_delreplicasbysfn(sfns_shard, guids_shard)
            
            if result == 0: #OK
                for guid, error in zip(guids_shard,error_list):
                    if error==0:
                        r[guid] = True
                    else:
                        r[guid] = LFCFileCatalogException("Could not delete file from LFC %s with error %s [%s]" % \
                                                      (self.__host, self.__lfc.sstrerror(error), files[guid]['lfn']))
          
            #If the bulk-deletion failed
            else:
                errcode = self.__lfc.cvar.serrno
                if self.__isCatalogDownOrSessionExpired(errcode):
                    raise FileCatalogUnavailable(self.__endpoint)
                else:
                    raise LFCFileCatalogException("Could not complete bulk-delete in LFC %s: %s" % (self.__host, self.__lfc.sstrerror(errcode)))
                    
        return r
