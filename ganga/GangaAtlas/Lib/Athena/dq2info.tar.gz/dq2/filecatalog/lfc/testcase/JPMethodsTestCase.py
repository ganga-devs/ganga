from dq2.filecatalog import create_file_catalog
from dq2.filecatalog.FileCatalogException import FileCatalogException
from dq2.filecatalog.lfc.LFCFileCatalog import LFCFileCatalog
import sys

endpoint='lfc://lxb7994.cern.ch:/'

cat=LFCFileCatalog(endpoint)

cat.connect()

start=0
stop=1000
files={}

if __name__ == '__main__':

    if sys.argv[1]=='reg':

        for i in xrange(start,stop):
            #guid=commands.getstatusoutput('uuidgen')[1]
            guid='00000000-0000-0000-0000-%012d'%(i)
            files[guid]={}
            files[guid]['dsn']='project1.2.3.4.type5'
            files[guid]['lfn']='project1.2.3.4.type5.%03d'%(i)
            files[guid]['surl']='srm://srm-atlas.cern.ch/castor/cern.ch/grid/atlas/atlasdatatape/project1/type5/project1.2.3.4.type5/project1.2.3.4.type5.%03d'%(i)
            files[guid]['fsize']=i+1000
            files[guid]['checksum']='AD:9ca1fb67'
    
        rep = cat.bulkRegisterFiles(files)
        print rep

    elif sys.argv[1]=='del':
#        j=0
        for i in xrange(start,stop):
#            guids=['3f5db311-c8d6-45e7-af6d-7e00b4c7f380','367849a7-802e-4992-94e2-e1a0d00b71e3','acd2de4e-c852-49f6-a12e-f17ac0ced65e','97356b11-e12c-49e1-a131-93388574e518','39871833-ff01-431d-8c48-4950f41ea809','662bd2cb-4f67-4515-9e52-4d148b2fd6fd','20f3503d-52e5-4b62-9461-f2d73a4bef54','6e489b49-da3e-4f73-9295-bf8635854f96','187c261a-7e5c-4233-bed9-e7223eccecf9','7086bb3c-2246-4361-9154-6f3337e4b639']

            guid='00000000-0000-0000-0000-%012d'%(i)
            #guid=guids[j]
            #j+=1

            files[guid]={}
            files[guid]['dsn']='project1.2.3.4.type5'
            files[guid]['lfn']='project1.2.3.4.type5.%03d'%(i)
            files[guid]['surls']=['srm://srm-atlas.cern.ch/castor/cern.ch/grid/atlas/atlasdatatape/project1/type5/project1.2.3.4.type5/project1.2.3.4.type5.%03d'%(i)]
            files[guid]['fsize']=i+1000
            files[guid]['checksum']='AD:9ca1fb67'            
            
        rep = cat.bulkUnregisterFiles(files,replicaOnly=False)

    elif sys.argv[1]=='ver':
        
        guids={}        
        
        for i in xrange(start,stop):
            guids['00000000-0000-0000-0000-%012d'%(i)]=''

        nfiles=cat.bulkFindReplicas(guids)

        for guid in nfiles:
            i=int(guid[-10:])
            if nfiles[guid]['checksum']!='ad:9ca1fb67' or nfiles[guid]['fsize']!=i+1000 or nfiles[guid]['surls']!=['srm://srm-atlas.cern.ch/castor/cern.ch/grid/atlas/atlasdatatape/project1/type5/project1.2.3.4.type5/project1.2.3.4.type5.%03d'%(i)]:
                print nfiles[guid]

      
cat.disconnect()
