from dq2.common.host import get_hostname
from dq2.filecatalog.lfc.lfcconventions import to_native_lfn
import errno

from dq2.filecatalog.FileCatalogUnavailable import FileCatalogUnavailable
from dq2.filecatalog.lfc.LFCFileCatalogException    import LFCFileCatalogException
from dq2.filecatalog.lfc.LFCFileCatalogConfigurator import LFCFileCatalogConfigurator

class LFCSerialMethods(object):

    def __init__(self, endpoint, lfc, host, prefix, shardLimit):
        """
        Constructor for the LFCBulkMethods object.        
        """        
        self.__endpoint = endpoint         
        self.__lfc = lfc
        self.__host = host        
        self.__prefix = prefix        
        self.__shardLimit = shardLimit


    def __isCatalogDownOrSessionExpired(self, code):
        """
        Returns whether catalogue is down or session
        has expired.
        
        @return: True if reconnect required, False otherwise.
        """
        if code in [1001,    # Host unknown
                    1002,    # Service unknown
                    1018,    # Communication error
                    1401,    # ...
                    1015]:   # Internal error (e.g. session expired)
            return True
        return False
    
    def __createShards(self, lst, n):
        blk, i = [], 0
        for el in lst:
            blk.append(el)
            i += 1
            if i == n:
                yield blk
                blk, i = [], 0
        if i > 0: yield blk
    
    def __bulkFindReplicas(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkFindReplicas(self, files)}
        """
        nfiles = {}

        for shard in self.__createShards(files, self.__shardLimit):                          
            # do bulk search of GUIDs
            (result, list) = self.__lfc.lfc_getreplicas(shard, '')
            if result != 0:
                errcode = self.__lfc.cvar.serrno
                
                if self.__isCatalogDownOrSessionExpired(errcode):
                    raise FileCatalogUnavailable(self.__endpoint)
                
                raise LFCFileCatalogException('Failed bulk files lookup on LFC [%s]' % self.__lfc.sstrerror(errcode))
            else:
                for i in list:
                    if i.guid not in files:
                        continue
                    if i.errcode in [0, errno.ENOENT, errno.EINVAL]:
                        if not nfiles.has_key(i.guid):
                            checksum = None
                            if i.csumvalue not in [None, '', 0]:
                                if i.csumtype == 'MD':
                                    checksum = 'md5:%s' % i.csumvalue
                                elif i.csumtype == 'AD':
                                    checksum = 'ad:%s' % i.csumvalue
                            nfiles[i.guid] = {'lfn': files[i.guid],
                                              'fsize': i.filesize,
                                              'surls': [],
                                              'checksum': checksum}
                        if i.errcode == 0:
                            nfiles[i.guid]['surls'].append(i.sfn)
                    else:
                        nfiles[i.guid] = LFCFileCatalogException('Failed looking up file on LFC [errcode: %s]' % i.errcode)
        
        return nfiles

        
    def bulkFindReplicas(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkFindReplicas(self, files)}
        """        
        response = None
        
        if vars(self.__lfc).has_key('lfc_getreplicas'):
            if LFCFileCatalogConfigurator().supportsBulkMethod(self.__host):
                response = self.__bulkFindReplicas(files)
                    
        return response
    
    def __addReplica(self, guid, surl, bit):
        """
        Add replica to an existing file.
        
        Addition is done within a single transaction.
        
        @param guid: The file's GUID.
        @param surl: The file's SURL
        @param bit: The archival bit (P or V).
        
        @return: True if replica added.
        """
        
        # try to create replica
        s = self.__lfc.lfc_addreplica( guid, None, get_hostname(surl), surl, '-', bit, '', '')
        if s == 0:
            return True
        
        errcode = self.__lfc.cvar.serrno
        if errcode == errno.EEXIST:
            # replica exists is safe to ignore
            return True
        
        elif self.__isCatalogDownOrSessionExpired(errcode):
            raise FileCatalogUnavailable(self.__endpoint)
        
        raise LFCFileCatalogException("Could not add replica with error %s [%s -> %s]" % \
                                      (self.__lfc.sstrerror(errcode), guid, surl))
    
    def __createPath(self, dsn, lfn, start=0):
        """
        Create path on LFC.
        
        First goes down from higher path until it creates successfully
        a directory. Then goes back up to create all missing directories
        in a recursive way.
        
        @param guid: The file's GUID.
        @param surl: The file's SURL
        @param bit: The archival bit (P or V).
        
        @return: True if replica added.
        """
        
        flfn = to_native_lfn(dsn, lfn)        
        dirs = flfn[:flfn.rfind('/')][len(self.__prefix):].split('/')
        
        # build up directory starting from upper level
        for i in xrange(start, len(dirs)):
            
            if i == 0:
                path = self.__prefix+('/'.join(dirs))
            else:
                path = self.__prefix+('/'.join(dirs[:-i]))

            s = self.__lfc.lfc_mkdir(path, 0775)
            if s == 0:
                if i == 0:
                    return True
                else:
                    return self.__createPath(dsn, lfn, start=i-1)
            
            errcode = self.__lfc.cvar.serrno
            if errcode == errno.ENOENT:
                # Path does not exist is acceptable
                continue
            elif self.__isCatalogDownOrSessionExpired(errcode):
                raise FileCatalogUnavailable(self.__endpoint)
            else:
                raise LFCFileCatalogException("Could not create path with error %s [%s]" % \
                                              (self.__lfc.sstrerror(errcode), path))
        
        raise LFCFileCatalogException("Could not create path [%s]" % path)

    def __createFile(self, dsn, lfn, guid, surl, bit, fsize, checksum, pathCreation=True):
        """
        Creates a file (LFN + GUID + SURL) entry on LFC.

        @param dsn: The dataset name.
        @param lfn: The file's logical file name.
        @param guid: The file's GUID.
        @param surl: The file's SURL.
        @param bit: The archival bit (P or V).
        @param fsize: The file size.
        @param checksum: The file's checksum.
        
        @return: True if file added.
        """
        s = self.__lfc.lfc_creatg(to_native_lfn(dsn, lfn), guid, 0775)
        if s == 0:
            csumvalue = ''
            csumtype = ''
            if checksum not in [None, '', 0]:
                if checksum[:4] == 'md5:':
                    csumtype = 'MD'
                    csumvalue = checksum[4:]
                elif checksum[:3] == 'ad:':
                    csumtype = 'AD'
                    csumvalue = checksum[3:]
            
            fsizevalue = None
            if fsize not in [None, '', 0]:
                fsizevalue = long(fsize)
            
            if fsizevalue is not None or csumvalue != '':
                s = self.__lfc.lfc_setfsizeg(guid, fsizevalue, csumtype, csumvalue)
                if s != 0:
                    errcode = self.__lfc.cvar.serrno
                    if self.__isCatalogDownOrSessionExpired(errcode):
                        raise FileCatalogUnavailable(self.__endpoint)
                    else:
                        raise LFCFileCatalogException("Could not set file size with error %s [%s]" % \
                                                      (self.__lfc.sstrerror(errcode), to_native_lfn(dsn, lfn)))
            
            # now add replica to newly created file
            return self.__addReplica(guid, surl, bit)
        
        # failed to create file
        errcode = self.__lfc.cvar.serrno
        
        if errcode == errno.EEXIST:
            # we have a problem as guid does not exist according
            # to previous call to _addReplica(..) but lfn exists!
            raise LFCFileCatalogException('Suspect LFN exists with different GUID [%s -> %s]' % \
                                          (to_native_lfn(dsn, lfn), guid))
        
        elif pathCreation and errcode == errno.ENOENT:
            # create path and try again
            self.__createPath(dsn, lfn)
            return self.__createFile(dsn, lfn, guid, surl, bit, fsize, checksum, pathCreation=False)
        
        elif self.__isCatalogDownOrSessionExpired(errcode):
            raise FileCatalogUnavailable(self.__endpoint)        
        
        # unknown error
        raise LFCFileCatalogException('Unexpected error %s [%s -> %s]' % \
                                      (self.__lfc.sstrerror(errcode), to_native_lfn(dsn, lfn), guid))

    def registerFiles(self, files):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkRegisterFiles(self, files)}
        """
        r = {}
        for guid in files:
            dsn = files[guid]['dsn']
            lfn = files[guid]['lfn']
            surl = files[guid]['surl']
            fsize = files[guid]['fsize']
            checksum = files[guid]['checksum']

            # set replica bit to permanent (NOTE: historical, never used)
            bit='P'
            
            # try to create only the replica first
            try:
                r[guid] = self.__addReplica(guid, surl, bit)
            except LFCFileCatalogException:
                # failed so try to create file
                try:
                    r[guid] = self.__createFile(dsn, lfn, guid, surl, bit, fsize, checksum)
                except LFCFileCatalogException, e:
                    r[guid] = e        
        return r

        
    def bulkUnlink (self, files):
        r = {}
        for guid in files:
            stat = self.__lfc.lfc_filestatg()
            s = self.__lfc.lfc_statg ("",guid,stat)
            if s != 0:
                errcode = self.__lfc.cvar.serrno
                r[guid] = LFCFileCatalogException("Could not unlink guid with error %s [%s]" % \
                                                  (self.__lfc.sstrerror(errcode), guid))
                continue
            else:                
                path = " ".ljust (self.__lfc.CA_MAXPATHLEN+1)
                s = self.__lfc.lfc_getpath ("", stat.fileid, path)
                if s != 0:
                    errcode = self.__lfc.cvar.serrno
                    r[guid] = LFCFileCatalogException("Could not unlink guid with error %s [%s]" % \
                                                      (self.__lfc.sstrerror(errcode), guid))
                    continue
                else:                    
                    path = '%s'%path.strip()[:-1]
                    s = self.__lfc.lfc_unlink(path)                
                    if s != 0:
                        errcode = self.__lfc.cvar.serrno
                        r[guid] = LFCFileCatalogException("Could not unlink lfn with error %s [%s]" % \
                                                          (self.__lfc.sstrerror(errcode), path))
                        continue
            r[guid] = True
        return r


    def bulkUnregisterFiles(self, files, replicaOnly=True):
        """
        @see L{dq2.filecatalog.FileCatalogInterface.bulkUnregisterFiles(self, files, replicaOnly=True)}
        """
        r = {}
        for guid in files:
            #dsn = files[guid]['dsn']
            lfn   = files[guid]['lfn']
            surls = files[guid]['surls']
            
            r[guid] = True #If it was not possible to unregister the file, this value will be changed
            for surl in surls:
                s = self.__lfc.lfc_delreplica(guid, None, surl)
                if s != 0:
                    errcode = self.__lfc.cvar.serrno
                    r[guid] = LFCFileCatalogException("Could not delete replica with error %s [%s]" % \
                                                  (self.__lfc.sstrerror(errcode), lfn))
                    continue
                
            # should also remove guid/lfn
            if not replicaOnly:                
                stat = self.__lfc.lfc_filestatg()
                s = self.__lfc.lfc_statg ("",guid,stat)
                if s != 0:
                    errcode = self.__lfc.cvar.serrno
                    r[guid] = LFCFileCatalogException("Could not unlink guid with error %s [%s]" % \
                                                      (self.__lfc.sstrerror(errcode), guid))
                    continue
                else:                
                    path = " ".ljust(self.__lfc.CA_MAXPATHLEN+1)
                    s = self.__lfc.lfc_getpath("", stat.fileid, path)
                    if s != 0:
                        errcode = self.__lfc.cvar.serrno
                        r[guid] = LFCFileCatalogException("Could not unlink guid with error %s [%s]" % \
                                                          (self.__lfc.sstrerror(errcode), guid))
                        continue
                    else:                    
                        path = '%s'%path.strip()[:-1]
                        s = self.__lfc.lfc_unlink(path)                
                        if s != 0:
                            errcode = self.__lfc.cvar.serrno
                            r[guid] = LFCFileCatalogException("Could not unlink lfn with error %s [%s]" % \
                                                              (self.__lfc.sstrerror(errcode), path))
                            continue
            

        return r

    
        