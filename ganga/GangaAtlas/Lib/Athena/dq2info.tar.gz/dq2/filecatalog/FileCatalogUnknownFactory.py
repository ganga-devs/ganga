"""
Contains the File Catalog Unknown Factory exception.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""
from dq2.filecatalog.FileCatalogException import FileCatalogException


class FileCatalogUnknownFactory(FileCatalogException):
    """
    Class representing an unknown file catalog implementation.
    
    @see: L{dq2.filecatalog.FileCatalogException}
    
    @author: Miguel Branco <miguel.branco@cern.ch>
    @version: $Id: FileCatalogUnknownFactory.py,v 1.5 2007/12/11 11:50:37 mbranco Exp $
    """    
    
    def __init__(self, endpoint):
        """
        Constructor for the FileCatalogUnknownFactory object.
        """
        self._endpoint = endpoint
        
    def __str__(self):
        """
        String representation of the FileCatalogUnknownFactory exception.
        """
        return "Unknown File Catalog implementation [%s]" % self._endpoint