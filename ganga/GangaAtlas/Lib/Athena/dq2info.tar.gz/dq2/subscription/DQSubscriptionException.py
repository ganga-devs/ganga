"""
@since: 0.3.0
"""

from dq2.common.DQException import DQException, DQFatalError, DQNonFatalError, DQSecurityException, DQUserError


class DQSubscriptionExistsException (DQException, DQUserError, DQNonFatalError):
    """
    DQException class for the cases when a unexpected subscription is found.
    
    @since: 0.2.0
    """


    def __init__(self, uid, location, root_cause=None):
        """
        Creates an instance of DQSubscriptionExistsException.
        
        @since: 0.2.0
        
        @param uid: dataset or dataset version unique identifier
        @param location: subscription site
        @param root_cause: original error/exception.
        @param tuid: transaction unique identifier.
        """        
        self.uid = uid
        self.location = location
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'A dataset subscription for %s already exists at %s!' % (self.uid, self.location)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQUnknownSubscriptionException (DQException, DQUserError, DQNonFatalError):
    """
    DQException class for the cases when a expected subscription isn't found.
    
    @since: 0.2.0
    """
    def __init__(self, uid, location):
        """
        Creates an instance of DQUnknownSubscriptionException.
        
        @since: 0.2.0
        
        @param uid: is the dataset or dataset version unique identifier.
        @param location: is the subscription dq2.location.
       """
        self.uid = uid
        self.location = location
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = """A dataset subscription for %s at %s doesn't exist!""" % (self.uid, self.location)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)
