"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.1
@version: $Id: exceptions.py,v 1.1 2008/06/12 11:36:40 psalgado Exp $
"""

from dq2.subscription.DQSubscriptionException import *