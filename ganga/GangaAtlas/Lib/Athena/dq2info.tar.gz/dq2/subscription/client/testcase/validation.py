"""
Subscription client validation aspect.

@since: 0.3.0

$Id: validation.py,v 1.1.2.1 2009/04/20 09:42:37 vgaronne Exp $
"""

from dq2.common.aspects import wrap_around
from dq2.subscription.client.SubscriptionClient import SubscriptionClient


def wrap_package ():
    """
    Loads the validation aspect for the subscription client.
    @since: 0.3.0
    """
    from dq2.subscription.aspects.validation import addDatasetSubscription, deleteDatasetSubscription, deleteDatasetSubscriptions, querySubscriptions, querySubscriptionsInSite, reset
    
    wrap_around (SubscriptionClient.addDatasetSubscription, addDatasetSubscription)
    wrap_around (SubscriptionClient.deleteDatasetSubscription, deleteDatasetSubscription)
    wrap_around (SubscriptionClient.deleteDatasetSubscriptions, deleteDatasetSubscriptions)
    wrap_around (SubscriptionClient.querySubscriptions, querySubscriptions)
    wrap_around (SubscriptionClient.querySubscriptionsInSite, querySubscriptionsInSite)
    wrap_around (SubscriptionClient.reset, reset)

