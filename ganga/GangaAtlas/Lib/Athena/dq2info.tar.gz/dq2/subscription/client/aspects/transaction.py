"""
Subscription client transaction aspect.

@since: 0.3.0

$Id: transaction.py,v 1.1.2.2 2007/09/24 10:22:52 psalgado Exp $
"""

from dq2.common.aspects import wrap_around
from dq2.subscription.client.SubscriptionClient import SubscriptionClient


def wrap_package ():
    """
    Loads the transaction aspect for the subscription client.
    @since: 0.3.0
    """
    from dq2.common.dao.aspects.transaction import start_and_end
    
    wrap_around (SubscriptionClient.addDatasetSubscription, start_and_end)
    wrap_around (SubscriptionClient.deleteDatasetSubscription, start_and_end)
    wrap_around (SubscriptionClient.deleteDatasetSubscriptions, start_and_end)
    wrap_around (SubscriptionClient.querySubscriptions, start_and_end)
    wrap_around (SubscriptionClient.querySubscriptionsInSite, start_and_end)
    wrap_around (SubscriptionClient.reset, start_and_end)

