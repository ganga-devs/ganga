"""
Client to the dataset location central catalog.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.1.4
@version: $Id: LocationClient.py,v 1.12.2.29 2010/01/22 09:49:21 vgaronne Exp $
"""

import getopt
import os
import string
import sys
import pickle

import dq2.common.validator.DQValidator

from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.location.DQLocationAPI import API
from dq2.common.client.DQClient import DQClient
from dq2.common.DQConstants import HTTP
from dq2.location.DQLocationConstants import LocationState
from dq2.location.DQLocationConstants import TransferState

from dq2.common.DQException import DQException, DQInvalidRequestException
from dq2.common.client.x509 import get_x509
from dq2.common.client.x509 import get_ca_path

class LocationClient (DQClient, Configurable):
    """
    Class to make requests to the dataset location central catalog.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.12.2.29 $
    """


    insecure = None
    secure   = None
    timeout  = None


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, timeout=None):
        """
        Constructs a LocationClient instance.
        
        @since: 0.2.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @param urlsec: is the secure URL of the host to be contacted.
        @param certificate: is the proxy certificate.
        @param ca_path: is the location of the Certification Authority certificates.
        @param timeout : the client timeout (in seconds). (since 0.3)
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path, api=API, timeout=timeout)


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 0.3.0
        """
        LocationClient.insecure = Config().getConfig('dq2-location-client').get('dq2-location-client', 'insecure')
        LocationClient.secure = Config().getConfig('dq2-location-client').get('dq2-location-client', 'secure')
        try:
            LocationClient.timeout = int(Config().getConfig('dq2-location-client').get('dq2-location-client', 'timeout'))
        except:
            LocationClient.timeout = 9999

    __configure__ = staticmethod(__configure__)


# PUBLIC methods

    def addDatasetReplica (self, vuid, site, complete=LocationState.INCOMPLETE, transferState=TransferState.INACTIVE, owner=None, group=None, archived=None, acl_alias=None, lifetime=None):
        """
        Add a new replica where the dataset is not yet fully available at the site.
        To allow multiple file guids in the pfn field the vuid is appended to each guid.
        
        LocationClient uses a secure POST HTTP request for this method.
        
        @param vuid: is the dataset unique identifier.
        @param location: is the dataset dq2.location.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        @param lifetime: Dataset replica lifetime. Acceptable formats are: "X days" or "X days, HH:MM:SS" or "HH:MM:SS".
        @param acl_alias: is the  acl_alias, e.g. custodial which will be assocaited with the replica.    
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQLocationExistsException is raised,
                in case a dataset version replica exists at the given dq2.location.        
        """        
        
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'addDatasetReplica', 'vuid':vuid,
                       'site':site, 'complete':complete, 'transferState': transferState, 'owner': owner,
                       'group': group, 'acl_alias': acl_alias, 'lifetime': lifetime}
        return self.send()

    def getMasterLocation(self, vuid):
        self.type = HTTP.GET        
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'getMasterLocation', 'vuid': vuid}
        return self.send()

    def setTransferringStates (self, location, vuids, state):
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'setTransferringStates', 'vuids': vuids, 'location': location, 'state':state}        
        self.send()

    def getTransferringState (self, vuid, location):
        self.type = HTTP.GET
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'getTransferringState', 'vuid': vuid, 'location': location}        
        return self.send()

    def deleteDataset (self, vuids):
        """
        Delete all replicas of the dataset.
        
        @param vuids: is a list containing the dataset unique identifiers.
        
        LocationClient uses a secure GET HTTP request for this method.
        
        @since: 0.3.0
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
        """
        
        self.type = HTTP.DELETE
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'deleteDataset', 'vuids': vuids}
        
        self.send()


    def deleteDatasetReplica (self, vuid, sites):
        """
        Deletes the dataset replica at the given sites.
        
        LocationClient uses a secure POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param vuid: is the dataset version unique identifier.
        @param sites: is a list of the dataset replica locations.
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        """
        
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'deleteDatasetReplica', 'vuid': vuid, 'sites': sites}
        
        self.send()


    def queryDatasetLocations (self, vuids=[], complete=None):
        """
        Return a list of locations of the datasets/dataset versions.
        
        @since: 0.2.0
        
        @param vuids: is a list containing dataset version unique identifiers.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        
        @return: list of locations.::
            {
                'vuid_A': {
                    LocationState.COMPLETE:
                    ['site_A', 'site_Y'],
                    LocationState.INCOMPLETE:
                    ['site_Z', 'site_X']
            }
        """
        
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False
        self.params = {'operation': 'queryDatasetLocations', 'vuids': vuids, 'complete': complete}
        
        return self.send()


    def queryDatasetsInSite (self, location, complete=None, page=1, rpp=100):
        """
        Retrieve dataset replicas at the given location with the given complete state.
        
        LocationClient uses a GET HTTP request for this method.
        
        @since: 0.2.0
        
        @param location: is the dataset dq2.location.
        @param complete: is the location state of the dataset at a site and may have
            the following values: None: in which case the
            location state is ignore; LocationState.COMPLETE: lists only datasets
            fully present at the site (no files missing);
            LocationState.INCOMPLETE: lists only datasets partially present at the
            site (some files missing).
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case there is a python or database error.
            - DQInvalidRequestException is raised,
                in case of an invalid or missing arguments.
        
        @return: list of dataset versions.::
            ['vuid_1', ... 'vuid_N']
        """
        
        if (page <= 0):
            page = 1
        if (rpp <= 0):
            rpp = 100
        
        
        self.type = HTTP.GET
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'queryDatasetsInSite', 'location': location, 'complete': complete, 'page': page, 'rpp': rpp}
        
        return self.send()    
        
 
 
    def queryDatasetLocationsByDataset(self, uids):
        """
        Retrieve dataset locations.
        
        LocationClient uses a POST HTTP request for this method.
        
        @since: 0.4.0
        
        @param uids:  is a list containing dataset version unique identifiers.

        @return: Dictionnary.::
            {
                'uid_1': 
                    ['site_A', 'site_Y'],
                'uid_2':                     
                    ['site_Z', 'site_X'],
            }
        """
        
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False        
        self.params = {'operation': 'queryDatasetLocationsByDataset', 'uids': uids}
                
        return self.send()  

    def listDatasetReplicas (self, duid):    
        
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False        
        self.params = {'operation': 'listDatasetReplicas', 'duid': duid}
        return self.send()  
          
    def listFileReplicas (self, vuid, location): 
     
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False        
        self.params = {'operation': 'listFileReplicas', 'vuid': vuid, 'location':location}
        return self.send()  

    def listDatasetReplicasInContainer (self, cn):

        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False        
        self.params = {'operation': 'listContainerReplicas', 'cn': cn}
        return self.send()

    def queryDatasetReplicaMetadata (self, vuid, location):
    
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False        
        self.params = {'operation': 'queryDatasetReplicaMetadata', 'vuid': vuid, 'location':location}
        return self.send()

    def refreshReplicaCompleteness (self, vuid, location, threshold=None):
    
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'refreshReplicaCompleteness', 'vuid': vuid, 'location':location, 'threshold': threshold}
        return self.send()

    def queryDatasetsByNameInSite (self,  site, complete=None, name=None, p=None, rpp=None, group=None):
    
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False          
        self.params = {'operation': 'queryDatasetsByNameInSite', 'site': site, 'complete': complete, 'name':name, 'p':p, 'rpp':rpp, 'group': group}
        return self.send()  

    def deleteDataset2(self, duid):

        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'deleteDataset2', 'duid': duid}   
        return self.send()  
    
    def deleteDatasetReplica2 (self, duid, locations): 
    
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'deleteDatasetReplica2', 'duid': duid, 'locations': locations}
        return self.send()  

    def bulkDeleteDatasetReplicas (self, pattern, locations):
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'bulkDeleteDatasetReplicas', 'pattern': pattern, 'locations': locations}
        return self.send()  

    def updateCompleteness (self, dsn, version, location, files):
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'updateCompleteness', 'dsn': dsn, 'version': version, 'location':location, 'files':files}
        return self.send()  
	
	
    def queryGarbageCollectedReplicas (self,  location, name=None, p=None, rpp=None):

        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False          
        self.params = {'operation': 'queryGarbageCollectedReplicas', 'location': location, 'name':name, 'p':p, 'rpp':rpp}    
        return self.send()  
    
    def countGarbageCollectedReplicas (self,  location, name=None):

        self.type = HTTP.GET
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'countGarbageCollectedReplicas', 'location': location, 'name':name}    
        return self.send()  
    
    def queryDeletedReplicas (self,  location, name=None, p=None, rpp=None):

        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False          
        self.params = {'operation': 'queryDeletedReplicas', 'location': location, 'name':name, 'p':p, 'rpp':rpp}    
        return self.send()  
    
    def countDeletedReplicas (self,  location, name=None):
        """
        @since: 0.4.*
        """
        self.type = HTTP.GET
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'countDeletedReplicas', 'location': location, 'name':name}    
        return self.send()  


    def listGarbageCollectedFiles (self, dsn, location):
 
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False          
        self.params = {'operation': 'listGarbageCollectedFiles', 'dsn': dsn, 'location': location}    
        return self.send()
    
    def setDatasetReplicaToDeleted (self, dsn, location):
        """
        @since: 0.4.*
        """
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'setDatasetReplicaToDeleted', 'dsn': dsn, 'location': location}    
        return self.send()

    def queryStorageUsage (self, key=None, value=None, site=None, metaDataAttributes={}, locations=[]):
        """
        @since: 0.4.*
        """
        self.type      = HTTP.POST
        self.is_secure = False        
        self.request   = '/ws_location/rpc'
        self.params    = {'operation': 'queryStorageUsage', 'key': key, 'value': value, 
        			   'site':site, 'metaDataAttributes':metaDataAttributes, 'locations': locations}    
        return self.send() 
    
    def queryStorageUsageHistory (self, site, key='GRID', value='total'):
        """
        @since: 0.4.*
        """
        self.type = HTTP.GET
        self.request = '/ws_location/rpc'
        self.params = {'operation': 'queryStorageUsageHistory', 'key': key, 'value': value, 'site':site}    
        return self.send()  

    def getDeletionReport(self):
        """
        @since: 0.4.*
        """
        self.type = HTTP.POST
        self.request = '/ws_location/rpc'
        self.is_secure = False          
        self.params = {'operation': 'getDeletionReport'}    
        return self.send()
        
    def queryReplicaHistory (self, dsn , location):
        """
        @since: 0.4.*
        """
        self.type      = HTTP.POST
        self.request   = '/ws_location/rpc'
        self.is_secure = False          
        self.params    = {'operation': 'queryReplicaHistory', 'dsn': dsn, 'location': location}
        return self.send()  
   
    def setReplicaMetaDataAttribute (self, dsn, location, attrname, attrvalue):
        """
        @since: 0.4.*
        """
        self.type      = HTTP.POST
        self.request   = '/ws_location/rpc'
        self.is_secure = True
        self.params    = {'operation': 'setReplicaMetaDataAttribute', 'dsn': dsn, 'location': location, 'attrname': attrname, 'attrvalue': attrvalue}
        return self.send()  
        
    def addRequest(self,  requestType, dsn, ignore=False, locations=[], options=[]): 
        self.type      = HTTP.POST
        self.request   = '/ws_location/rpc'
        self.is_secure = True
        self.params    = {'operation'  : 'addRequest',  'requestType': requestType, 
                          'dsn': dsn, 'ignore': int(ignore), 'locations': locations, 'options': options}
        statuses = self.send()
        for l in statuses:
            if 'status' in statuses[l] and not statuses[l]['status'] and 'error' in statuses[l]:
               try:
                  statuses[l]['error'] = pickle.loads(statuses[l]['error'])
               except TypeError:               	 
                  pass
        return statuses