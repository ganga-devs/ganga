"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: __init__.py,v 1.2 2007/11/18 13:37:26 vgaronne Exp $
"""