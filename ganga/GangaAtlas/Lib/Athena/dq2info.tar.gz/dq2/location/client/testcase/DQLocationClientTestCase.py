"""
(since 0.3.0)

$Id: DQLocationClientTestCase.py,v 1.2 2007/01/24 09:59:15 mbranco Exp $
"""


from dq2.common.DQException import DQException, DQBackendException
from dq2.location.DQLocationException import DQLocationExistsException

from dq2.location.testcase.DQLocationTestCase import DQLocationTestCase
from dq2.location.client.LocationClient import LocationClient


class DQLocationClientTestCase (DQLocationTestCase):
    """
    
    (since 0.2.0)
    """


    def __init__ (self, name):
        """
    
        (since 0.2.0)
        """
        instance = LocationClient()
        DQLocationTestCase.__init__(self, name, instance)


# PUBLIC methods


if __name__ == '__main__':
    """
    Runs all tests in DQLocationClientTestCase.
    
    (since 0.2.0)
    """
    import sys
    
    test = DQLocationClientTestCase.main(
        'dq2.location.client.testcase', 'DQLocationClientTestCase',
        sys.argv[1:]
    )
