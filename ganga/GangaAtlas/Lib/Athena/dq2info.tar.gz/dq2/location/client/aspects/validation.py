"""
Location client validation aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: validation.py,v 1.7.2.15 2009/10/07 14:36:05 vgaronne Exp $
"""

from dq2.common.aspects import wrap_around

from dq2.location.client.LocationClient import LocationClient


def wrap_package ():
    """
    Loads the validation aspect for the location client.
    
    @since: 0.3.0
    """
    from dq2.location.aspects.validation import addDatasetReplica,                 \
    getMasterLocation, deleteDataset, setTransferringStates, getTransferringState, \
    deleteDatasetReplica, queryDatasetLocations, queryDatasetsInSite,              \
    queryDatasetLocationsByDataset, listDatasetReplicas,                           \
    listFileReplicas, queryDatasetReplicaMetadata, refreshReplicaCompleteness,     \
    queryDatasetsByNameInSite,                                                     \
    deleteDataset2, deleteDatasetReplica2, queryGarbageCollectedReplicas,          \
    countGarbageCollectedReplicas, queryDeletedReplicas, countDeletedReplicas,     \
    listGarbageCollectedFiles, setDatasetReplicaToDeleted, getDeletionReport,      \
    updateCompleteness, bulkDeleteDatasetReplicas, queryStorageUsage,              \
    queryStorageUsageHistory, queryReplicaHistory, addRequest

    # Replica methods
    wrap_around (LocationClient.addDatasetReplica,      addDatasetReplica)
    wrap_around (LocationClient.getMasterLocation,      getMasterLocation)

    # Deletion methods
    wrap_around (LocationClient.deleteDataset, deleteDataset)
    wrap_around (LocationClient.deleteDatasetReplica, deleteDatasetReplica)
    
    wrap_around (LocationClient.queryDatasetLocations,          queryDatasetLocations)
    wrap_around (LocationClient.queryDatasetsInSite,            queryDatasetsInSite)
    wrap_around (LocationClient.queryDatasetLocationsByDataset, queryDatasetLocationsByDataset)

    wrap_around (LocationClient.setTransferringStates,         setTransferringStates)
    wrap_around (LocationClient.getTransferringState,           getTransferringState)
    
    wrap_around (LocationClient.listDatasetReplicas,            listDatasetReplicas)    
    wrap_around (LocationClient.listFileReplicas,               listFileReplicas)
    
    wrap_around (LocationClient.queryDatasetReplicaMetadata, queryDatasetReplicaMetadata)    
    wrap_around (LocationClient.refreshReplicaCompleteness, refreshReplicaCompleteness)
    
    wrap_around (LocationClient.queryDatasetsByNameInSite, queryDatasetsByNameInSite)

    wrap_around (LocationClient.deleteDataset2,                deleteDataset2)
    wrap_around (LocationClient.deleteDatasetReplica2,         deleteDatasetReplica2)
    wrap_around (LocationClient.bulkDeleteDatasetReplicas,     bulkDeleteDatasetReplicas)
    wrap_around (LocationClient.addRequest,                    addRequest)
    
    
    wrap_around (LocationClient.updateCompleteness,            updateCompleteness)
    
    wrap_around (LocationClient.queryGarbageCollectedReplicas, queryGarbageCollectedReplicas)
    wrap_around (LocationClient.countGarbageCollectedReplicas, countGarbageCollectedReplicas)    
    wrap_around (LocationClient.queryDeletedReplicas,          queryDeletedReplicas)
    wrap_around (LocationClient.countDeletedReplicas,          countDeletedReplicas)
    wrap_around (LocationClient.listGarbageCollectedFiles,     listGarbageCollectedFiles)
    wrap_around (LocationClient.setDatasetReplicaToDeleted,    setDatasetReplicaToDeleted)
    wrap_around (LocationClient.getDeletionReport,             getDeletionReport)

    wrap_around (LocationClient.queryStorageUsage,             queryStorageUsage)
    wrap_around (LocationClient.queryStorageUsageHistory,      queryStorageUsageHistory)
    
    wrap_around (LocationClient.queryReplicaHistory,          queryReplicaHistory)    