"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: DQLocationAPI.py,v 1.4.4.1 2010/02/02 20:08:46 vgaronne Exp $
"""

API = '0_3_0'
