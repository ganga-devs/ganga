"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: __init__.py,v 1.4.2.2 2010/02/02 20:08:46 vgaronne Exp $
"""