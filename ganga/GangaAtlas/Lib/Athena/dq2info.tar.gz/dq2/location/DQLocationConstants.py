"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: DQLocationConstants.py,v 1.9.2.1 2010/02/02 20:08:46 vgaronne Exp $

@see: "8.2 State Guidelines
(...)
168. State Names Should Be Simple but Descriptive
(...)
Ideally, state names should also be written in present tense,
although names such as Proposed (past tense) are better than
Is Proposed (present tense).
", The Elements of UML Style - Scott W. Ambler
"""

class TransferState:
    """
    @authors: Pedro Salgado, Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.9.2.1 $
    """
    __ANY__ = None
    ACTIVE       = 0
    INACTIVE      = 1
        
    STATES = [ACTIVE, INACTIVE]

class DeletionState:
    """
    @authors: Pedro Salgado, Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.9.2.1 $
    """
    __ANY__ = None
    GARBAGE_COLLECTED = 0
    RELEASED          = 1
    DELETED           = 2
    
    STATES = [GARBAGE_COLLECTED, RELEASED, DELETED]
    
    
class LocationState:
    """
    @authors: Pedro Salgado, Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.9.2.1 $
    """
    __ANY__ = None
    INCOMPLETE        = 0
    COMPLETE          = 1
    
    STATES = [INCOMPLETE, COMPLETE]

class MutableState:
    """
    @authors: Pedro Salgado, Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.5.0
    @version: $Revision: 1.9.2.1 $
    """
    __ANY__ = None
    UNKNOWN      = -1
    MUTABLE      =  0
    IMMUTABLE    =  1
    
    STATES = [UNKNOWN, MUTABLE, IMMUTABLE]


class CheckState:
    """
    @authors: Pedro Salgado, Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.5.0
    @version: $Revision: 1.9.2.1 $
    """
    __ANY__ = None
    WAITING      =  0  
    REQUESTED    =  1  
    CHECKING     =  2    
    CHECKED      =  6
        
    STATES = [WAITING,CHECKED,CHECKING,REQUESTED]


class MasterReplicaState:
    """
    @authors: Pedro Salgado, Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.9.2.1 $
    """
    __ANY__ = None
    ALREADY_REGISTERED     = 0 
    MASTER_REPLICA         = 1
        
    STATES = [ALREADY_REGISTERED, MASTER_REPLICA]