"""
Testcase for the dq2.location.DQLocationValidator module.

(since 0.2)

$Id: DQLocationValidatorTestCase.py,v 1.1.1.1 2007/01/16 15:02:06 mbranco Exp $
"""

import dq2.location.DQLocationValidator

from dq2.common.DQConstants import *
from dq2.common.DQException import DQInvalidRequestException
from dq2.common.testcase.DQTestCase import DQTestCase


class DQLocationValidatorTestCase (DQTestCase):
    """
    Testcase for the dq2.location.DQLocationValidator module.
    
    (since 0.2.1)
    """


    def __init__ (self, name):
        """
        Constructs an instance of DQLocationValidatorTestCase.
        (since 0.2.1)
        
        name is the testcase name.
        """
        DQTestCase.__init__(self, name)
        
        self.param_dict_0 = {}
        
        self.param_int__1 = -1
        self.param_int_0 = 0
        self.param_int_1 = 1
        
        self.param_lst_0 = []
        
        self.param_str_0 = ''
        
        self.param_invalid_dsn_0 = 'dqtest/invalid/name'
        
        self.param_invalid_lfn_0 = 'dqtest/invalid/name'
        
        self.param_tpl_0 = ()


# PUBLIC methods


    def setUp (self):
        """
        (since 0.2.1)
        """
        pass


    def tearDown (self):
        """
        (since 0.2.1)
        """
        pass


    def test_is_location_state (self):
        """
        Tests dq2.location.DQLocationValidator.is_location_state method.
        (since 0.2.1)
        
        # 1. test entering valid parameters
        # 1.1 test all valid dq2.common.DQConstants.LocationState.STATES
        # 2. test entering invalid parameters
        # 2.1 test entering an invalid state
        # 2.2 test entering a string
        # 2.3 test entering a list
        # 2.4 test entering a dictionary
        # 2.5 test entering a tuple
        """
        
        # 1. test entering valid parameters
        
        # 1.1 test all valid dq2.common.DQConstants.LocationState.STATES
        expected = None
        
        for eachState in LocationState.STATES:
            result = dq2.location.DQLocationValidator.is_location_state(eachState)
            self.assertEqual(result, expected, self._fmt_message('1.1', expected, result))
        
        
        # 2. test entering invalid parameters
        
        # 2.1 test entering an invalid state
        self.assertRaises(
            DQInvalidRequestException,
            dq2.location.DQLocationValidator.is_location_state,
            self.param_int__1
        )
        
        # 2.2 test entering a string
        self.assertRaises(
            DQInvalidRequestException,
            dq2.location.DQLocationValidator.is_location_state,
            self.param_str_0
        )
        
        # 2.3 test entering a list
        self.assertRaises(
            DQInvalidRequestException,
            dq2.location.DQLocationValidator.is_location_state,
            self.param_lst_0
        )
        
        # 2.4 test entering a dictionary
        self.assertRaises(
            DQInvalidRequestException,
            dq2.location.DQLocationValidator.is_location_state,
            self.param_dict_0
        )
        
        # 2.5 test entering a tuple
        self.assertRaises(
            DQInvalidRequestException,
            dq2.location.DQLocationValidator.is_location_state,
            self.param_tpl_0
        )


if __name__ == '__main__':
    """
    Runs all tests in DQLocationValidatorTestCase.
    (since 0.2.1)
    """
    import unittest
    suite = unittest.makeSuite(DQLocationValidatorTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
