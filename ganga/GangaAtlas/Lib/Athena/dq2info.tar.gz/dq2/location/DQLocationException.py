"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQLocationException.py,v 1.5.4.1 2010/02/02 20:08:46 vgaronne Exp $
"""

from dq2.common.DQException import DQException, DQNonFatalError, DQUserError, DQWarning


class DQLocationExistsException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.5.4.1 $
    """
    def __init__(self, dsn, location, root_cause=None):
        """
        
        @since: 0.2.0
        
        """
        self.dsn = dsn
        self.location = location
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message  = 'This dataset (%s) is being deleted at this site (%s) !' % (self.dsn, self.location)
        
        #message = 'The dataset %s already exists at location %s!' % (self.dsn, self.location)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQLocationDefinitionDeletedException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.4.0
    @version: $Revision: 1.5.4.1 $
    """
    def __init__(self, dsn, location, root_cause=None):
        """
        
        @since: 0.4.0
        
        """
        self.dsn = dsn
        self.location = location
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.4.0
        """
        message = 'This dataset definition %s has been deleted !' % (self.dsn)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)

        
class DQLocationDatasetBeingDeleted (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.4.0
    @version: $Revision: 1.5.4.1 $
    """
    def __init__(self, dsn, location, root_cause=None):
        """
        
        @since: 0.4.0
        
        """
        self.dsn = dsn
        self.location = location
        DQException.__init__(self, root_cause=root_cause)
        
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.4.0
        """
        message = 'This dataset (%s) is being deleted at this site (%s) !'% (self.dsn, self.location)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)
        