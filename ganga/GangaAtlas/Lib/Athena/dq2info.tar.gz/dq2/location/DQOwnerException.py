"""
Contains the Onwer excection

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

from dq2.common.DQException import DQException, DQNonFatalError, DQUserError, DQWarning


class DQOwnerNonExistsException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Vincent Garonne
    @contact: vincent.garonne@cern.ch
    @since: 
    @version: $$
    """
    def __init__(self, owner, root_cause=None):

        self.owner = owner
        DQException.__init__(self, root_cause=root_cause)
        
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'The owner %s do not exist !' % (self.owner)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)