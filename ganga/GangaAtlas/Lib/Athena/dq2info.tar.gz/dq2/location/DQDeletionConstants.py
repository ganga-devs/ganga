"""
Contains the Deletion constants.

@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

@author: Vincent Garonne
@contact: vincent.garonne@cern.ch
@since: 0.2
@version: $ $
"""

class DeletionState:
    """
    @authors: Vincent Garonne
    @contact: atlas-dq2-dev@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    __ANY__ = None
    WAITING   = 0
    READY     = 4
    DELETED   = 2
    
    STATES = [WAITING, READY, DELETED]