"""
DQ2 common methods.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2.2
@version: $Id: DQLocationValidator.py,v 1.4 2007/11/25 18:49:44 vgaronne Exp $
"""


from dq2.location.DQLocationConstants import LocationState
from dq2.common.DQException import DQInvalidRequestException
from dq2.common.validator.DQValidator import is_integer


def is_location_state (args):
    """
    Tests if the given state is a valid dataset state (dq2.common.DQConstants.LocationState).
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.1
    @version: $Revision: 1.4 $
    
    @param args: is the list of arguments to be tested.
    @type args: 
    
    @raise DQInvalidRequestException: in case the state is not an integer or if it is an invalid state.  
    """
    
    for arg in args:
        is_integer([arg])
        
        if not arg in LocationState.STATES:
            err_msg = 'Parameter value [%s] is not a valid location state!' % (arg)
            raise DQInvalidRequestException(err_msg)
