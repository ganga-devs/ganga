"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.4.4.1 2010/02/02 20:08:46 vgaronne Exp $
"""

__version__ = '$Name: dq2-location-1-1-1 $'

API = '0_3_0'