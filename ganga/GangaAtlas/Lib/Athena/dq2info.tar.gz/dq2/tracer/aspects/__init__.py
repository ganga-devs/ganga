"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: __init__.py,v 1.1 2007/11/30 08:24:48 vgaronne Exp $
"""