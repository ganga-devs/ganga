"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

"""
Tracer client transaction aspect.

@author: Mario Lassnig
@author: Pedro Salgado
@contact: mario.lassnig@cern.ch
@since: 0.3.0
@version: $Id: transaction.py,v 1.2 2007/12/04 14:42:04 mlassnig Exp $
"""

from dq2.common.aspects import wrap_around

from dq2.tracer.client.TracerClient import TracerClient


def wrap_package ():
    """
    Loads the transaction aspect for the location client.
    
    @since: 0.3.0
    """
    from dq2.common.dao.aspects.transaction import start_and_end
    
    #Consistency methods
    wrap_around(TracerClient.addReport, start_and_end)
    