"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

"""
Load aspects for dq2.tracer.client package.

Warning: order is important!
"""

from dq2.tracer.client.aspects.validation import wrap_package
wrap_package()