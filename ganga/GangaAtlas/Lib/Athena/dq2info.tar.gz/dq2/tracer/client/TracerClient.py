"""
Copyright (c) ATLAS Distributed Data Management project, 2007.

@license: Apache License 2.0
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

"""
Client to the tracer central catalog.

@author: Mario Lassnig
@author: Pedro Salgado
@contact: maro.lassnig@cern.ch
@since: 0.1.4
@version: $Id: TracerClient.py,v 1.2.2.3 2008/06/18 15:59:14 mlassnig Exp $
"""

from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.common.client.DQClient import DQClient
from dq2.common.DQConstants import HTTP
from dq2.common.constants import API_030


class TracerClient (DQClient, Configurable):
    """
    Class to make requests to the tracer central catalog.
    
    @author: Pedro Salgado
    @author: Mario Lassnig
    @contact: mario.lassnig@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.2.2.3 $
    """

    insecure = None
    secure   = None
    timeout  = None

    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, timeout=None, api=API_030):
        """
        Constructs a tracerClient instance.
        
        @since: 0.2.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @param urlsec: is the secure URL of the host to be contacted.
        @param certificate: is the proxy certificate.
        @param ca_path: is the location of the Certification Authority certificates.
        @param timeout : the client timeout (in seconds). (since 0.3)
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path, api=api, timeout=timeout)


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 0.3.0
        """
        try:
            TracerClient.insecure = Config().getConfig('dq2-tracer-client').get('dq2-tracer-client', 'insecure')
        except:
            TracerClient.insecure = 'http://atlddmcat.cern.ch:80/'
            
        try:
            TracerClient.secure = Config().getConfig('dq2-tracer-client').get('dq2-tracer-client', 'secure')
        except:
            TracerClient.secure = 'https://atlddmcat.cern.ch:443/'
        
        try:
            TracerClient.timeout = int(Config().getConfig('dq2-tracer-client').get('dq2-tracer-client', 'timeout'))
        except:
            TracerClient.timeout = 600

    __configure__ = staticmethod(__configure__)


# PUBLIC methods

    def addReport (self, report):
            self.type = HTTP.POST   
            self.is_secure = False                    
            self.request = '/ws_tracer/rpc'
            self.params = {'operation': 'addReport', 'report': report}
            #print self.params
            return self.send()