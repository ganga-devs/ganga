"""
Contains the class definition for Config objects.

@author: Fernando H. Barreiro Megino 
@contact: fernando.harald.barreiro.megino@cern.ch
@since: 0.2
@version: $Id: destinationConfigurator.py,v 1.1.2.3 2009/07/13 13:27:31 fbarreir Exp $
"""
from dq2.common.Config import Config


class destinationConfigurator:
    """
    Class definition for destination configurator.
    
    @author: Fernando H. Barreiro Megino <fernando.harald.barreiro.megino@cern.ch>
    """
    
    """
    Holds the singleton reference.
    """
    _instance = None
    
    """
    Configuration objects
    """
    _tagSuffixesList = []
    _pandaSuffixesList = []    
    
    def __new__(cls):
        """
        Invoked on every class instance creation.
        
        Makes sure that only one instance of this class ever exists.
        
        @return: A reference to the class singleton
        """
        if not cls._instance:
            cls._instance = object.__new__(cls)
        
        return cls._instance


    def __init__(self):
        """
        Object constructor.
        
        As this is a singleton, nothing is put in here (otherwise it would
        be constantly called).
        """
        pass


    def getTagSuffixesList(self):
        if self._tagSuffixesList:
            return self._tagSuffixesList
        
        config = Config().getConfig('dq2-info-destination')
        
        try:
            suffixesString=str(config.get('dq2-info-destination', 'tagSuffixesList'))
            self._tagSuffixesList = suffixesString.split(',')
        except:
            pass
        
        return self._tagSuffixesList

    
    def getPandaSuffixesList(self):
        if self._pandaSuffixesList:
            return self._pandaSuffixesList
        
        config = Config().getConfig('dq2-info-destination')
        
        try:
            suffixesString=str(config.get('dq2-info-destination', 'pandaSuffixesList'))
            self._pandaSuffixesList = suffixesString.split(',')
        except:
            pass
        
        return self._pandaSuffixesList
    