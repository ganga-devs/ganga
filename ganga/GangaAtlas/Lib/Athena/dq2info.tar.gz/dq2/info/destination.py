"""
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.3
@version: $Id: destination.py,v 1.2.2.8 2009/10/06 11:12:53 vgaronne Exp $
"""

import time
import re
from dq2.info.destinationConfigurator import destinationConfigurator 

def __strip_tag(tag):
    """
    Drop the _sub and _dis suffixes for panda datasets from the lfc path 
    they will be registered in 
    """
    import re

    suffixes_to_drop=['_dis','_sub','_tid']
    config_suffixes=destinationConfigurator().getTagSuffixesList()
    if config_suffixes:
        suffixes_to_drop.extend(config_suffixes)
    
    stripped_tag=tag
    
    try:
        for suffix in suffixes_to_drop:
            stripped_tag=re.sub('%s.*$'%suffix,'',stripped_tag)
    except IndexError:        
        return stripped_tag
    
    return stripped_tag            


def __strip_dsn(dsn):
    """
    Drop the _sub and _dis suffixes for panda datasets from the lfc path 
    they will be registered in 
    """
    import re

    suffixes_to_drop=['_dis','_sub','_frag']
    config_suffixes=destinationConfigurator().getPandaSuffixesList()
    if config_suffixes:
        suffixes_to_drop.extend(config_suffixes)
    
    fields=dsn.split('.')
    last_field=fields[-1]    
    
    try:
        for suffix in suffixes_to_drop:            
            last_field=re.sub('%s.*$'%suffix,'', last_field)
    except IndexError:        
        return dsn
    fields[-1]=last_field
    stripped_dsn='.'.join(fields)        

    return stripped_dsn     


def construct_surl(dsn, filename):
    """
    Defines relative SURL for new replica. This method
    contains DQ2 convention.
    
    @return: relative SURL for new replica. 
    @rtype: str
    """

    # check how many dots in dsn
    fields = dsn.split('.')
    nfields=len(fields)
    
    if nfields == 1:
        stripped_dsn=__strip_dsn(dsn)
        return '/other/%s/%s' % (stripped_dsn, filename)

    elif nfields == 2:
        project = fields[0]    
        stripped_dsn=__strip_dsn(dsn)
        return '/%s/%s/%s' % (project, stripped_dsn, filename)         
        
    elif nfields < 5 or re.match('user*|group*',fields[0]):
        project = fields[0]
        f2 = fields[1]
        f3 = fields[2]
        stripped_dsn=__strip_dsn(dsn)
        return '/%s/%s/%s/%s/%s' % (project, f2, f3, stripped_dsn, filename)
             
    else: 
        project = fields[0]
        dataset_type = fields[4]
        if nfields==5:
            tag='other'
        else:
            tag = __strip_tag(fields[-1])                        
        stripped_dsn=__strip_dsn(dsn)
        return '/%s/%s/%s/%s/%s' % (project, dataset_type, tag, stripped_dsn, filename)
