"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: TiersOfATLASTestCase.py,v 1.2 2008/11/28 10:14:40 mbranco Exp $
"""


import os

from dq2.common.testcase.DQTestCase import DQTestCase

from dq2.info.TiersOfATLASConfigurator import TiersOfATLASConfigurator
from dq2.info.TiersOfATLASException import TiersOfATLASException

from dq2.info.TiersOfATLAS import ToATLASCache

class TiersOfATLASTestCase (DQTestCase):


    def __init__ (self, name):
        DQTestCase.__init__(self, name)


    def _removeToACache (self):
        """
        @since: 0.3.0
        """
        try:
            os.remove(self.ToAscript)
        except:
            pass


    def setUp (self):
        """
        """
        import dq2.info.TiersOfATLAS
        
        dq2.info.TiersOfATLAS.ToACache = None
        dq2.info.TiersOfATLAS.cache.module = None
        self.ToAscript = dq2.info.TiersOfATLAS.cache.script
        self._removeToACache()


    def tearDown (self):
        """
        """
        import dq2.info.TiersOfATLAS
        
        dq2.info.TiersOfATLAS.ToACache = None
        
    
    def testDownloadInvalidToA (self):
        """
        Override default URL to point to bad place
        (then put it back right or rest of tests will fail :-)
        """
        
        import dq2.info.TiersOfATLAS
        
        good = dq2.info.TiersOfATLAS.cache.url
        dq2.info.TiersOfATLAS.cache.url = 'http://something.bad'
        # there is no local copy yet
        
        self._removeToACache()
        try:
            try:
                dq2.info.TiersOfATLAS.getAllDestinationSites()
            except TiersOfATLASException, e:
                return
        finally:
            dq2.info.TiersOfATLAS.cache.url = good
        
        print dq2.info.TiersOfATLAS.cache.origin
        assert(False)


    def testDownloadToA (self):
        """
        1.2 _verifyIntegrity response is ok? ToACache is None
        2.2 ToACache.py copy was made? [%s]
        2.3 _verifyIntegrity response is ok? with good ToACache
        """
        import dq2.info.TiersOfATLAS
        
        
        # 1. empty ToACache
        
        assert(dq2.info.TiersOfATLAS.ToACache is None)
        assert(dq2.info.TiersOfATLAS.cache.module is None)
        
        # 1.2 _verifyIntegrity response is ok? ToACache is None
        message = '1.2 _verifyIntegrity response is ok? ToACache is None'
        
        result = dq2.info.TiersOfATLAS.cache._verifyIntegrity()
        expected = False
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
        # 2. download a copy
        
        dq2.info.TiersOfATLAS.getAllDestinationSites()
        assert(dq2.info.TiersOfATLAS.ToACache is not None)
        
        # 2.2 ToACache.py copy was made? [%s]
        message = '2.2 ToACache.py copy was made? [%s]' % (self.ToAscript)
        
        result = os.path.exists(dq2.info.TiersOfATLAS.cache.script)
        expected = True
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        # 2.3 _verifyIntegrity response is ok? with good ToACache
        message = '2.3 _verifyIntegrity response is ok? with good ToACache'
        
        result = dq2.info.TiersOfATLAS.cache._verifyIntegrity()
        expected = True
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
    def testGetAllDestinationSites (self):
        """
        
        # 1. check if CNAF is a destination site
        # 2. check if a clound isn't a destination site
        """
        from dq2.info.TiersOfATLAS import getAllDestinationSites
        
        s = getAllDestinationSites()
        #print s
        
        # 1. check if CNAF is a destination site
        assert(s.count('CERNCAF') == 1)
        
        # 2. check if a clound isn't a destination site
        assert(s.count('TIER1S') == 0)
    
    
    def testGetAllSources (self):
        """
        
        # 1. check if CNAF is a destination site
        # 2. check if a clound isn't a destination site
        """
        from dq2.info.TiersOfATLAS import getAllSources
        
        s = getAllSources()
        #print s
        
        # 1. check if CNAF is a destination site
        assert(s.count('CERNCAF') == 1)
        
        # 2. check if a clound isn't a destination site
        assert(s.count('TIER1S') == 1)
        
        
    def testGetFTS (self):
        """
        """
        from dq2.info.TiersOfATLAS import getFTS
        
        src_surl = 'srm://srm.cern.ch/castor/cern.ch/grid/atlas/test/file1'
        dest_site = 'PICTAPE'
        
        r = getFTS(src_surl, dest_site)
        #print r
        assert(r is not None)
        

    def testGetCloseSites (self):
        """
        """
        from dq2.info.TiersOfATLAS import getCloseSites
        
        sites = getCloseSites('TIER0DISK')
        assert(sites.count('PICDISK') == 1)
        
        sites = getCloseSites('GARBAGE')
        assert(sites == [])


    def testGetLocalCatalog (self):
        """
        """
        from dq2.info.TiersOfATLAS import getLocalCatalog
        
        lrc = getLocalCatalog('CERNCAF')
        assert(lrc.find('cern.ch') != -1)
        
        lrc = getLocalCatalog('TIER1S')
        assert(lrc is None)
        
        lrc = getLocalCatalog('GARBAGE')
        assert(lrc is None)
        
        
    def testGetRemoteCatalogs (self):
        """
        """
        from dq2.info.TiersOfATLAS import getRemoteCatalogs
        
        lrcs = getRemoteCatalogs('CERNCAF')
        assert(len(lrcs) == 1)
        assert(lrcs[0].find('cern.ch') != -1)
        
        lrcs = getRemoteCatalogs('TIER1S')
        #print 'TIER1S remote catalogs:',lrcs
        assert(len(lrcs) > 0)
        
        lrcs = getRemoteCatalogs('GARBAGE')
        assert(len(lrcs) == 0)


    def testGetSiteProperty (self):
        """
        """
        from dq2.info.TiersOfATLAS import getSiteProperty
        
        p = getSiteProperty('CERNCAF', 'srm')
        #print p
        assert(p is not None)
        
        p = getSiteProperty('CERNCAF', 'nothing')
        assert(p is None)
        
        p = getSiteProperty('GARBAGE', 'srm')
        assert(p is None)
        
        
    def testIsSURLFromSiteOrCloud (self):
        """
        """
        from dq2.info.TiersOfATLAS import isSURLFromSiteOrCloud
        
        file = 'srm://srm-durable-atlas.cern.ch/castor/cern.ch/grid/atlas/caf/test/file1'
        assert(isSURLFromSiteOrCloud(file, 'CERNCAF') == True)
        assert(isSURLFromSiteOrCloud(file, 'PICDISK') == False)

        file = 'srm://srm-disk.pic.es/grid/atlas/test/file1'
        assert(isSURLFromSiteOrCloud(file, 'PICDISK') == True)
        assert(isSURLFromSiteOrCloud(file, 'TIER1S') == True)
        assert(isSURLFromSiteOrCloud(file, 'CERNCAF') == False)
        
        
    def testRefreshToACache (self):
        """
        1. init ToACache [1]
        1.1 ToACache loaded from remote copy?
        2. corrupt ToACache [2]
        2.1 ToACache loaded from remote copy?
        3. regular refresh
        3.1 ToACache loaded from memory?
        4. timeout ToACache memory copy [4]
        4.1 ToACache loaded from local disk copy?
        5. timeout ToACache memory and disk copy [5]
        5.1 ToACache loaded from remote copy?
        6. init ToACache with bad URL will try a possible disk copy?
        6.1 ToACache loaded from local disk copy?
        """
        
        import dq2.info.TiersOfATLAS
        
        
        # 1. init ToACache [1]
        dq2.info.TiersOfATLAS._refreshToACache()
        
        assert(dq2.info.TiersOfATLAS.ToACache.sites is not None)
        assert(len(dq2.info.TiersOfATLAS.ToACache.sites) > 0)
        
        # 1.1 ToACache loaded from remote copy?
        message = '1.1 ToACache loaded from remote copy?'
        result = dq2.info.TiersOfATLAS.cache.origin
        expected = 'remote'
        
        
        # 2. corrupt ToACache [2]
        firstid = id(dq2.info.TiersOfATLAS.ToACache)
        del(dq2.info.TiersOfATLAS.ToACache.__dict__['sites'])
        assert(not ('sites' in dq2.info.TiersOfATLAS.ToACache.__dict__.keys()))
        dq2.info.TiersOfATLAS._refreshToACache()
        secondid = id(dq2.info.TiersOfATLAS.ToACache)
        assert(dq2.info.TiersOfATLAS.ToACache.sites is not None)
        assert(len(dq2.info.TiersOfATLAS.ToACache.sites) > 0)
        assert(not(firstid == secondid)) # ToACache was loaded?
        
        # 2.1 ToACache loaded from remote copy?
        message = '2.1 ToACache loaded from remote copy?'
        result = dq2.info.TiersOfATLAS.cache.origin
        expected = 'remote'
        
        
        # 3. regular refresh
        firstid = id(dq2.info.TiersOfATLAS.ToACache)
        dq2.info.TiersOfATLAS._refreshToACache()
        assert(dq2.info.TiersOfATLAS.ToACache.sites is not None)
        assert(len(dq2.info.TiersOfATLAS.ToACache.sites) > 0)
        secondid = id(dq2.info.TiersOfATLAS.ToACache)
        
        assert(firstid == secondid) # ToACache was *not* loaded?
        
        # 3.1 ToACache loaded from memory?
        message = '3.1 ToACache loaded from memory?'
        result = dq2.info.TiersOfATLAS.cache.origin
        expected = 'memory'
        
        
        # 4. timeout ToACache memory copy [ [4]
        firstid = id(dq2.info.TiersOfATLAS.ToACache)
        dq2.info.TiersOfATLAS.cache.lastupdated = None
        dq2.info.TiersOfATLAS._refreshToACache()
        secondid = id(dq2.info.TiersOfATLAS.ToACache)
        
        assert(dq2.info.TiersOfATLAS.ToACache.sites is not None)
        assert(len(dq2.info.TiersOfATLAS.ToACache.sites) > 0)
        assert(not(firstid == secondid)) # ToACache was loaded?
        
        # 4.1 ToACache loaded from local disk copy?
        message = '4.1 ToACache loaded from local disk copy?'
        result = dq2.info.TiersOfATLAS.cache.origin
        expected = 'local'
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
        # 5. timeout ToACache memory and disk copy [5]
        firstid = id(dq2.info.TiersOfATLAS.ToACache)
        self._removeToACache() # remove the local copy
        dq2.info.TiersOfATLAS.cache.lastupdated = None # force timeout of ToACache in memory
        dq2.info.TiersOfATLAS._refreshToACache()
        secondid = id(dq2.info.TiersOfATLAS.ToACache)
        
        assert(dq2.info.TiersOfATLAS.ToACache.sites is not None)
        assert(len(dq2.info.TiersOfATLAS.ToACache.sites) > 0)
        assert(not (firstid == secondid)) # ToACache was loaded?
        
        # 5.1 ToACache loaded from remote copy?
        message = '5.1 ToACache loaded from remote copy?'
        result = dq2.info.TiersOfATLAS.cache.origin
        expected = 'remote'
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))
        
        
        # 6. init ToACache with bad URL will try a possible disk copy?
        firstid = id(dq2.info.TiersOfATLAS.ToACache)
        dq2.info.TiersOfATLAS.ToACache = None # force download/retrieval
        dq2.info.TiersOfATLAS.cache.module = None # force download/retrieval
        dq2.info.TiersOfATLAS.cache.url = 'http://something.bad' # bad URL to force a local copy
        dq2.info.TiersOfATLAS._refreshToACache()
        secondid = id(dq2.info.TiersOfATLAS.ToACache)
        
        assert(dq2.info.TiersOfATLAS.ToACache.sites is not None)
        assert(len(dq2.info.TiersOfATLAS.ToACache.sites) > 0)
        assert(not(firstid == secondid)) # ToACache was loaded?
        
        # 6.1 ToACache loaded from local disk copy?
        message = '6.1 ToACache loaded from local disk copy?'
        result = dq2.info.TiersOfATLAS.cache.origin
        expected = 'local'
        
        self.assertEqual(result, expected, self._fmt_message(message, expected, result))


if __name__ == '__main__':
    """
    Runs all tests in TiersOfATLASTestCase.
    
    @since: 0.3.0
    """
    import sys
    test = TiersOfATLASTestCase.main(
        'dq2.info.testcase', TiersOfATLASTestCase.__name__, sys.argv[1:]
    )
    sys.exit(0)
