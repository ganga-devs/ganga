"""
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.2.2.5 2009/10/16 11:45:58 vgaronne Exp $
"""

__version__ = '$Name: dq2-info-0-4-9 $'

class PermissionType:
    READ       = 'r'
    WRITE      = 'w'
    UPLOAD     = 'u'
    ADMIN      = 'a'
    DELETE     = 'd'
    FETCH      = 'f'
    __ALL__ = [READ, WRITE, ADMIN, DELETE, UPLOAD, FETCH]