"""
Client for the DQ2 content 0.3.* catalog.

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.1.4
@version: $Id: ContentClient.py,v 1.12.2.9.4.5 2008/07/30 09:03:56 psalgado Exp $
"""

import os
import string
import sys

import dq2.common.validator.DQValidator

from dq2.common import Configurable
from dq2.common.Config import Config
from dq2.common.DQConstants import HTTP
from dq2.common.DQException import DQException, DQInvalidRequestException
from dq2.common.client.DQClient import DQClient
from dq2.common.client.x509 import get_ca_path
from dq2.common.client.x509 import get_x509
from dq2.common.constants import API_030

from dq2.content.client import PACKAGE


class ContentClient (DQClient, Configurable):
    """
    Class to make requests to the dataset content central catalog.
    
    @author: David Cameron
    @contact: david.cameron@cern.ch
    @author: Miguel Branco
    @contact: miguel.branco@cern.ch
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.12.2.9.4.5 $
    
    @cvar insecure: the central catalog's insecure URL.
    @type insecure: str
    @cvar secure: the central catalog's secure URL.
    @type secure: str
    @cvar timeout: the HTTP connection timeout.
    @type timeout: int
    """


    insecure = None
    secure = None
    timeout = None


    def __init__ (self, url=None, urlsec=None, certificate=None, ca_path=None, timeout=None):
        """
        Constructs a ContentClient instance.
        
        @since: 0.2.0
        
        @param url: is the non-secure URL of the host to be contacted.
        @type url: str
        @param urlsec: is the secure URL of the host to be contacted.
        @type url: str
        @param certificate: is the proxy certificate.
        @type certificate: str
        @param ca_path: is the location of the Certification Authority certificates.
        @type ca_path: str
        @param timeout : the client timeout (in seconds).
        @type timeout: int
        """
        DQClient.__init__(self, url, urlsec, certificate, ca_path, api=API_030, timeout=timeout)


    def __configure__ ():
        """
        Setup client default configuration.
        
        @since: 0.3.0
        
        @deprecated: with the content client factory the configure will be moved into the factory.
        """
        
        ContentClient.insecure = Config().getConfig(PACKAGE).get(PACKAGE, 'insecure')
        ContentClient.secure = Config().getConfig(PACKAGE).get(PACKAGE, 'secure')
        try:
            ContentClient.timeout = int(Config().getConfig(PACKAGE).get(PACKAGE, 'timeout'))
        except:
            ContentClient.timeout = 9999

    __configure__ = staticmethod(__configure__)


# PUBLIC methods


    def addFilesToDataset (self, vuid, vuids, files):
        """
        Add multiple files to a dataset.
        
        To allow multiple file guids in the pfn field the vuid is appended to each guid.
        
        @note: the client uses a secure POST HTTP request for this method.
        
        @since: 0.2.3
        
        @param vuid: the dataset version unique identifier.
        @type vuid: str
        @param vuids: list of dataset's dataset version unique identifiers.
        @type vuids: list
        @param files: list containing the files information
            ({'guid', 'vuid', 'lfn', 'size', 'checksum'})
            where checksum is 'md5:<md5_32_character_string>'
        @type files: list
        @param guids: are the file unique identifiers. Note: the GUID is typically
            assigned by external tools (e.g. POOL) and must be passed along as is.
        @type guids: list
        
        @raise DQDaoException: in case there is a python or database error.
        @raise DQFileExistsInDatasetException: in case the given guid is already registered for the given dataset.
        @raise DQInvalidRequestException: in case of an invalid or missing arguments.
        
        @return List containing warnings.
            [(lfn, guid), ..., (...)]
        """
        
        self.type = HTTP.PUT
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'addFilesToDataset', 'vuid': vuid, 'vuids': vuids, 'files': files}
        
        return self.send()


    def addFilesToDatasets (self, filesdict):
        """
        @since: 0.3.0
        
        @param filedict: list of file dictionaries to be registered on the given datasets.
            [{'vuid', 'vuids', 'files'}]
        @type filedict: list
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQFileExistsInDatasetException:
            in case the given guid is already registered for the given dataset.
        @raise DQInvalidFileMetadataException:
            in case the given file is already registered with a different GUID.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        
        @return dictionary containing warnings per vuids.
            {'vuid': [(lfn, guid), ..., (...)]}
        @rtype: dict
        """
        
        self.type = HTTP.PUT
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'addFilesToDatasets', 'filesdict': filesdict}
        
        return self.send()


    def deleteDataset (self, vuids):
        """
        Deletes all files associated to this dataset.
        
        @note: client uses a secure POST HTTP request for this method.
        
        @since: 0.2.0
        
        @param vuids: is a list of dataset version unique identifiers.
        @type vuids: list
        
        @raise DQDaoException: in case there is a python or database error.
        @raise DQInvalidRequestException: in case of an invalid or missing arguments.
        """
        
        self.type = HTTP.POST
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'deleteDataset', 'vuids': vuids}
        self.send()


    def deleteFilesFromDataset (self, vuid, vuids, guids):
        """
        Method used by Local Copy of Content Catalog per site!
        Bulk deletion of associations of a file with a vuid.
        
        @note: client uses a secure POST HTTP request for this method.
        
        @since: 0.3.0
        
        @param vuid: is the dataset version.
        @type vuid: str
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @type guids: list
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        """
        
        self.type = HTTP.POST
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'deleteFilesFromDataset', 'vuid': vuid, 'vuids': vuids, 'guids': guids}
        
        return self.send()


    def filesInDataset (self, vuids, guids):
        """
        @since: 0.4.0
        
        @param vuids: is a list of dataset's dataset version unique identifiers.
        @type vuids: list
        @param guids: is a list of file unique identifiers (GUID).
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @type guids: list
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        
        @return: Dictionary with the following format:
            {
                GUIDX: True, # exist
                (...)
                GUIDY: False # don't exist
            }
        """
        
        self.type = HTTP.POST
        self.is_secure = False
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'filesInDataset', 'vuids': vuids, 'guids': guids}
        
        return self.send()


    def getNumberOfFiles (self, vuids):
        """
        Returns the number of files with the given set of vuids.
        
        @note: client uses a GET HTTP request for this method.
        
        @since: 0.3.0
        
        @param vuids: is a list of dataset version unique identifiers.
        @type vuids: list
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        
        @return: the number of files
        @rtype: int
        """
        
        self.type = HTTP.GET
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'getNumberOfFiles', 'vuids': vuids}
        
        return self.send()


    def queryDatasetsWithFileByGUID (self, guid):
        """
        Query content catalog for datasets containing the given file guid.
        
        @since: 0.2.0
        
        @param guid: file unique identifier.
            Note: the GUID is typically assigned by external tools
            (e.g. POOL) and must be passed along as is.
        @type guid: str
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        
        @return: List of VUIDs that contain this file.::
            ('vuid_0', ..., 'vuid_n')
        @rtype: tuple
        """
        
        self.type = HTTP.GET
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'queryDatasetsWithFileByGUID', 'guid': guid}
        
        return self.send()


    def queryFilesInDataset (self, vuids):
        """
        Returns the files in the given dataset.
        
        @since: 0.2
        
        @param vuids: is a list of the dataset version unique identifiers.
        @type vuids: list
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        
        @return: Tuple containing the last timestamp and dictionary of guids mapped to lfns.::
            (
            {
                'guid_00': {'lfn': 'lfn_00', 'filesize': filesize_00, 'checksum': checksum_00},
                ...,
                'guid_n0': {'lfn': 'lfn_n0', 'filesize': filesize_n0, 'checksum': checksum_n0}
            },
            lastdate
            )
            where checksum is 'md5:<md5_32_character_string>'
        @rtype: tuple
        """
        
        self.type = HTTP.POST
        self.is_secure = False
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'queryFilesInDataset', 'vuids': vuids}
        
        return self.send()


    def queryFilesByCreationDate (self, vuid, date_minimum, date_maximum=None):
        """
        Returns all files in the dataset created between the given dates ([date_minimum, date_maximum]).
        
        @since: 0.2.3
        
        @param vuid: the dataset version unique identifier.
        @type vuid: str
        @param date_minimum: is the latest date.
        @type date_minimum: 
        @keyword date_maximum: is the nearest date.
        @type date_maximum: 
        
        @raise DQDaoException:
            in case there is a python or database error.
        @raise DQInvalidRequestException:
            in case of an invalid or missing arguments.
        
        @return: Tuple containing the last timestamp and dictionary of guids mapped to lfns.::
            (
            {
                0: {
                    'guid_00': {'lfn': 'lfn_00', 'filesize': filesize_00, 'checksum': checksum_00},
                    ...,
                    'guid_n0': {'lfn': 'lfn_n0', 'filesize': filesize_n0, 'checksum': checksum_n0}} HIDDEN
                1: {
                    'guid_01': {'lfn': 'lfn_01', 'filesize': filesize_01, 'checksum': checksum_01},
                    ...,
                    'guid_n1': {'lfn': 'lfn_n1', 'filesize': filesize_n1, 'checksum': checksum_n1}} ADDED
                2: {
                    'guid_02': {'lfn': 'lfn_02', 'filesize': filesize_02, 'checksum': checksum_02},
                    ...,
                    'guid_n2': {'lfn': 'lfn_n2', 'filesize': filesize_n2, 'checksum': checksum_n2}} DELETED
            },
            lastcreationdate
            )
            where checksum is 'md5:<md5_32_character_string>'
        @rtype: tuple
        """
        
        self.type = HTTP.POST
        self.is_secure = False
        self.request = '/ws_content/rpc'
        self.params = {'operation': 'queryFilesByCreationDate', 'vuid': vuid, 'min': date_minimum, 'max': date_maximum}
        
        return self.send()