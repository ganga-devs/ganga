"""
Content catalog specific exceptions.

@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.3.0
@version: $Id: DQContentException.py,v 1.1 2008/05/30 13:00:22 psalgado Exp $
"""


from dq2.common.DQException import DQException, DQFatalError, DQNonFatalError, DQUserError, DQWarning


class DQInvalidFileMetadataException (DQException, DQUserError, DQNonFatalError):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, guid, lfn):
        """
        @since: 0.2.0
        """
        self.guid = guid
        self.lfn = lfn
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'The file LFN or GUID is already registered! [%s :: %s]' % (self.guid, self.lfn)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQFileAlreadyDeletedFromDatasetException (DQException, DQUserError, DQWarning):
    """
    @since: 0.2.4
    """
    def __init__ (self, lfn, guid, vuid):
        """
        @since: 0.2.0
        """
        self.lfn = lfn
        self.guid = guid
        self.vuid = vuid
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = "File %s (%s) isn't registered in vuid %s!" % (self.lfn, self.guid, self.vuid)
        return '%s%s %s' % (DQUserError.prefix, DQWarning.prefix, message)


class DQFileExistsInDatasetException (DQException, DQUserError, DQWarning):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.4
    @version: $Revision: 1.1 $
    """
    def __init__ (self, lfn, guid, vuid):
        """
        @since: 0.2.0
        """
        self.lfn = lfn
        self.guid = guid
        self.vuid = vuid
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = "File %s (%s) already registered in vuid %s!" % (self.lfn, self.guid, self.vuid)
        return '%s%s %s' % (DQUserError.prefix, DQWarning.prefix, message)


class DQFileMetaDataMismatchException (DQException, DQUserError, DQNonFatalError):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, guid, lfn, attribute, user_value, ddm_value):
        """
        @since: 0.2.0
        """
        self.guid = guid
        self.lfn = lfn
        self.attribute = attribute
        self.user = user_value
        self.ddm = ddm_value
        DQException.__init__(self)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = "File %s (%s) %s attribute doesn't match the value stored in DDM! [%s != %s]" % (self.lfn, self.guid, self.attribute, self.user, self.ddm)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)
