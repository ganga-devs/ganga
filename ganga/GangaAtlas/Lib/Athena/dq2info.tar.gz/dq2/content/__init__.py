"""
Package for DQ2 content catalog.

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.1
@version: $Id: __init__.py,v 1.3 2008/06/17 20:16:43 psalgado Exp $
"""


API_030 = '030'


def build_file_dictionary (lfns, guids, sizes, checksums):
    """
    Builds the file dictionary structure.
    
    @since: 0.3.0
    
    @param lfns: is a list of logical filenames (LFN).
    @type lfns: list
    @param guids: is a list of file unique identifiers (GUID).
        Note: the GUID is typically assigned by external tools
        (e.g. POOL) and must be passed along as is.
    @type guids: list
    @param sizes: is a list of the file sizes.
    @type sizes: list
    @param checksums: is a list of the file checksums.
    @type checksums: list
    
    @return: list of dictionaries.
        [
            { 'guid': <guid_0>, 'lfn' : <lfn_0>, 'size': size, 'checksum' : checksum}
            ...
            { 'guid': <guid_N>, 'lfn' : <lfn_N>, 'size': size, 'checksum' : checksum}
        ]
    """
    
    # 
    files = []
    if len(lfns) > 0:
        
        for eachNum in range(len(lfns)):
            if len(sizes) > 0:
                """user provided file sizes"""
                size = sizes[eachNum]
            else:
                size = None
            if len(checksums) > 0:
                """user provided checksums"""
                checksum = checksums[eachNum]
            else:
                checksum = None
            
            file = {
                'guid': guids[eachNum],
                'lfn' : lfns[eachNum],
                'size': size,
                'checksum' : checksum
            }
            
            files.append(file)
    return files