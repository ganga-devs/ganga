"""
@license: Apache License 2.0
"""
"""
Copyright (c) ATLAS Distributed Data Management project, 2009.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
"""

__author__ = 'vincent.garonne@cern.ch'
__version__ = '$Revision: 1.1.2.1 $'


def decode(classobj, value):   
    associations = [(eval ('%s.%s'%(classobj.__name__, s)), s) for s in dir (classobj)]
    for item in associations:
        if value == item[0]: return item[1:][0]

class RequestType:
    
    __ANY__  = None    
    LOOKUP           = 1
    DELETION         = 2
    COPY             = 3
    STAGE            = 4
    
    STATES = [DELETION, LOOKUP, COPY, STAGE]

class RequestState:
    
    __ANY__  = None    
    QUEUED   = 0
    ACTIVE   = 2    
    BROKEN   = 3
    ABORTING = 4
    ABORTED  = 5
    SUCCESS  = 6
    
    STATES = [QUEUED, ACTIVE, BROKEN, SUCCESS, ABORTING, ABORTED]
    