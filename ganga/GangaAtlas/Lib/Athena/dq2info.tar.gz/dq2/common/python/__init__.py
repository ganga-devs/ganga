"""
This package contains python modules that may not be present or that behave differently,
in some versions of python.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 1.0.0
@version: $Id: __init__.py,v 1.2.2.2 2008/09/25 21:54:44 psalgado Exp $
"""