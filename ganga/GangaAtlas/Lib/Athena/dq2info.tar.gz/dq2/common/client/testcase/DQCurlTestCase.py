"""
Testcase to check DQ clients<->DDM server communications.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQCurlTestCase.py,v 1.1.1.1.2.5 2007/11/21 09:36:29 psalgado Exp $
"""

HOST_TEST = 'pcatlas264.cern.ch'

from dq2.common.DQConstants import HTTP
from dq2.common.DQException import DQException

from dq2.common.client.DQClient import DQClient
from dq2.common.client.DQClientException import DQInternalServerException

from dq2.common.testcase.DQTestCase import DQTestCase


class DQClientTest (DQClient):
    """
    Class to wrap HTTP request configurations.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1.1.1.2.5 $
    
    @ivar ca_path: is the location of the Certification Authority certificates.
    @ivar certificate: is the proxy certificate.
    @ivar params: are the parameters to be sent with the request
        (USE dictionary for GET and DELETE and USE lists for POST and PUT).
    @ivar request: is the HTTP URL.
    @type request: str
    @ivar is_secure: send the HTTP request as secure (only applicable for GET and POST),
        by default GET is insecure and POST is secure.
    @type is_secure: bool
    @ivar type: is the type of HTTP request to send.
    @type type: str
    @ivar url: is the non-secure URL of the host to be contacted.
    @type url: str
    @ivar urlsec: is the secure URL of the host to be contacted.
    @type urlsec: str
    @ivar timeout : the client timeout (in seconds).
    @type timeout: int
    """


    def __init__ (self):
        """
        @since: 0.3.0
        """
        url ='http://%s:%s' % (HOST_TEST, '8000')
        urlsec = 'https://%s:%s' % (HOST_TEST, '8443')
        
        DQClient.__init__(self, url=url, urlsec=urlsec, timeout=5)



class DQCurlTestCase (DQTestCase):
    """
    Testcase to check DQCurl<->DQ2 communications.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1.1.1.2.5 $
    
    @ivar c: the test client.
    @type c: object
    """


    def __init__ (self, name, proxy_cert=None):
        """
        @since: 0.2.0
        """
        self.c = DQClientTest()
        DQTestCase.__init__(self, name)


    def tearDown (self):
        """
        @since: 0.2.0
        """
        pass


    def attemptEmptyServerResponse (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
            
            # 1.1
            
            self.c.type = HTTP.GET
            self.c.request = '/ws_test/empty'
            self.c.params = {'operation': 'None'}
            
            try:
                out = self.c.send()
            except DQInternalServerException, e:
                continue
            #print '%s :: %s' % (DQClient.implementation, out)
            
            self.fail('DQInternalServerException should have been raised!')


    def attemptEmptyAndOKServerResponse (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
            
            # 1.1
            
            self.c.type = HTTP.GET
            self.c.request = '/ws_test/empty_and_ok'
            self.c.params = {'operation': 'None'}
            
            try:
                out = self.c.send()
            except DQInternalServerException, e:
                continue
            print '%s :: %s' % (DQClient.implementation, out)
            
            self.fail('DQInternalServerException should have been raised!')


    def attemptTimeout (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
            
            # 1.1
            
            self.c.type = HTTP.GET
            self.c.request = '/ws_test/timeout'
            self.c.params = {'operation': 'None'}
            
            try:
                out = self.c.send()
            except DQInternalServerException, e:
                continue
            
            self.fail('DQInternalServerException should have been raised!')


    def testSendDelete (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
    
            # 1.1
            
            self.c.type = HTTP.DELETE
            self.c.request = '/ws_test/which_method'
            self.c.params = {'operation': 'deleteDataset', 'dsn': 'csc11.xxx'}
            expected_params = self.c.params
            
            out = self.c.send()
            
            expected = True
            result = out['dn'] != ''
            self.assertEqual(expected, result, self._fmt_message("The DN doesn't match!", expected, result))
            
            expected = 1
            result = out['security']
            self.assertEqual(expected, result, self._fmt_message("The method should be secure!", expected, result))
    
            expected_params['delete'] = 'yes'
            result = out['form']
            self.assertEqual(expected_params, result, self._fmt_message("The sent parameters don't match!", expected_params, result))


    def testSendGet (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
            
            # 1.1
            
            self.c.type = HTTP.GET
            self.c.request = '/ws_test/which_method'
            self.c.params = {'operation': 'deleteDataset', 'dsn': 'csc11.xxx'}
            expected_params = self.c.params
            
            out = self.c.send()
            
            expected = 0
            result = out['security']
            self.assertEqual(expected, result, self._fmt_message("The method shouldn't be secure!", expected, result))
            
            result = out['form']
            self.assertEqual(expected_params, result, self._fmt_message("The sent parameters don't match!", expected_params, result))


    def testSendPost (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
            
            # 1.1
            
            self.c.type = HTTP.POST
            self.c.request = '/ws_test/which_method'
            self.c.params = {'operation': 'deleteDataset', 'dsn': 'csc11.xxx'}
            expected_params = self.c.params
            
            out = self.c.send()
            
            expected = True
            result = out['dn'] != ''
            self.assertEqual(expected, result, self._fmt_message("The DN doesn't match!", expected, result))
            
            expected = 1
            result = out['security']
            self.assertEqual(expected, result, self._fmt_message("The method should be secure!", expected, result))
    
            result = out['form']
            self.assertEqual(expected_params, result, self._fmt_message("The sent parameters don't match!", expected_params, result))


    def testSendPut (self):
        """
        @since: 0.2.0
        """
        
        for impl in ['curl', 'pycurl']:
            DQClient.implementation = impl
            
            # 1.1
            
            self.c.type = HTTP.PUT
            self.c.request = '/ws_test/which_method'
            self.c.params = {'operation': 'deleteDataset', 'dsn': 'csc11.xxx'}
            expected_params = self.c.params
            expected_params['update'] = 'yes'
            
            out = self.c.send()
            
            expected = True
            result = out['dn'] != ''
            self.assertEqual(expected, result, self._fmt_message("The DN doesn't match!", expected, result))
            
            expected = 1
            result = out['security']
            self.assertEqual(expected, result, self._fmt_message("The method should be secure!", expected, result))
            
            result = out['form']
            self.assertEqual(expected_params, result, self._fmt_message("The sent parameters don't match!", expected_params, result))


if __name__ == '__main__':
    """
    @since: 0.2.0
    """
    import sys
    argv = sys.argv[1:]
    
    import unittest
    if len(argv) >= 1:
        suite = unittest.TestSuite()
        for method in argv:
            suite.addTest(DQCurlTestCase(method))
            
    else:
        suite = unittest.TestSuite()
        
        for method in dir(DQCurlTestCase):
            if method[0:4] == 'test' or method[0:8] == 'scenario' or method[0:7] == 'attempt':
                suite.addTest(DQCurlTestCase(method))
    
    unittest.TextTestRunner(verbosity=2).run(suite)
