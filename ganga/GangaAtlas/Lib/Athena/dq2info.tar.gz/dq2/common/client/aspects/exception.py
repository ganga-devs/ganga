"""
Client exception aspects.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: exception.py,v 1.1.1.1.2.2 2007/12/04 13:41:15 psalgado Exp $
"""


from dq2.common.aspects import wrap_around, wrap_around_re


def wrap_package ():
    """
    @since: 0.3.0
    """
    
    wrap_client()


def wrap_client ():
    """
    Wraps client components.
    
    @since: 0.3.0
    """
    from dq2.common.client.DQClient import DQClient
    
    # before sending a HTTP request a tuid should be assigned to the client
    wrap_around (DQClient.send, wrap_send)


def wrap_send (self, *args, **kwargs):
    """
    Wraps the send method in order to cleanup the client settings in case of an exception.
    
    @since: 0.3.0
    """
    try:
        return self.__proceed(*args, **kwargs)
    finally:
        self._reset()