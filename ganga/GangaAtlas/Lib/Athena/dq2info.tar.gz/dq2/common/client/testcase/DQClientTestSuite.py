"""
Client module test suite.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQClientTestSuite.py,v 1.2.2.4 2007/10/18 14:38:47 psalgado Exp $
"""

from unittest import TestSuite


class DQClientTestSuite (TestSuite):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.2.2.4 $
    """


    def __init__ (self, factory, api, testcases, specificTest=None):
        """
        @since: 0.3.0
        
        @param factory: the factory to be used to create the test instance.
        @type factory: object
        @param api: the API to be used to create the instance.
        @type api: str
        @param testcases: the testcases to run.
        @type testcases: list
        @param specificTest: a specific test to be run.
        @type specificTest: str
        """
        
        TestSuite.__init__(self)
        
        
        self.api = api
        
        instance = factory.create(api=self.api)
        instance.tuid = 'testcase-0000-0000-0000-000000000000'
        
        for eachTestCase in testcases:
            for method in dir(eachTestCase):
                if specificTest is not None:
                    if method == specificTest:
                        self.addTest(eachTestCase(method, instance))
                elif method[0:4] == 'test' or method[0:8] == 'scenario' or method[0:7] == 'attempt':
                    """method name starts by 'test': add it to the test suite"""
                    self.addTest(eachTestCase(method, instance))