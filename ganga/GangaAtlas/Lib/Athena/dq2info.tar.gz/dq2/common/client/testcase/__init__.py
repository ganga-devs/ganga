"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: __init__.py,v 1.1.1.1.2.1 2007/09/05 13:00:18 psalgado Exp $
"""