"""
The pycurl implementation to contact the central catalogs.

@author: 
@contact: 
@since: 0.2.0
@version: $Id: DQPycurl.py,v 1.6.2.18.2.4 2009/02/09 13:54:43 mlassnig Exp $
"""


import cPickle
import datetime
import re
import os
import pycurl

from StringIO import StringIO

import dq2.common


from dq2.common.DQConstants import HTTP
from dq2.common.DQException import *
from dq2.common.dao.DQDaoException import *
from dq2.common.client.DQClientException import DQInternalServerException


class DQPycurl:
    """
    Class responsible to establish and send HTTP requests to DDM servers using pycurl.
    
    @since: 0.2.0
    """


    REG_CURL_ERROR = re.compile('^curl: \([0-9]+\) (.)*$')


    def __init__ (self, url, urlsec, proxy_cert, ca_path, timeout, headers, hostname='<unknown>'):
        """
        Constructs an instance of DQPycurl.
        
        @since: 0.2.0
        
        @ivar url: is the non-secure URL of the host to be contacted.
        @type url: str
        @ivar urlsec: is the secure URL of the host to be contacted.
        @type urlsec: str
        @ivar proxy_cert: is the proxy certificate.
        @type proxy_cert:
        @ivar ca_path: is the directory where the Certification Authority certificates are located (by default it is /etc/grid-security/certificates but can be overriden by the X509_CERT_DIR environment variable.
        @type ca_path: str
        @ivar timeout : the client timeout (in seconds). (since 0.3)
        @type timeout: str
        @ivar hostname: is the client's hostname.
        @type hostname: str
        
        @raise DQSecurityException: in case of an invalid proxy certificate.
        """
        self.url = url
        self.urlsec = urlsec
        self.hostname = hostname
        self.headers = headers
        self.timeout = timeout
        
        c = pycurl.Curl()
        c.setopt(pycurl.DNS_CACHE_TIMEOUT, 60)
        c.setopt(pycurl.FOLLOWLOCATION, 1)
        c.setopt(pycurl.MAXREDIRS, 5)
        
        if self.timeout is not None:
            c.setopt(pycurl.TIMEOUT, self.timeout) # in seconds
        
        c.setopt(pycurl.HTTPHEADER, self.headers)
        
        
        if os.environ.has_key('DQCURL_VERBOSE') and \
           os.environ['DQCURL_VERBOSE'] != '0':
            c.setopt(pycurl.VERBOSE, 1)
        
        
        self.c = c
        
        
        if proxy_cert is not None:
            
            if proxy_cert == -1:
                err_msg = "Invalid certificate!"
                raise DQSecurityException(err_msg)
            
            
            csec = pycurl.Curl()
            csec.setopt(pycurl.SSL_VERIFYHOST,01)
            csec.setopt(pycurl.FOLLOWLOCATION, 1)
            csec.setopt(pycurl.MAXREDIRS, 5)
            csec.unsetopt(pycurl.CAINFO)
            if ca_path is not None:
                csec.setopt(pycurl.CAPATH, ca_path)
            csec.setopt(pycurl.SSLCERT, proxy_cert)
            csec.setopt(pycurl.SSLKEY, proxy_cert)
            csec.setopt(pycurl.SSLVERSION, 3)
            csec.setopt(pycurl.HTTPHEADER, self.headers)
            
            if self.get_pycurl_version() <= '7.10.6':
                """
                for pycurl.version < 7.10.6 (at least) need to set SSL_VERIFYPEER to 0
                possible insecure option : exposure to "man-in-the-middle" attack
                http://mail.python.org/pipermail/python-list/2003-February/147296.html
                """
                csec.setopt(pycurl.SSL_VERIFYPEER, 0)
            
                
            if os.environ.has_key('DQCURL_VERBOSE') and os.environ['DQCURL_VERBOSE'] != '0':
                csec.setopt(pycurl.VERBOSE, 1)
            
            self.csec = csec


    def __del__ (self):
        """
        Closes DQPycurl HTTP connection.
        
        @since: 0.2.0
        """
        if 'csec' in vars(self):
            self.csec.close()
        self.c.close()


# PRIVATE methods


    def _process (self, c):
        """
        Process the response of the web service.
        
        @since: 0.2.0
        
        @param c: is the pycurl instance.
        @type c: pycurl.Curl
        """
        
        try:
            c.perform()
        except pycurl.error, e:
            """@see: http://curl.haxx.se/libcurl/c/libcurl-errors.html"""
            errno, text = e
            
            if errno == 6:
                err_msg = 'Unknown DDM server %s! Please check your configuration file.\n[(%s) %s]' % (
                    dq2.common.get_hostname(c.getinfo(pycurl.EFFECTIVE_URL)),
                    errno,
                    text
                )
                raise DQInternalServerException(err_msg, self.url, self.urlsec, errno)
            if errno == 7:
                err_msg = 'The central catalog is not responding! The service is down or bad configuration (host port number)!\n [(%s) %s]' % (errno, text)
                raise DQInternalServerException(err_msg, self.url, self.urlsec, errno)
            elif errno == 23:
                err_msg = 'The central catalog database is down!\n [(%s) %s]' % (errno, text)
                raise DQInternalServerException(err_msg, self.url, self.urlsec, errno)
            elif errno == 28:
                err_msg = 'The client timed out!'
                raise DQInternalServerException(err_msg, self.url, self.urlsec, errno)
            elif errno == 35:
                err_msg = 'Proxy certificate expired!\n[(%s) %s]' % (errno, text)
                raise DQInternalServerException(e, curl_error=errno)
            elif errno == 52:
                """empty reply from the server -> server too busy?"""
                err_msg = 'The central catalog sent an empty response!\n (%s)' % (errno)
                raise DQBadServerResponse(err_msg, self.url, self.urlsec, errno)
            else:
                raise DQInternalServerException(e, self.url, self.urlsec, curl_error=errno)
        
        
        st = c.getinfo(pycurl.HTTP_CODE)
        response = c.body.getvalue()
        response = response.strip('\n') # remove new line characters
        
        if len(response) == 0:
            err_msg = 'The server sent an empty response:\n'
            raise DQInternalServerException(err_msg, self.url, self.urlsec)
        
        if st == 200:
            
            if re.findall(DQPycurl.REG_CURL_ERROR, response):
                raise DQInternalServerException(response, self.url, self.urlsec)
            
            # ugly but only way is to grep for error string
            if response.find('Mod_python error') != -1:
                raise DQBadServerResponse(response, self.url, self.urlsec, None)
            
            # convert non strings to list, dict etc
            try:
                response = eval(response)
            except StandardError, e:
                raise DQException(root_cause=e)
            return response
            
        else:
            
            try:
                raise cPickle.loads(response)
            except SyntaxError, e:
                err_msg = 'The server sent an invalid response:\n [%s]' % (response)
                DQInternalServerException(err_msg, self.url, self.urlsec)
            except cPickle.UnpicklingError, e:
                if str(response).find('<!DOCTYPE') == 0:
                    err_msg = 'The server sent an invalid response:\n [%s]' % (response)
                    DQInternalServerException(err_msg, self.url, self.urlsec)
                err_msg = 'Unknown server error:\n [%s]' % (response)
                raise DQInternalServerException(err_msg, self.url, self.urlsec)


# PUBLIC methods


    def delete (self, request):
        """
        Does HTTP GET with 'delete=yes' field.
        
        @since: 0.2.0
        
        @param request: the URL.
        @type request: str
        """
        
        self.csec.body = StringIO()
        if request.find('?') != -1: request += '&delete=yes'
        else: request += '?delete=yes'
        
        return self.get(request, secure=True)


    def get (self, request, secure=False):
        """
        Does HTTP GET.
        
        @since: 0.2.0
        
        @param request: the URL.
        @type request: str
        @param secure: flag to indicate if the request should be secure.
        @type secure: bool
        """
        if secure: c = self.csec
        else: c = self.c
        c.body = StringIO()
        if secure: c.setopt(pycurl.URL, str('%s%s' % (self.urlsec, request)))
        else: c.setopt(pycurl.URL, str('%s%s' % (self.url, request)))
        c.setopt(pycurl.WRITEFUNCTION, c.body.write)
        
        return self._process(c)


    def get_pycurl_version (self):
        """
        @since: 0.3.0
        """
        separator = pycurl.version.find(' ')
        installed_version = pycurl.version[8:separator]
        return installed_version


    def post (self, request, pf, secure=True):
        """
        Does HTTP POST.
        
        @since: 0.2.0
        
        @param request: the URL.
        @type request: str
        @param pf: the parameters.
        @type pf: dict
        @param secure: flag to indicate if the request should be secure.
        @type secure: bool
        
        @warning: expects list with fields (format per field is 'field1=value1')
        """
        assert pf != []
        
        if secure: c = self.csec
        else: c = self.c
        c.body = StringIO()
        if secure: c.setopt(pycurl.URL, str('%s%s' % (self.urlsec, request)))
        else: c.setopt(pycurl.URL, str('%s%s' % (self.url, request)))
        
        c.setopt(pycurl.WRITEFUNCTION, c.body.write)
        
        params = []
        pycurl_version = self.get_pycurl_version()
        
        for eachKey in pf:
            if pycurl_version > '7.10.6':
                """item is a tuple"""
                item = (str(eachKey), str(pf[eachKey]))
            else:
                """item is a string"""
                item = '%s=%s' % (eachKey, pf[eachKey])
                
            params.append(item)
        c.setopt(pycurl.HTTPPOST, params)

        return self._process(c)


    def put (self, request, pf):
        """
        Does HTTP POST with 'update=yes' field.
        
        @since: 0.2.0
        
        @param request: the URL.
        @type request: str
        @param params: the parameters.
        @type params: dict
        """
        assert pf != []
        pf['update'] = 'yes'
        
        return self.post(request, pf, secure=True)
