"""
Load aspects for dq2.common.client

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: __init__.py,v 1.2.2.2.2.1 2007/12/11 10:54:34 psalgado Exp $

@warning: order is important
"""


__version__ = '$Name: dq2-common-client-0-3-5 $'


from dq2.common.client.aspects.transaction import wrap_package
wrap_package()

from dq2.common.client.aspects.exception import wrap_package
wrap_package()