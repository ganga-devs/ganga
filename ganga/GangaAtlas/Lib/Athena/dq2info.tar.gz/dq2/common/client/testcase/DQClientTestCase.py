"""
Testcase to check DQClient<->DQ2 communications.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQClientTestCase.py,v 1.1.1.1.2.5 2007/10/18 14:36:24 psalgado Exp $
"""


from dq2.common.DQConstants import HTTP
from dq2.common.client.DQClient import DQClient
from dq2.common.testcase.DQTestCase import DQTestCase


class DQClientTestCase (DQTestCase):
    """
    Testcase to check DQClient<->DQ2 communications.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1.1.1.2.5 $
    """

    # for testing purposes, parameters should only be strings
    PARAMS_DELETE = {'dsn': 'mcatnlo0310.005921.W+W-enuenu', 'id': '123', 'delete': 'yes'}
    PARAMS_GET    = {'dsn': 'mcatnlo0310.005921.W+W-enuenu', 'id': '123'}
    PARAMS_POST   = {'dsn': 'mcatnlo0310.005921.W+W-enuenu', 'id': '123'}
    PARAMS_PUT    = {'dsn': 'mcatnlo0310.005921.W+W-enuenu', 'id': '123', 'update': 'yes'}


    def __init__ (self, name):
        """
        Constructs an instance of DQClientTestCase.
        @since: 0.2.1
        
        name is the testcase name.
        """
        DQTestCase.__init__(self, name)


    def setUp(self):
        """
    
        @since: 0.2.0
        """

        url ='http://%s:%s' % ('pcatlas264', '8000')
        urlsec = 'https://%s:%s' % ('pcatlas264', '8443')

        self.client = DQClient(url, urlsec)


    def tearDown(self):
        """
    
        @since: 0.2.0
        """
        pass


    def testHTTPRequests(self):
        """
    
        @since: 0.2.0
        """
        
        # DELETE request test (by default they are secure and is transformed into a GET)
        self.client.type = HTTP.DELETE
        self.client.request = '/test/which_method'
        self.client.params = DQClientTestCase.PARAMS_GET # you don't pass the delete param

        result = self.client.send()

        # assertion test
        self.assertEqual(result['method'], HTTP.GET) # DELETE is transformed into GET
        self.assertEqual(result['security'], 1)
        self.assertEqual(
            result['form'],
            DQClientTestCase.PARAMS_DELETE,
            """On DELETE request, parameters sent and received should be equal! [\n\t params : %s\n\tform   : %s\n]""" %
            (DQClientTestCase.PARAMS_DELETE, result['form'])
        )
        self.assertEqual(
            result['headers']['User-Agent'],
            HTTP.USER_AGENT,
            """On DELETE request, the User-Agent header should be '%s' instead of '%s'""" %
            (HTTP.USER_AGENT, result['headers']['User-Agent'])
        )


        # GET request test (by default is insecure)
        self.client.type = HTTP.GET
        self.client.request = '/test/which_method'
        self.client.params = DQClientTestCase.PARAMS_GET

        result = self.client.send()
        self.assertEqual(result['method'], HTTP.GET)
        self.assertEqual(result['security'], 0)
        self.assertEqual(result['form'], DQClientTestCase.PARAMS_GET )


        # POST request test (by default they are secure)
        self.client.type = HTTP.POST
        self.client.request = '/test/which_method'
        self.client.params = DQClientTestCase.PARAMS_POST
        
        result = self.client.send()

        self.assertEqual(result['method'], HTTP.POST)
        self.assertEqual(result['security'], 1)
        self.assertEqual(result['form'], DQClientTestCase.PARAMS_POST)


        # PUT request test (by default they are secure and is transformed into a POST)
        self.client.type = HTTP.PUT
        self.client.request = '/test/which_method'
        self.client.params = DQClientTestCase.PARAMS_POST # you don't pass the update parameter
        
        result = self.client.send()
        
        self.assertEqual(result['method'], HTTP.POST) # PUT is transformed into POST
        self.assertEqual(result['security'], 1)
        self.assertEqual(result['form'], DQClientTestCase.PARAMS_PUT, """On PUT requests, the sent and received parameters should be equal [\n\tparams : %s\n\tform   : %s\n]""" %
        (DQClientTestCase.PARAMS_PUT, result['form'])
        )


if __name__ == '__main__':
    """
    
    @since: 0.2.0
    """
    import unittest
    suite = unittest.makeSuite(DQClientTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
