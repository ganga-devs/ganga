"""
@author: 
@contact: 
@since: 0.3.0
@version: $Id: DQClientException.py,v 1.1.1.1.2.4 2007/10/18 14:39:39 psalgado Exp $
"""

from dq2.common.DQException import DQCurlError, DQException, DQFatalError


class DQInternalServerException (DQException, DQCurlError, DQFatalError):
    """
    @since: 0.2.0
    @version: $Revision: 1.1.1.1.2.4 $
    
    @ivar desc: 
    @type desc: str
    @ivar url: the url of the request.
    @type url: str
    @ivar urlsec: the url of the request.
    @type urlsec: str
    @ivar curl_error: the curl error.
    @type curl_error: str
    """


    def __init__ (self, desc, url='', urlsec='', curl_error=''):
        self.desc = desc
        self.url = url
        self.urlsec = urlsec
        self.curl_error = curl_error
        DQException.__init__(self)
    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'DQ2 internal exception [\n\n%s\n\n] [\n%s\n%s\n]\n[curl error code:%s]' % (self.desc, self.url, self.urlsec, self.curl_error)
        return '%s%s %s' % (DQCurlError.prefix, DQFatalError.prefix, message)
