"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: x509TestCase.py,v 1.2.2.3 2007/12/04 13:41:16 psalgado Exp $
"""


import commands
import os

from dq2.common.client.x509 import get_x509, get_ca_path, DEFAULT_CA_LOCATION, KEY_X509_CERT_DIR
from dq2.common.testcase.DQTestCase import DQTestCase

X509_USER_PROXY = 'X509_USER_PROXY'


class X509TestCase (DQTestCase):
    """
    X509 module test cases.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.2.2.3 $
    
    @ivar x509: is the grid certificate default location (/tmp/x509up_u<user_id>).
    @type x509: str
    @ivar fake_file: is the location of the temporary grid certificate.
    @type fake_file: str
    @ivar environment_proxy: stores the X509_USER_PROXY environment variable.
    @type environment_proxy: str
    """


    def __init__ (self, name):
        """
        @since: 0.3.0
        """
        DQTestCase.__init__(self, name)


    def _default_certificate_exists (self):
        """
        Returns True if the default grid certificate file (/tmp/x509up_u<user_id>) exists; False otherwise.
        """
        try:
            f = open(self.x509, 'r')
            f.close()
            return True
        except IOError:
            return False


    def setUp (self):
        """
        Setup the test environment.
        
        Checks if there is a file on the grid certificate default location (/tmp/x509up_u<user_id>).
        Creates a temporary copy of a grid certificate.
        Saves the user original grid certificate location pointed by X509_USER_PROXY environment variable (in case it exists).
        """
        
        
        # checking grid environment
        
        (s, o) = commands.getstatusoutput('grid-proxy-info')
        if s == 0:
            i = o.find("timeleft : ")
            timeleft = o[i:].split()[2]
        
        if s != 0 or timeleft == "0:00:00":
            """grid-proxy-info failed, or proxy expired"""
            err_msg = 'grid-proxy-info failed or proxy expired!'
            self.fail(err_msg)
        
        
        # check grid certificate default location
        
        self.x509 = '/tmp/x509up_u%s' % os.getuid()
        
        
        # saving environment variables
        
        if os.environ.has_key(X509_USER_PROXY):
            """
            save the X509_USER_PROXY environment variable
            copy the certificate into the default location
            """
            self.environment_proxy = os.environ[X509_USER_PROXY]
            if not self.environment_proxy == self.x509:
                os.system('cp %s %s' % (self.environment_proxy, self.x509))
        else:
            self.environment_proxy = None
        
        
        if not self._default_certificate_exists():
            err_msg = '%s file does not exist!' % (self.x509)
            self.fail(err_msg)
        
        
        # create a temporary copy of a grid certificate
        
        self.fake_file = '/tmp/nonsense_file'
        os.system('cp %s %s' % (self.x509, self.fake_file))


    def tearDown (self):
        """
        Clean up the test environment.
        
        Deletes the temporary copy of a grid certificate.
        """
        # remove the grid certificate temporary copy
        os.system('rm %s' % (self.fake_file))
        if self.environment_proxy is not None:
            os.environ[X509_USER_PROXY] = self.environment_proxy
        else:
            try:
                del os.environ[X509_USER_PROXY]
            except: pass


    def testCACertificateLocation (self):
        """
        Test if the grid  CA certificate default location (/etc/grid-security/certificates) is returned.
        
        1. default location for CA certificates is correct?
        """
        tmp = None
        
        try:
            tmp = os.environ[KEY_X509_CERT_DIR]
            del os.environ[KEY_X509_CERT_DIR] # delete this entry to force the retrieval of the default grid certificates location
        except: pass
        
        # 1. default location for CA certificates is correct?
        message = '1. default location for CA certificates is correct?'
        
        if os.environ.has_key(KEY_X509_CERT_DIR):
            result = get_ca_path()
            expected = os.environ[KEY_X509_CERT_DIR]
        else:
            result = get_ca_path()
            expected = DEFAULT_CA_LOCATION
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        if tmp is not None:
            os.environ[KEY_X509_CERT_DIR] = tmp


    def testDefaultCertificateLocation (self):
        """
        Test if the grid certificate default location (/tmp/x509up_u<user_id>) is returned.
        """
        try:
            del os.environ[X509_USER_PROXY] # delete this entry to force the retrieval of the default grid certificate location
        except: pass
        
        
        # 1.
        message = '/tmp/x509up_u<user_id> grid certificate was not returned by x509 module.'
        
        result = get_x509()
        expected = self.x509
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))


    def testEnvironmentCertificateLocation (self):
        """
        Test if the grid certificate pointed by the user X509_USER_PROXY environment variable is returned.
        """
        
        os.environ[X509_USER_PROXY] = self.fake_file
        
        # 1.
        message = 'the grid certificate pointed by the user environment variable X509_USER_PROXY was not returned by x509 module.'
        
        result = get_x509()
        expected = self.fake_file
        
        self.assertEqual(expected, result, self._fmt_message(message, expected, result))
        
        os.environ[X509_USER_PROXY] = self.environment_proxy


if __name__ == '__main__':
    """
    @since: 0.2.0
    """
    import unittest
    unittest.main()
    suite = unittest.makeSuite(X509TestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)
