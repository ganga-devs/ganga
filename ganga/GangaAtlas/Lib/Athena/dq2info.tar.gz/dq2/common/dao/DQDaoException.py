"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: DQDaoException.py,v 1.14 2008/02/08 15:25:28 psalgado Exp $
"""


from dq2.common.DQException import DQException, DQFatalError


class DQDaoException (DQException, DQFatalError):
    """
    DQException class for the cases when a database or catalog error occurs.
    
    @since: 0.2.0
    
    @deprecated: moved into dq2.common.dao.exceptions
    """
    
    def __init__ (self, desc, root_cause=None):
        """
        
        @since: 0.2.0
        """
        self.desc = desc
        DQException.__init__(self, root_cause=root_cause)
    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        root_error = ''
        if self.root_cause is not None:
            root_error = "\n\t%s""" % (str(self.root_cause))
        return "\t%s%s" % (self.desc, root_error)


class DQDatabaseConnectionException (DQDaoException):
    """
    @since: 0.3.0
    """
    
    def __init__ (self, user, db, host, root_cause=None):
        """
        
        @since: 0.3.0
        """
        self.user = user
        self.db = db
        self.host = host
        err_msg = """
    Error establishing central catalogs database connection.
    Possible causes:
    - database server is down
    - database misconfiguration [%s@%s::%s]
        """ % (self.user, self.host, self.db)
        DQDaoException.__init__(self, err_msg, root_cause=root_cause)


class DQMySQLException (DQDaoException):
    """
    Class to wrap cx_Oracle exceptions.
    
    @since: 0.3.0
    """


    def __init__ (self, desc, root_cause=None):
        self.err_code = int(root_cause[0])
        self.err_msg = root_cause[1]
        DQDaoException.__init__(self, desc, root_cause=root_cause)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.3.0
        
        @return the exception error message.
            example:
            dq2.common.dao.DQDaoException.DQMySQLException:
                    Unable to connect to the database
                    [ORA-12162] TNS:net service name is incorrectly specified
                    http://ora-12162.ora-code.com/
        """
        return """\n\t[%s] %s""" % (self.err_code, self.err_msg)


    def isErrorCode (self, code):
        """
        @since: 0.3.0
        """
        if code == self.err_code:
            return True
        return False


class DQOracleException (DQDaoException):
    """
    Class to wrap cx_Oracle exceptions.
    
    @since: 0.3.0
    """


    def __init__ (self, desc, root_cause=None):
        """
        Constructs a DQOracleException instance.
        
        @since: 0.3.0
        """
        self.ora_code = str(root_cause)[0:9].upper()
        
        if not self.ora_code[0:3] == 'ORA':
            self.ora_code = None
        
        if root_cause is not None:
            self.ora_error = str(root_cause)[11:]
        else:
            self.ora_error = ''
        
        if self.ora_code is not None:
            self.help = "http://%.9s.ora-code.com/" % (self.ora_code.lower())
        else:
            self.help = ''
        
        # WARNING:
        # don't pass root_cause to super class
        # or else it will break the client [unpickle of _Error objects]
        DQDaoException.__init__(self, desc)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.3.0
        
        @return the exception error message.
            example:
            dq2.common.dao.DQDaoException.DQOracleException:
                    Unable to connect to the database
                    [ORA-12162] TNS:net service name is incorrectly specified
                    http://ora-12162.ora-code.com/
        """
        return '\n\t%s\n\t[%s] %s\t%s' % (self.desc, self.ora_code, self.ora_error, self.help)


    def isErrorCode(self, code):
        """
        @since: 0.3.0
        """
        if code == self.ora_code:
            return True
        return False


class DQPostGreSQLException (DQDaoException):
    """
    Class to wrap PostGreSQL exceptions.
    
    @since: 0.3.0
    """


    def __init__ (self, desc, root_cause=None):
        self.err_code = int(root_cause[0])
        self.err_msg = root_cause[1]
        DQDaoException.__init__(self, desc, root_cause=root_cause)


    def __str__ (self):
        """
        Returns a string representation of this object.
        
        @since: 0.3.0
        
        @return the exception error message.
            example:
            dq2.common.dao.DQDaoException.DQPostGreSQLException:
                    Unable to connect to the database
                    [ORA-12162] TNS:net service name is incorrectly specified
                    http://ora-12162.ora-code.com/
        """
        return """\n\t[%s] %s""" % (self.err_code, self.err_msg)


    def isErrorCode (self, code):
        """
        @since: 0.3.0
        """
        if code == self.err_code:
            return True
        return False

