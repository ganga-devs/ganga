"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2.0
@version: $Id: DQDbDao.py,v 1.10 2007/12/14 10:31:07 psalgado Exp $
"""


from dq2.common.dao.DQDao import DQDao

from dq2.common.dao.DQDaoException import DQDaoException


class DQDbDao (DQDao):
    """
    Base DQ database implementaton DAO.

    Each catalog class should define the following class static attributes:
    - CATALOG_IMPLEMENTATION
    - CATALOG_NAME
    
    @since: 0.2.0
    @version: $Revision: 1.10 $
    """


    def __init__ (self):
        pass


    def __del__ (self):
        """
        Closes the database connection in case it exists.
        
        @since: 0.2.8
        """
        if not self.connection is None:
            self.endTransaction()


    def __enter__ (self):
        """
        @since: 1.0
        """
        self.startTransaction()
        return self.connection.cursor()


    def __exit__ (self, type, value, tb):
        """
        @since: 1.0
        """
        try:
            if tb is None:
                """no exception, so commit"""
                self.commitTransaction()
            else:
                """exception occurred, so rollback"""
                self.rollbackTransaction()
        finally:
            """always close transaction to release connection into pool"""
            self.endTransaction()


    def __str__ (self):
        """
        @since: 0.2
        """
        return """%s [%s] [%s]""" % (
            self.CATALOG_NAME, self.DAO_IMPL, self.CATALOG_IMPLEMENTATION)


# PROTECTED METHODS


    def _date (self, value):
        """
        Stub method that should be implemented by its subclasses.
        
        @since: 0.3.0
        """
        pass


    def _escape (self, value):
        """
        Stub method that should be implemented by its subclasses.
        
        @since: 0.2.0
        """
        pass


    def _exec (self, sql):
        """
        Executes the given SQL query and returns a cursor.
        
        @since: 0.2.0
        
        @param sql: the SQL query.
        """
        cursor = self.connection.cursor()
        cursor.execute(sql)
        return cursor


    def _execute (self, sql):
        """
        Executes the given SQL query and returns a cursor.
        
        @since: 0.2.0
        
        @param sql: the SQL query.
        """
        return self._exec(sql)


    def _execute_and_close (self, sql):
        """
        Executes the given SQL query and returns a cursor.
        
        @since: 0.2.0
        
        @param sql: the SQL query.
        """
        cursor = self._exec(sql)
        cursor.close()


    def _getDatabaseConnection (self):
        """
        Returns the database connection to be used by this DAO.
        
        @since: 0.2.0
        """
        pass


    # PUBLIC METHODS


    def commitTransaction (self):
        """
        Commits the changes done on the transaction.
        
        @since: 0.2.0
        
        B{Exceptions:}
            - DQOracleException is raised,
                in case the transaction was not committed.
        """
        pass


    def endTransaction (self):
        """
        Ends the database transaction (closes the connection) without committing any changes.
        
        @since: 0.2.0
        """
        pass


    def getInfo (self):
        """
        @since: 0.3.0
        """
        return (self.DAO_IMPL, self.CATALOG_IMPLEMENTATION, self.CATALOG_NAME)


    def rollbackTransaction (self):
        """
        Rollsback the changes done on the database transaction.
        
        @since: 0.2.0
        
        B{Exceptions:}
            - DQDaoException is raised,
                in case the transaction was not committed.
        """
        pass


    def startTransaction (self):
        """
        Starts a new database transaction (it will close a previous transaction).
        
        @since: 0.3.0
        """
        pass


    def status (self):
        """
        Checks if the DAO can connect to the database.
        
        @since: 0.2.0
        
        @return: True if the connection to the database was successfull; False otherwise.
        """
        
        try:
            self.connection = self._getDatabaseConnection()
            self.connection.close()
            self.connection = None
            return True
        
        except StandardError, e:
            return False
