"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.2
@version: $Id: __init__.py,v 1.11.2.2 2010/02/02 12:18:40 vgaronne Exp $
"""


__package__ = __name__
__version__ = '$Name: dq2-common-dao-1-1-2 $'


from dq2.common.Config import Config
from dq2.common.log import DQLog
LOG = DQLog(__name__)
LOGGER = LOG
READER = 0
WRITER = 1


def get_dao_implementation (package, mypath=None):
    """
    @since: 0.3.0
    
    @param package: name of the package configuration.
    @type package: str
    @param mypath: .
    @type mypath: str
    """
    return Config().getConfig(package, mypath=mypath).get(package, 'impl')


def get_pool_reader (package, mypath=None):
    """
    
    @since: 1.0
    
    @param package: name of the package configuration.
    @type package: str
    @param mypath: .
    @type mypath: str
    """
    
    try:
        """try to get configuration for the reader pool"""
        return Config().getConfig(package, mypath=mypath).get(package, 'pool_reader')
    except:
        pass
    
    return None


def get_pool_writer (package, mypath=None):
    """
    
    @since: 1.0
    
    @param package: name of the package configuration.
    @type package: str
    @param mypath: .
    @type mypath: str
    """
    
    try:
        """try to get configuration for the writer pool"""
        return Config().getConfig(package, mypath=mypath).get(package, 'pool_writer')
    except:
        pass
    
    return None


def get_table_prefix (package, mypath=None):
    """
    
    @since: 0.3.0
    
    @param package: name of the package configuration.
    @type package: str
    @param mypath: .
    @type mypath: str
    """
    
    try:
        """try to retrieve if there is a configuration for the given table"""
        return Config().getConfig(package, mypath=mypath).get(package, 'table_prefix')
    except:
        pass
    
    return None


def get_table_suffix (package, mypath=None):
    """
    
    @since: 0.3.0
    
    @param package: name of the package configuration.
    @type package: str
    @param mypath: .
    @type mypath: str
    """
    
    try:
        """try to retrieve if there is a configuration for the given table"""
        return Config().getConfig(package, mypath=mypath).get(package, 'table_suffix')
    except:
        pass
    
    return None