"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2.0
@version: $Id: DQDao.py,v 1.3 2007/10/22 13:53:15 psalgado Exp $
"""


class DQDao (object):
    """
    Base DQ data access object (DAO).
    
    @since: 0.2.0
    """


    def commitTransaction (self):
        """
        Commits a transaction.
        
        @since: 0.2.0
        """
        return


    def endTransaction (self):
        """
        Ends a transaction (without committing or rollingback).
        
        @since: 0.2.0
        """
        return


    def rollbackTransaction (self):
        """
        Rollsback a transaction.
        
        @since: 0.2.0
        """
        return


    def startTransaction (self):
        """
        Starts a transaction.
        
        @since: 0.2.0
        """
        return