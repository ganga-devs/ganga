"""
Logger aspect module for DQ2 DAO components.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.1
@version: $Id: logger.py,v 1.8 2008/06/02 07:35:35 psalgado Exp $
"""


from dq2.common.log import DQLog


LOG = DQLog('dq2.common.dao')