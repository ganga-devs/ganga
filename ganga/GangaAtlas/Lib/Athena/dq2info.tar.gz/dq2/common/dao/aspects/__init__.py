"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.2
@version: $Id: __init__.py,v 1.4 2007/11/23 16:33:50 psalgado Exp $
"""