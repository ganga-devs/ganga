"""

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@version: $Id: DQFactory.py,v 1.13 2008/02/11 14:40:53 psalgado Exp $
@since: 0.2

@var DEFAULT_MAX_RETRIES: the default maximum number of retries to get a connection from pool.
@type DEFAULT_MAX_RETRIES: int
@var DEFAULT_SLEEP: default time between retries.
@type DEFAULT_SLEEP: int
"""


from dq2.common.Config import Config

from dq2.common.dao.DQDaoException import DQDaoException


class DQFactory (object):
    """
    Class to provide generic constants and methods for the DQ catalog factories.
    
    @since: 0.2.0
    
    @deprecated: this class will be removed on the next version.
    
    @cvar CATALOG_MYSQL:the name to used to create MySQL catalogs.
    @cvar CATALOG_MOCK: the name to used to create mock-up catalogs.
    @cvar CATALOG_ORACLE: the name to used to create Oracle catalogs.
    @cvar CATALOGS: is a list containing all possible catalog implementations.

    @warning: all DQ catalog factories should extend this class.
    
    @todo: move some of these to separate LRC subclass)
    """
    CATALOG_MYSQL = "mysql"
    CATALOG_MOCK = "mock"
    CATALOG_ORACLE = "oracle"
    
    CATALOGS = [CATALOG_MYSQL, CATALOG_MOCK, CATALOG_ORACLE]
