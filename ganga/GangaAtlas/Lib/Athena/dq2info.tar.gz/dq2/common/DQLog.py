"""
@deprecated: moved into dq2.common.cli.
"""


from dq2.common import log as logging


#LOGGER = logging.getLogger(__name__)
#LOGGER.warning('application is using a deprecated module: dq2.common.DQLog!')


from dq2.common.log import DQLog