"""
Package for DQ2 repository catalog.

@author: David Cameron
@contact: david.cameron@cern.ch
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.1
@version: $Id: __init__.py,v 1.1 2008/05/30 13:00:22 psalgado Exp $

@var API_030: the string identifier for the 0.3.0 API.
@type API_030: str
"""

API_030 = '0_3_0'