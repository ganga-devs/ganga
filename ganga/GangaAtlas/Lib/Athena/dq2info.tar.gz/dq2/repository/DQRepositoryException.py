"""
@author: Miguel Branco
@contact: miguel.branco@cern.ch
@since: 0.3.0
@version: $Id: DQRepositoryException.py,v 1.1 2008/05/30 13:00:22 psalgado Exp $
"""

from dq2.common.DQException import DQException, DQFatalError, DQNonFatalError, DQSecurityException, DQUserError


class DQDatasetExistsException (DQException, DQUserError, DQNonFatalError):
    """
    DQException class for the cases when a unexpected dataset is found.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dsn, root_cause=None):
        """
        @since: 0.2.0
        
        @param dsn: dataset name.
        @type dsn: str
        @param root_cause: is the original error/exception.
        @type root_cause: object
        """
        self.dsn = dsn
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'The dataset %s already exists!' % self.dsn
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQDatasetOwnershipException (DQSecurityException, DQUserError, DQFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dataset, owner):
        self.dataset = dataset
        self.owner = owner
        err_msg = 'User %s is not the owner of dataset %s' % (self.owner, self.dataset)
        DQSecurityException.__init__(self, err_msg)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'User %s is not the owner of dataset %s' % (self.owner, self.dataset)
        return '%s%s %s' % (DQUserError.prefix, DQFatalError.prefix, message)


class DQUnknownDatasetException (DQException, DQUserError, DQNonFatalError):
    """
    DQException class for the cases when a expected dataset isn't found.
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dsn=None, vuid=None, duid=None, root_cause=None):
        """
        
        
        @since: 0.2.0
        
        @param dsn: dataset name.
        @param vuid: is the dataset version unique identifier.
        @param duid: is the dataset unique identifier.
        """
        self.dsn = dsn
        self.vuid = vuid
        self.duid = duid
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        astr = '('
        if self.dsn is not None: astr += "dataset='%s', " % self.dsn
        if self.vuid is not None: astr += "vuid='%s', " % self.vuid
        if self.duid is not None: astr += "duid='%s', " % self.duid
        astr = astr[:-2] + ")"
        message = 'Unknown dataset exception! %s' % (astr)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQUnknownDatasetVersionException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dsn, version, root_cause=None):
        """
        Construts a DQUnknowDatasetVersionException.
        
        @since: 0.2.0
        
        dsn is the dataset name.
        version is the dataset version.
        """
        self.version = version
        self.dsn = dsn
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'Unknown dataset %s version number %s.' % (self.dsn, self.version)
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQClosedDatasetException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dataset, root_cause=None):
        """
        @since: 0.2.0
        """
        self.dataset = dataset
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'The dataset %s is already closed!' % self.dataset
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQFrozenDatasetException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dataset, root_cause=None):
        """
        @since: 0.2.0
        """
        self.dataset = dataset
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'The dataset %s is already frozen!' % self.dataset
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQDeletedDatasetException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dataset, root_cause=None):
        """
        @since: 0.2.0
        """
        self.dataset = dataset
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
    
        @since: 0.2.0
        """
        message = 'The dataset %s is already deleted!' % self.dataset
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)


class DQOpenedDatasetException (DQException, DQUserError, DQNonFatalError):
    """
    
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.2.0
    @version: $Revision: 1.1 $
    """
    def __init__ (self, dataset, root_cause=None):
        """
        
        @since: 0.2.0
        """
        self.dataset = dataset
        DQException.__init__(self, root_cause=root_cause)
    def __str__(self):
        """
        Returns a string representation of this object.
        
        @since: 0.2.0
        """
        message = 'The dataset %s is already open!' % self.dataset
        return '%s%s %s' % (DQUserError.prefix, DQNonFatalError.prefix, message)