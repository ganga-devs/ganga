"""
Repository client aspects.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: validation.py,v 1.7.2.2 2007/09/24 11:17:02 psalgado Exp $
"""

from dq2.common.aspects import wrap_around

from dq2.repository.aspects.validation import *
from dq2.repository.client.RepositoryClient import RepositoryClient


def wrap_package ():
    """
    Loads the validation aspect for the repository client.
    
    @since: 0.3.0
    """
    
    wrap_around (RepositoryClient.addDataset, addDataset)
    
    wrap_around (RepositoryClient.getMetaDataAttribute, getMetaDataAttribute)
    wrap_around (RepositoryClient.getState, getState)
    
    wrap_around (RepositoryClient.queryDatasetByClosedDate, queryDatasetByClosedDate)
    wrap_around (RepositoryClient.queryDatasetByCreationDate, queryDatasetByCreationDate)
    wrap_around (RepositoryClient.queryDatasetByFrozenDate, queryDatasetByFrozenDate)
    wrap_around (RepositoryClient.queryDatasetByMetaData, queryDatasetByMetaData)
    wrap_around (RepositoryClient.queryDatasetByName, queryDatasetByName)
    wrap_around (RepositoryClient.queryDatasetByUID, queryDatasetByUID)
    wrap_around (RepositoryClient.queryDatasetByDUIDs, queryDatasetByDUIDs)
    
    wrap_around (RepositoryClient.resolveName, resolveName)
    wrap_around (RepositoryClient.resolveVUID, resolveVUID)
    
    wrap_around (RepositoryClient.setMetaDataAttribute, setMetaDataAttribute)
    wrap_around (RepositoryClient.setState, setState)
    
    wrap_around (RepositoryClient.trashDataset, trashDataset)
    
    wrap_around (RepositoryClient.updateVersion, updateVersion)
