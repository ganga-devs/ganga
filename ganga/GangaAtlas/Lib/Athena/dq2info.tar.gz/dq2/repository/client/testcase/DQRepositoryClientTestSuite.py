"""
DQ2 Repository catalog test suite for Oracle implementation.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: DQRepositoryClientTestSuite.py,v 1.1.2.6.2.2 2008/06/17 20:28:13 psalgado Exp $
"""

import unittest


from dq2.common.client.testcase.DQClientTestSuite import DQClientTestSuite
from dq2.common.constants import API_030

from dq2.repository.client.RepositoryClient import RepositoryClient
from dq2.repository.client.testcase.DQRepositoryClientTestCase import DQRepositoryClientTestCase
from dq2.repository.testcase.DQQueryDatasetByMetadata import DQQueryDatasetByMetadata
from dq2.repository.testcase.DQResolveVUIDTestCase import DQResolveVUIDTestCase
from dq2.repository.testcase.GetMetaDataAttribute import GetMetaDataAttribute


class DQRepositoryClientTestSuite (DQClientTestSuite):
    """
    @author: Pedro Salgado
    @contact: pedro.salgado@cern.ch
    @since: 0.3.0
    @version: $Revision: 1.1.2.6.2.2 $
    """


    def __init__ (self, specificTest=None):
        """
        @since: 0.3.0
        """
        print RepositoryClient()
        super(DQRepositoryClientTestSuite, self).__init__(
            RepositoryClient(),
            [
                DQQueryDatasetByMetadata,
                DQRepositoryClientTestCase,
                DQResolveVUIDTestCase,
                GetMetaDataAttribute
            ],
            specificTest=specificTest
        )


if __name__ == '__main__':
    """
    Runs all tests in DQRepositoryClientTestSuite.
    
    @since: 0.1.01.0)
    """
    suite = DQRepositoryClientTestSuite()
    unittest.TextTestRunner(verbosity=2).run(suite)