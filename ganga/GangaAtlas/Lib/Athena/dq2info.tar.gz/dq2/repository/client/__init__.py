"""
Load aspects for dq2.repository.client package.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3.0
@version: $Id: __init__.py,v 1.3.2.3.2.1 2008/06/17 14:30:21 psalgado Exp $

@warning: order is important!
"""

__version__ = '$Name: dq2-repository-client-0-3-8 $'

PACKAGE = 'dq2-repository-client'


from dq2.repository.client.aspects.transaction import wrap_package
wrap_package()

from dq2.repository.client.aspects.validation import wrap_package
wrap_package()