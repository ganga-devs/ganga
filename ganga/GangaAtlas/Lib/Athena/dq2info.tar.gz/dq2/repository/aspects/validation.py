"""
Repository validation aspect.

@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: validation.py,v 1.2.2.2 2010/01/22 09:48:40 vgaronne Exp $
"""

from dq2.common.DQException import DQInvalidRequestException
from dq2.common.validator.DQValidator import *

from dq2.info.TiersOfATLASValidator import *


def addDataset (self, dsn, duid, vuid, owner=None, cooldown=None):
    """
    @since: 0.3.0
    """
    is_dataset_name([dsn])
    is_uid([duid])
    is_uid([vuid])
    
    if owner:    is_owner([owner])
    if cooldown: is_timedelta([cooldown])
    
    return self.__proceed(dsn, duid, vuid, owner, cooldown)


def getMetaDataAttribute (self, dsn, attributes, version=0):
    """
    @since: 0.3.0
    """
    
    is_dataset_or_container_name([dsn])
    is_metadata_attribute(attributes)
    is_integer([version])
    
    if version < 0:
        version = 0
    
    return self.__proceed(dsn, attributes, version)


def getState (self, dsn):
    """
    @since: 0.3.0
    """
    is_dataset_or_container_name([dsn])
    
    return self.__proceed(dsn)


def hasPermission (self, owner, role, dsn=None, vuid=None):
    """
    @since: 0.3.0
    """
    
    is_owner([owner])
    if dsn is None and vuid is None: raise DQInvalidRequestException('Dataset name or version needs to be provided!')
    if dsn is not None: is_dataset_or_container_name([dsn])
    if vuid is not None: is_uid([vuid])

    return self.__proceed(owner, role, dsn, vuid)


def queryDatasetByClosedDate (self, seconds, criteria, dsn=None):
    """
    @since: 0.3.0
    """
    is_integer([seconds])
    is_date_criteria([criteria])
    if dsn is not None:
        is_dataset_or_container_name([dsn])
    
    return self.__proceed(seconds, criteria, dsn)


def queryDatasetByCreationDate (self, seconds, criteria, dsn=None):
    """
    @since: 0.3.0
    """
    is_integer([seconds])
    is_date_criteria([criteria])
    if dsn is not None:
        is_dataset_or_container_name([dsn])
    
    return self.__proceed(seconds, criteria, dsn)


def queryDatasetByFrozenDate (self, seconds, criteria, dsn=None):
    """
    @since: 0.3.0
    """
    is_integer([seconds])
    is_date_criteria([criteria])
    if dsn is not None:
        is_dataset_name([dsn])
    
    return self.__proceed(seconds, criteria, dsn)


def queryDatasetByMetaData (self, filterBy):
    """
    @since: 0.3.0
    """
    is_dictionary([filterBy])
    
    for eachAttribute in filterBy.keys():
        is_metadata_attribute([eachAttribute])
    
    return self.__proceed(filterBy)


def queryDatasetByName (self, dsn, version=0, onlyNames=False, p=None, rpp=None):
    """
    @since: 0.3.0
    """
    is_dataset_or_container_name([dsn])
    if version is not None: is_integer([version])
    if rpp is not None:     is_integer([rpp])    
    if p is not None:       is_integer([p])

        
    if version is not None and version < 0:
        version = 0
    
    return self.__proceed(dsn, version, onlyNames, p, rpp)


def queryDatasetByDUIDs (self, uids):
    """
    @since: 0.3.0
    """
    is_uid(uids)

    return self.__proceed(uids)


def queryDatasetByVUIDs (self, vuids):
    """
    @since: 0.3.0
    """
    is_uid(vuids)
    
    return self.__proceed(vuids)


def queryDatasetByUID (self, uid):
    """
    @since: 0.3.0
    """
    is_uid([uid])
    
    return self.__proceed(uid)


def resolveName (self, dsn):
    """
    @since: 0.3.0
    """
    is_dataset_or_container_name([dsn])
    
    return self.__proceed(dsn)


def resolveVUID (self, vuid):
    """
    @since: 0.3.0
    """
    is_uid([vuid])
    
    return self.__proceed(vuid)


def rest (self, closeddatemax=None, closeddatemin=None, creationdatemax=None, creationdatemin=None, duid=None, frozendatemax=None, frozendatemin=None, name=None, owner=None, state=None, vuid=None):
    """
    @since: 0.3.0
    """
    
    #if closeddatemax is not None: is_date(closeddatemax)
    #if closeddatemin is not None: is_date(closeddatemin)
    #if creationdatemax is not None: is_date(creationdatemax)
    #if creationdatemin is not None: is_date(creationdatemin)
    if duid is not None: is_uid([duid])
    #if frozendatemax is not None: (frozendatemax)
    #if frozendatemin is not None: (frozendatemin)
    if name is not None: is_dataset_or_container_name([name])
    if owner is not None: is_owner([owner])
    if state is not None: is_dataset_state([state])
    if vuid is not None: is_uid([vuid])
    
    return self.__proceed(closeddatemax, closeddatemin, creationdatemax, creationdatemin, duid, frozendatemax, frozendatemin, name, owner, state, vuid)


def setMetaDataAttribute (self, dsn, attrname, attrvalue, owner=None, role=None):
    """
    @since: 0.3.0
    """
    is_dataset_or_container_name([dsn])
    is_string([attrname])
    if not attrname.lower() == 'owner':
        is_metadata_attribute([attrname])
    if attrname.lower() == 'origin':
        is_destination(attrvalue) 
    
    if owner is not None: is_owner([owner])
    
    return self.__proceed(dsn, attrname, attrvalue, owner, role)


def setState (self, dsn, state, owner=None, role=None, ip=None):
    """
    @since: 0.3.0
    """
    is_dataset_or_container_name([dsn])
    is_dataset_state([state])
    
    # client-side always has a owner == None
    if owner is not None: is_owner([owner])
    
    return self.__proceed(dsn, state, owner, role, ip)


def trashDataset (self, dsn):
    """
    @since: 0.3.0
    """
    is_dataset_name([dsn])
    
    return self.__proceed(dsn)


def updateVersion (self, dsn, vuid, owner=None, role=None):
    """
    @since: 0.3.0
    """
    is_dataset_name([dsn])
    is_uid([vuid])
    
    if owner is not None: is_owner([owner])
    
    return self.__proceed(dsn, vuid, owner, role)