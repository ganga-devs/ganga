"""
@author: Pedro Salgado
@contact: pedro.salgado@cern.ch
@since: 0.3
@version: $Id: __init__.py,v 1.1 2008/05/30 13:00:23 psalgado Exp $
"""